---
applyTo: "**/*.cs"
---

-   Always use C# 12 primary constructors when defining classes.
-   Format primary constructor parameters with **one parameter per line** and place opening and closing parentheses on their own lines.
-   Place the colon that introduces base classes or interfaces after primary constructor on its own line and indented.
-   Prefer `file-scoped namespaces`.
-   Use `var` for local variables unless explicit typing adds clarity.
-   Always use braces `{ }` for `if`, even for single-line statements.
-   Write all comments and documentation in English.
-   Replace calls to `Any()` with the collection's `Length`, `Count`, or `IsEmpty` property when checking for emptiness.
-   Always use `LF` (line feed) as line endings.
