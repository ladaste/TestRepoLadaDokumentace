# Code Review – Current Branch vs Develop

Perform a complete, professional code review of the **current Git branch**, comparing it against the **develop** branch.

**🔶 All output must ALWAYS be written in Czech. However, ALL code, code comments, identifiers, patches, and diff blocks MUST remain in English.**

## Compare Against

- Base branch: `develop`
- Review branch: _current checked-out branch_

## Important Formatting Rules

- **Every filename must ALWAYS be a clickable link** in format:  
  `[FileName.ext](relative/path/to/FileName.ext)`
- If referencing specific lines, use:  
  `[FileName.ext:123](relative/path/to/FileName.ext)`
- Use Markdown diff blocks for suggested patches:
  ```diff
  - old line
  + new line
  ```

## Review Scope

Evaluate all changes in:

- modified files
- added files
- deleted files
- renamed files
- configuration & infrastructure changes
- API changes (DTOs, controllers, contracts)
- domain model modifications
- tests

## Output Format

Provide a structured, high-clarity review with the following sections (in this order):

---

## 1. Summary of Changes

Short, factual summary of what the branch introduces or modifies.

---

## 2. High-Risk Issues (Must Fix)

List all severe problems:

- bugs
- incorrect logic
- potential null refs
- data corruption risks
- concurrency issues
- async/await misuse
- security issues
- breaking changes

For each issue include:

- filename
- line reference
- reasoning
- **proposed fix**

---

## 3. Medium-Risk Issues (Should Fix)

- code smells
- anti-patterns
- violation of clean code / SOLID
- poor naming / unclear intent
- inconsistent styles
- missing error handling
- incorrect or missing validation
- misuse of DTOs vs domain models
- performance concerns

---

## 4. Low-Risk Issues (Nice to Have)

- optimizations
- simplification
- refactoring opportunities
- readability improvements
- better async patterns
- improved LINQ usage
- smaller structural enhancements

---

## 5. Architecture & Design Observations

Comment on:

- coupling & cohesion
- boundaries between layers
- domain correctness
- cross-service/API consistency
- folder & namespace structure
- whether the change fits the architecture

---

## 6. Tests & Coverage

Check:

- missing tests
- incorrect or weak assertions
- coverage gaps
- edge cases not covered
- integration test impacts
- mocking correctness

Suggest new test cases if needed.

---

## 7. Suggested Improvements (with Patches)

For each improvement:

- provide exact code patch (`diff` block)
- explain why the change is beneficial
- link to affected file(s)

---

## 8. Final Verdict

Provide a short, assertive conclusion:

- **Approve**
- **Approve with minor fixes**
- **Request changes**
- **Strongly request changes**

Justify the result clearly.

---

## Important Notes

- Always base diff on `develop`.
- Resolve ambiguity by analyzing context of nearby files.
- Be strict and professional: this is a senior-level review.
- If something seems unclear, note it explicitly.
- If code suggests a potential bug, call it out.
