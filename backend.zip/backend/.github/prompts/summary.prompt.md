# Copilot Prompt – Conversation Context Summary

**🔶 All output must ALWAYS be written in Czech. However, ALL code, code comments, identifiers, patches, and diff blocks MUST remain in English.**

Please summarize the entire conversation context so far clearly and concisely, so I can transfer it into a new chat.

Divide the summary into the following sections:

- 🧭 Project Context – what the project is about and what its purpose is.
- ⚙️ Technical State of the Project – the current technology stack, what is already done, and how the structure and configuration look.
- 🎯 Current Phase / Goal – what we were working on or what the next planned step was.
- 💬 Notes for Continuation – conventions, agreements, and details that should remain preserved in the new chat.
