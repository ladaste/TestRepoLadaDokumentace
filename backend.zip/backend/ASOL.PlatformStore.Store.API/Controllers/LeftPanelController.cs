using System;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.ApiController;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.PlatformStore.Store.Contracts.LeftPanels;
using ASOL.PlatformStore.Store.Facades;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

#nullable enable

namespace ASOL.PlatformStore.Store.API.Controllers;

[ApiConventionType(typeof(DefaultApiConventions))]
[Route("api/v{version:apiVersion}/[controller]")]
[Produces(MediaTypeNames.Application.Json)]
[Consumes(MediaTypeNames.Application.Json)]
public class LeftPanelController
(
    ILeftPanelFacade leftPanelFacade,
    ILogger<LeftPanelController> logger
)
    : AuthorizeControllerBase(logger)
{
    private readonly ILeftPanelFacade _leftPanelFacade = leftPanelFacade
            ?? throw new ArgumentNullException(nameof(leftPanelFacade));

    [HttpGet]
    [ProducesResponseType(typeof(LeftPanelModel), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> GetPanel(
        [FromQuery] PagingFilter? pagination,
        CancellationToken cancellationToken)
    {
        var panel = await _leftPanelFacade.GetPanelAsync(
            pagination,
            pagination,
            cancellationToken);
        return Ok(panel);
    }

    [HttpGet]
    [Route("AllApplications")]
    [ProducesResponseType(typeof(CollectionResult<PanelItemModel>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> GetAllApplicationsPart(
        [FromQuery] PagingFilter? pagination,
        CancellationToken cancellationToken)
    {
        var items = await _leftPanelFacade.GetAllApplicationsItemsAsync(pagination,
            cancellationToken);
        return Ok(items);
    }

    [HttpGet]
    [Route("QuickAccess")]
    [ProducesResponseType(typeof(CollectionResult<PanelItemModel>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> GetQuickAccessPart(
        [FromQuery] PagingFilter? pagination,
        CancellationToken cancellationToken)
    {
        var items = await _leftPanelFacade.GetQuickAccessItemsAsync(pagination,
            cancellationToken);
        return Ok(items);
    }

    [HttpPost]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> UpdatePanel(
        [FromBody] UpdatePanelRequestModel request,
        CancellationToken cancellationToken)
    {
        await _leftPanelFacade.UpdatePanelAsync(request, cancellationToken);
        return Ok();
    }
}
