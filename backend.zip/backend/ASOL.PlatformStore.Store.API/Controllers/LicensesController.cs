using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.ApiController;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.PlatformStore.Store.API.Validation;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Contracts.Filters;
using ASOL.PlatformStore.Store.Contracts.Subscription;
using ASOL.PlatformStore.Store.Infrastructure.SubscriptionRoot.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.API.Controllers;

[ApiController]
[ApiConventionType(typeof(DefaultApiConventions))]
[Route("api/v{version:apiVersion}/[controller]")]
[Produces(MediaTypeNames.Application.Json)]
[Consumes(MediaTypeNames.Application.Json)]
public class LicensesController
(
    ILogger<LicensesController> logger,
    SubscriptionLicenseService subscriptionLicenseService
)
    : AuthorizeControllerBase(logger)
{
    /// <summary>
    /// Returns a paged list of licenses across all subscriptions.
    /// <para/>
    /// Route: GET /api/v{version}/Licenses
    /// </summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CollectionResult<SubscriptionLicenseModel>))]
    public async Task<IActionResult> GetList(
        [FromQuery] LicenseFilter licenseFilter,
        [FromQuery] PagingFilter pagingFilter,
        CancellationToken ct)
    {
        var result = await subscriptionLicenseService.GetListAsync(
            licenseFilter,
            pagingFilter,
            ct
        );

        return Ok(result);
    }

    /// <summary>
    /// Returns license details by licenseId (no subscriptionId required).
    /// <para/>
    /// Route: GET /api/v{version}/Licenses/{licenseId}
    /// </summary>
    [HttpGet("{licenseId}")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(SubscriptionLicenseModel))]
    public async Task<IActionResult> GetById(
        [FromRoute, NotEmptyOrWhiteSpace] string licenseId,
        CancellationToken ct)
    {
        var result = await subscriptionLicenseService.GetAsync(
            licenseId,
            ct
        );

        return result is null ? NotFound() : Ok(result);
    }

    /// <summary>
    /// Replaces an existing license (global scope, no subscriptionId required).
    /// <para/>
    /// Route: PUT /api/v{version}/Licenses/{licenseId}
    /// </summary>
    [HttpPut("{licenseId}")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(SubscriptionLicenseModel))]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(
        [FromRoute, NotEmptyOrWhiteSpace] string licenseId,
        [FromBody] LicenseModelUpdate model,
        CancellationToken ct)
    {
        var subscriptionLicense = await subscriptionLicenseService.GetAsync(licenseId, ct);

        await subscriptionLicenseService.UpdateAsync(
            subscriptionLicense.SubscriptionId,
            licenseId,
            model,
            ct
        );

        var result = await subscriptionLicenseService.GetAsync(
            licenseId,
            ct
        );

        return Ok(result);
    }
}
