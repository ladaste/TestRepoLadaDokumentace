using System.Net.Mime;
using System.Threading.Tasks;
using ASOL.Core.ApiController.Captcha;
using ASOL.Core.ApiController.Extensions;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Facades;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ASOL.PlatformStore.Store.API.Controllers;

/// <summary>
/// Controller for sending messages
/// </summary>
[ApiController]
[ApiConventionType(typeof(DefaultApiConventions))]
[Route("api/v{version:apiVersion}/[controller]")]
[Produces(MediaTypeNames.Application.Json)]
[Consumes(MediaTypeNames.Application.Json)]
public class MessageController
(
    IMessageFacade messageFacade,
    ICaptchaValidator captchaValidator
)
    : ControllerBase
{
    private const string CaptchaActionContactUs = "PublicContactUsValidation";
    private readonly ICaptchaValidator CaptchaValidator = captchaValidator;

    protected IMessageFacade MessageFacade { get; } = messageFacade;

    /// <summary>
    /// Sends message from authorized user
    /// </summary>
    /// <returns></returns>
    [HttpPost]
    [Authorize(AuthenticationSchemes = "Bearer")]
    public async Task<IActionResult> ContactUs([FromBody] ContactUsModel message)
    {
        await MessageFacade.ContactUsAsync(message);
        return Ok();
    }

    /// <summary>
    /// Sends message from user
    /// </summary>
    /// <returns></returns>
    [HttpPost]
    [Route("public")]
    public async Task<IActionResult> ContactUsPublic([FromBody] ContactUsPublicModel message)
    {
        // handle captcha validation include suppress validation logic for action "PublicContactUsValidation"
        if (!await CaptchaValidator.ValidateUserScoreAsync(message.Captcha, CaptchaActionContactUs))
        {
            // throw exception with Captcha validation reponse body
            return this.CaptchaError();
        }

        await MessageFacade.ContactUsPublicAsync(message);
        return Ok();
    }
}
