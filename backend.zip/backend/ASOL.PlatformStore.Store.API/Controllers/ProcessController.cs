using System;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.ApiController;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Interfaces;
using ASOL.PlatformStore.Store.Infrastructure.SubscriptionRoot.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.API.Controllers;

// TODO: this controller will be removed when the subscription import is completed.
[ApiController]
[ApiConventionType(typeof(DefaultApiConventions))]
[Route("api/v{version:apiVersion}/[controller]")]
[Produces(MediaTypeNames.Application.Json)]
[Consumes(MediaTypeNames.Application.Json)]
public class ProcessController
(
    SubscriptionImportOrchestrator subscriptionImportSubscriptionOrchestration,
    IEventFlowStorageCleaner eventFlowStorageCleaner,
    ILogger<ProcessController> logger
)
    : AuthorizeControllerBase(logger)
{
    /// <summary>
    /// Imports a subscription based on all purchased aggregated items.
    /// </summary>
    /// <param name="tenantId">Tenant Id</param>
    /// <param name="execute">If true, the import will be executed otherwise 'dry run'.</param>
    /// <param name="correlationId">Optional correlation id (X-Correlation-ID header). If not provided, a new one is generated.</param>
    /// <param name="ct"></param>
    /// <returns></returns>
    [HttpPost]
    [Route("subscriptions/import")]
    [ProducesResponseType(StatusCodes.Status202Accepted)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesDefaultResponseType]
    public async Task<IActionResult> ImportSubscription(
        [FromQuery] string tenantId,
        [FromQuery] bool execute,
        [FromHeader(Name = "X-Correlation-ID")]
        string correlationId,
        CancellationToken ct)
    {
        correlationId = !string.IsNullOrWhiteSpace(correlationId)
            ? correlationId
            : Guid.NewGuid().ToString("N");

        await subscriptionImportSubscriptionOrchestration.ScheduleImportsAsync(tenantId, execute, correlationId, ct);

        Response.Headers["X-Correlation-ID"] = correlationId;

        return Accepted(new
        {
            CorrelationId = correlationId,
            TenantId = tenantId,
            Execute = execute
        });
    }
/*
    /// <summary>
    /// Deletes read models related to the subscription.
    /// </summary>
    /// <param name="ct"></param>
    /// <returns></returns>
    [HttpPost]
    [Route("eventFlowStorageCleaner/deleteReadModels")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesDefaultResponseType]
    public async Task<IActionResult> EventFlowStorageCleanerDeleteReadModels(CancellationToken ct)
    {
        await eventFlowStorageCleaner.DeleteReadModelsAsync(ct);

        return NoContent();
    }

    /// <summary>
    /// Deletes all related data to event sourcing.
    /// </summary>
    /// <param name="ct"></param>
    /// <returns></returns>
    [HttpPost]
    [Route("eventFlowStorageCleaner/deleteEventSourcingData")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesDefaultResponseType]
    public async Task<IActionResult> EventFlowStorageCleanerDeleteEventSourcingData(CancellationToken ct)
    {
        await eventFlowStorageCleaner.DeleteEventSourcingDataAsync(ct);

        return NoContent();
    }
*/
}
