using System;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Facades;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ASOL.PlatformStore.Store.API.Controllers;

/// <summary>
/// Query controller for entities.
/// </summary>
[ApiController]
[ApiConventionType(typeof(DefaultApiConventions))]
[Route("api/v{version:apiVersion}/[controller]")]
[Produces(MediaTypeNames.Application.Json)]
[Consumes(MediaTypeNames.Application.Json)]
public class StoreController
(
    IStoreFacade storeFacade,
    ICacheFacade cacheFacade,
    IProductCatalogCodebooksFacade productCatalogCodebooksFacade
)
    : ControllerBase
{
    protected IStoreFacade StoreFacade { get; } = storeFacade;
    protected ICacheFacade CacheFacade { get; } = cacheFacade;
    protected IProductCatalogCodebooksFacade ProductCatalogCodebooksFacade { get; } = productCatalogCodebooksFacade;


    /// <summary>
    /// Gets similar applications
    /// </summary>
    /// <returns></returns>        
    [Route("similar/{sourceItemId:guid}")]
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CollectionResult<StoreItemModel>))]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetStoreItemsSimilar(string sourceItemId, [FromQuery] PagingFilter pagingFilter)
    {
        var result = await StoreFacade.GetStoreItemsSimilarAsync(sourceItemId.ToLowerInvariant(), null, pagingFilter);
        if (result == null || result.Items == null)
        {
            return Ok(new CollectionResult<StoreItemModel> { Items = [], TotalCount = 0 });
        }
        return Ok(result);
    }

    /// <summary>
    /// Search for store items based on search parameters
    /// </summary>
    /// <param name="searchParameters">Search parameters to be used for searching between store items</param>
    /// <param name="pagingFilter">Paging filter to be used</param>
    /// <returns>Collection of store items that match the search criteria</returns>
    [Route("search")]
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(SearchResultModel))]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetStoreItemsSearch([FromQuery] SearchParametersModel searchParameters, [FromQuery] PagingFilter pagingFilter)
    {
        var result = await StoreFacade.GetStoreItemsSearchAsync(searchParameters, null, pagingFilter);

        return Ok(result ?? new SearchResultModel());
    }

    /// <summary>
    /// Gets detail of store item by id
    /// </summary>
    /// <param name="storeItemId">Id of the store item</param>
    /// <returns></returns>
    [Route("detail/{storeItemId:guid}")]
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(StoreItemDetailModel))]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetStoreItemDetailById(string storeItemId)
    {
        var result = await StoreFacade.GetStoreItemDetailByIdAsync(storeItemId, null);

        return Ok(result ?? new StoreItemDetailModel());
    }

    /// <summary>
    /// Search for all purchased store items based on search parameters
    /// </summary>
    /// <param name="searchParameters">Search parameters to be used for searching between all purchased store items</param>
    /// <param name="pagingFilter">Paging filter to be used</param>
    /// <returns>Collection of all purchased store items that match the search criteria</returns>
    [Route("allPurchased")]
    [HttpGet]
    [Obsolete]
    [Authorize(AuthenticationSchemes = "Bearer")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CollectionResult<StoreItemWithLicenceInformationModel>))]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetAllPurchasedStoreItemsSearch([FromQuery] SearchParametersModel searchParameters, [FromQuery] PagingFilter pagingFilter)
    {
        var result = await StoreFacade.GetAllPurchasedStoreItemsSearchAsync(searchParameters, null, pagingFilter);

        return Ok(result ?? new CollectionResult<StoreItemWithLicenceInformationModel>());
    }

    /// <summary>
    /// Search for subscription based on search parameters
    /// </summary>
    /// <param name="searchParameters">Search parameters to be used for searching between subscriptions</param>
    /// <param name="pagingFilter">Paging filter to be used</param>
    /// <returns>Collection of subscriptions that match the search criteria</returns>
    [Route("subscriptions")]
    [HttpGet]
    [Authorize(AuthenticationSchemes = "Bearer")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CollectionResult<SubscriptionsSummaryModel>))]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetSubscriptions([FromQuery] SearchSubscriptionsModel searchParameters, [FromQuery] PagingFilter pagingFilter)
    {
        var result = await StoreFacade.GetSubscriptionsAsync(searchParameters, null, pagingFilter);

        return Ok(result ?? new CollectionResult<SubscriptionsSummaryModel>());
    }

    /// <summary>
    /// Get Allowed Operations for provided product catalog id
    /// </summary>
    /// <param name="productCatalogId">Product Catalog Id</param>
    /// <returns>Allowed Operations for provided product catalog id</returns>
    [Route("getOrderLicenceInformation")]
    [HttpGet]
    [Authorize(AuthenticationSchemes = "Bearer")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(OrderLicenceInformation))]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetOrderLicenceInformation([FromQuery] string productCatalogId)
    {
        var result = await StoreFacade.GetOrderLicenceInformationAsync(productCatalogId);

        return Ok(result ?? new OrderLicenceInformation());
    }

    /// <summary>
    /// Get codebooks used in the product catalog
    /// </summary>
    [HttpGet]
    [Route("productCatalogCodebooks")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<ProductCatalogCodebooksModel>> GetProductCatalogCodebooks(CancellationToken cancellationToken)
    {
        var result = await ProductCatalogCodebooksFacade.GetProductCatalogCodebooksAsync(cancellationToken);
        return Ok(result ?? new ProductCatalogCodebooksModel());
    }

    /// <summary>
    /// Invalidate store cachce.
    /// </summary>
    /// <returns></returns>
    [HttpPost]
    [Route("[action]")]
    [Authorize(AuthenticationSchemes = "Bearer")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status412PreconditionFailed)]
    public Task InvalidateCache()
    {
        return CacheFacade.InvalidateCacheAsync();
    }

    /// <summary>
    /// get all helpdesk data
    /// </summary>
    /// <param name="pagingFilter">Paging filter to be used</param>
    /// <returns>Collection of all helpdesk data according to filter</returns>
    [Route("allHelpdeskData")]
    [HttpGet]
    [Authorize(AuthenticationSchemes = "Bearer")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CollectionResult<HelpdeskDataModel>))]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetHelpdeskDataQueryHandler(CancellationToken ct = default)
    {
        var result = await StoreFacade.GetAllHelpdeskDataAsync(ct);
        return Ok(result ?? new CollectionResult<HelpdeskDataModel>());
    }

    /// <summary>
    /// Sync AllPurchased Data
    /// </summary>
    /// <returns>Bool status of triggered service</returns>
    [Route("syncAllPurchasedData")]
    [HttpPost]
    [Authorize(AuthenticationSchemes = "Bearer")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(bool))]
    public async Task<IActionResult> SyncAllPurchasedDataAsync([FromQuery] string tenantId)
    {
        var result = await StoreFacade.RequestSyncAllPurchasedDataAsync(tenantId);
        return Ok(result);
    }

    /// <summary>
    /// Search for all purchased data based on search parameters
    /// </summary>
    /// <param name="searchParameters">Search parameters to be used for searching between all purchased data</param>
    /// <param name="pagingFilter">Paging filter to be used</param>
    /// <returns>Collection of all purchased data that match the search criteria</returns>
    [Route("allPurchasedData")]
    [HttpGet]
    [Authorize(AuthenticationSchemes = "Bearer")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CollectionResult<AllPurchasedDataSummaryModel>))]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetAllPurchasedDataAsync([FromQuery] SearchAllPurchasedDataModel searchParameters, [FromQuery] PagingFilter pagingFilter)
    {
        var result = await StoreFacade.GetAllPurchasedDataAsync(searchParameters, null, pagingFilter);

        return Ok(result ?? new CollectionResult<AllPurchasedDataSummaryModel>());
    }

    /// <summary>
    /// Send notification for ending subscriptions.
    /// </summary>
    /// <returns></returns>
    [Route("[action]")]
    [HttpPost]
    [Authorize(AuthenticationSchemes = "Bearer")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status412PreconditionFailed)]
    public async Task<IActionResult> NotifySubscriptionPeriodEnds()
    {
        var result = await StoreFacade.NotifySubscriptionPeriodEndsAsync();
        return Ok(result);
    }
}
