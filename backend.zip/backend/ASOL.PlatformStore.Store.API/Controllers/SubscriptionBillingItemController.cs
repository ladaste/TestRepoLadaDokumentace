using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.ApiController;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.PlatformStore.Store.Contracts.Subscription;
using ASOL.PlatformStore.Store.Infrastructure.SubscriptionRoot.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.API.Controllers;

[ApiController]
[ApiConventionType(typeof(DefaultApiConventions))]
[Route("api/v{version:apiVersion}/[controller]")]
[Produces(MediaTypeNames.Application.Json)]
[Consumes(MediaTypeNames.Application.Json)]
public class SubscriptionBillingItemsController
(
    SubscriptionBillingItemService subscriptionBillingItemService,
    ILogger<SubscriptionBillingItemsController> logger
)
    : AuthorizeControllerBase(logger)
{

    /// <summary>
    /// Gets a list of subscription billing items filtered by tenant.
    /// </summary>
    /// <param name="tenantId">The tenant ID to filter by.</param>
    /// <param name="pagingFilter">Paging and filtering options.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>List of subscription billing items.</returns>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CollectionResult<SubscriptionBillingItemModel>))]
    public async Task<IActionResult> GetList(
        [FromQuery] string? tenantId,
        [FromQuery] PagingFilter pagingFilter,
        CancellationToken cancellationToken)
    {
        var subscriptionBillingItems = await subscriptionBillingItemService.GetListAsync(tenantId, pagingFilter, cancellationToken);

        return Ok(subscriptionBillingItems);
    }
}

