using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.ApiController;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.DataGridComponent.Contracts;
using ASOL.PlatformStore.Store.Contracts.Subscription;
using ASOL.PlatformStore.Store.Contracts.Subscription.Filters;
using ASOL.PlatformStore.Store.Contracts.Subscription.Updates;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Queries;
using ASOL.PlatformStore.Store.Infrastructure.SubscriptionRoot.Services;
using EventFlow;
using EventFlow.Queries;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.API.Controllers;

[ApiController]
[ApiConventionType(typeof(DefaultApiConventions))]
[Route("api/v{version:apiVersion}/[controller]")]
[Produces(MediaTypeNames.Application.Json)]
[Consumes(MediaTypeNames.Application.Json)]
public class SubscriptionController
(
    ILogger<SubscriptionController> logger,
    IQueryProcessor queryProcessor,
    ICommandBus commandBus,
    SubscriptionService subscriptionService,
    SubscriptionSolutionStatusService subscriptionStatusService,
    SubscriptionDetailResponseService subscriptionDetailResponseService
)
    : AuthorizeControllerBase(logger)
{
    /// <summary>
    /// Get customer subscription summary
    /// </summary>
    [HttpPost("customer/summary")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PagedResult<CustomerSubscriptionSummaryModel>))]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> GetCustomerSubscriptionSummaries([FromBody] CustomerSubscriptionSummaryRequest request, CancellationToken ct)
    {
        var query = new GetCustomerSubscriptionSummariesQuery(request);
        var result = await queryProcessor.ProcessAsync(query, ct);

        return Ok(result);
    }

    /// <summary>
    /// Get customer subscription summary data grid definition
    /// </summary>
    [HttpGet("customer/summary/definition")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(SubscriptionSummaryDefinition))]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public IActionResult GetCustomerSubscriptionSummaryDefinition()
    {
        var result = subscriptionService.GetCustomerSubscriptionSummaryDefinition();

        return Ok(result);
    }

    /// <summary>
    /// Get partner subscription summary
    /// </summary>
    [HttpPost("summary")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PagedResult<SubscriptionSummaryModel>))]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> GetSubscriptionSummaries([FromBody] SubscriptionSummaryRequest request, CancellationToken ct)
    {
        var query = new GetSubscriptionSummariesQuery(request);
        var result = await queryProcessor.ProcessAsync(query, ct);

        return Ok(result);
    }

    /// <summary>
    /// Get partner subscription summary data grid definition
    /// </summary>
    [HttpGet("summary/definition")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(SubscriptionSummaryDefinition))]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public IActionResult GetSubscriptionSummaryDefinition()
    {
        var result = subscriptionService.GetSubscriptionSummaryDefinition();

        return Ok(result);
    }

    /// <summary>
    /// Get customer subscription detail
    /// </summary>
    [HttpGet("customer/{subscriptionId}/detail")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CustomerSubscriptionDetailModel))]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetCustomerSubscriptionDetail([FromRoute] string subscriptionId, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(subscriptionId))
        {
            return BadRequest("Subscription ID is required");
        }

        var query = new GetCustomerSubscriptionDetailQuery(subscriptionId);
        var result = await queryProcessor.ProcessAsync(query, ct);

        return result is null ? NotFound() : Ok(result);
    }

    /// <summary>
    /// Get partner subscription detail
    /// </summary>
    [HttpGet("{subscriptionId}/detail")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(SubscriptionDetailModel))]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetSubscriptionDetail([FromRoute] string subscriptionId, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(subscriptionId))
        {
            return BadRequest("Subscription ID is required");
        }

        var subscriptionDetail = await subscriptionDetailResponseService.GetSubscriptionDetailAsync(subscriptionId, ct);
        if (subscriptionDetail is null)
        {
            return NotFound();
        }

        return Ok(subscriptionDetail);
    }

    /// <summary>
    /// Get list of store subscription cards (icons)
    /// </summary>
    [HttpGet("store/cards")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CollectionResult<SubscriptionCardModel>))]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> GetStoreCards([FromQuery] PagingFilter pagingFilter, CancellationToken ct)
    {
        var query = new GetStoreCardsQuery(pagingFilter);
        var result = await queryProcessor.ProcessAsync(query, ct);

        return Ok(result);
    }

    /// <summary>
    /// Change subscription solution status
    /// </summary>
    /// <param name="subscriptionId">The subscription ID</param>
    /// <param name="statusUpdateModel">The status change request</param>
    /// <param name="ct">Cancellation token</param>
    /// <returns>Success response or error</returns>
    [HttpPatch("{subscriptionId}/status")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> UpdateSubscriptionSolutionStatus([FromRoute] string subscriptionId, [FromBody] SubscriptionSolutionStatusUpdateModel statusUpdateModel, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(subscriptionId))
        {
            return BadRequest("Subscription ID is required");
        }

        await subscriptionStatusService.UpdateSolutionStatusAsync(subscriptionId, statusUpdateModel, ct);

        return NoContent();
    }

    /// <summary>
    /// Update subscription discount
    /// </summary>
    [HttpPut("{subscriptionId}/discount")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateSubscriptionDiscount([FromRoute] string subscriptionId, [FromBody] SubscriptionDiscountUpdateModel model, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(subscriptionId))
        {
            return BadRequest("Subscription ID is required");
        }

        var id = SubscriptionId.With(subscriptionId);
        var command = new SubscriptionDiscountUpdateCommand(id, model.DiscountAmount, model.DiscountValidFrom, model.DiscountValidTo, model.DiscountInternalNote);

        var result = await commandBus.PublishAsync(command, ct);

        if (!result.IsSuccess)
        {
            return BadRequest(result.ToString());
        }

        return Ok();
    }

    /// <summary>
    /// Create subscription from order.
    /// </summary>
    /// <param name="orderId"></param>
    /// <param name="ct"></param>
    /// <returns></returns>
    [ApiExplorerSettings(IgnoreApi = true)]
    [HttpPost("fromOrder/{orderId}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> CreateOrUpdateSubscriptionFromOrder([FromRoute] string orderId, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(orderId))
        {
            return BadRequest("Order Id is required.");
        }

        await subscriptionService.CreateOrUpdateSubscriptionFromOrderAsync(orderId, ct);

        return NoContent();
    }
}
