using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.ApiController;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.PlatformStore.Store.API.Validation;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Contracts.Filters;
using ASOL.PlatformStore.Store.Contracts.Subscription;
using ASOL.PlatformStore.Store.Infrastructure.SubscriptionRoot.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.API.Controllers;

[ApiController]
[ApiConventionType(typeof(DefaultApiConventions))]
[Route("api/v{version:apiVersion}/Subscriptions/{subscriptionId}/Licenses")]
[Produces(MediaTypeNames.Application.Json)]
[Consumes(MediaTypeNames.Application.Json)]
public class SubscriptionLicensesController
(
    ILogger<SubscriptionLicensesController> logger,
    SubscriptionLicenseService subscriptionLicenseService
)
    : AuthorizeControllerBase(logger)
{
    /// <summary>
    /// Returns a paged list of licenses under the specified subscription.
    /// <para/>
    /// Route: GET /api/v{version}/Subscriptions/{subscriptionId}/Licenses
    /// </summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CollectionResult<SubscriptionLicenseModel>))]
    public async Task<IActionResult> GetList(
        [FromRoute, NotEmptyOrWhiteSpace] string subscriptionId,
        [FromQuery] LicenseFilter licenseFilter,
        [FromQuery] PagingFilter pagingFilter,
        CancellationToken ct)
    {
        var subscriptionLicenses = await subscriptionLicenseService.GetListAsync(
            licenseFilter,
            pagingFilter,
            ct,
            subscriptionId
        );

        return Ok(subscriptionLicenses);
    }

    /// <summary>
    /// Creates a new license within the specified subscription.
    /// <para/>
    /// Route: POST /api/v{version}/Subscriptions/{subscriptionId}/Licenses
    /// </summary>
    [HttpPost]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CollectionResult<SubscriptionLicenseModel>))]
    public async Task<IActionResult> Create(
        [FromRoute, NotEmptyOrWhiteSpace] string subscriptionId,
        [FromBody] LicenseModelCreate model,
        CancellationToken ct)
    {
        var subscriptionLicenseIds = await subscriptionLicenseService.CreateAsync(
            subscriptionId,
            model,
            ct
        );

        var result = await subscriptionLicenseService.GetListByIdsAsync(subscriptionLicenseIds, ct);

        return Ok(result);
    }

    /// <summary>
    /// Replaces an existing license within the specified subscription (idempotent PUT).
    /// <para/>
    /// Route: PUT /api/v{version}/Subscriptions/{subscriptionId}/Licenses/{licenseId}
    /// </summary>
    [HttpPut("{licenseId}")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(SubscriptionLicenseModel))]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Update(
        [FromRoute, NotEmptyOrWhiteSpace] string subscriptionId,
        [FromRoute, NotEmptyOrWhiteSpace] string licenseId,
        [FromBody] LicenseModelUpdate model,
        CancellationToken ct)
    {
        await subscriptionLicenseService.UpdateAsync(
            subscriptionId,
            licenseId,
            model,
            ct
        );

        var result = await subscriptionLicenseService.GetAsync(
            licenseId,
            ct
        );

        return Ok(result);
    }

    /// <summary>
    /// Deletes a license within the specified subscription.
    /// <para/>
    /// Route: DELETE /api/v{version}/Subscriptions/{subscriptionId}/Licenses/{licenseId}
    /// </summary>
    [HttpDelete("{licenseId}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(
        [FromRoute, NotEmptyOrWhiteSpace] string subscriptionId,
        [FromRoute, NotEmptyOrWhiteSpace] string licenseId,
        CancellationToken ct)
    {
        var result = await subscriptionLicenseService.DeleteAsync(
            subscriptionId,
            licenseId,
            ct);

        if (result)
        {
            return NoContent();
        }

        return NotFound();
    }
}
