namespace ASOL.PlatformStore.Store.API.CustomSetup;

internal sealed class CorsPolicyNames
{
    internal const string Api = "Api";
}
