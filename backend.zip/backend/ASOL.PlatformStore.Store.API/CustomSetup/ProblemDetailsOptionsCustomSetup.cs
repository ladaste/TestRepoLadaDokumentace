using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Authentication;
using ASOL.Core.ApiConnector;
using ASOL.Core.Identity;
using ASOL.Core.Identity.Exceptions;
using ASOL.Core.Multitenancy.Exceptions;
using ASOL.Core.ProblemDetailsConventions;
using ASOL.Core.Processing;
using ASOL.Core.Processing.Exceptions;
using ASOL.Core.Telemetry.Client;
using ASOL.PlatformStore.Store.Domain.LeftPanels.Application;
using ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;
using Hellang.Middleware.ProblemDetails;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Pathoschild.Http.Client;

namespace ASOL.PlatformStore.Store.API.CustomSetup;

/// <summary>
/// Represents the custom problem details configuration options.
/// </summary>
public class ProblemDetailsOptionsCustomSetup(IWebHostEnvironment environment,
    IHttpContextAccessor httpContextAccessor, IOptions<ApiBehaviorOptions> apiOptions, Telemetry telemetry) : ProblemDetailsOptionsDefaultSetup(environment, httpContextAccessor, apiOptions)
{
    protected Telemetry Telemetry { get; } = telemetry;

    public override void Configure(Hellang.Middleware.ProblemDetails.ProblemDetailsOptions options)
    {
        base.Configure(options);

        options.Map<KeyNotFoundException>(ex => KeyNotFoundExceptionMapping(TrackException(ex)));
        options.Map<ApiException>(ex => ApiClientExceptionMapping(TrackException(ex)));
        options.Map<InvalidTenantException>(ex => InvalidTenantExceptionMapping(TrackException(ex)));
        options.Map<InsufficientIdentityException>(ex => InsufficientIdentityExceptionMapping(TrackException(ex)));
        options.Map<UnauthorizedAccessException>(ex => UnauthorizedAccessExceptionMapping(TrackException(ex)));
        options.Map<AuthenticationException>(ex => AuthenticationExceptionMapping(TrackException(ex)));
        options.Map<ArgumentException>(ex => ArgumentExceptionMapping(TrackException(ex)));
        options.Map<NotSupportedException>(ex => NotSupportedExceptionMapping(TrackException(ex)));
        options.Map<ValidationException>((ctx, ex) => ValidationExceptionMapping(ctx, TrackException(ex)));
        options.Map<UpdatingOutdatedDataException>((ctx, ex) => UpdatingOutdatedDataException(TrackException(ex)));
        options.Map<BusinessException>((ctx, ex) => BusinessExceptionMapping(TrackException(ex)));

        options.Map<ProcessingCoreException>((ctx, ex) =>
        {
            Telemetry.TrackException(ex);

            var processingEx = ProcessingCoreException.FindProcessingException(ex);
            return processingEx.InnerException switch
            {
                KeyNotFoundException inner => KeyNotFoundExceptionMapping(inner),
                ApiException inner => ApiClientExceptionMapping(inner),
                InvalidTenantException inner => InvalidTenantExceptionMapping(inner),
                InsufficientIdentityException inner => InsufficientIdentityExceptionMapping(inner),
                UnauthorizedAccessException inner => UnauthorizedAccessExceptionMapping(inner),
                AuthenticationException inner => AuthenticationExceptionMapping(inner),
                NotImplementedException inner => NotImplementedExceptionMapping(inner),
                NotSupportedException inner => NotSupportedExceptionMapping(inner),
                ArgumentException inner => ArgumentExceptionMapping(inner),
                ValidationException inner => ValidationExceptionMapping(ctx, inner),
                UpdatingOutdatedDataException inner => UpdatingOutdatedDataException(inner),
                BusinessException inner => BusinessExceptionMapping(inner),
                _ => UnhandledExceptionMapping(processingEx),
            };
        });
    }

    private T TrackException<T>(T exception) where T : Exception
    {
        Telemetry.TrackException(exception);
        return exception;
    }

    private static ProblemDetails ValidationExceptionMapping(HttpContext ctx, ValidationException exception)
    {
        var factory = ctx.RequestServices.GetRequiredService<ProblemDetailsFactory>();
        var validationErrors = exception.ValidationErrors.ToDictionary();
        return factory.CreateValidationProblemDetails(ctx, validationErrors, StatusCodes.Status400BadRequest);
    }

    private static ProblemDetails ArgumentExceptionMapping(ArgumentException exception)
    {
        return new StatusCodeProblemDetails(StatusCodes.Status400BadRequest) { Detail = exception.Message };
    }

    private static ProblemDetails ApiClientExceptionMapping(ApiException exception)
    {
        var errorMessage = ApiClientHelper.ResolveErrorDetailsAsync(exception).GetAwaiter().GetResult();
        return new StatusCodeProblemDetails(StatusCodes.Status500InternalServerError)
        {
            Title = "Internal Server Error - API commmunication failed",
            Detail = errorMessage
        };
    }

    private static ProblemDetails InvalidTenantExceptionMapping(InvalidTenantException exception)
    {
        return new StatusCodeProblemDetails(StatusCodes.Status403Forbidden)
        {
            Detail = new InsufficientIdentityException(KnownClaimTypes.TenantId).Message
        };
    }

    private static ProblemDetails InsufficientIdentityExceptionMapping(InsufficientIdentityException exception)
    {
        return new StatusCodeProblemDetails(StatusCodes.Status403Forbidden) { Detail = exception.Message };
    }

    private static ProblemDetails UnauthorizedAccessExceptionMapping(UnauthorizedAccessException exception)
    {
        return new StatusCodeProblemDetails(StatusCodes.Status403Forbidden) { Detail = exception.Message };
    }

    private static ProblemDetails AuthenticationExceptionMapping(AuthenticationException exception)
    {
        return new StatusCodeProblemDetails(StatusCodes.Status401Unauthorized);
    }

    private static ProblemDetails NotImplementedExceptionMapping(NotImplementedException exception)
    {
        return new StatusCodeProblemDetails(StatusCodes.Status501NotImplemented) { Detail = exception.Message };
    }

    private static ProblemDetails NotSupportedExceptionMapping(NotSupportedException exception)
    {
        return new StatusCodeProblemDetails(StatusCodes.Status406NotAcceptable) { Detail = exception.Message };
    }

    private static ProblemDetails KeyNotFoundExceptionMapping(KeyNotFoundException exception)
    {
        return new StatusCodeProblemDetails(StatusCodes.Status404NotFound) { Detail = exception.Message };
    }

    private static ProblemDetails UpdatingOutdatedDataException(UpdatingOutdatedDataException exception)
    {
        return new StatusCodeProblemDetails(StatusCodes.Status409Conflict)
        {
            Detail = exception.Message
        };
    }

    private static ProblemDetails BusinessExceptionMapping(BusinessException exception)
    {
        return new StatusCodeProblemDetails(StatusCodes.Status400BadRequest)
        {
            Detail = exception.Message
        };
    }

    private static ProblemDetails UnhandledExceptionMapping(Exception exception)
    {
        return new StatusCodeProblemDetails(StatusCodes.Status500InternalServerError) { Detail = exception.Message };
    }
}
