using System.Threading.Tasks;
using ASOL.Core.ApiController.SignalR;
using ASOL.PlatformStore.Store.API.Services;
using ASOL.PlatformStore.Store.Domain.Helpers;

namespace ASOL.PlatformStore.Store.API.Hubs;

public class ApplicationHub(IConnectionManagerService connectionManager) : AuthorizedHubBase
{
    private readonly IConnectionManagerService ConnectionManager = connectionManager;

    public override Task OnConnectedAsync()
    {
        return base.OnConnectedAsync();
    }

    public override Task OnDisconnectedAsync(System.Exception exception)
    {
        ConnectionManager.RemoveConnection(Context.ConnectionId);
        return base.OnDisconnectedAsync(exception);
    }

    public string GetConnectionId()
    {
        var runtimeContext = Context.GetRuntimeContext();

        var accountId = AccountHelper.GenerateAccountId(runtimeContext);
        var tenantId = runtimeContext.Security.TenantId;

        ConnectionManager.AddConnection(tenantId, accountId, Context.ConnectionId);

        return Context.ConnectionId;
    }
}
