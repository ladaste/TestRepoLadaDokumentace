using System.Threading.Tasks;
using ASOL.Core.Identity;
using ASOL.Core.Processing;
using ASOL.IdentityManager.Contracts.Events;
using ASOL.IdentityProvider.Contracts.Tenant.Events;
using ASOL.PlatformStore.PDM.Contracts.Events;
using ASOL.PlatformStore.Store.Facades;
using ASOL.SubjectManager.Contracts.Events;
using MassTransit;

namespace ASOL.PlatformStore.Store.API.MessageConsumers;

/// <summary>
/// Message consumer for category change and delete events. Updates the data in the service product storage.
/// </summary>
/// <remarks>
/// Initializes the instance
/// </remarks>
/// <param name="storeFacade">Sync facade</param>     
public class AllPurchasedDataSyncConsumer(
    IStoreFacade storeFacade,
    IRuntimeContext runtimeContext,
    ICommandProcessor commandProcessor) :
    IConsumer<ApplicationLicenseChanged>,
    IConsumer<LicenseRoleMemberChanged>,
    IConsumer<OrganizationRelationshipCreated>,
    IConsumer<OrganizationRelationshipChanged>,
    IConsumer<OrganizationRelationshipDeleted>,
    IConsumer<TenantReleased>,
    IConsumer<ProductCatalogChanged>,
    IConsumer<ApplicationLicenseDeleted>
{

    /// <summary>
    /// Sync facade
    /// </summary>
    protected IStoreFacade StoreFacade { get; } = storeFacade;

    protected IRuntimeContext RuntimeContext { get; } = runtimeContext;

    protected ICommandProcessor CommandProcessor { get; } = commandProcessor;

    /// <summary>
    /// Trigger the sync of allPurchased data based on ApplicationLicenseChanged action
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<ApplicationLicenseChanged> context)
    {
        var message = context.Message;
        await StoreFacade.SyncAllPurchasedDataApplicationLicenseChangedAsync(message.ApplicationCode, message.EditionCode, message.LicenseId);
    }

    /// <summary>
    /// Trigger the sync of allPurchased data based on LicenseRoleMemberChanged action
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<LicenseRoleMemberChanged> context)
    {
        var message = context.Message;
        await StoreFacade.SyncAllPurchasedDataLicenseRoleMemberChangedAsync(message.AccountId, message.Assigned, message.LicenseCode, message.LicenseId, message.RoleCode, message.RoleId);
    }

    /// <summary>
    /// Trigger the sync of allPurchased data based on OrganizationRelationshipCreated action
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<OrganizationRelationshipCreated> context)
    {
        var message = context.Message;
        await StoreFacade.SyncAllPurchasedDataOrganizationRelationshipCreatedAsync(message.AccessLevel, message.OrganizationRelationshipId);
    }

    /// <summary>
    /// Trigger the sync of allPurchased data based on OrganizationRelationshipChanged action
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<OrganizationRelationshipChanged> context)
    {
        var message = context.Message;
        await StoreFacade.SyncAllPurchasedDataOrganizationRelationshipChangedAsync(message.AccessLevel, message.OrganizationRelationshipId, message.OrganizationRelationshipDataId);
    }

    /// <summary>
    /// Trigger the sync of allPurchased data based on OrganizationRelationshipDeleted action
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<OrganizationRelationshipDeleted> context)
    {
        var message = context.Message;
        await StoreFacade.SyncAllPurchasedDataOrganizationRelationshipDeletedAsync(message.AccessLevel, message.OrganizationRelationshipId);
    }

    /// <summary>
    /// Trigger the sync of allPurchased data based on TenantReleased action
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<TenantReleased> context)
    {
        var message = context.Message;

        await StoreFacade.SyncAllPurchasedDataTenantReleasedAsync(message.Id);
    }

    /// <summary>
    /// Trigger the sync of allPurchased data based on ProductCatalogChanged action
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<ProductCatalogChanged> context)
    {
        var message = context.Message;

        await StoreFacade.SyncAllPurchasedDataProductCatalogChangedAsync(message.Id);
    }

    /// <summary>
    /// Trigger the sync of allPurchased data based on ApplicationLicenseDeleted action
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<ApplicationLicenseDeleted> context)
    {
        var message = context.Message;

        var command = new SyncAllPurchasedDataApplicationLicenseDeletedCommand(message.ApplicationCode, message.EditionCode, message.LicenceCode, message.LicenseId, message.SolutionPackageCode, RuntimeContext?.Security?.TenantId);
        var commandResult = await CommandProcessor.ProcessAsync<SyncAllPurchasedDataApplicationLicenseDeletedCommand, bool>(command, context.CancellationToken);

        _ = FacadeHelper.ResolveCommandResultValue(commandResult);
    }
}
