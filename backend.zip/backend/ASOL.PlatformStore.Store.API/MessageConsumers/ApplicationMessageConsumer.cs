using System.Collections.Generic;
using System.Threading.Tasks;
using ASOL.Core.Identity;
using ASOL.Core.Paging.Contracts;
using ASOL.IdentityManager.Connector;
using ASOL.IdentityManager.Contracts;
using ASOL.IdentityManager.Contracts.Events;
using ASOL.PlatformStore.Store.API.Hubs;
using ASOL.PlatformStore.Store.API.Services;
using ASOL.PlatformStore.Store.Contracts.Primitives;
using ASOL.PlatformStore.Store.Domain.Helpers;
using ASOL.PlatformStore.Store.Facades;
using MassTransit;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.API.MessageConsumers;

/// <summary>
/// Message consumer for licence changed and recent applications changed events. Invalidates the store cache.
/// </summary>
/// <remarks>
/// Initializes the instance
/// </remarks>
/// <param name="cacheFacade">Cache facade</param>   
public class ApplicationMessageConsumer(
    IHubContext<ApplicationHub> hub,
    IConnectionManagerService connectionManager,
    IIdentityManagerClient identityManagerClient,
    IRuntimeContext runtimeContext,
    ICacheFacade cacheFacade,
    ILogger<ApplicationMessageConsumer> logger) : IConsumer<ApplicationLicenseChanged>, IConsumer<ApplicationRecentChanged>, IConsumer<LicenseRoleMemberChanged>
{
    protected IConnectionManagerService ConnectionManager = connectionManager;
    protected IHubContext<ApplicationHub> Hub { get; } = hub;
    protected IRuntimeContext RuntimeContext { get; } = runtimeContext;
    protected IIdentityManagerClient IdentityManagerClient { get; } = identityManagerClient;
    protected ILogger Logger { get; } = logger;

    /// <summary>
    /// Cache facade
    /// </summary>
    protected ICacheFacade CacheFacade { get; } = cacheFacade;

    /// <summary>
    /// Consume the application recent changed event.
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<ApplicationRecentChanged> context)
    {
        var tenantId = RuntimeContext.Security.TenantId;
        var accountId = AccountHelper.GenerateAccountId(RuntimeContext);

        await CacheFacade.InvalidateCacheAsync(InvalidateCacheEventType.ApplicationRecentChanged,
            tenantId,
            accountId);

        await NotifyMember(tenantId, accountId, "ApplicationRecentChanged");
    }

    /// <summary>
    /// Consume the recent application licence changed event.
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<ApplicationLicenseChanged> context)
    {
        var tenantId = RuntimeContext.Security.TenantId;
        await CacheFacade.InvalidateCacheAsync(InvalidateCacheEventType.ApplicationLicenseChanged, tenantId);

        try
        {
            var license = await IdentityManagerClient.Licenses.GetByIdAsync(context.Message.LicenseId);

            foreach (var licFtr in license.Features)
            {
                foreach (var licRole in licFtr.Roles)
                {
                    var roleMembersResults = await IdentityManagerClient.GetRoleMembersAsync(licRole.RoleCode);

                    if (roleMembersResults?.Items != null)
                    {
                        foreach (var item in roleMembersResults.Items)
                        {
                            await NotifyMember(tenantId, item.AccountId, "ApplicationLicenseChanged");
                        }
                    }
                }
            }
        }
        catch (System.Exception ex)
        {
            Logger.LogError($"There were an error fetching license from IDM with provided LicenseId: {context.Message.LicenseId}", ex);
            return;
        }
    }

    /// <summary>
    /// Consume the License Role Member changed event.
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<LicenseRoleMemberChanged> context)
    {
        var tenantId = RuntimeContext.Security.TenantId;
        var accountId = AccountHelper.GenerateAccountId(RuntimeContext);

        await CacheFacade.InvalidateCacheAsync(InvalidateCacheEventType.LicenseRoleMemberChanged,
            tenantId,
            accountId);

        await NotifyMember(tenantId, accountId, "LicenseRoleMemberChanged");
    }

    private async Task NotifyMember(string tenantId, string accountId, string clientFunctionName)
    {
        var connections = ConnectionManager.GetConnections(tenantId, accountId);

        if (connections != null && connections.Count > 0)
        {
            foreach (var conn in connections)
            {
                await Hub.Clients.Clients(conn).SendAsync(clientFunctionName, $"{tenantId}-{accountId}");
            }
        }
    }
}
