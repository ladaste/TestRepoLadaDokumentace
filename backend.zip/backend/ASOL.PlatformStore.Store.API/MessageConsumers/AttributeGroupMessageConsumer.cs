using System.Threading.Tasks;
using ASOL.CustomAttributes.Contracts.Events;
using ASOL.PlatformStore.Store.Facades;
using MassTransit;

namespace ASOL.PlatformStore.Store.API.MessageConsumers;


/// <summary>
/// Message consumer for attribute group change and delete events. Updates the data in the service product storage.
/// </summary>
/// <remarks>
/// Initializes the instance
/// </remarks>
/// <param name="syncFacade">Sync facade</param>     
public class AttributeGroupMessageConsumer(
    ISyncFacade syncFacade
        ) : IConsumer<AttributeGroupChanged>, IConsumer<AttributeGroupDeleted>, IConsumer<AttributeGroupCreated>
{
    protected ISyncFacade SyncFacade { get; } = syncFacade;

    /// <summary>
    /// Consume the category created event.
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<AttributeGroupCreated> context)
    {
        var message = context.Message;
        await SyncFacade.SyncAttributeGroupAsync(message.Id);
    }

    /// <summary>
    /// Consume the attribute group changed event.
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<AttributeGroupChanged> context)
    {
        var message = context.Message;
        await SyncFacade.SyncAttributeGroupAsync(message.Id);
    }

    /// <summary>
    /// Consume the attribute group deleted event.
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<AttributeGroupDeleted> context)
    {
        var message = context.Message;
        await SyncFacade.SyncAttributeGroupAsync(message.Id, true);
    }
}
