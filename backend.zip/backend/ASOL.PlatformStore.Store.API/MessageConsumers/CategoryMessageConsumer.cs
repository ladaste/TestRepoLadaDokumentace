using System.Threading.Tasks;
using ASOL.CustomAttributes.Contracts.Events;
using ASOL.PlatformStore.Store.Facades;
using MassTransit;

namespace ASOL.PlatformStore.Store.API.MessageConsumers;

/// <summary>
/// Message consumer for category change and delete events. Updates the data in the service product storage.
/// </summary>
/// <remarks>
/// Initializes the instance
/// </remarks>
/// <param name="syncFacade">Sync facade</param>     
public class CategoryMessageConsumer(
    ISyncFacade syncFacade) : IConsumer<CategoryChanged>, IConsumer<CategoryDeleted>, IConsumer<CategoryCreated>
{

    /// <summary>
    /// Sync facade
    /// </summary>
    protected ISyncFacade SyncFacade { get; } = syncFacade;

    /// <summary>
    /// Consume the category created event.
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<CategoryCreated> context)
    {
        var message = context.Message;
        await SyncFacade.SyncCategoryAsync(message.Id);
    }

    /// <summary>
    /// Consume the category changed event.
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<CategoryChanged> context)
    {
        var message = context.Message;
        await SyncFacade.SyncCategoryAsync(message.Id);
    }

    /// <summary>
    /// Consume the category deleted event.
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<CategoryDeleted> context)
    {
        var message = context.Message;
        await SyncFacade.SyncCategoryAsync(message.Id, true);
    }
}
