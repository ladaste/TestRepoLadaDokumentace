using System.Threading.Tasks;
using ASOL.PlatformStore.Store.Contracts.Events;
using ASOL.PlatformStore.Store.Facades;
using MassTransit;

namespace ASOL.PlatformStore.Store.API.MessageConsumers;

/// <summary>
/// Message consumer for category change and delete events. Updates the data in the service product storage.
/// </summary>
/// <remarks>
/// Initializes the instance
/// </remarks>
/// <param name="messageFacade">Sync facade</param>     
public class HelpDeskMessageConsumer(
    IMessageFacade messageFacade) : IConsumer<TriggerHelpDeskTickets>
{

    /// <summary>
    /// Sync facade
    /// </summary>
    protected IMessageFacade MessageFacade { get; } = messageFacade;

    /// <summary>
    /// Consume the trigger helpdesk APIs event.
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<TriggerHelpDeskTickets> context)
    {
        var message = context.Message;
        await MessageFacade.TriggerHelpDeskTickets(message.Subject, message.Message, message.ApplicationCode, message.CurrentUrl);
    }
}
