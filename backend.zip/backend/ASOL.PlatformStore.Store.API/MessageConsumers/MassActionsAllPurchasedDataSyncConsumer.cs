using System.Threading.Tasks;
using ASOL.PlatformStore.Store.Contracts.Events;
using ASOL.PlatformStore.Store.Facades;
using MassTransit;

namespace ASOL.PlatformStore.Store.API.MessageConsumers;

/// <summary>
/// Message consumer for allPurchasedDataSync
/// </summary>
/// <remarks>
/// Initializes the instance
/// </remarks>
/// <param name="storeFacade">Sync facade</param>     
public class MassActionsAllPurchasedDataSyncConsumer(
    IStoreFacade storeFacade) : IConsumer<TriggerAggregateAllPurchasedDataSync>
{

    /// <summary>
    /// Sync facade
    /// </summary>
    protected IStoreFacade StoreFacade { get; } = storeFacade;

    /// <summary>
    /// Trigger the Master sync of allPurchased data
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<TriggerAggregateAllPurchasedDataSync> context)
    {
        var message = context.Message;
        await StoreFacade.SyncAllPurchasedTenantDataAsync(message.RequestId);
    }
}
