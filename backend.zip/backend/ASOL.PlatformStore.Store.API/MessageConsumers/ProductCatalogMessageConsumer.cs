using System.Threading.Tasks;
using ASOL.PlatformStore.PDM.Contracts.Events;
using ASOL.PlatformStore.Store.Domain.Helpers;
using ASOL.PlatformStore.Store.Facades;
using MassTransit;
using Microsoft.Extensions.Caching.Memory;

namespace ASOL.PlatformStore.Store.API.MessageConsumers;

/// <summary>
/// Consumer for ProductCatalogCreated, ProductCatalogChanged and ProductCatalogDeleted messages.
/// </summary>
/// <remarks>
/// Initializes the instance
/// </remarks>
/// <param name="syncFacade">Sync facade</param>     
public class ProductCatalogMessageConsumer(
    ISyncFacade syncFacade,
    IMemoryCache cache) : IConsumer<ProductCatalogCreated>, IConsumer<ProductCatalogChanged>, IConsumer<ProductCatalogDeleted>
{

    /// <summary>
    /// Sync facade
    /// </summary>
    protected ISyncFacade SyncFacade { get; } = syncFacade;

    /// <summary>
    /// Cache
    /// </summary>
    protected IMemoryCache Cache { get; } = cache;

    /// <summary>
    /// Consumes the ProductCatalogCreated message
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<ProductCatalogCreated> context)
    {
        var message = context.Message;
        await SyncFacade.SyncProductCatalogAsync(message.Id);
    }

    /// <summary>
    /// Consumes the ProductCatalogChanged message
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<ProductCatalogChanged> context)
    {
        var message = context.Message;
        await SyncFacade.SyncProductCatalogAsync(message.Id);
        Cache.ClearCache();
    }

    /// <summary>
    /// Consumes the ProductCatalogDeleted message
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task Consume(ConsumeContext<ProductCatalogDeleted> context)
    {
        var message = context.Message;
        await SyncFacade.SyncProductCatalogAsync(message.Id, true);
        Cache.ClearCache();
    }
}
