using System;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Localization;
using ASOL.MessageProvider.Connector;
using ASOL.MessageProvider.Connector.MetadataExchange.FluentApi;
using ASOL.MessageProvider.Contracts;
using ASOL.MessageProvider.Contracts.Primitives;
using ASOL.PlatformStore.Store.Domain.Consts;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.API.MetadataImport;

public class MessageProviderMetadataImporter : IMessageProviderMetadataImporter
{
    public const string MessageSourceCode = StoreMessageProviderCodes.MessageSourceCode;

    public const string ApplicationTemplateCode = StoreMessageProviderCodes.ApplicationTemplateCode;
    public const string ApplicationTemplateHtmlCode = StoreMessageProviderCodes.ApplicationTemplateHtmlCode;

    public const string GeneralTemplateCode = StoreMessageProviderCodes.GeneralTemplateCode;
    public const string GeneralTemplateHtmlCode = StoreMessageProviderCodes.GeneralTemplateHtmlCode;

    public const string PartnerTemplateCode = StoreMessageProviderCodes.PartnerTemplateCode;
    public const string PartnerTemplateHtmlCode = StoreMessageProviderCodes.PartnerTemplateHtmlCode;

    public const string GeneralAndApplicationConfirmationTemplateCode = StoreMessageProviderCodes.GeneralAndApplicationConfirmationTemplateCode;
    public const string GeneralAndApplicationConfirmationTemplateHtmlCode = StoreMessageProviderCodes.GeneralAndApplicationConfirmationTemplateHtmlCode;

    public const string PartnerConfirmationTemplateCode = StoreMessageProviderCodes.PartnerConfirmationTemplateCode;
    public const string PartnerConfirmationTemplateHtmlCode = StoreMessageProviderCodes.PartnerConfirmationTemplateHtmlCode;

    public const string SupportTemplateCode = StoreMessageProviderCodes.SupportTemplateCode;
    public const string SupportTemplateHtmlCode = StoreMessageProviderCodes.SupportTemplateHtmlCode;

    public const string SubscriptionExpiresReminderTemplateCode = StoreMessageProviderCodes.SubscriptionExpiresReminderTemplateCode;
    public const string SubscriptionExpiresReminderTemplateHtmlCode = StoreMessageProviderCodes.SubscriptionExpiresReminderTemplateHtmlCode;

    private readonly ILogger _logger;
    private readonly IMessageProviderClient _mpClient;
    private readonly Assembly _assembly = typeof(MessageProviderMetadataImporter).Assembly;
    private readonly Func<MessageSourceModelCreate> _messageSource;

    public MessageProviderMetadataImporter(ILogger<MessageProviderMetadataImporter> logger, IMessageProviderClient mpClient)
    {
        _logger = logger;
        _mpClient = mpClient;
        _messageSource = () => new MessageSourceModelCreate
        {
            Code = MessageSourceCode,
            Name = new LocalizedValue<string>(("en-US", "PlatformStore Store"), ("cs-CZ", "PlatformStore Store"), ("sk-SK", "PlatformStore Store")),
            IconId = "https://mafstory.blob.core.windows.net/plaza/images/storeorder-icon.svg",
        };
    }

    public Task ImportMetadataAsync(IMessageProviderMetadataConfigurator configurator, MessageAccess access, CancellationToken ct = default)
    {
        switch (access)
        {
            case MessageAccess.Public:
                break;
            default:
                return Task.CompletedTask;
        }

        return configurator
            .RegisterMessageSource(_messageSource)
                .AddRootTemplate(_assembly, $"Resources.MessageProvider.Templates.ContactUs.Application.{ApplicationTemplateCode}.json")
                    .AddChildTemplate(_assembly, $"Resources.MessageProvider.Templates.ContactUs.Application.{ApplicationTemplateHtmlCode}.json")
                .AddRootTemplate(_assembly, $"Resources.MessageProvider.Templates.ContactUs.General.{GeneralTemplateCode}.json")
                    .AddChildTemplate(_assembly, $"Resources.MessageProvider.Templates.ContactUs.General.{GeneralTemplateHtmlCode}.json")
                .AddRootTemplate(_assembly, $"Resources.MessageProvider.Templates.ContactUs.Partner.{PartnerTemplateCode}.json")
                    .AddChildTemplate(_assembly, $"Resources.MessageProvider.Templates.ContactUs.Partner.{PartnerTemplateHtmlCode}.json")
                .AddRootTemplate(_assembly, $"Resources.MessageProvider.Templates.ContactUs.GeneralAndApplicationConfirmation.{GeneralAndApplicationConfirmationTemplateCode}.json")
                    .AddChildTemplate(_assembly, $"Resources.MessageProvider.Templates.ContactUs.GeneralAndApplicationConfirmation.{GeneralAndApplicationConfirmationTemplateHtmlCode}.json")
                .AddRootTemplate(_assembly, $"Resources.MessageProvider.Templates.ContactUs.PartnerConfirmation.{PartnerConfirmationTemplateCode}.json")
                    .AddChildTemplate(_assembly, $"Resources.MessageProvider.Templates.ContactUs.PartnerConfirmation.{PartnerConfirmationTemplateHtmlCode}.json")
                .AddRootTemplate(_assembly, $"Resources.MessageProvider.Templates.ContactUs.Support.{SupportTemplateCode}.json")
                    .AddChildTemplate(_assembly, $"Resources.MessageProvider.Templates.ContactUs.Support.{SupportTemplateHtmlCode}.json")
                .AddRootTemplate(_assembly, $"Resources.MessageProvider.Templates.SubscriptionExpiresReminder.{SubscriptionExpiresReminderTemplateCode}.json")
                    .AddChildTemplate(_assembly, $"Resources.MessageProvider.Templates.SubscriptionExpiresReminder.{SubscriptionExpiresReminderTemplateHtmlCode}.json")
            .SynchronizeAsync(_mpClient, access, /*_logger, */ ct);
    }
}
