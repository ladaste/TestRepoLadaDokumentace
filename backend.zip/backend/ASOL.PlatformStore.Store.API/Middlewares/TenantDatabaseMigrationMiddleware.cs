using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Multitenancy;
using ASOL.Core.Multitenancy.MongoDb;
using ASOL.Core.Multitenancy.Persistence.Migrations;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;

namespace ASOL.PlatformStore.Store.API.Middlewares;

/// <summary>
/// Middleware for initializing the MongoDB model. Data migration, index migration and initial data seeding for the tenant database.
/// </summary>
/// <remarks>
/// Initializes the instance
/// </remarks>
/// <param name="next">Request delegate</param>
public class TenantDatabaseMigrationMiddleware(RequestDelegate next)
{
    private RequestDelegate Next { get; } = next;

    /// <summary>
    /// Initializes the MongoDB model.
    /// </summary>
    /// <param name="context">Http context</param>
    /// <param name="tenantContext">Tenant context</param>
    /// <returns>Task</returns>
    public async Task Invoke(HttpContext context, ITenantContext tenantContext)
    {
        if (!tenantContext.IsTenantValid)
        {
            await Next(context);
            return;
        }

        var dbContext = context.RequestServices.GetRequiredService<ITenantDbContext>();
        var migrationProcessor = context.RequestServices.GetRequiredService<ITenantDbMigrationProcessor>();
        await migrationProcessor.ExecuteTenantMigrationAsync(context.RequestServices, dbContext, context.User, CancellationToken.None);
        await Next(context);
    }


}
