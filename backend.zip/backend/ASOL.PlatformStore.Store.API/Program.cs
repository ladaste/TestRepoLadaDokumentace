using System.Reflection;
using ASOL.Core.Configuration.Extensions;
using ASOL.Core.Telemetry.Client.Logger;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;

namespace ASOL.PlatformStore.Store.API;

public class Program
{
    public static void Main(string[] args)
    {
        CreateHostBuilder(args).Build().Run();
    }

    public static IHostBuilder CreateHostBuilder(string[] args) =>
        Host.CreateDefaultBuilder(args)
            .ConfigureWebHostDefaults(webBuilder =>
            {
                webBuilder.UseStartup<Startup>();
            })
            .ConfigureAppConfiguration((hostBuilderContext, configurationBuilder) =>
            {
                configurationBuilder.AddAsolConfiguration(hostBuilderContext.HostingEnvironment);
                if (hostBuilderContext.HostingEnvironment.IsDevelopment()) // local configuration provider 
                {
                    configurationBuilder.AddJsonFile($"appsettings.{hostBuilderContext.HostingEnvironment.EnvironmentName}.json", optional: true, reloadOnChange: true);
                    configurationBuilder.AddUserSecrets(Assembly.GetExecutingAssembly(), true);
                }
            })
            .AddTelemetryLogger();
}
