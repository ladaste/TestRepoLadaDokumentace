using System;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.PlatformStore.Store.Domain.Consts;
using ASOL.PlatformStore.Store.Facades;
using ASOL.Scheduler.AspNetCore.Providers;
using ASOL.Scheduler.Contracts;
using ASOL.Scheduler.Contracts.Events;

namespace ASOL.PlatformStore.Store.API.MessageConsumers;

/// <summary>
/// Message consumer for subscription checks events. Checks subscription periods and notify users.
/// </summary>
/// <remarks>
/// Initializes the instance
/// </remarks>
/// <param name="storeFacade">Store facade</param>     
public class StoreSchedulerEventProcessor(
    IStoreFacade storeFacade) : ISchedulerEventProcessor
{

    /// <summary>
    /// Store facade
    /// </summary>
    protected IStoreFacade _storeFacade { get; } = storeFacade;


    public bool IsListenedEvent(DataAccessLevel accessLevel, ISchedulerTaskActivatedEvent taskActivated)
    {
        var isPlatformStore = string.Equals(taskActivated.ApplicationCode, SchedulerConfigs.ApplicationCode, StringComparison.OrdinalIgnoreCase);

        return isPlatformStore;
    }

    /// <summary>
    /// Consume the category created event.
    /// </summary>
    /// <param name="context">Consume context</param>
    /// <returns></returns>
    public async Task ProcessEventAsync(DataAccessLevel accessLevel, ISchedulerTaskActivatedEvent taskActivated, SchedulerTaskModel taskDefinition, CancellationToken ct = default)
    {
        if (string.Equals(taskActivated.CustomCode, SchedulerConfigs.CustomCodeNotifySubscriptionPeriodEnds, StringComparison.OrdinalIgnoreCase))
        {
            await _storeFacade.NotifySubscriptionPeriodEndsAsync(ct);
        }
    }
}
