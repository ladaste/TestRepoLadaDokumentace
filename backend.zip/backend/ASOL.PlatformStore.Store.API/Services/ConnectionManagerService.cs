using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.API.Services;

public class ConnectionManagerService : IConnectionManagerService
{
    private static readonly Dictionary<string, HashSet<string>> userMap = [];

    public IEnumerable<string> OnlineUsers => userMap.Keys;

    public void AddConnection(string tenantId, string accountId, string connectionId)
    {
        var key = $"{tenantId}-{accountId}";

        lock (userMap)
        {
            if (!userMap.TryGetValue(key, out var value))
            {
                value = ([]);
                userMap[key] = value;
            }

            value.Add(connectionId);
        }
    }

    public void RemoveConnection(string connectionId)
    {
        lock (userMap)
        {
            foreach (var key in userMap.Keys)
            {
                if (userMap.TryGetValue(key, out var value))
                {
                    if (value.Contains(connectionId))
                    {
                        value.Remove(connectionId);
                        break;
                    }
                }
            }
        }
    }

    public HashSet<string> GetConnections(string tenantId, string accountId)
    {
        var conn = new HashSet<string>();
        var key = $"{tenantId}-{accountId}";

        try
        {
            lock (userMap)
            {
                conn = userMap[key];
            }
        }
        catch
        {
            conn = null;
        }
        return conn;
    }
}
