using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.API.Services;

public interface IConnectionManagerService
{
    void AddConnection(string tenantId, string accountId, string connectionId);
    void RemoveConnection(string connectionId);
    HashSet<string> GetConnections(string tenantId, string accountId);
    IEnumerable<string> OnlineUsers { get; }
}
