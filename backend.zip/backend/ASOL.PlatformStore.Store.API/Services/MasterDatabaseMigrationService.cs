using System;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Identity;
using ASOL.Core.Multitenancy.MongoDb;
using ASOL.Core.Persistence.MongoDb.Migrations;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace ASOL.PlatformStore.Store.API.Services;

/// <summary>
/// Master database migration service as background service. Execute when API service started.
/// </summary>
/// <remarks>
/// Initialize service
/// </remarks>
/// <param name="provider"></param>
public class MasterDatabaseMigrationService(IServiceProvider provider) : BackgroundService
{

    /// <summary>
    /// Global service provider.
    /// </summary>
    protected IServiceProvider Provider { get; } = provider;

    /// <inheritdoc/>
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var scope = Provider.CreateScope();

        var processor = scope.ServiceProvider.GetRequiredService<IDbMigrationProcessor>();
        var dbContextFactory = scope.ServiceProvider.GetRequiredService<IRepoFactory>();
        var dbContext = dbContextFactory.GetOrCreateMasterDbContext();
        var user = ClaimsPrincipalBuilder.CreateClientPrincipal("ASOL.PlatformStore.Store").AddAuthenticateType().Build();
        await processor.ExecuteMigrationAsync(scope.ServiceProvider, dbContext, user, stoppingToken);
    }
}
