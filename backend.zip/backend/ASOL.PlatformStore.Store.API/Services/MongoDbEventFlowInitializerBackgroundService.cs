using System;
using System.Threading;
using System.Threading.Tasks;
using EventFlow.MongoDB.EventStore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.API.Services;

public class MongoDbEventFlowInitializerBackgroundService(
    IServiceProvider serviceProvider,
    ILogger<MongoDbEventFlowInitializerBackgroundService> logger
    ) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        using var scope = serviceProvider.CreateScope();
        var persistenceInitializer = scope.ServiceProvider.GetService<IMongoDbEventPersistenceInitializer>();

        logger.LogInformation("Starting MongoDB index initialization for EventFlow collections...");

        try
        {
            await persistenceInitializer.InitializeAsync(ct);

            logger.LogInformation("MongoDB index initialization for EventFlow collections completed successfully.");
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "An error occurred while initializing MongoDB EventFlow collections.");

            throw;
        }
    }
}
