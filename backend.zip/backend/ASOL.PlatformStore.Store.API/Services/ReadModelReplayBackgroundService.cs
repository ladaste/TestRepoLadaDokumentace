using System;
using System.Threading;
using System.Threading.Tasks;
using ASOL.PlatformStore.Store.MongoDb.Services;
using ASOL.PlatformStore.Store.MongoDb.SubscriptionReadModel;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.API.Services;

public class ReadModelReplayBackgroundService
(
    IServiceProvider serviceProvider,
    ILogger<ReadModelReplayBackgroundService> logger
)
    : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var scope = serviceProvider.CreateScope();
        var readModelReplay = scope.ServiceProvider.GetService<ReadModelReplayService>();

        logger.LogInformation("Replaying read models");

        foreach (var replay in RegisteredReadModels.All)
        {
            await replay(readModelReplay, stoppingToken);
        }

        logger.LogInformation("Replaying read models completed");
    }
}
