using System;
using System.Threading;
using System.Threading.Tasks;
using ASOL.PlatformStore.Store.Domain.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace ASOL.PlatformStore.Store.API.Services;

public class SchedulerInitializationService
(
    IServiceProvider provider
)
    : BackgroundService
{
    protected IServiceProvider Provider { get; } = provider;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var scope = Provider.CreateScope();
        var schedulerService = scope.ServiceProvider.GetRequiredService<ISchedulerInitializationService>();
        await schedulerService.InitializeSchedulerAsync(stoppingToken);
    }
}
