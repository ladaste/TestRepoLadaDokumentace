using System;
using ASOL.Core.ApiController.Captcha;
using ASOL.Core.ApiController.Extensions;
using ASOL.Core.ApiController.Options;
using ASOL.Core.ApiController.Swashbuckle.Extensions;
using ASOL.Core.Localization;
using ASOL.Core.Multitenancy.AspNetCore.Extensions;
using ASOL.Core.Persistence.MongoDb.Options;
using ASOL.Core.Versioning;
using ASOL.IdentityManager.AspNetCore.Extensions;
using ASOL.PlatformStore.Store.API.CustomSetup;
using ASOL.PlatformStore.Store.API.Hubs;
using ASOL.PlatformStore.Store.API.Middlewares;
using ASOL.PlatformStore.Store.API.Services;
using ASOL.PlatformStore.Store.Infrastructure.CustomSetup;
using ASOL.PlatformStore.Store.MongoDb;
using Hellang.Middleware.ProblemDetails;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;

namespace ASOL.PlatformStore.Store.API;

/// <summary>
/// Startup
/// </summary>
/// <remarks>
/// Initializes the instance
/// </remarks>
/// <param name="configuration"></param>
public class Startup
(
    IConfiguration configuration
)
{
    /// <summary>
    /// App configuration
    /// </summary>
    public IConfiguration Configuration { get; } = configuration;

    /// <summary>
    /// Configure services
    /// </summary>
    /// <param name="services"></param>
    public virtual void ConfigureServices(IServiceCollection services)
    {
        services.AddClaimTransformation();
        services.AddAutoMapper(typeof(Startup).Assembly, typeof(MappingProfile).Assembly);
        services.AddCorsAndControllers();
        services.AddReverseProxy(Configuration);

        services.AddMultitenacySetup();

        services.ConfigureOptions<ProblemDetailsOptionsCustomSetup>();

        services.AddLocalizationSupport();

        ProblemDetailsExtensions.AddProblemDetails(services);
        services.AddApiVersioningWithExplorer(Configuration);
        services.AddSwaggerInterface(Configuration);
        services.AddTelemetryLogging(Configuration);

        services.AddFacades();
        services.AddProcessingQueryAndCommands();
        services.AddMessagingAndHostedService(Configuration);
        services.AddMongoDb(Configuration.GetSection(nameof(MongoDbConnectionOptions)));
        services.AddServices();
        services.AddConnectors(Configuration);
        services.AddDomainServices(Configuration);
        services.AddInfrastractureServices(Configuration);
        services.AddHostedService<SchedulerInitializationService>();

        services.AddSignalR();
        services.AddSingleton<IConnectionManagerService, ConnectionManagerService>();
        services.AddPlatformHealthChecks<Startup>(Configuration);
        services.AddIdentityManager(Configuration, ["/hubs/application"])
            .SetApplicationName(new LocalizedValue<string>(("en-US", "Platform Store")))
            .SetApiAuthorization(opt =>
            {
                opt.AddAssembly(typeof(Startup).Assembly);
            })
            .SetBuiltInRightObjects(typeof(Startup).Assembly, "Metadata.IdentityManager.RightObjects.json")
            .SetBuiltInRoles(typeof(Startup).Assembly, "Metadata.IdentityManager.Roles.json")
            .SetBuiltInRoleAuthorizations(typeof(Startup).Assembly, "Metadata.IdentityManager.RoleAuthorizations.json");

        services.Configure<GoogleReCaptchaOptions>(Configuration.GetSection("GoogleReCaptchaOptions"));
        services.AddHttpClient<ICaptchaValidator, GoogleReCaptchaValidator>();
        services.AddSingleton(TimeProvider.System);
    }

    public virtual void Configure(IApplicationBuilder app, IWebHostEnvironment env, IOptions<ReverseProxyOptions> reverseProxyOptions)
    {
        app.UseReverseProxy(reverseProxyOptions);
        app.UseProblemDetails();

        if (!env.IsDevelopment())
        {
            app.UseHsts();
        }

        app.UseLocalizationSupport();

        app.UseRouting();
        app.UseCors(CorsPolicyNames.Api);
        app.UseAuthentication();
        app.UseMultitenancy();
        app.UseIdentityManager();
        app.UseMiddleware<TenantDatabaseMigrationMiddleware>(); // enable tenant db migration
        app.UseSwagger(option =>
        {
            option.SetSwaggerRouteTemplate(app.ApplicationServices);
            option.AddReverseProxyHosting(reverseProxyOptions);
        });
        app.UseSwaggerUI(options =>
        {
            options.GenerateSwaggerEndpoints(app.ApplicationServices);
            options.DocumentTitle = "PlatformStore Store API";
            options.AddPlatformSecurity(options.DocumentTitle);
            options.DisplayRequestDuration();
        });
        app.UseEndpoints(endpoints =>
        {
            endpoints.MapControllers();
            endpoints.MapHub<ApplicationHub>("/hubs/application");
            endpoints.MapPlatformHealthChecks();
            endpoints.MapVersionHealthChecks();
        });
    }
}
