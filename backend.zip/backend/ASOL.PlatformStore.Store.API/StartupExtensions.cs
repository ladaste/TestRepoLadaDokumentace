using ASOL.ContentManager.Connector.Extensions;
using ASOL.ContentManager.Connector.Options;
using ASOL.Core.ApiConnector.Extensions;
using ASOL.Core.ApiController.Swashbuckle.Extensions;
using ASOL.Core.Identity.Options;
using ASOL.Core.Multitenancy.AspNetCore.Extensions;
using ASOL.Core.Processing;
using ASOL.Core.Serialization.Configuration;
using ASOL.Core.Telemetry.Client.AspNetCore;
using ASOL.Core.Versioning;
using ASOL.CustomAttributes.Connector.Extensions;
using ASOL.CustomAttributes.Connector.Options;
using ASOL.IdentityProvider.AspNetCore.Extensions;
using ASOL.IdentityProvider.Connector.Options;
using ASOL.MessageProvider.AspNetCore.Extensions;
using ASOL.MessageProvider.Connector.Extensions;
using ASOL.MessageProvider.Connector.Options;
using ASOL.PlatformStore.Domain.Options;
using ASOL.PlatformStore.Order.Connector.Extensions;
using ASOL.PlatformStore.Order.Connector.Options;
using ASOL.PlatformStore.PDM.Connector.Extensions;
using ASOL.PlatformStore.PDM.Connector.Options;
using ASOL.PlatformStore.Store.API.CustomSetup;
using ASOL.PlatformStore.Store.API.MetadataImport;
using ASOL.PlatformStore.Store.API.Services;
using ASOL.PlatformStore.Store.Contracts.LeftPanels;
using ASOL.PlatformStore.Store.Contracts.LeftPanels.Updates;
using ASOL.PlatformStore.Store.Domain.CommandHandlers;
using ASOL.PlatformStore.Store.Domain.Helpers;
using ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;
using ASOL.PlatformStore.Store.Domain.Options;
using ASOL.PlatformStore.Store.Domain.QueryHandlers;
using ASOL.PlatformStore.Store.Domain.Services;
using ASOL.PlatformStore.Store.Domain.Services.AllPurchased;
using ASOL.PlatformStore.Store.Domain.Services.Helpdesk;
using ASOL.PlatformStore.Store.Domain.Services.Helpdesk.Options;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.AccessStrategies;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Interfaces;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Sagas;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Services;
using ASOL.PlatformStore.Store.Facades;
using ASOL.PlatformStore.Store.Infrastructure.Facades;
using ASOL.PlatformStore.Store.Infrastructure.Services.Scheduler;
using ASOL.PlatformStore.Store.Infrastructure.SubscriptionRoot.Services;
using ASOL.PlatformStore.Store.MongoDb.Queries;
using ASOL.PlatformStore.Store.MongoDb.SubscriptionReadModel;
using ASOL.Scheduler.Connector.Extensions;
using ASOL.Scheduler.Connector.Options;
using ASOL.SubjectManager.Connector.Extensions;
using ASOL.SubjectManager.Connector.Options;
using Asp.Versioning;
using EventFlow.Extensions;
using EventFlow.MongoDB.Extensions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using ApiVersioningOptions = ASOL.Core.Versioning.ApiVersioningOptions;

namespace ASOL.PlatformStore.Store.API;

/// <summary>
/// Startup configuration methods
/// </summary>
public static class StartupExtensions
{
    /// <summary>
    /// Cors/Controllers setup
    /// </summary>
    /// <param name="services"></param>
    /// <returns></returns>
    public static IServiceCollection AddCorsAndControllers(this IServiceCollection services)
    {
        services.AddCors(options =>
        {
            options.AddPolicy(CorsPolicyNames.Api, policy =>
            {
                policy.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod();
            });
            options.AddDefaultPolicy(p => p.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
        });

        services.AddControllers(o =>
            {
                // optional tweaks to built-in mvc non-success http responses
                //o.Conventions.Add(new NotFoundResultApiConvention());
                //o.Conventions.Add(new ProblemDetailsResultApiConvention());

                // decorate Controllers to distinguish SwaggerDoc (v1, v2, etc.)
                //o.Conventions.Add(new ApiExplorerGroupPerVersionConvention())
            })
            //.SetCompatibilityVersion(CompatibilityVersion.Latest/*Version_3_1*/)
            .AddNewtonsoftJson(options =>
            {
                new JsonSerializationConfiguration().Configure(options.SerializerSettings); //core settings
                options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
            });

        return services;
    }

    /// <summary>
    /// Setup multitenancy
    /// </summary>
    /// <param name="services"></param>
    /// <returns></returns>
    public static IServiceCollection AddMultitenacySetup(this IServiceCollection services)
    {
        services.AddMultitenancy()
            .AddAuthorization();

        return services;
    }

    /// <summary>
    /// Api version
    /// </summary>
    /// <param name="services"></param>
    /// <param name="configuration"></param>
    /// <returns></returns>
    public static IServiceCollection AddApiVersioningWithExplorer(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<ApiVersioningOptions>(configuration.GetSection(nameof(ApiVersioningOptions)));
        var apiVersioningBuilder = services.AddApiVersioning(options =>
        {
            options.ReportApiVersions = true;
            options.DefaultApiVersion = new ApiVersion(1, 0);
            options.AssumeDefaultVersionWhenUnspecified = true;
            // Use whatever reader you want
            options.ApiVersionReader = ApiVersionReader.Combine(new UrlSegmentApiVersionReader(),
                new HeaderApiVersionReader("x-api-version"),
                new MediaTypeApiVersionReader("x-api-version"));
        });

        apiVersioningBuilder.AddMvc(options =>
        {
        });

        apiVersioningBuilder.AddApiExplorer(options =>
        {
            // add the versioned api explorer, which also adds IApiVersionDescriptionProvider service
            // note: the specified format code will format the version as "'v'major[.minor][-status]"
            options.GroupNameFormat = "'v'VVV";

            // note: this option is only necessary when versioning by url segment. the SubstitutionFormat
            // can also be used to control the format of the API version in route templates
            options.SubstituteApiVersionInUrl = true;
        });
        return services;
    }

    /// <summary>
    /// Initialized the telemetry
    /// </summary>
    /// <param name="services"></param>
    /// <param name="configuration"></param>
    /// <returns></returns>
    public static IServiceCollection AddTelemetryLogging(this IServiceCollection services, IConfiguration configuration)
    {
        var telemetryOptions = configuration.GetSection("Telemetry").Get<TelemetryOptions>();
        services.AddTelemetry(telemetryOptions);
        return services;
    }

    /// <summary>
    /// Swagger setup
    /// </summary>
    /// <param name="services">Service collection</param>
    /// <param name="configuration">Configuration</param>
    /// <returns>Service collection</returns>
    public static IServiceCollection AddSwaggerInterface(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddSwaggerGen(options =>
        {
            //it is necessary to build a temporary service provider here, because no one has been created yet
            var sp = services.BuildServiceProvider();
            options.GenerateSwaggerDocs(sp);
            options.OperationFilter<ApiVersionOperationFilter>();

            var ssoAuth = configuration.GetSection(SsoAuthOptions.DefaultSectionName).Get<SsoAuthOptions>();
            options.AddPlatformSecurity(ssoAuth);

            //options.DocumentFilter<CustomApiVersionDocumentFilter>("custom argument");
            options.DocInclusionPredicate();
            options.IncludeXmlComments<Startup>();

            options.UseOneOfForPolymorphism(builder =>
            {
                builder
                    .MapPolymorphismForModel<PanelItemModel>()
                    .MapDiscriminatorValue<PanelItemModel>("PanelItem")
                    .MapDiscriminatorValue<ApplicationPanelItemModel>("ApplicationPanelItem")
                    .MapPolymorphismForModel<PanelUpdateModel>()
                    .MapDiscriminatorValue<MoveItemModel>("MoveItem")
                    .MapDiscriminatorValue<CreateCustomItemModel>("CreateCustomItem");
            });
        });
        services.AddSwaggerGenNewtonsoftSupport();
        //services.AddSwaggerGenJsonKnownTypesSupport();

        return services;
    }

    /// <summary>
    /// Adds Facades to DI
    /// </summary>
    /// <param name="services"></param>
    /// <returns></returns>
    public static IServiceCollection AddFacades(this IServiceCollection services)
    {
        services.AddTransient<IStoreFacade, StoreFacade>();
        services.AddTransient<ISyncFacade, SyncFacade>();
        services.AddTransient<IMessageFacade, MessageFacade>();
        services.AddTransient<ICacheFacade, CacheFacade>();
        services.AddTransient<IProductCatalogCodebooksFacade, ProductCatalogCodebooksFacade>();
        services.AddTransient<ILeftPanelFacade, LeftPanelFacade>();
        return services;
    }

    /// <summary>
    /// Adds services to DI
    /// </summary>
    /// <param name="services"></param>
    /// <returns></returns>
    public static IServiceCollection AddServices(this IServiceCollection services)
    {
        services.AddHostedService<MasterDatabaseMigrationService>();
        services.AddScoped<IStoreAccessControlService, StoreAccessControlService>();
        services.AddScoped<ISchedulerInitializationService, SchedulerService>();
        services.AddHostedService<ReadModelReplayBackgroundService>();
        services.AddHostedService<MongoDbEventFlowInitializerBackgroundService>();
        return services;
    }

    /// <summary>
    /// Adds Queries and Commands to DI
    /// </summary>
    /// <param name="services"></param>
    /// <returns></returns>
    public static IServiceCollection AddProcessingQueryAndCommands(this IServiceCollection services)
    {
        // auto register all commands/queries and their handlers.
        services.Scan(scan =>
        {
            scan.FromAssembliesOf(typeof(InvalidateStoreCacheCommandHandler))
                .AddClasses(classes => classes.AssignableTo(typeof(ICommandHandler<,>)))
                .AsImplementedInterfaces()
                .WithTransientLifetime();
            scan.FromAssembliesOf(typeof(SyncProductCatalogCommandHandler))
                .AddClasses(classes => classes.AssignableTo(typeof(ICommandHandler<>)))
                .AsImplementedInterfaces()
                .WithTransientLifetime();
            scan.FromAssembliesOf(typeof(SyncAttributeGroupCommandHandler))
                .AddClasses(classes => classes.AssignableTo(typeof(ICommandHandler<>)))
                .AsImplementedInterfaces()
                .WithTransientLifetime();
            scan.FromAssembliesOf(typeof(GetStoreItemsSearchQueryHandler))
                .AddClasses(classes => classes.AssignableTo(typeof(IQueryHandler<,>)))
                .AsImplementedInterfaces()
                .WithTransientLifetime();
        });

        services.AddScoped<ICommandHandlerProvider, CommandHandlerProvider>();
        services.AddScoped<ICommandProcessor, CommandProcessor>();
        services.AddScoped<IQueryHandlerProvider, QueryHandlerProvider>();
        services.AddScoped<IQueryProcessor, QueryProcessor>();

        return services;
    }

    /// <summary>
    /// Adds connectors to DI
    /// </summary>
    /// <param name="services"></param>
    /// <returns></returns>
    public static IServiceCollection AddConnectors(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<HelpdeskClientOptions>(configuration.GetSection(nameof(HelpdeskClientOptions)));
        services.Configure<CustomAttributesClientOptions>(configuration.GetSection(nameof(CustomAttributesClientOptions)));
        services.Configure<PlatformStorePdmClientOptions>(configuration.GetSection(nameof(PlatformStorePdmClientOptions)));
        services.Configure<PlatformStoreOrderClientOptions>(configuration.GetSection(nameof(PlatformStoreOrderClientOptions)));
        services.Configure<MessageProviderClientOptions>(configuration.GetSection(nameof(MessageProviderClientOptions)));
        services.Configure<SubjectManagerClientOptions>(configuration.GetSection(nameof(SubjectManagerClientOptions)));
        services.Configure<ContentManagerClientOptions>(configuration.GetSection(nameof(ContentManagerClientOptions)));
        services.Configure<IdentityProviderClientOptions>(configuration.GetSection(nameof(IdentityProviderClientOptions)));
        services.Configure<SchedulerClientOptions>(configuration.GetSection(nameof(SchedulerClientOptions)));

        services.Configure<AppUrlOptions>(configuration.GetSection(AppUrlOptions.DefaultSectionName));

        services.AddSchedulerClient();
        services.AddApiConnectorInfrastructure();
        services.AddCustomAttributesClient();
        services.AddPlatformStorePdmClient();
        services.AddPlatformStoreOrderClient();
        services.AddMessageProviderClient();
        services.AddSubjectManagerClient();
        services.AddContentManagerClient();
        services.AddIdentityProviderClient();

        services.AddMessageProviderMetadataImporter<MessageProviderMetadataImporter>();

        return services;
    }

    /// <summary>
    /// Adds domain services to DI
    /// </summary>
    /// <param name="services"></param>
    /// <returns></returns>
    public static IServiceCollection AddDomainServices(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddScoped<IMappingService, MappingService>();
        services.AddScoped<IHelpdeskService, HelpdeskService>();
        services.AddScoped<ISyncAllPurchasedDataService, SyncAllPurchasedDataService>();
        services.AddScoped<IImpersonateService, ImpersonateService>();
        services.AddScoped<IRightsObjectGroupService, RightsObjectGroupService>();
        services.AddTransient<ValidationHelper>();
        services.AddTransient<SubscriptionLicenseReadModelLocator>();
        services.AddTransient<SubscriptionOrderIndexReadModelLocator>();
        services.AddTransient<SubscriptionBillingItemReadModelLocator>();
        services.AddMemoryCache();
        services.AddLeftPanel();

        services.Configure<NavigationServiceOptions>(configuration.GetSection(nameof(NavigationServiceOptions)));

        services.AddEventFlow(ef =>
        {
            ef.AddDefaults(typeof(Subscription).Assembly); // add all eventflow implementation from domain assemblies (commands, commandhandlers, events, aggregates, snapshots)
            ef.AddQueryHandlers(typeof(GetSubscriptionSummariesQueryHandler).Assembly);
            ef.AddSagas(typeof(SubscriptionSaga).Assembly);
            ef.AddSagaLocators(typeof(SubscriptionSagaLocator).Assembly);
            ef.ConfigureMongoDb();
            ef.UseMongoDbEventStore();
            ef.UseMongoDbSnapshotStore();
            // Here you can add read models and their locators
            ef.UseMongoDbReadModel<SubscriptionOrderIndexReadModel, SubscriptionOrderIndexReadModelLocator>();
            ef.UseMongoDbReadModel<SubscriptionOrganizationIndexReadModel>();
            ef.UseMongoDbReadModel<SubscriptionCardReadModel>();
            ef.UseMongoDbReadModel<SubscriptionDetailReadModel>();
            ef.UseMongoDbReadModel<SubscriptionSummaryReadModel>();
            ef.UseMongoDbReadModel<SubscriptionLicenseReadModel, SubscriptionLicenseReadModelLocator>();
            ef.UseMongoDbReadModel<SubscriptionBillingItemReadModel, SubscriptionBillingItemReadModelLocator>();
            // Subscribers for event handling
            ef.AddSubscribers(typeof(SubscriptionDiscountBulkUpdateHandler));
        });

        return services;
    }

    /// <summary>
    /// Adds infrastructure services to DI
    /// </summary>
    /// <param name="services"></param>
    /// <param name="configuration"></param>
    /// <returns></returns>
    public static IServiceCollection AddInfrastractureServices(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddScoped<SubscriptionOrderService>();
        services.AddScoped<SubscriptionImportService>();
        services.AddScoped<SubscriptionOrderNoteService>();
        services.AddScoped<SubscriptionOrderResponsiblePersonService>();
        services.AddScoped<SubscriptionOrderStatusService>();
        services.AddScoped<SubscriptionSolutionPartnerService>();
        services.AddScoped<SubscriptionOrganizationRelationshipService>();
        services.AddScoped<SubscriptionImportOrchestrator>();
        services.AddScoped<SubscriptionSolutionStatusService>();
        services.AddScoped<SubscriptionDetailResponseService>();
        services.AddScoped<SubscriptionLicenseService>();
        services.AddScoped<SubscriptionLicenseDomainService>();
        services.AddScoped<ISubscriptionTenantProvider, SubscriptionTenantProvider>();
        services.AddScoped<SystemSubscriptionReadAccess>();
        services.AddScoped<SubscriptionService>();
        services.AddScoped<SubscriptionBillingItemService>();
        services.AddScoped<ISubscriptionOrganizationService, SubscriptionOrganizationService>();
        services.AddScoped<AllSubscriptionsReadAccess>();

        return services;
    }
}
