using System;
using ASOL.Core.Messaging.Extensions;
using ASOL.Core.Messaging.RabbitMq.Extensions;
using ASOL.Core.Messaging.RabbitMq.Options;
using ASOL.Core.MetadataExchange;
using ASOL.Core.MetadataExchange.Extensions;
using ASOL.Core.Multitenancy.Messaging.Extensions;
using ASOL.Core.Serialization.Configuration;
using ASOL.PlatformStore.Store.API.MessageConsumers;
using ASOL.PlatformStore.Store.Domain.Publishers;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Publishers;
using ASOL.PlatformStore.Store.Infrastructure.MessageConsumers;
using ASOL.PlatformStore.Store.Infrastructure.Publishers;
using ASOL.PlatformStore.Store.Infrastructure.SubscriptionRoot.Consumers;
using ASOL.PlatformStore.Store.Infrastructure.SubscriptionRoot.Publishers;
using ASOL.Scheduler.AspNetCore.Consumers;
using ASOL.Scheduler.AspNetCore.Providers;
using MassTransit;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace ASOL.PlatformStore.Store.API;

/// <summary>
/// Initialize messaging infrastructure extensions.
/// </summary>
public static class StartupMessaging
{
    /// <summary>
    /// Configuration path to setup of Message broker (RabbitMQ).
    /// </summary>
    public const string RabbitMqConfigurationSectionName = "Messaging:RabbitMq";

    /// <summary>
    /// Add messaging and message broker connection hosted service.
    /// </summary>
    /// <param name="services"></param>
    /// <param name="configuration"></param>
    /// <returns></returns>
    public static IServiceCollection AddMessagingAndHostedService(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<RabbitMqConnectionOptions>(configuration.GetSection(RabbitMqConfigurationSectionName));
        services.AddMultitenancyMessaging();
        services.AddMessaging(config =>
        {
            config.AddConsumers(
                typeof(MetadataAcceptConsumer).Assembly, // Add all consumers in core metadataexchange
                typeof(Startup).Assembly, //  Add all consumers in API assembly
                typeof(EventPublisherBase).Assembly, //  Add all consumers in infrastructure assembly
                typeof(ISchedulerEventProcessor).Assembly);

            config.AddMetadataExchangeConsumers();
            config.UsingRabbitMq(UseRabbitMq);
        });

        services.AddMetadataExchange();
        services.AddScoped<IStoreEventPublisher, StoreEventPublisher>();
        services.AddScoped<ISchedulerEventProcessor, StoreSchedulerEventProcessor>();
        services.AddScoped<IImportSubscriptionEventPublisher, ImportSubscriptionEventPublisher>();
        services.AddScoped<ISubscriptionLicenseEventPublisher, SubscriptionLicenseEventPublisher>();

        return services;
    }

    /// <summary>
    /// Create RabbitMQ connection and configuration to messaging.
    /// </summary>
    private static void UseRabbitMq(IBusRegistrationContext regContext, IRabbitMqBusFactoryConfigurator cfg)
    {
        var configuration = regContext.GetRequiredService<IConfiguration>();
        var serviceName = configuration?["ServiceName"] ?? throw new ArgumentNullException(nameof(regContext), "ServiceName is not defined in AppSettings.");

        cfg.Host(regContext.GetRequiredService<IConfiguration>(), RabbitMqConfigurationSectionName);

        cfg.ConfigureMetadataExchangeAccept(serviceName, regContext);

        cfg.ConfigureJsonSerializer(jsonConfiguration =>
        {
            new JsonSerializationConfiguration().Configure(jsonConfiguration);
            return jsonConfiguration;
        });

        cfg.ReceiveEndpoint(serviceName, ep =>
        {
            ep.UseServiceScope(regContext);
            ep.UseIdentity();
            ep.UseMultitenancy();
            ep.ConcurrentMessageLimit = 1;
            ep.Consumer<ProductCatalogMessageConsumer>(regContext);
            ep.Consumer<CategoryMessageConsumer>(regContext);
            ep.Consumer<ApplicationMessageConsumer>(regContext);
            ep.Consumer<AttributeGroupMessageConsumer>(regContext);
            ep.Consumer<HelpDeskMessageConsumer>(regContext);
            ep.Consumer<AllPurchasedDataSyncConsumer>(regContext);
        });

        cfg.ReceiveEndpoint($"{serviceName}_MassActionsAllPurchasedItems", ep =>
        {
            ep.UseServiceScope(regContext);
            ep.UseIdentity();
            ep.UseMultitenancy();
            ep.ConcurrentMessageLimit = 1;

            ep.Consumer<MassActionsAllPurchasedDataSyncConsumer>(regContext, epx =>
            {
                epx.UseConcurrentMessageLimit(10); //ConcurrencyMessageLimit 10
                epx.UseRateLimit(30, TimeSpan.FromMinutes(1)); //RateLimitPerMinute 30
            });
        });

        cfg.ReceiveEndpoint($"{serviceName}.ProcessLatestSalesInvoiceItems", ep =>
        {
            ep.UseServiceScope(regContext);
            ep.UseIdentity();
            ep.UseMultitenancy();
            ep.Consumer<LatestSalesInvoiceItemConsumer>(regContext, epx =>
            {
                epx.UseConcurrentMessageLimit(10);
                epx.UseRateLimit(1200, TimeSpan.FromMinutes(1));
            });
        });

        cfg.ReceiveEndpoint($"{serviceName}.ProcessSalesInvoiceItemGenerated", ep =>
        {
            ep.UseServiceScope(regContext);
            ep.UseIdentity();
            ep.UseMultitenancy();
            ep.Consumer<SalesInvoiceItemGeneratedConsumer>(regContext, epx =>
            {
                epx.UseConcurrentMessageLimit(10);
                epx.UseRateLimit(1200, TimeSpan.FromMinutes(1));
            });
        });

        cfg.ReceiveEndpoint($"{serviceName}.ProcessSkippedBillingItemProcessed", ep =>
        {
            ep.UseServiceScope(regContext);
            ep.UseIdentity();
            ep.UseMultitenancy();
            ep.Consumer<SkippedBillingItemProcessedConsumer>(regContext, epx =>
            {
                epx.UseConcurrentMessageLimit(10);
                epx.UseRateLimit(1200, TimeSpan.FromMinutes(1));
            });
        });

        cfg.ReceiveEndpoint($"{serviceName}.ProcessSalesInvoiceItemDeleted", ep =>
        {
            ep.UseServiceScope(regContext);
            ep.UseIdentity();
            ep.UseMultitenancy();
            ep.Consumer<SalesInvoiceItemDeletedConsumer>(regContext, epx =>
            {
                epx.UseConcurrentMessageLimit(10);
                epx.UseRateLimit(1200, TimeSpan.FromMinutes(1));
            });
        });

        cfg.ReceiveEndpoint($"{serviceName}.SchedulerEvents", ep =>
        {
            ep.UseServiceScope(regContext);
            ep.UseIdentity();
            ep.UseMultitenancy();
            ep.Consumer<SchedulerEventConsumer>(regContext, epx =>
            {
                epx.UseConcurrentMessageLimit(10);
                epx.UseRateLimit(1200, TimeSpan.FromMinutes(1));
            });
        });

        cfg.ReceiveEndpoint($"{serviceName}.ImportSubscription", ep =>
        {
            ep.UseServiceScope(regContext);
            ep.UseIdentity();
            ep.UseMultitenancy();
            ep.Consumer<ImportSubscriptionConsumer>(regContext, epx =>
            {
                epx.UseConcurrentMessageLimit(5);
                epx.UseRateLimit(15, TimeSpan.FromMinutes(1));
            });
        });

        cfg.ReceiveEndpoint($"{serviceName}.Subscription", ep =>
        {
            ep.UseServiceScope(regContext);
            ep.UseIdentity();
            ep.UseMultitenancy();
            ep.ConcurrentMessageLimit = 1;
            ep.Consumer<OrderConsumer>(regContext);
            ep.Consumer<OrderNoteConsumer>(regContext);
            ep.Consumer<OrganizationRelationshipConsumer>(regContext);
        });
    }
}
