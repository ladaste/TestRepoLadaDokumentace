using System.ComponentModel.DataAnnotations;

namespace ASOL.PlatformStore.Store.API.Validation;

public sealed class NotEmptyOrWhiteSpaceAttribute : ValidationAttribute
{
    public NotEmptyOrWhiteSpaceAttribute()
        : base("{0} is required.") { }

    protected override ValidationResult IsValid(object value, ValidationContext validationContext)
    {
        if (value is string s && !string.IsNullOrWhiteSpace(s))
        {
            return ValidationResult.Success;
        }

        var message = FormatErrorMessage(validationContext.DisplayName ?? "Id");
        return new ValidationResult(message);
    }
}
