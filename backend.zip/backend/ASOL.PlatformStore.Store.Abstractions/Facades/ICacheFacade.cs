using System.Threading;
using System.Threading.Tasks;
using ASOL.PlatformStore.Store.Contracts.Primitives;

namespace ASOL.PlatformStore.Store.Facades;

/// <summary>
/// Cache facade
/// </summary>
public interface ICacheFacade
{
    /// <summary>
    /// Invalidates store cachce.
    /// </summary>
    /// <param name="accountId">AccountId</param>
    /// <param name="tenantId">TenantId</param>
    /// <param name="ct">Cancellation token</param>
    /// <returns></returns>
    Task InvalidateCacheAsync(InvalidateCacheEventType? eventType = null, string tenantId = null, string accountId = null, CancellationToken ct = default);
}
