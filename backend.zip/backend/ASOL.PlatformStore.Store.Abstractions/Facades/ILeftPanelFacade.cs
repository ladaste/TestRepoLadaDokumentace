using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.PlatformStore.Store.Contracts.LeftPanels;

#nullable enable

namespace ASOL.PlatformStore.Store.Facades;

public interface ILeftPanelFacade
{
    Task<CollectionResult<PanelItemModel>> GetAllApplicationsItemsAsync(
        PagingFilter? pagingFilter,
        CancellationToken cancellationToken);

    Task<LeftPanelModel> GetPanelAsync(
        PagingFilter? quickAccessPagination,
        PagingFilter? allAppsPagination,
        CancellationToken cancellationToken);

    Task<CollectionResult<PanelItemModel>> GetQuickAccessItemsAsync(
        PagingFilter? pagingFilter,
        CancellationToken cancellationToken);

    Task UpdatePanelAsync(
        UpdatePanelRequestModel request,
        CancellationToken cancellationToken);
}
