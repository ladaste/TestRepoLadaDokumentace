using System.Threading;
using System.Threading.Tasks;
using ASOL.PlatformStore.Store.Contracts;

namespace ASOL.PlatformStore.Store.Facades;

public interface IMessageFacade
{
    Task ContactUsPublicAsync(ContactUsPublicModel message, CancellationToken ct = default);

    Task ContactUsAsync(ContactUsModel message, CancellationToken ct = default);

    Task<bool> TriggerHelpDeskTickets(
        string subject,
        string message,
        string applicationCode,
        string currentUrl,
        CancellationToken ct = default);
}
