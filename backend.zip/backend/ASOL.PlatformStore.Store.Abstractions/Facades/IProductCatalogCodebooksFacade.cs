using System.Threading;
using System.Threading.Tasks;
using ASOL.PlatformStore.Store.Contracts;

namespace ASOL.PlatformStore.Store.Facades;

public interface IProductCatalogCodebooksFacade
{
    Task<ProductCatalogCodebooksModel> GetProductCatalogCodebooksAsync(CancellationToken ct = default);
}
