using System;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Domain.Contracts;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.PlatformStore.Store.Contracts;

namespace ASOL.PlatformStore.Store.Facades;

public interface IStoreFacade
{
    Task<CollectionResult<StoreItemModel>> GetStoreItemsSimilarAsync(
        string sourceItemId,
        BaseEntityFilter baseEntityFilter,
        PagingFilter pagingFilter,
        CancellationToken ct = default);

    Task<SearchResultModel> GetStoreItemsSearchAsync(
        SearchParametersModel searchParameters,
        BaseEntityFilter baseEntityFilter,
        PagingFilter pagingFilter,
        CancellationToken ct = default);

    Task<StoreItemDetailModel> GetStoreItemDetailByIdAsync(
        string storeItemId,
        BaseEntityFilter baseEntityFilter,
        CancellationToken ct = default);

    Task<CollectionResult<StoreItemWithLicenceInformationModel>> GetAllPurchasedStoreItemsSearchAsync(
        SearchParametersModel searchParameters,
        BaseEntityFilter baseEntityFilter,
        PagingFilter pagingFilter,
        CancellationToken ct = default);

    Task<CollectionResult<SubscriptionsSummaryModel>> GetSubscriptionsAsync(
        SearchSubscriptionsModel searchParameters,
        BaseEntityFilter baseEntityFilter,
        PagingFilter pagingFilter,
        CancellationToken ct = default);

    Task<CollectionResult<AllPurchasedDataSummaryModel>> GetAllPurchasedDataAsync(
        SearchAllPurchasedDataModel searchParameters,
        BaseEntityFilter baseEntityFilter,
        PagingFilter pagingFilter,
        CancellationToken ct = default);

    Task<OrderLicenceInformation> GetOrderLicenceInformationAsync(
        string productCatalogId,
        CancellationToken ct = default);

    Task<CollectionResult<HelpdeskDataModel>> GetAllHelpdeskDataAsync(CancellationToken ct = default);

    Task<string> RequestSyncAllPurchasedDataAsync(string tenantId = null, CancellationToken ct = default);

    Task<bool> SyncAllPurchasedTenantDataAsync(Guid requestId, CancellationToken ct = default);

    Task<bool> SyncAllPurchasedDataApplicationLicenseChangedAsync(string applicationCode,
        string editionCode,
        string licenseId,
        CancellationToken ct = default);

    Task<bool> SyncAllPurchasedDataLicenseRoleMemberChangedAsync(string accountId,
        bool assigned,
        string licenseCode,
        string licenseId,
        string roleCode,
        string roleId,
        CancellationToken ct = default);

    Task<bool> SyncAllPurchasedDataOrganizationRelationshipCreatedAsync(DataAccessLevel accessLevel,
        string organizationRelationshipId,
        CancellationToken ct = default);

    Task<bool> SyncAllPurchasedDataOrganizationRelationshipChangedAsync(DataAccessLevel accessLevel,
        string organizationRelationshipId,
        string organizationRelationshipDataId,
        CancellationToken ct = default);

    Task<bool> SyncAllPurchasedDataOrganizationRelationshipDeletedAsync(DataAccessLevel accessLevel,
        string organizationRelationshipId,
        CancellationToken ct = default);

    Task<bool> SyncAllPurchasedDataTenantReleasedAsync(string tenantId,
        CancellationToken ct = default);

    Task<bool> SyncAllPurchasedDataProductCatalogChangedAsync(string ProductCatalogId,
        CancellationToken ct = default);

    Task<bool> NotifySubscriptionPeriodEndsAsync(CancellationToken ct = default);
}
