using System.Threading;
using System.Threading.Tasks;

namespace ASOL.PlatformStore.Store.Facades;

public interface ISyncFacade
{
    Task SyncCategoryAsync(string id, bool delete = false, CancellationToken ct = default);

    Task SyncProductCatalogAsync(string id, bool delete = false, CancellationToken ct = default);

    Task SyncAttributeGroupAsync(string id, bool delete = false, CancellationToken ct = default);
}
