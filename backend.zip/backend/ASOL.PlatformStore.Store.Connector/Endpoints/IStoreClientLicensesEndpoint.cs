using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Contracts.Filters;
using ASOL.PlatformStore.Store.Contracts.Subscription;

namespace ASOL.PlatformStore.Store.Connector;

/// <summary>
/// Defines the HTTP endpoint contract for managing Store Client licenses,
/// including listing, retrieving, and updating license resources.
/// </summary>
/// <remarks>
/// All operations are asynchronous and honor request cancellation via <see cref="CancellationToken"/>.
/// </remarks>
public interface IStoreClientLicensesEndpoint
{
    /// <summary>
    /// Retrieves a paged collection of licenses for the current client according to the specified filters.
    /// </summary>
    /// <param name="licenseFilter">
    /// License filtering options. See <see cref="LicenseFilter"/> for supported criteria
    /// such as validity, trial exclusion, order number, solution package, edition, application, search text,
    /// and date range constraints.
    /// </param>
    /// <param name="pagingFilter">
    /// Paging and sorting options for the result set. See <see cref="PagingFilter"/>.
    /// </param>
    /// <param name="ct">A <see cref="CancellationToken"/> to observe while waiting for the task to complete.</param>
    /// <returns>
    /// <see cref="CollectionResult{SubscriptionLicenseModel}"/>
    /// </returns>
    Task<CollectionResult<SubscriptionLicenseModel>> GetList(LicenseFilter licenseFilter, PagingFilter pagingFilter, CancellationToken ct);

    /// <summary>
    /// Retrieves a single license by its unique identifier.
    /// </summary>
    /// <param name="licenseId">The unique identifier of the license to retrieve.</param>
    /// <param name="ct">A <see cref="CancellationToken"/> to observe while waiting for the task to complete.</param>
    /// <returns>
    /// An <see cref="SubscriptionLicenseModel"/>
    /// typically 200 OK with the license when found, or 404 Not Found if no license exists for the given <paramref name="licenseId"/>.
    /// </returns>
    Task<SubscriptionLicenseModel> GetById(string licenseId, CancellationToken ct);


    /// <summary>
    /// Retrieves a single license by its unique identifier, with an option to accept not found result.
    /// </summary>
    /// <param name="licenseId">The unique identifier of the license to retrieve.</param>
    /// <param name="acceptNotFound">If true, the method returns <c>null</c> when the license is not found; otherwise, it may throw or handle not found differently.</param>
    /// <param name="ct">A <see cref="CancellationToken"/> to observe while waiting for the task to complete.</param>
    /// <returns>
    /// <see cref="SubscriptionLicenseModel"/>: The license when found, or <c>null</c> if no license exists for the given <paramref name="licenseId"/> and <paramref name="acceptNotFound"/> is true.
    /// </returns>
    Task<SubscriptionLicenseModel> GetById(string licenseId, bool acceptNotFound, CancellationToken ct);

    /// <summary>
    /// Updates selected properties of an existing license.
    /// </summary>
    /// <param name="licenseId">The unique identifier of the license to update.</param>
    /// <param name="model">
    /// The update payload. See <see cref="LicenseModelUpdate"/> for supported properties such as
    /// <c>UserMaxCount</c>, <c>Status</c>, and validity date range (<c>ValidFrom</c>, <c>ValidTo</c>).
    /// Date range validation is enforced by <see cref="LicenseModelDateRangeValidatableBase"/>.
    /// </param>
    /// <param name="ct">A <see cref="CancellationToken"/> to observe while waiting for the task to complete.</param>
    /// <returns>
    /// An <see cref="SubscriptionLicenseModel"/>
    /// </returns>
    Task<SubscriptionLicenseModel> Update(string licenseId, LicenseModelUpdate model, CancellationToken ct);
}
