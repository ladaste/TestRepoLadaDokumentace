using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.PlatformStore.Store.Contracts.Subscription;

namespace ASOL.PlatformStore.Store.Connector;

/// <summary>
/// Defines the client endpoint contract for managing subscription-bound billing items
/// in the Platform Store. Supports only listing.
/// </summary>
public interface IStoreClientSubscriptionBillingItemsEndpoint
{
    /// <summary>
    /// Retrieves a paged list of billing items.
    /// </summary>
    /// <param name="tenantId">(Optional) The unique identifier of the tenantId whose billing items are requested.</param>    
    /// <param name="pagingFilter">Paging and sorting parameters. See <see cref="PagingFilter"/>.</param>
    /// <param name="ct">A <see cref="CancellationToken"/> to observe while waiting for the task to complete.</param>
    /// <returns>
    /// An <see cref="CollectionResult{SubscriptionBillingItemModel}"/> producing a paged collection of billing items matching the criteria.
    /// </returns>
    Task<CollectionResult<SubscriptionBillingItemModel>> GetList(string? tenantId, PagingFilter pagingFilter, CancellationToken ct);
}
