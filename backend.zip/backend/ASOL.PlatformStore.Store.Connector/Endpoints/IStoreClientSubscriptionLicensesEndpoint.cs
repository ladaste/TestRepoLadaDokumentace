using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Contracts.Filters;
using ASOL.PlatformStore.Store.Contracts.Subscription;
using Microsoft.AspNetCore.Mvc;

namespace ASOL.PlatformStore.Store.Connector;

/// <summary>
/// Defines the client endpoint contract for managing subscription-bound licenses
/// in the Platform Store. Supports listing, creating, updating, and deleting licenses.
/// </summary>
public interface IStoreClientSubscriptionLicensesEndpoint
{
    /// <summary>
    /// Retrieves a paged list of licenses for the specified subscription.
    /// </summary>
    /// <param name="subscriptionId">The unique identifier of the subscription whose licenses are requested.</param>
    /// <param name="licenseFilter">
    /// The filter criteria to apply when querying licenses. See <see cref="LicenseFilter"/> for details.
    /// </param>
    /// <param name="pagingFilter">Paging and sorting parameters. See <see cref="PagingFilter"/>.</param>
    /// <param name="ct">A <see cref="CancellationToken"/> to observe while waiting for the task to complete.</param>
    /// <returns>
    /// An <see cref="CollectionResult{SubscriptionLicenseModel}"/> producing a paged collection of licenses matching the criteria.
    /// </returns>
    Task<CollectionResult<SubscriptionLicenseModel>> GetList(string subscriptionId, LicenseFilter licenseFilter, PagingFilter pagingFilter, CancellationToken ct);

    /// <summary>
    /// Creates a new license for the specified subscription.
    /// </summary>
    /// <param name="subscriptionId">The unique identifier of the subscription for which the license is created.</param>
    /// <param name="model">The payload describing the license to create. See <see cref="LicenseModelCreate"/>.</param>
    /// <param name="ct">A <see cref="CancellationToken"/> to observe while waiting for the task to complete.</param>
    /// <returns>
    /// An <see cref="CollectionResult{SubscriptionLicenseModel}"/>
    /// </returns>
    Task<CollectionResult<SubscriptionLicenseModel>> Create(string subscriptionId, LicenseModelCreate model, CancellationToken ct);

    /// <summary>
    /// Updates an existing license within the specified subscription.
    /// </summary>
    /// <param name="subscriptionId">The unique identifier of the subscription that owns the license.</param>
    /// <param name="licenseId">The unique identifier of the license to update.</param>
    /// <param name="model">The payload containing updatable fields. See <see cref="LicenseModelUpdate"/>.</param>
    /// <param name="ct">A <see cref="CancellationToken"/> to observe while waiting for the task to complete.</param>
    /// <returns>
    /// An <see cref="IActionResult"/> indicating the result of the update operation.
    /// </returns>
    Task<SubscriptionLicenseModel> Update(string subscriptionId, string licenseId, LicenseModelUpdate model, CancellationToken ct);

    /// <summary>
    /// Deletes a license from the specified subscription.
    /// </summary>
    /// <param name="subscriptionId">The unique identifier of the subscription that owns the license.</param>
    /// <param name="licenseId">The unique identifier of the license to delete.</param>
    /// <param name="ct">A <see cref="CancellationToken"/> to observe while waiting for the task to complete.</param>
    /// <returns>
    /// An <see cref="bool"/>
    /// </returns>
    Task<bool> Delete(string subscriptionId, string licenseId, CancellationToken ct);
}
