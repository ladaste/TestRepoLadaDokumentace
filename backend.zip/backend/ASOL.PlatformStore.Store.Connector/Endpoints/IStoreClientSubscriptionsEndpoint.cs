using System.Threading;
using System.Threading.Tasks;

namespace ASOL.PlatformStore.Store.Connector;

public interface IStoreClientSubscriptionsEndpoint
{
    /// <summary>
    /// Create or update subscription from order.
    /// </summary>
    /// <param name="orderId">The unique identifier of the odrder.</param>
    /// <param name="ct">A <see cref="CancellationToken"/> to observe while waiting for the task to complete.</param>
    /// <returns>
    /// A task that represents create or update operation.
    /// </returns>
    Task CreateOrUpdateSubscriptionFromOrder(string orderId, CancellationToken ct);
}
