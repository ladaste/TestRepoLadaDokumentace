using System;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Contracts.Filters;
using ASOL.PlatformStore.Store.Contracts.Subscription;
using Microsoft.Extensions.Logging;
using Pathoschild.Http.Client;

namespace ASOL.PlatformStore.Store.Connector;

public partial class PlatformStoreStoreClient : IStoreClientLicensesEndpoint
{
    public async Task<SubscriptionLicenseModel> GetById(string licenseId, CancellationToken ct)
    {
        var result = await GetById(licenseId, false, ct);

        return result;
    }

    public async Task<SubscriptionLicenseModel> GetById(string licenseId, bool acceptNotFound, CancellationToken ct)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(licenseId);

        ct.ThrowIfCancellationRequested();

        var resource = $"{ApiVersionPrefix}/Licenses/{Uri.EscapeDataString(licenseId)}";
        Logger.LogDebug($"Get license detail {CombineUri(resource)}");

        var request = (await AddAuthenticationAndHeaders(Client.GetAsync(resource), ct))
            .WithOptions(false)
            .WithCancellationToken(ct);

        var result = await GetSingleResultAsync<SubscriptionLicenseModel>(request, acceptNotFound, ct);

        return result;
    }

    public async Task<CollectionResult<SubscriptionLicenseModel>> GetList(LicenseFilter licenseFilter, PagingFilter pagingFilter, CancellationToken ct)
    {
        ArgumentNullException.ThrowIfNull(licenseFilter);

        ArgumentNullException.ThrowIfNull(pagingFilter);

        ct.ThrowIfCancellationRequested();

        var resource = $"{ApiVersionPrefix}/Licenses";
        Logger.LogDebug($"Get licenses list {CombineUri(resource)}");

        var request = (await AddAuthenticationAndHeaders(Client.GetAsync(resource), ct))
            .WithOptions(false)
            .WithArguments(licenseFilter)
            .WithArguments(pagingFilter)
            .WithCancellationToken(ct);

        var result = await request.As<CollectionResult<SubscriptionLicenseModel>>();

        return result;
    }

    public async Task<SubscriptionLicenseModel> Update(string licenseId, LicenseModelUpdate model, CancellationToken ct)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(licenseId);

        ArgumentNullException.ThrowIfNull(model);

        ct.ThrowIfCancellationRequested();

        var resource = $"{ApiVersionPrefix}/Licenses/{Uri.EscapeDataString(licenseId)}";
        Logger.LogDebug($"Update license {CombineUri(resource)}");

        var request = (await AddAuthenticationAndHeaders(Client.PutAsync(resource, model), ct))
            .WithOptions(false)
            .WithCancellationToken(ct);

        var updated = await request.As<SubscriptionLicenseModel>();
        return updated;
    }
}
