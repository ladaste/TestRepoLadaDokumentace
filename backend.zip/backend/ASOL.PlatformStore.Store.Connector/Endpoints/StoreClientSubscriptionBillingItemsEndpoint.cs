using System;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.PlatformStore.Store.Contracts.Subscription;
using Microsoft.Extensions.Logging;
using Pathoschild.Http.Client;

namespace ASOL.PlatformStore.Store.Connector;

public partial class PlatformStoreStoreClient : IStoreClientSubscriptionBillingItemsEndpoint
{
    public async Task<CollectionResult<SubscriptionBillingItemModel>> GetList(string tenantId, PagingFilter pagingFilter, CancellationToken ct)
    {
        ArgumentNullException.ThrowIfNull(pagingFilter);

        ct.ThrowIfCancellationRequested();

        var resource = $"{ApiVersionPrefix}/SubscriptionBillingItems";
        Logger.LogDebug($"Get billing item list {CombineUri(resource)}");

        var request = (await AddAuthenticationAndHeaders(Client.GetAsync(resource), ct))
            .WithOptions(false)
            .WithCancellationToken(ct);

        if (!string.IsNullOrWhiteSpace(tenantId))
        {
            request = request.WithArgument(nameof(tenantId), tenantId);
        }

        if (pagingFilter != null)
        {
            request = request.WithArguments(pagingFilter);
        }

        var result = await request.As<CollectionResult<SubscriptionBillingItemModel>>();
        return result;
    }
}
