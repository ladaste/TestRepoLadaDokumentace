using System;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Contracts.Filters;
using ASOL.PlatformStore.Store.Contracts.Subscription;
using Microsoft.Extensions.Logging;
using Pathoschild.Http.Client;

namespace ASOL.PlatformStore.Store.Connector;

public partial class PlatformStoreStoreClient : IStoreClientSubscriptionLicensesEndpoint
{
    public async Task<CollectionResult<SubscriptionLicenseModel>> Create(string subscriptionId, LicenseModelCreate model, CancellationToken ct)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(subscriptionId);

        ArgumentNullException.ThrowIfNull(model);

        ct.ThrowIfCancellationRequested();

        var resource = $"{ApiVersionPrefix}/Subscriptions/{Uri.EscapeDataString(subscriptionId)}/Licenses";
        Logger.LogDebug($"Create subscription license {CombineUri(resource)}");

        var request = (await AddAuthenticationAndHeaders(Client.PostAsync(resource, model), ct))
            .WithOptions(false)
            .WithCancellationToken(ct);

        var result = await request.As<CollectionResult<SubscriptionLicenseModel>>();
        return result;
    }

    public async Task<bool> Delete(string subscriptionId, string licenseId, CancellationToken ct)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(subscriptionId);

        ArgumentException.ThrowIfNullOrWhiteSpace(licenseId);

        ct.ThrowIfCancellationRequested();

        var resource = $"{ApiVersionPrefix}/Subscriptions/{Uri.EscapeDataString(subscriptionId)}/Licenses/{Uri.EscapeDataString(licenseId)}";
        Logger.LogDebug($"Delete subscription license {CombineUri(resource)}");

        var request = (await AddAuthenticationAndHeaders(Client.DeleteAsync(resource), ct));

        return await GetDeleteResultAsync(request, ct);
    }

    public async Task<CollectionResult<SubscriptionLicenseModel>> GetList(string subscriptionId, LicenseFilter licenseFilter, PagingFilter pagingFilter, CancellationToken ct)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(subscriptionId);

        ArgumentNullException.ThrowIfNull(licenseFilter);

        ArgumentNullException.ThrowIfNull(pagingFilter);

        ct.ThrowIfCancellationRequested();

        var resource = $"{ApiVersionPrefix}/Subscriptions/{Uri.EscapeDataString(subscriptionId)}/Licenses";
        Logger.LogDebug($"Get licenses list {CombineUri(resource)}");

        var request = (await AddAuthenticationAndHeaders(Client.GetAsync(resource), ct))
            .WithOptions(false)
            .WithCancellationToken(ct);

        if (licenseFilter != null)
        {
            request = request.WithArguments(licenseFilter);
        }

        if (pagingFilter != null)
        {
            request = request.WithArguments(pagingFilter);
        }

        var result = await request.As<CollectionResult<SubscriptionLicenseModel>>();
        return result;
    }

    public async Task<SubscriptionLicenseModel> Update(string subscriptionId, string licenseId, LicenseModelUpdate model, CancellationToken ct)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(subscriptionId);

        ArgumentException.ThrowIfNullOrWhiteSpace(licenseId);

        ArgumentNullException.ThrowIfNull(model);

        ct.ThrowIfCancellationRequested();

        var resource = $"{ApiVersionPrefix}/Subscriptions/{Uri.EscapeDataString(subscriptionId)}/Licenses/{Uri.EscapeDataString(licenseId)}";
        Logger.LogDebug($"Update subscription license {CombineUri(resource)}");

        var request = (await AddAuthenticationAndHeaders(Client.PutAsync(resource, model), ct))
            .WithOptions(false)
            .WithCancellationToken(ct);

        var updated = await request.As<SubscriptionLicenseModel>();
        return updated;
    }
}
