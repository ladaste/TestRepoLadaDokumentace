using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Pathoschild.Http.Client;

namespace ASOL.PlatformStore.Store.Connector;

public partial class PlatformStoreStoreClient : IStoreClientSubscriptionsEndpoint
{
    public async Task CreateOrUpdateSubscriptionFromOrder(string orderId, CancellationToken ct = default)
    {
        if (string.IsNullOrEmpty(orderId))
        {
            throw new ArgumentNullException(nameof(orderId));
        }

        ct.ThrowIfCancellationRequested();

        var resource = $"{ApiVersionPrefix}/Subscription/fromOrder/{Uri.EscapeDataString(orderId)}";
        Logger.LogDebug($"Create or update subrscription by order {CombineUri(resource)}");

        var request = (await AddAuthenticationAndHeaders(Client.PostAsync(resource), ct))
            .WithOptions(false)
            .WithCancellationToken(ct);

        await request.AsResponse();
    }
}
