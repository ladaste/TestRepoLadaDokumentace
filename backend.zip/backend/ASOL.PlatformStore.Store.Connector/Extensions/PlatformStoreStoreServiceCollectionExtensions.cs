using System;
using ASOL.Core.ApiConnector;
using ASOL.PlatformStore.Store.Connector.Options;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace ASOL.PlatformStore.Store.Connector.Extensions;

/// <summary>
/// Represents the PlatformStore Store client extension methods for service collection.
/// </summary>
public static class PlatformStoreStoreServiceCollectionExtensions
{
    /// <summary>
    /// Represents the PlatformStore Store client extension methods for service collection.
    /// </summary>
    /// <param name="services">The services collection.</param>
    /// <param name="customTokenProvider"></param>
    /// <param name="options">The options for PlatformStore Store client. (optional)</param>
    /// <returns>The services collection. (fluent api)</returns>
    public static IServiceCollection AddPlatformStoreStoreClient(this IServiceCollection services, Func<IServiceProvider, IConnectorTokenProvider> customTokenProvider = null, Action<PlatformStoreStoreClientOptions> options = null)
    {
        //services.TryAddScoped<IConnectorTokenProvider, ConnectorTokenForwardProvider>();
        services.AddScoped<IPlatformStoreStoreClient>(sp =>
        {
            var logger = sp.GetRequiredService<ILogger<PlatformStoreStoreClient>>();
            var tokenProvider = customTokenProvider?.Invoke(sp) ?? sp.GetRequiredService<IConnectorTokenProvider>();
            var requestHeaderProviders = sp.GetServices<IRequestHeaderProvider>();
            if (options == null)
            {
                var opt = sp.GetRequiredService<IOptions<PlatformStoreStoreClientOptions>>();
                return new PlatformStoreStoreClient(opt, logger, tokenProvider, requestHeaderProviders);
            }
            else
            {
                var opt = PlatformStoreStoreClientOptions.Default;
                options(opt);
                return new PlatformStoreStoreClient(opt, logger, tokenProvider, requestHeaderProviders);
            }
        });

        return services;
    }
}
