using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.PlatformStore.Store.Contracts;

namespace ASOL.PlatformStore.Store.Connector;

/// <summary>
/// Represents a client of PlatformStore Store API service.
/// </summary>
public interface IPlatformStoreStoreClient
{
    /// <inheritdoc cref="IStoreClientLicensesEndpoint"/>
    IStoreClientLicensesEndpoint Licenses { get; }

    /// <inheritdoc cref="IStoreClientSubscriptionLicensesEndpoint"/>
    IStoreClientSubscriptionLicensesEndpoint SubscriptionLicenses { get; }

    /// <inheritdoc cref="IStoreClientSubscriptionBillingItemsEndpoint"/>
    IStoreClientSubscriptionBillingItemsEndpoint SubscriptionBillingItems { get; }

    /// <inheritdoc cref="IStoreClientSubscriptionsEndpoint"/>
    IStoreClientSubscriptionsEndpoint Subscriptions { get; }

    /// <summary>
    /// Get subscriptions based on search parameters
    /// </summary>
    /// <param name="searchParameters">The custom filter</param>
    /// <param name="pagingFilter">The paging filter</param>
    /// <param name="ct">The cancellation token</param>
    /// <returns>The list of orders.</returns>
    Task<CollectionResult<SubscriptionsSummaryModel>> GetSubscriptionsAsync(
        SearchSubscriptionsModel searchParameters,
        PagingFilter pagingFilter,
        CancellationToken ct = default);
}
