using ASOL.Core.ApiConnector;
using ASOL.Core.ApiConnector.HealthChecks;
using ASOL.Core.ApiConnector.Options;
using ASOL.Core.HealthChecks;

namespace ASOL.PlatformStore.Store.Connector.Options;

/// <summary>
/// Represents the PlatformStore Store client options.
/// </summary>
public class PlatformStoreStoreClientOptions : ApiClientOptions<IApiClient>, IPlatformHealthCheckableOptions<ApiConnectorHealthCheck<PlatformStoreStoreClientOptions>>
{
    /// <summary>
    /// Default section name in appsettings.json.
    /// </summary>
    public const string DefaultSectionName = nameof(PlatformStoreStoreClientOptions);

    /// <summary>
    /// Default options.
    /// </summary>
    public static PlatformStoreStoreClientOptions Default => new();

    public HealthCheckMode HealthCheckMode { get; set; } = HealthCheckMode.Enabled;
}
