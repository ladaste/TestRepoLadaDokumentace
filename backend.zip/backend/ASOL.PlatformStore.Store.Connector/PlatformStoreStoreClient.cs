using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.ApiConnector;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.PlatformStore.Store.Connector.Options;
using ASOL.PlatformStore.Store.Contracts;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Pathoschild.Http.Client;

namespace ASOL.PlatformStore.Store.Connector;

/// <summary>
/// Represents a client of PlatformStore Store API service.
/// </summary>
public partial class PlatformStoreStoreClient
    : SecuredApiClientBase<PlatformStoreStoreClientOptions,
        IConnectorTokenProvider>, IPlatformStoreStoreClient
{
    /// <summary>
    /// Api version prefix
    /// </summary>
    protected override string ApiVersionPrefix => "api/v1";

    /// <summary>
    /// Creates new client instance
    /// </summary>
    /// <param name="options">Client options</param>
    /// <param name="logger">Logger</param>
    /// <param name="tokenProvider">Token provider</param>
    /// <param name="requestHeaderProviders">Request headers providers</param>
    /// <param name="baseClient">Base client</param>
    /// <param name="manageBaseClient"></param>
    /// <returns></returns>
    public static PlatformStoreStoreClient Create(
        PlatformStoreStoreClientOptions options,
        ILogger<PlatformStoreStoreClient> logger,
        IConnectorTokenProvider tokenProvider,
        IEnumerable<IRequestHeaderProvider> requestHeaderProviders,
        HttpClient baseClient = null,
        bool manageBaseClient = false)
    {
        return new PlatformStoreStoreClient(options, logger, tokenProvider, requestHeaderProviders, baseClient, manageBaseClient);
    }

    /// <summary>
    /// Initializes the instance.
    /// </summary>
    /// <param name="options">Client options</param>
    /// <param name="logger">Logger</param>
    /// <param name="tokenProvider">Token provider</param>
    /// <param name="requestHeaderProviders">Request headers providers</param>
    public PlatformStoreStoreClient(
        IOptions<PlatformStoreStoreClientOptions> options,
        ILogger<PlatformStoreStoreClient> logger,
        IConnectorTokenProvider tokenProvider,
        IEnumerable<IRequestHeaderProvider> requestHeaderProviders)
        : this(options?.Value, logger, tokenProvider, requestHeaderProviders, baseClient: null)
    {
    }

    /// <summary>
    /// Initialized the instance.
    /// </summary>
    /// <param name="options">Client options</param>
    /// <param name="logger">Logger</param>
    /// <param name="tokenProvider">Token provider</param>
    /// <param name="requestHeaderProviders">Request headers providers</param>
    public PlatformStoreStoreClient(
        PlatformStoreStoreClientOptions options,
        ILogger<PlatformStoreStoreClient> logger,
        IConnectorTokenProvider tokenProvider,
        IEnumerable<IRequestHeaderProvider> requestHeaderProviders)
        : this(options, logger, tokenProvider, requestHeaderProviders, baseClient: null)
    {
    }

    /// .ctor
    protected PlatformStoreStoreClient(
        PlatformStoreStoreClientOptions options,
        ILogger<PlatformStoreStoreClient> logger,
        IConnectorTokenProvider tokenProvider,
        IEnumerable<IRequestHeaderProvider> requestHeaderProviders,
        HttpClient baseClient = null,
        bool manageBaseClient = false)
        : base(options, logger, tokenProvider, requestHeaderProviders, baseClient, manageBaseClient)
    {
    }

    public IStoreClientLicensesEndpoint Licenses => this;

    public IStoreClientSubscriptionLicensesEndpoint SubscriptionLicenses => this;

    public IStoreClientSubscriptionsEndpoint Subscriptions => this;

    public IStoreClientSubscriptionBillingItemsEndpoint SubscriptionBillingItems => this;

    /// <inheritdoc/>
    public async Task<CollectionResult<SubscriptionsSummaryModel>> GetSubscriptionsAsync(
        SearchSubscriptionsModel searchParameters,
        PagingFilter pagingFilter,
        CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(searchParameters);

        ct.ThrowIfCancellationRequested();

        var resource = $"{ApiVersionPrefix}/Store/subscriptions";
        Logger.LogInformation($"Retrieving subscriptions from {CombineUri(resource)}");

        var request = (await AddAuthenticationAndHeaders(Client.GetAsync(resource), ct))
            .WithArguments(pagingFilter)
            .WithCancellationToken(ct);

        if (searchParameters != null)
        {
            request = request
                .WithArgument(nameof(searchParameters.ExcludeDefaultApps), searchParameters.ExcludeDefaultApps);

            if (!string.IsNullOrWhiteSpace(searchParameters.SearchText))
            {
                request = request
                    .WithArgument(nameof(searchParameters.SearchText), searchParameters.SearchText);
            }

            if (searchParameters.AccessTypeViews != null && searchParameters.AccessTypeViews.Count != 0)
            {
                foreach (var view in searchParameters.AccessTypeViews)
                {
                    request = request
                        .WithArgument(nameof(searchParameters.AccessTypeViews), view);
                }
            }
        }

        var result = await request.As<CollectionResult<SubscriptionsSummaryModel>>();

        return result;
    }
}
