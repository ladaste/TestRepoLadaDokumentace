using System;
using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Model for store item with licence information
/// </summary>
public class AllPurchasedAggregatedItemModel
{
    public string Id { get; set; }

    public string Name { get; set; }

    public string OrderNumber { get; set; }

    public DateTime? ApprovedByCustomerOn { get; set; }

    public string ShortDescription { get; set; }

    public string CardImageId { get; set; }

    public string FrontendUrl { get; set; }

    public string ApplicationCode { get; set; }

    public string EditionName { get; set; }

    public string TenantSolutionPartnerId { get; set; }

    public string TenantSolutionPartnerName { get; set; }

    public string ApplicationSolutionPartnerId { get; set; }

    public string ApplicationSolutionPartnerName { get; set; }

    public string DevelopmentPartnerId { get; set; }

    public string DevelopmentPartnerName { get; set; }

    public string CustomerName { get; set; }

    public DateTime ValidFrom { get; set; }

    public DateTime? ValidTo { get; set; }

    public string BillingPeriod { get; set; }

    public string Status { get; set; }

    public DateTime? ModifiedOn { get; set; }

    public CategoryModel Category { get; set; }

    public List<CategoryModel> IntegrationCategories { get; set; }

    public string StatusDescription { get; set; }

    public bool IsSourceLicense { get; set; }

    public bool Published { get; set; }
}
