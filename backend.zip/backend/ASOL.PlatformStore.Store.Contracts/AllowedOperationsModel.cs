using System;
using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Model for store item with licence information
/// </summary>
public class OrderLicenceInformation
{
    /// <summary>
    /// Id of the item - id of the product
    /// </summary>
    public string Id { get; set; }

    /// <summary>
    /// Localized product name for display in the store
    /// </summary>
    public string Name { get; set; }

    /// <summary>
    ///  Tile short description text
    /// </summary>
    public string ShortDescription { get; set; }

    /// <summary>
    /// Reference to image of the tile
    /// </summary>
    public string CardImageId { get; set; }

    /// <summary>
    /// Name of category
    /// </summary>
    public string CategoryName { get; set; }

    /// <summary>
    /// Application Code
    /// </summary>
    public string ApplicationCode { get; set; }

    /// <summary>
    /// Order number
    /// </summary>
    public string OrderNumber { get; set; }

    /// <summary>
    /// Is Subscription Canceled
    /// </summary>
    public bool IsSubscriptionCanceled { get; set; }

    /// <summary>
    /// The subscription date of expiration.
    /// </summary>
    public DateTime? SubscriptionValidTo { get; set; }

    /// <summary>
    /// List of Licenc eInformation Models
    /// </summary>
    public IEnumerable<LicenceInformationModel> LicenceInformationModels { get; set; }
}
