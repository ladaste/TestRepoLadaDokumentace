namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Billing period
/// </summary>
public class BillingPeriodModel
{
    /// <summary>
    /// Id
    /// </summary>
    public string Id { get; set; }

    /// <summary>
    /// Code
    /// </summary>
    public string Code { get; set; }

    /// <summary>
    /// Type: 
    /// * Forward = 1
    /// * Backward = 2
    /// </summary>
    /// <example>Forward</example>
    public PeriodTypeModel Type { get; set; }

    /// <summary>
    /// Period
    /// </summary>
    /// <example>0</example>
    public uint? Period { get; set; }

    /// <summary>
    /// PeriodUnit:
    /// * Day = 1
    /// * Month = 2
    /// * Year = 3
    /// * [null] = oneTime
    /// </summary>
    /// <example>Month</example>
    public PeriodUnitModel? PeriodUnit { get; set; }
}
