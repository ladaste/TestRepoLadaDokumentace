namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Model for category
/// </summary>
public class CategoryModel
{
    /// <summary>
    /// Category id
    /// </summary>
    public string Id { get; set; }

    /// <summary>
    /// Category code
    /// </summary>
    public string Code { get; set; }

    /// <summary>
    /// Localized name of the category
    /// </summary>
    public string Name { get; set; }
}
