using ASOL.Core.Paging.Contracts;

namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Model for category result
/// </summary>
public class CategoryResultModel
{
    /// <summary>
    /// Category code
    /// </summary>
    public string CategoryCode { get; set; }

    /// <summary>
    /// Localized name of the category
    /// </summary>
    public string CategoryName { get; set; }

    /// <summary>
    /// List of store items that match the search criteria
    /// </summary>
    public CollectionResult<StoreItemModel> StoreItems { get; set; }
}
