namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Enum for types of contact requests
/// </summary>
public enum ContactRequestType
{
    /// <summary>
    /// None
    /// </summary>
    None = 0,

    /// <summary>
    /// Partner
    /// </summary>
    Partner = 1,

    /// <summary>
    /// General
    /// </summary>
    General = 2,

    /// <summary>
    /// Application
    /// </summary>
    Application = 3,

    /// <summary>
    /// Support
    /// </summary>
    Support = 4,

    /// <summary>
    /// ApplicationQuestion
    /// </summary>
    ApplicationQuestion = 5
}
