namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Model for private contact us message
/// </summary>
public class ContactUsModel
{
    /// <summary>
    /// Ssubject
    /// </summary>
    public string Subject { get; set; }

    /// <summary>
    /// Message
    /// </summary>
    public string Message { get; set; }

    /// <summary>
    /// Product id
    /// </summary>
    public string ProductId { get; set; }

    /// <summary>
    /// Application Code
    /// </summary>
    public string ApplicationCode { get; set; }

    /// <summary>
    /// Current Url
    /// </summary>
    public string CurrentUrl { get; set; }

    /// <summary>
    /// Current AppId
    /// </summary>
    public string CurrentAppId { get; set; }

    /// <summary>
    /// Deeplink Base Url
    /// </summary>
    public string DeeplinkBaseUrl { get; set; }

    /// <summary>
    /// Chat Id
    /// </summary>
    public string ChatId { get; set; }

    /// <summary>
    /// Type of contact request
    /// </summary>
    public ContactRequestType ContactRequestType { get; set; }
}
