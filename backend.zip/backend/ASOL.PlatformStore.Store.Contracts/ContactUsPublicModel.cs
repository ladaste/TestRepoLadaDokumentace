namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Model for contact us message
/// </summary>
public class ContactUsPublicModel : ContactUsModel
{
    /// <summary>
    /// Sender name
    /// </summary>
    public string Name { get; set; }

    /// <summary>
    /// Sender email
    /// </summary>
    public string Email { get; set; }

    /// <summary>
    /// Sender company name
    /// </summary>
    public string CompanyName { get; set; }

    /// <summary>
    /// Sender phone number
    /// </summary>
    public string PhoneNumber { get; set; }

    /// <summary>
    /// Captcha token
    /// </summary>
    public string Captcha { get; set; }
}
