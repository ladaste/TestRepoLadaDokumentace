namespace ASOL.PlatformStore.Store.Contracts;

public class DescriptionDataItemModel
{
    public string Text { get; set; }
}
