namespace ASOL.PlatformStore.Store.Contracts;

public class DescriptionFeatureItemModel
{
    public DescriptionDataItemModel Subject { get; set; }

    public DescriptionDataItemModel Description { get; set; }

    public string ContentImageId { get; set; }

    public string ImageRedirectUrl { get; set; }
}
