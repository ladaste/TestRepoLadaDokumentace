using System;
using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Model for edition
/// </summary>
public class EditionModel
{
    /// <summary>
    /// Id of edition
    /// </summary>
    public string Id { get; set; }

    /// <summary>
    /// Part code of edition
    /// </summary>
    public string PartCode { get; set; }

    /// <summary>
    /// Name of edition
    /// </summary>
    public string Name { get; set; }

    /// <summary>
    /// Order of the edition
    /// </summary>
    public decimal SortOrder { get; set; }

    /// <summary>
    /// Flag if edition is highlighted
    /// </summary>
    public bool Default { get; set; }

    /// <summary>
    /// Description of edition
    /// </summary>
    public string Description { get; set; }

    /// <summary>
    /// Flag is reference is mandatory
    /// </summary>
    public bool IsMandatory { get; set; }

    /// <summary>
    /// Code from ItemType codebook
    /// </summary>
    public string ItemTypeCode { get; set; }

    /// <summary>
    /// OwnershipType
    /// </summary>
    public OwnershipTypeModel? OwnershipType { get; set; }

    /// <summary>
    /// Code from BillingPeriod codebook
    /// </summary>
    public string BillingPeriodCode { get; set; }

    /// <summary>
    /// Unit Of Sale - code
    /// </summary>
    public string UnitOfSaleCode { get; set; }

    /// <summary>
    /// Unit Of Measure - code
    /// </summary>
    public string UnitOfMeasureCode { get; set; }

    /// <summary>
    /// Valid from
    /// </summary>
    public DateTime? ValidFrom { get; set; }

    /// <summary>
    /// Valid to
    /// </summary>
    public DateTime? ValidTo { get; set; }

    /// <summary>
    /// Upgrade type
    /// </summary>
    public UpgradeTypeModel? UpgradeType { get; set; }

    /// <summary>
    /// can be canceled / cannot be canceled
    /// </summary>
    public bool? CanCancel { get; set; }

    /// <summary>
    /// Collection of assigned features
    /// </summary>
    public ICollection<FeatureModel> Features { get; set; }

    /// <summary>
    /// Collection of assigned licences
    /// </summary>
    [Obsolete("Use Subscriptions")]
    public ICollection<LicenceModel> Licences { get; set; }

    /// <summary>
    /// List of ordered subscriptions
    /// </summary>
    public ICollection<SubscriptionModel> Subscriptions { get; set; }

    /// <summary>
    /// Collection of assigned extensions
    /// </summary>
    public ICollection<ExtensionModel> Extensions { get; set; }
}
