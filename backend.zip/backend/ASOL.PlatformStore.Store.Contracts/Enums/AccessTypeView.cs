namespace ASOL.PlatformStore.Store.Contracts.Enums;

public enum AccessTypeView
{
    Customer = 1,
    ApplicationSolutionPartner = 2,
    TenantSolutionPartner = 3,
    DevelopmentPartner = 4
}
