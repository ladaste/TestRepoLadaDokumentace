namespace ASOL.PlatformStore.Store.Contracts.Enums;

public enum AllPurchasedStates
{
    InPreparation = 1,
    Done = 2,
    Failed = 3,
    Ended = 4
}
