namespace ASOL.PlatformStore.Store.Contracts.Events;

public class ImportSubscriptionStarted
{
    public string TenantId { get; init; }

    public bool Execute { get; init; }

    public string CorrelationId { get; init; }
}
