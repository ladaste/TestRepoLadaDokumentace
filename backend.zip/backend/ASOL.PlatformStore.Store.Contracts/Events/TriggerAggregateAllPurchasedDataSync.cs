using System;

namespace ASOL.PlatformStore.Store.Contracts.Events;

/// <summary>
/// Event for trigger Helpdesk Tickets.
/// </summary>
public class TriggerAggregateAllPurchasedDataSync
{
    /// <summary>
    /// RequestId
    /// </summary>
    public Guid RequestId { get; set; }
}
