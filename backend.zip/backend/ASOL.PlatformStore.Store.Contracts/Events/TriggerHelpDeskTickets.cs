namespace ASOL.PlatformStore.Store.Contracts.Events;

/// <summary>
/// Event for trigger Helpdesk Tickets.
/// </summary>
public class TriggerHelpDeskTickets
{
    /// <summary>
    /// Subject
    /// </summary>
    public string Subject { get; set; }

    /// <summary>
    /// Message
    /// </summary>
    public string Message { get; set; }

    /// <summary>
    /// ApplicationCode
    /// </summary>
    public string ApplicationCode { get; set; }

    /// <summary>
    /// CurrentUrl
    /// </summary>
    public string CurrentUrl { get; set; }
}
