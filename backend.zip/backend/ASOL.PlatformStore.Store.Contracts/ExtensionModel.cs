using System;
using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Model for licence
/// </summary>
public class ExtensionModel
{
    /// <summary>
    /// Id of extension
    /// </summary>
    public string Id { get; set; }

    /// <summary>
    /// Part code of extension
    /// </summary>
    public string PartCode { get; set; }

    /// <summary>
    /// Flag is reference is mandatory
    /// </summary>
    public bool IsMandatory { get; set; }

    /// <summary>
    /// Code from ItemType codebook
    /// </summary>
    public string ItemTypeCode { get; set; }

    /// <summary>
    /// OwnershipType
    /// </summary>
    public OwnershipTypeModel? OwnershipType { get; set; }

    /// <summary>
    /// Code from BillingPeriod codebook
    /// </summary>
    public string BillingPeriodCode { get; set; }

    /// <summary>
    /// Unit Of Sale - code
    /// </summary>
    public string UnitOfSaleCode { get; set; }

    /// <summary>
    /// Unit Of Measure - code
    /// </summary>
    public string UnitOfMeasureCode { get; set; }

    /// <summary>
    /// Valid from
    /// </summary>
    public DateTime? ValidFrom { get; set; }

    /// <summary>
    /// Valid to
    /// </summary>
    public DateTime? ValidTo { get; set; }

    /// <summary>
    /// Upgrade type
    /// </summary>
    public UpgradeTypeModel? UpgradeType { get; set; }

    /// <summary>
    /// can be canceled / cannot be canceled
    /// </summary>
    public bool? CanCancel { get; set; }

    /// <summary>
    /// Data of extension
    /// </summary>
    public object ExtensionData { get; set; }

    /// <summary>
    /// Name of extension
    /// </summary>
    public string ExtensionName { get; set; }

    /// <summary>
    /// Extension description
    /// </summary>
    public string ExtensionDescription { get; set; }

    /// <summary>
    /// Extension long description title
    /// </summary>
    public string ExtensionLongDescriptionTitle { get; set; }

    /// <summary>
    /// Extension long description
    /// </summary>
    public string ExtensionLongDescription { get; set; }

    /// <summary>
    /// Extension long description title
    /// </summary>
    public string ExtensionSliderTitle { get; set; }

    /// <summary>
    /// Extension long description
    /// </summary>
    public string ExtensionSliderDescription { get; set; }

    /// <summary>
    /// List of ordered subscriptions
    /// </summary>
    public ICollection<SubscriptionModel> Subscriptions { get; set; }
}
