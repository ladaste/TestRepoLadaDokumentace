using System;

namespace ASOL.PlatformStore.Store.Contracts.Filters;

public class LicenseFilter
{
    /// <summary>
    /// Include invalid licenses (out of time validity).
    /// If you specified <see cref="ValidFrom"/> or <see cref="ValidTo"/> then this condition will be ignored.
    /// </summary>
    public bool IncludeInvalid { get; set; }

    /// <summary>
    /// Exclude current valid license (time validity).
    /// If you specified <see cref="ValidFrom"/> or <see cref="ValidTo"/> then this condition will be ignored.
    /// </summary>
    public bool ExcludeValid { get; set; }

    /// <summary>
    /// Exclude all licenses which are trial.
    /// </summary>
    public bool ExcludeTrial { get; set; }

    /// <summary>
    /// Exclude license without OrderNumber.
    /// </summary>
    public bool ExcludeWithoutOrderNumber { get; set; }

    /// <summary>
    /// Valid licenses will be at the beginning of the list.
    /// If set to true, <see cref="ValidFrom"/> or <see cref="ValidTo"/>, IncludeInvalid and ExcludeValid are ignored.
    /// </summary>
    public bool SortValidFirst { get; set; }

    public string OrderNumber { get; set; }

    public string SolutionPackageCode { get; set; }

    public string SolutionPackageName { get; set; }

    public string EditionCode { get; set; }

    public string ApplicationCode { get; set; }

    /// <summary>
    /// Filter OrderNumber or SolutionPackageName
    /// </summary>
    public string Search { get; set; }

    public DateOnly? ValidFrom { get; set; }

    public DateOnly? ValidTo { get; set; }

    /// <summary>
    /// When is true then return licences limited to Visible applications only without exception like role LicenseOwner or SpaceOwner.
    /// </summary>
    public bool ForceApplyFilterIsVisibleApplication { get; set; }
}
