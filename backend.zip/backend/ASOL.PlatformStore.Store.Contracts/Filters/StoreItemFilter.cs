namespace ASOL.PlatformStore.Store.Contracts.Filters;

/// <summary>
/// Search params for store items
/// </summary>
public class StoreItemFilter
{
    /// <summary>
    /// Category Id to search the store for
    /// </summary>
    public string Category { get; set; }

    /// <summary>
    /// Category code to search the store for
    /// </summary>
    public string CategoryCode { get; set; }
}
