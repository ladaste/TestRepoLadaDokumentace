namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Model for store item with licence information
/// </summary>
public class HelpdeskDataModel
{
    /// <summary>
    /// Id of the item - id of the product
    /// </summary>
    public string Id { get; set; }

    /// <summary>
    /// Localized product name for display in the store
    /// </summary>
    public string ApplicationCode { get; set; }

    /// <summary>
    ///  Tile short description text
    /// </summary>
    public string SolutionPackageCode { get; set; }

    /// <summary>
    /// Reference to image of the tile
    /// </summary>
    public string SolutionPackageName { get; set; }

    /// <summary>
    /// Category assigned to the item
    /// </summary>
    public string EditionCode { get; set; }

    /// <summary>
    /// Url for navigation
    /// </summary>
    public string FrontendUrl { get; set; }
}
