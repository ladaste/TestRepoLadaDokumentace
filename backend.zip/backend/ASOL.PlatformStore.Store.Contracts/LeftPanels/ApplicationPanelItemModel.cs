using Newtonsoft.Json;

namespace ASOL.PlatformStore.Store.Contracts.LeftPanels;

public sealed class ApplicationPanelItemModel : PanelItemModel
{
    [JsonRequired]
    public string ApplicationCode { get; set; }

    [JsonRequired]
    public bool IsPinned { get; set; }
}
