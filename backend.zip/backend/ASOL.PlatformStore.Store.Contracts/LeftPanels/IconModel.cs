using Newtonsoft.Json;

namespace ASOL.PlatformStore.Store.Contracts.LeftPanels;

public sealed class IconModel
{
    [JsonRequired]
    public string Value { get; set; }

    [JsonRequired]
    public IconTypeModel Type { get; set; }
}
