namespace ASOL.PlatformStore.Store.Contracts.LeftPanels;

public enum IconTypeModel
{
    Url = 1,
    GoogleName = 2,
    Svg = 3,
    Initials = 4,
}
