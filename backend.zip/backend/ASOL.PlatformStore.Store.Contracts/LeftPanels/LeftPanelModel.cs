using ASOL.Core.Paging.Contracts;
using Newtonsoft.Json;

namespace ASOL.PlatformStore.Store.Contracts.LeftPanels;

public class LeftPanelModel
{
    [JsonRequired]
    public int Version { get; set; }

    [JsonRequired]
    public CollectionResult<PanelItemModel> QuickAccess { get; set; }

    [JsonRequired]
    public CollectionResult<PanelItemModel> AllApplications { get; set; }
}
