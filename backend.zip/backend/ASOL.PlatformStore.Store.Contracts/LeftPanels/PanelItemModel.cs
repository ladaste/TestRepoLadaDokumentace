using System.ComponentModel;
using System.Runtime.Serialization;
using ASOL.Core.Localization;
using ASOL.Core.Serialization;
using Newtonsoft.Json;

namespace ASOL.PlatformStore.Store.Contracts.LeftPanels;

[Description("CustomPanelItem")]
[JsonConverter(
    typeof(PolymorphismModelJsonConverter<PanelItemModel>),
    [new string[] { "Model" }])]
[KnownType(typeof(ApplicationPanelItemModel))]
public class PanelItemModel
{
    [JsonRequired]
    public string Id { get; set; }

    [JsonRequired]
    public LocalizedValue<string> Label { get; set; }

    [JsonRequired]
    public string Url { get; set; }

    [JsonRequired]
    public IconModel Icon { get; set; }

    [JsonRequired]
    public bool OpenInSeparateWindow { get; set; }

    [JsonRequired]
    [JsonProperty("$type")]
    public string Type { get; set; }
}
