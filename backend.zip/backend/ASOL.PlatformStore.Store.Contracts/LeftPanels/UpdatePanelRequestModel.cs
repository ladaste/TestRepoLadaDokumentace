using System.Collections.Generic;
using ASOL.PlatformStore.Store.Contracts.LeftPanels.Updates;
using Newtonsoft.Json;

namespace ASOL.PlatformStore.Store.Contracts.LeftPanels;

public sealed class UpdatePanelRequestModel
{
    [JsonRequired]
    public int PanelVersion { get; set; }

    [JsonRequired]
    public IEnumerable<PanelUpdateModel> Updates { get; set; }
}
