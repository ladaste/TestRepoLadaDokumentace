using Newtonsoft.Json;

namespace ASOL.PlatformStore.Store.Contracts.LeftPanels.Updates;

public sealed class ChangeApplicationItemPinnedStateModel : PanelUpdateModel
{
    [JsonRequired]
    public PanelItemPositionModel Position { get; set; }

    [JsonRequired]
    public bool IsPinned { get; set; }
}
