using Newtonsoft.Json;

namespace ASOL.PlatformStore.Store.Contracts.LeftPanels.Updates;

public sealed class ChangeItemIconModel : PanelUpdateModel
{
    [JsonRequired]
    public PanelItemPositionModel Position { get; set; }

    [JsonRequired]
    public IconModel Icon { get; set; }
}
