using ASOL.Core.Localization;
using Newtonsoft.Json;

namespace ASOL.PlatformStore.Store.Contracts.LeftPanels.Updates;

public sealed class ChangeItemLabelModel : PanelUpdateModel
{
    [JsonRequired]
    public PanelItemPositionModel Position { get; set; }

    [JsonRequired]
    public LocalizedValue<string> Label { get; set; }
}
