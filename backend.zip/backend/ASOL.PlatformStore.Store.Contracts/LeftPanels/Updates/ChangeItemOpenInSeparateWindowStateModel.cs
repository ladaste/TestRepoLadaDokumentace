using Newtonsoft.Json;

namespace ASOL.PlatformStore.Store.Contracts.LeftPanels.Updates;

public sealed class ChangeItemOpenInSeparateWindowStateModel : PanelUpdateModel
{
    [JsonRequired]
    public PanelItemPositionModel Position { get; set; }

    [JsonRequired]
    public bool OpenInSeparateWindow { get; set; }
}
