using ASOL.Core.Localization;
using Newtonsoft.Json;

namespace ASOL.PlatformStore.Store.Contracts.LeftPanels.Updates;

public sealed class CreateCustomItemModel : PanelUpdateModel
{
    [JsonRequired]
    public PanelItemPositionModel Position { get; set; }

    [JsonRequired]
    public LocalizedValue<string> Label { get; set; }

    [JsonRequired]
    public string Url { get; set; }
}
