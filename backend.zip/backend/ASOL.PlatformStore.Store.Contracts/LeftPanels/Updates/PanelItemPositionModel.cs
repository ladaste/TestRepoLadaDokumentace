using Newtonsoft.Json;

namespace ASOL.PlatformStore.Store.Contracts.LeftPanels.Updates;

public sealed class PanelItemPositionModel
{
    [JsonRequired]
    public PanelPartModel Part { get; set; }

    [JsonRequired]
    public uint Index { get; set; }
}
