namespace ASOL.PlatformStore.Store.Contracts.LeftPanels.Updates;

public enum PanelPartModel
{
    QuickAccess = 1,
    AllApplications = 2
}
