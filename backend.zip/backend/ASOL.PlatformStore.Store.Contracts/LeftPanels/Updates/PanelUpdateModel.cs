using System.Runtime.Serialization;
using ASOL.Core.Serialization;
using Newtonsoft.Json;

namespace ASOL.PlatformStore.Store.Contracts.LeftPanels.Updates;

[JsonConverter(
    typeof(PolymorphismModelJsonConverter<PanelUpdateModel>),
    [new string[] { "Model" }])]
[KnownType(typeof(CreateCustomItemModel))]
[KnownType(typeof(MoveItemModel))]
[KnownType(typeof(ChangeItemLabelModel))]
[KnownType(typeof(ChangeCustomItemUrlModel))]
[KnownType(typeof(ChangeItemIconModel))]
[KnownType(typeof(ChangeApplicationItemPinnedStateModel))]
[KnownType(typeof(ChangeItemOpenInSeparateWindowStateModel))]
[KnownType(typeof(RemoveItemModel))]
public abstract class PanelUpdateModel
{
    [JsonRequired]
    [JsonProperty("$type")]
    public string Type { get; set; }
}
