using Newtonsoft.Json;

namespace ASOL.PlatformStore.Store.Contracts.LeftPanels.Updates;

public sealed class RemoveItemModel : PanelUpdateModel
{
    [JsonRequired]
    public PanelItemPositionModel Position { get; set; }
}
