namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Model for File Ref
/// </summary>
public class LegalDocumentFileRef
{
    /// <summary>
    /// FileId.
    /// </summary>
    public string FileId { get; set; }
    /// <summary>
    /// Is Public.
    /// </summary>
    public string IsPublic { get; set; }
}
