namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Model for Legal Document
/// </summary>
public class LegalDocumentLocalizedModel
{
    /// <summary>
    /// Prefix.
    /// </summary>
    public string Prefix { get; set; }
    /// <summary>
    /// HyperlinkTex.
    /// </summary>
    public string HyperlinkTex { get; set; }
    /// <summary>
    /// Suffix.
    /// </summary>
    public string Suffix { get; set; }
    /// <summary>
    /// Legal Document Id.
    /// </summary>
    public string LegalDocumentId { get; set; }
}
