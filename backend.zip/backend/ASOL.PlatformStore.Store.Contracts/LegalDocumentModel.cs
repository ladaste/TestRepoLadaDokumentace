using ASOL.Core.Localization;

namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Model for Legal Document
/// </summary>
public class LegalDocumentModel
{
    /// <summary>
    /// Prefix.
    /// </summary>
    public LocalizedValue<string> Prefix { get; set; }
    /// <summary>
    /// HyperlinkTex.
    /// </summary>
    public LocalizedValue<string> HyperlinkTex { get; set; }
    /// <summary>
    /// Suffix.
    /// </summary>
    public LocalizedValue<string> Suffix { get; set; }
    /// <summary>
    /// Legal Document.
    /// </summary>
    public LocalizedValue<LegalDocumentFileRef> LegalDocument { get; set; }
}
