using System;
namespace ASOL.PlatformStore.Store.Contracts;

public class LicenceInformationModel
{
    public LicenceInformationModel()
    {
    }

    /// <summary>
    /// Edition name
    /// </summary>
    public string EditionName { get; set; }

    /// <summary>
    /// Licence Code
    /// </summary>
    public string LicenceCode { get; set; }

    /// <summary>
    /// Id of OrderLine
    /// </summary>
    public string OrderLineId { get; set; }

    /// <summary>
    /// Flag if licence is trial
    /// </summary>
    public bool IsTrial { get; set; }

    /// <summary>
    /// Description text for the licence status
    /// </summary>
    public string StatusDescription { get; set; }

    /// <summary>
    /// Valid from date
    /// </summary>
    public DateTime? ValidFrom { get; set; }

    /// <summary>
    /// Valid to date
    /// </summary>
    public DateTime? ValidTo { get; set; }

    /// <summary>
    /// Represents allowed operations to the item (create, edit)
    /// No operations allowed when null
    /// </summary>
    public string AllowedOperation { get; set; }

    /// <summary>
    /// Licence Role
    /// </summary>
    public LicenseRoleModel Role { get; set; }
}
