using System;

namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Model for licence
/// </summary>
[Obsolete("Use SubscriptionModel")]
public class LicenceModel
{
    /// <summary>
    /// Id of licence
    /// </summary>
    public string Id { get; set; }

    /// <summary>
    /// Part code of licence
    /// </summary>
    public string PartCode { get; set; }

    /// <summary>
    /// Data of licence
    /// </summary>
    public string LicenceData { get; set; }

    /// <summary>
    /// Data of licence2
    /// </summary>
    public string LicenceData2 { get; set; }
}
