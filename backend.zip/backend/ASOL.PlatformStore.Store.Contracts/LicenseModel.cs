using System;

namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// License model for GET operations
/// </summary>
public class LicenseModel
{
    /// <summary>
    /// Valid from (inclusive). It can be null, which means it is valid from the beginning of time.
    /// </summary>
    public DateOnly? ValidFrom { get; set; }

    /// <summary>
    /// Valid to (inclusive). It can be null, which means it is valid to end of time.
    /// </summary>
    public DateOnly? ValidTo { get; set; }

    /// <summary>
    /// Package code.
    /// </summary>
    public string PackageCode { get; set; }

    /// <summary>
    /// Package name.
    /// </summary>
    public string PackageName { get; set; }

    /// <summary>
    /// Edition code.
    /// </summary>
    public string EditionCode { get; set; }

    /// <summary>
    /// Application code.
    /// </summary>
    public string ApplicationCode { get; set; }

    /// <summary>
    /// Subscription code.
    /// </summary>
    public string SubscriptionCode { get; set; }

    /// <summary>
    /// Sales item code.
    /// </summary>
    public string SalesItemCode { get; set; }

    /// <summary>
    /// Role code.
    /// </summary>
    public string RoleCode { get; set; }

    /// <summary>
    /// Current license system status <see cref="LicenseSystemStatus"/>.
    /// </summary>
    public LicenseSystemStatus? Status { get; set; }

    /// <summary>
    /// Maximum users allowed in license for this role.
    /// </summary>
    public int? UserMaxCount { get; set; }
}
