using System.ComponentModel.DataAnnotations;

namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// License model for Create operations
/// </summary>
public class LicenseModelCreate : LicenseModelDateRangeValidatableBase, IValidatableObject
{
    /// <summary>
    /// Package code.
    /// </summary>
    [Required]
    public required string PackageCode { get; init; }

    /// <summary>
    /// Package name.
    /// </summary>
    public string PackageName { get; init; }

    /// <summary>
    /// Edition code.
    /// </summary>
    [Required]
    public required string EditionCode { get; init; }

    /// <summary>
    /// Application code.
    /// </summary>
    [Required]
    public required string ApplicationCode { get; init; }

    /// <summary>
    /// Subscription code.
    /// </summary>
    public string SubscriptionCode { get; init; }

    /// <summary>
    /// Sales item code.
    /// </summary>
    public string SalesItemCode { get; init; }

    /// <summary>
    /// Role code.
    /// </summary>
    [Required]
    public required string RoleCode { get; init; }

    /// <summary>
    /// Maximum users allowed in license for this role.
    /// </summary>
    public int? UserMaxCount { get; init; }

    /// <summary>
    /// Current license system status <see cref="LicenseSystemStatus"/>.
    /// </summary>
    public LicenseSystemStatus? Status { get; init; }
}
