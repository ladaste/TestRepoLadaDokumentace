using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Abstract base class for license models that require validation of a date range.
/// Provides <c>ValidFrom</c> and <c>ValidTo</c> properties and ensures that <c>ValidTo</c> is not earlier than <c>ValidFrom</c>.
/// Implements <see cref="IValidatableObject"/> for use with data annotation validation.
/// </summary>
public abstract class LicenseModelDateRangeValidatableBase : IValidatableObject
{
    /// <summary>
    /// Valid from (inclusive). It can be null, which means it is valid from the beginning of time.
    /// </summary>
    public DateOnly? ValidFrom { get; init; }

    /// <summary>
    /// Valid to (inclusive). It can be null, which means it is valid to end of time.
    /// </summary>
    public DateOnly? ValidTo { get; init; }

    public virtual IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (ValidFrom.HasValue && ValidTo.HasValue && ValidTo.Value < ValidFrom.Value)
        {
            yield return new ValidationResult(
                "ValidTo must be greater than or equal to ValidFrom.",
                [nameof(ValidFrom), nameof(ValidTo)]
            );
        }
    }
}
