using System.ComponentModel.DataAnnotations;

namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// License model for Update operations (only selected properties can be updated)
/// </summary>
public class LicenseModelUpdate : LicenseModelDateRangeValidatableBase, IValidatableObject
{
    /// <summary>
    /// Maximum users allowed in license for this role.
    /// </summary>
    public int? UserMaxCount { get; init; }

    /// <summary>
    /// Current license system status <see cref="LicenseSystemStatus"/>.
    /// </summary>
    public LicenseSystemStatus? Status { get; init; }
}
