namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// License Role
/// </summary>
public class LicenseRoleModel
{
    /// <summary>
    /// Role Code
    /// </summary>
    public string RoleCode { get; set; }

    /// <summary>
    /// Role Name
    /// </summary>
    public string RoleName { get; set; }

    /// <summary>
    /// User Count
    /// </summary>
    public int? UserCount { get; set; }

    /// <summary>
    /// User Max Count
    /// </summary>
    public int? UserMaxCount { get; set; }
}
