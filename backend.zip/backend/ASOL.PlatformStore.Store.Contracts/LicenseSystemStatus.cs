namespace ASOL.PlatformStore.Store.Contracts;

public enum LicenseSystemStatus
{
    Validation = 1,
    Fail = 2,
    Confirmed = 3,
    Done = 4
}
