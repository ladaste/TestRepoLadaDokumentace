using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Localized Unit Name
/// </summary>
public class LocalizedUnitNameModel
{
    /// <summary>
    /// Locale
    /// </summary>
    /// <example>cs-CZ</example>
    public string Locale { get; set; }

    /// <summary>
    /// Localized unit name by quantity
    /// </summary>
    public IList<QuantifiedUnitNameModel> QuantifiedUnitName { get; set; }
}
