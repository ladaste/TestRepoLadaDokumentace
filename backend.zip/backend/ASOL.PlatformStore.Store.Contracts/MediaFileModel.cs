namespace ASOL.PlatformStore.Store.Contracts;

public class MediaFileModel
{
    public string Type { get; set; }

    public string ContentFileId { get; set; }

    public string PosterFileId { get; set; }
}
