namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Enum for types of nodes in the product catalog tree
/// </summary>
public enum NodeTypeModel
{
    /// <summary>
    /// Application
    /// </summary>
    Application = 1,

    /// <summary>
    /// Feature
    /// </summary>
    Feature = 2,

    /// <summary>
    /// Package
    /// </summary>
    Package = 3,

    /// <summary>
    /// Licence
    /// </summary>
    Licence = 4,

    /// <summary>
    /// Subscription
    /// </summary>
    Subscription = 5,

    /// <summary>
    /// Service
    /// </summary>
    Service = 6,

    /// <summary>
    /// Extension
    /// </summary>
    Extension = 7,

    /// <summary>
    /// Edition
    /// </summary>
    Edition = 8,

    /// <summary>
    /// SalesItem
    /// </summary>
    SalesItem = 9
}
