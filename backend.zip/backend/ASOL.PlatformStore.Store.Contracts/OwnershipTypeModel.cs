namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Ownership type
/// </summary>
public enum OwnershipTypeModel
{
    /// <summary>
    /// Own
    /// </summary>
    Own = 1,

    /// <summary>
    /// Rent
    /// </summary>
    Rent = 2
}
