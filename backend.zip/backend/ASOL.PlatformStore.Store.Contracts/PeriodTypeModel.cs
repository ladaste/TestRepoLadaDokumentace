namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// PeriodType
/// </summary>
public enum PeriodTypeModel
{
    /// <summary>
    /// Forward
    /// </summary>
    Forward = 1,

    /// <summary>
    /// Backward
    /// </summary>
    Backward = 2
}
