namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// PeriodUnit
/// </summary>
public enum PeriodUnitModel
{
    /// <summary>
    /// Day
    /// </summary>
    Day = 1,

    /// <summary>
    /// Month
    /// </summary>
    Month = 2,

    /// <summary>
    /// Year
    /// </summary>
    Year = 3
}
