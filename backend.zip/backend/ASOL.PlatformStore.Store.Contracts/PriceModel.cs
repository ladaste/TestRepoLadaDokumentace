using System;

namespace ASOL.PlatformStore.Store.Contracts;

public class PriceModel
{
    public DateTime? ValidFrom { get; set; }
    public DateTime? ValidTo { get; set; }
    public decimal BasePrice { get; set; }
}
