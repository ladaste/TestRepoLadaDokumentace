namespace ASOL.PlatformStore.Store.Contracts;

public class PriceScaleModel
{
    public int? MinLicences { get; set; }
    public int? MaxLicences { get; set; }
    public decimal BasePricePercentage { get; set; }
}
