namespace ASOL.PlatformStore.Store.Contracts.Primitives;

public enum InvalidateCacheEventType
{
    ApplicationRecentChanged = 1,
    ApplicationLicenseChanged,
    LicenseRoleMemberChanged,
}
