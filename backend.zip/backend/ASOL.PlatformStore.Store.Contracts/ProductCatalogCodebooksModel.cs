using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.Contracts;

public class ProductCatalogCodebooksModel
{
    public IList<BillingPeriodModel> BillingPeriods { get; set; }
    public IList<UnitOfMeasureModel> UnitsOfMeasures { get; set; }
    public IList<UnitOfSaleModel> UnitsOfSales { get; set; }
}
