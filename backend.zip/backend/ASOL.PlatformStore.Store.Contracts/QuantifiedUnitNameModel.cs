namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Quantified Unit Name
/// </summary>
public class QuantifiedUnitNameModel
{
    /// <summary>
    /// Minimum Quantity
    /// </summary>
    public uint? MinQuantity { get; set; }

    /// <summary>
    /// Maximum Quantity
    /// </summary>
    public uint? MaxQuantity { get; set; }

    /// <summary>
    /// Unit name
    /// </summary>
    public string Name { get; set; }
}
