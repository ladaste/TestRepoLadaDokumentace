using System;

namespace ASOL.PlatformStore.Store.Contracts;

public class SalesItemModel
{
    /// <summary>
    /// Subscription id
    /// </summary>
    public string Id { get; set; }

    /// <summary>
    /// Part code of licence
    /// </summary>
    public string PartCode { get; set; }

    /// <summary>
    /// Flag is reference is mandatory
    /// </summary>
    public bool IsMandatory { get; set; }

    /// <summary>
    /// Code from ItemType codebook
    /// </summary>
    public string ItemTypeCode { get; set; }

    /// <summary>
    /// OwnershipType
    /// </summary>
    public OwnershipTypeModel? OwnershipType { get; set; }

    /// <summary>
    /// Code from BillingPeriod codebook
    /// </summary>
    public string BillingPeriodCode { get; set; }

    /// <summary>
    /// Unit Of Sale - code
    /// </summary>
    public string UnitOfSaleCode { get; set; }

    /// <summary>
    /// Unit Of Measure - code
    /// </summary>
    public string UnitOfMeasureCode { get; set; }

    /// <summary>
    /// Valid from
    /// </summary>
    public DateTime? ValidFrom { get; set; }

    /// <summary>
    /// Valid to
    /// </summary>
    public DateTime? ValidTo { get; set; }

    /// <summary>
    /// Upgrade type
    /// </summary>
    public UpgradeTypeModel? UpgradeType { get; set; }

    /// <summary>
    /// can be canceled / cannot be canceled
    /// </summary>
    public bool? CanCancel { get; set; }

    /// <summary>
    /// Sales item
    /// </summary>
    public SalesItemReferenceModel SalesItem { get; set; }

    /// <summary>
    /// Name
    /// </summary>
    public string Name { get; set; }

    /// <summary>
    /// Role Code
    /// </summary>
    public string RoleCode { get; set; }
}
