using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.Contracts;

public class SalesItemReferenceModel
{
    public IEnumerable<PriceModel> PriceList { get; set; }
    public IEnumerable<PriceScaleModel> PriceScales { get; set; }
}
