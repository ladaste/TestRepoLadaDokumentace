using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Search parameters for store items
/// </summary>
public class SearchAllPurchasedDataModel
{
    /// <summary>
    /// Search text to search the store for
    /// </summary>
    public string SearchText { get; set; }

    /// <summary>
    /// Flag marking if api should exclude default apps from response 
    /// </summary>
    public bool ExcludeDefaultApps { get; set; }

    /// <summary>
    /// 
    /// </summary>
    public List<string> ExcludeCategoryCodes { get; set; }

    /// <summary>
    /// 
    /// </summary>
    public List<string> CategoryCodes { get; set; }
}
