using System.Collections.Generic;
namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Search parameters for store items
/// </summary>
public class SearchParametersModel
{
    /// <summary>
    /// Is Carousel View to specify search and response structure
    /// </summary>
    public bool IsCarouselView { get; set; }

    /// <summary>
    /// Is Source Licenses to specify source from which to get data from IDM
    /// </summary>
    public bool IsSourceLicenses { get; set; }

    /// <summary>
    /// Search text to search the store for
    /// </summary>
    public string SearchText { get; set; }

    /// <summary>
    /// Flag marking if api should exclude default apps from response 
    /// </summary>
    public bool ExcludeDefaultApps { get; set; }

    /// <summary>
    /// Flag marking if api should include Solution Partners info in response
    /// </summary>
    public bool ShowSolutionPartners { get; set; }

    /// <summary>
    /// List of category codes to exclude from the search
    /// </summary>
    public ICollection<string> ExcludeCategoryCodes { get; set; }

    /// <summary>
    /// List of category codes to search the store for
    /// </summary>
    public ICollection<string> CategoryCodes { get; set; }

    /// <summary>
    /// List of category codes suitable for to search the store for
    /// </summary>
    public ICollection<string> SuitableForCategoryCodes { get; set; }

    /// <summary>
    /// List of additional filetrs
    /// </summary>
    public ICollection<string> AdditionalFilter { get; set; }
}
