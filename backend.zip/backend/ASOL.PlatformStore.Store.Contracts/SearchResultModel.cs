using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Model for search result
/// </summary>
public class SearchResultModel
{
    /// <summary>
    /// List of category results after search
    /// </summary>
    public ICollection<CategoryResultModel> Categories { get; set; }
}
