using System.Collections.Generic;
using ASOL.PlatformStore.Store.Contracts.Enums;

namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Search parameters for store items
/// </summary>
public class SearchSubscriptionsModel
{
    /// <summary>
    /// Search text to search the store for
    /// </summary>
    public string SearchText { get; set; }

    /// <summary>
    /// Flag marking if api should exclude default apps from response 
    /// </summary>
    public bool ExcludeDefaultApps { get; set; }

    /// <summary>
    /// Enum marking type of access type view
    /// </summary>
    public List<AccessTypeView> AccessTypeViews { get; set; }
}
