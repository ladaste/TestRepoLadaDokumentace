using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Model for store item detail
/// </summary>
public class StoreItemDetailModel : StoreItemModel
{
    /// <summary>
    ///  Tile description text
    /// </summary>
    public string Description { get; set; }

    /// <summary>
    ///  Tile detail description text
    /// </summary>
    public string DetailDescription { get; set; }

    /// <summary>
    ///  Tile detail description data
    /// </summary>
    public ICollection<DescriptionFeatureItemModel> DetailDescriptionStructure { get; set; }

    /// <summary>
    ///  Tile media files
    /// </summary>
    public string MediaFiles { get; set; }

    /// <summary>
    ///  Slider definition
    /// </summary>
    public string SliderDefinition { get; set; }

    /// <summary>
    ///  Tile media files structure
    /// </summary>
    public ICollection<MediaFileModel> MediaFilesStructure { get; set; }

    /// <summary>
    ///  Flag if Navigate To Edition is Visible
    /// </summary>
    public bool NavigateToEditionVisible { get; set; }

    /// <summary>
    ///  Navigate To Edition Text
    /// </summary>
    public string NavigateToEditionText { get; set; }

    /// <summary>
    ///  Navigate To Edition Part Code
    /// </summary>
    public string NavigateToEditionPartCode { get; set; }

    /// <summary>
    ///  Marketing Claim
    /// </summary>
    public string MarketingClaim { get; set; }

    /// <summary>
    ///  Legal Disclaimer Short
    /// </summary>
    public string LegalDisclaimerShort { get; set; }

    /// <summary>
    ///  Selected Default Edition Id
    /// </summary>
    public string DefaultEditionId { get; set; }

    /// <summary>
    ///  Selected Default Licence Id
    /// </summary>
    public string DefaultLicenceId { get; set; }

    /// <summary>
    ///  Coming Soon
    /// </summary>
    public bool ComingSoon { get; set; }

    /// <summary>
    ///  Licence Provider
    /// </summary>
    public string LicenceProvider { get; set; }

    /// <summary>
    ///  Additional Legal Documents
    /// </summary>
    public List<LegalDocumentLocalizedModel> AdditionalLegalDocuments { get; set; }

    /// <summary>
    /// Collection of assigned editions
    /// </summary>
    public ICollection<EditionModel> Editions { get; set; }

    /// <summary>
    /// Collection of all package features
    /// </summary>
    public ICollection<FeatureModel> Features { get; set; }

    /// <summary>
    /// Version of the store item detail.
    /// </summary>
    public string Version { get; set; }

    /// <summary>
    /// Flag if store item is Published
    /// </summary>
    public bool Published { get; set; }
}
