using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Model for store item
/// </summary>
public class StoreItemModel
{
    /// <summary>
    /// Id of the item - id of the product
    /// </summary>
    public string Id { get; set; }

    /// <summary>
    /// Localized product name for display in the store
    /// </summary>
    public string Name { get; set; }

    /// <summary>
    ///  Tile short description text
    /// </summary>
    public string ShortDescription { get; set; }

    /// <summary>
    /// Reference to image of the tile
    /// </summary>
    public string CardImageId { get; set; }

    /// <summary>
    /// Url for navigation
    /// </summary>
    public string FrontendUrl { get; set; }

    /// <summary>
    /// Category assigned to the item
    /// </summary>
    public CategoryModel Category { get; set; }

    /// <summary>
    /// Integration Categories assigned to the item
    /// </summary>
    public List<CategoryModel> IntegrationCategories { get; set; }

    /// <summary>
    /// Application Code
    /// </summary>
    public string ApplicationCode { get; set; }

    /// <summary>
    /// Solution Partner Id
    /// </summary>
    public string SolutionPartnerId { get; set; }

    /// <summary>
    /// Solution Partner Name
    /// </summary>
    public string SolutionPartnerName { get; set; }

    /// <summary>
    /// Flag if store item is Published
    /// </summary>
    public bool Published { get; set; }
}
