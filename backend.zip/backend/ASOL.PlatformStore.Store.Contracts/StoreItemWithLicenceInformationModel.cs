using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Model for store item with licence information
/// </summary>
public class StoreItemWithLicenceInformationModel : StoreItemModel
{
    /// <summary>
    /// Order number
    /// </summary>
    public string OrderNumber { get; set; }

    public IEnumerable<LicenceInformationModel> LicenceInformationModels { get; set; }
}
