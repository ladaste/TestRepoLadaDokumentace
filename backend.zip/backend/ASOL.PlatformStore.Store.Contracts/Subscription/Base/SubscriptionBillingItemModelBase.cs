using System;
using ASOL.PlatformStore.Store.Contracts.Subscription.Enums;
using ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Base;

/// <summary>
/// Base implementation of <see cref="ISubscriptionBillingItemModel{TValue}"/> for billing items related to subscriptions.
/// </summary>
public class SubscriptionBillingItemModelBase<TValue> : ISubscriptionBillingItemModel<TValue>
    where TValue : class
{
    /// <inheritdoc/>
    public string Id { get; set; }

    /// <inheritdoc/>
    public string SubscriptionId { get; set; }

    /// <inheritdoc/>
    public SubscriptionCustomerModel Customer { get; set; }

    /// <inheritdoc/>
    public string OrderNumber { get; set; }

    /// <inheritdoc/>
    public string OrderLineId { get; set; }

    /// <inheritdoc/>
    public string ProductId { get; set; }

    /// <inheritdoc/>
    public string ProductCode { get; set; }

    /// <inheritdoc/>
    public TValue ProductName { get; set; }

    /// <inheritdoc/>
    public string ProductPartCode { get; set; }

    /// <inheritdoc/>
    public decimal? BasePrice { get; set; }

    /// <inheritdoc/>
    public int? LicenseCount { get; set; }

    /// <inheritdoc/>
    public string BillingPeriodCode { get; set; }

    /// <inheritdoc/>
    public string UnitOfMeasureCode { get; set; }

    /// <inheritdoc/>
    public string UnitOfSaleCode { get; set; }

    /// <inheritdoc/>
    public string OwnershipType { get; set; }

    /// <inheritdoc/>
    public string ItemTypeCode { get; set; }

    /// <inheritdoc/>
    public SubscriptionDevelopmentPartnerModel DevelopmentPartner { get; set; }

    /// <inheritdoc/>
    public string ApplicationCode { get; set; }

    /// <inheritdoc/>
    public DateOnly? AccrualDateFrom { get; set; }

    /// <inheritdoc/>
    public DateOnly? AccrualDateTo { get; set; }

    /// <inheritdoc/>
    public decimal? DiscountAmount { get; set; }

    /// <inheritdoc/>
    public DateOnly? DiscountValidFrom { get; set; }

    /// <inheritdoc/>
    public DateOnly? DiscountValidTo { get; set; }

    /// <inheritdoc/>
    public string DiscountInternalNote { get; set; }

    /// <inheritdoc/>
    public bool IsInitialDiscountFromOrder { get; set; }

    /// <inheritdoc/>
    public DateOnly? NextInvoiceExpectedDate { get; set; }

    /// <inheritdoc/>
    public InvoiceStatus InvoiceStatus { get; set; } = InvoiceStatus.NotGenerated;
}
