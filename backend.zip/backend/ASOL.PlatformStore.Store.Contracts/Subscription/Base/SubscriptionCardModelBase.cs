using ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Base;

public class SubscriptionCardModelBase<TValue> : ISubscriptionCardModel<TValue>
    where TValue : class
{
    /// <inheritdoc/>
    public string Id { get; set; }

    /// <inheritdoc/>
    public string OrderNumber { get; set; }

    /// <inheritdoc/>
    public string PendingOrderNumber { get; set; }

    /// <inheritdoc/>
    public string TenantId { get; set; }

    /// <inheritdoc/>
    public string PackageProductId { get; set; }

    /// <inheritdoc/>
    public TValue PackageName { get; set; }

    /// <inheritdoc/>
    public TValue PackageShortDescription { get; set; }

    /// <inheritdoc/>
    public string PackageCardImageFileId { get; set; }

    /// <inheritdoc/>
    public string ApplicationProductId { get; set; }

    /// <inheritdoc/>
    public TValue ApplicationName { get; set; }

    /// <inheritdoc/>
    public string ApplicationCode { get; set; }

    /// <inheritdoc/>
    public TValue ApplicationShortDescription { get; set; }

    /// <inheritdoc/>
    public string EditionProductId { get; set; }

    /// <inheritdoc/>
    public TValue EditionName { get; set; }

    /// <inheritdoc/>
    public TValue EditionDescription { get; set; }

    /// <inheritdoc/>
    public string FrontendUrl { get; set; }

    /// <inheritdoc/>
    public string BackendUrl { get; set; }

    /// <inheritdoc/>
    public string SubscriptionStatus { get; set; }

    /// <inheritdoc/>
    public bool IsNative { get; set; }

    /// <inheritdoc/>
    public bool IsVisible { get; set; }

    /// <summary>
    /// Status of the subscription description
    /// </summary>
    public TValue SubscriptionStatusLabel { get; set; }

    /// <summary>
    /// Indicates whether this is a system subscription
    /// </summary>
    public bool IsSystem { get; set; }
}
