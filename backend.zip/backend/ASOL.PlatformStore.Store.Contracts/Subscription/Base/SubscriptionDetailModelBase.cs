using System.Collections.Generic;
using ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Base;

public class SubscriptionDetailModelBase<TValue, TOrder, TOrderLine, TOrderItem, TMetadata, TOrderInfo, TSolutionStatus>
    : ISubscriptionDetailModel<TValue, TOrder, TOrderLine, TOrderItem, TMetadata, TOrderInfo, TSolutionStatus>
    where TValue : class
    where TOrderLine : ISubscriptionOrderLineModel<TValue>
    where TOrder : ISubscriptionOrderModel<TValue, TOrderLine, TOrderItem, TOrderInfo>
    where TOrderInfo : SubscriptionOrderMetadataModelBase<TValue>, new()
    where TOrderItem : SubscriptionOrderItemGroupModelBase<TValue>
    where TMetadata : SubscriptionMetadataModelBase<TValue>
    where TSolutionStatus : SubscriptionSolutionStatusModelBase<TValue>
{
    /// <summary>
    /// Subscription id
    /// </summary>
    public string Id { get; set; }

    /// <summary>
    /// Tenant id
    /// </summary>
    public string TenantId { get; set; }

    /// <inheritdoc/>
    public string PackageProductId { get; set; }

    /// <inheritdoc/>
    public TValue PackageName { get; set; }

    /// <inheritdoc/>
    public TValue PackageShortDescription { get; set; }

    /// <inheritdoc/>
    public string PackageCardImageFileId { get; set; }

    /// <inheritdoc/>
    public string ApplicationProductId { get; set; }

    /// <inheritdoc/>
    public TValue ApplicationName { get; set; }

    /// <inheritdoc/>
    public string ApplicationCode { get; set; }

    /// <inheritdoc/>
    public TValue ApplicationShortDescription { get; set; }

    /// <inheritdoc/>
    public string EditionProductId { get; set; }

    /// <inheritdoc/>
    public TValue EditionName { get; set; }

    /// <inheritdoc/>
    public TValue EditionDescription { get; set; }

    /// <inheritdoc/>
    public string FrontendUrl { get; set; }

    /// <inheritdoc/>
    public string BackendUrl { get; set; }

    /// <inheritdoc/>
    public bool IsNative { get; set; }

    /// <inheritdoc/>
    public bool IsVisible { get; set; }

    /// <inheritdoc/>
    public TMetadata SubscriptionMetadata { get; set; }

    /// <inheritdoc/>
    public SubscriptionBillingSummaryModel BillingSummaryModel { get; set; }

    /// <inheritdoc/>
    public ICollection<TOrder> Orders { get; set; }

    /// <inheritdoc/>
    public SubscriptionSolutionPartnerModel ApplicationSolutionPartner { get; set; }

    /// <inheritdoc/>
    public SubscriptionDevelopmentPartnerModel DevelopmentPartner { get; set; }

    /// <inheritdoc/>
    public SubscriptionSolutionPartnerModel TenantSolutionPartner { get; set; }

    /// <inheritdoc/>
    public SubscriptionCustomerModel Customer { get; set; }

    /// <inheritdoc/>
    public ICollection<TSolutionStatus> StatusHistory { get; set; }

    /// <summary>
    /// Indicates whether this is a system subscription
    /// </summary>
    public bool IsSystem { get; set; }
}
