using System;
using ASOL.PlatformStore.Store.Contracts.Subscription.Enums;
using ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Base;

public class SubscriptionMetadataModelBase<TValue> : ISubscriptionMetadataModel
    where TValue : class
{
    /// <summary>
    /// Status of the subscription description
    /// </summary>
    public TValue SubscriptionStatusLabel { get; set; }

    /// <inheritdoc/>
    public string OrderNumber { get; set; }

    /// <inheritdoc/>
    public string PendingOrderNumber { get; set; }

    /// <inheritdoc/>
    public bool AutoInvoicingEnabled { get; set; }

    /// <inheritdoc/>
    public bool IsChangeInProgress { get; set; }

    /// <inheritdoc/>
    public string SubscriptionStatus { get; set; }

    /// <summary>
    /// Solution status label
    /// </summary>
    public TValue SolutionStatusLabel { get; set; }

    /// <inheritdoc/>
    public string SolutionStatus { get; set; }

    /// <inheritdoc/>
    public DateOnly? SolutionActiveFrom { get; set; }

    /// <summary>
    /// Indicates whether the subscription is active.
    /// </summary>
    public bool IsActive =>
        SolutionStatus == nameof(SubscriptionSolutionStatus.Active) &&
        SolutionActiveFrom.HasValue;

    /// <inheritdoc/>
    public string SolutionStatusNote { get; set; }

    /// <inheritdoc/>
    public string SolutionStatusModifiedBy { get; set; }

    /// <inheritdoc/>
    public DateTime? SolutionStatusModifiedOn { get; set; }

    /// <inheritdoc/>
    public string KeyAccountUserName { get; set; }

    /// <inheritdoc/>
    public string KeyAccountAccountId { get; set; }

    /// <inheritdoc/>
    public string KeyAccountPersonId { get; set; }

    /// <inheritdoc/>
    public string KeyAccountFirstName { get; set; }

    /// <inheritdoc/>
    public string KeyAccountLastName { get; set; }

    /// <inheritdoc/>
    public decimal? DiscountAmount { get; set; }

    /// <inheritdoc/>
    public DateOnly? DiscountValidFrom { get; set; }

    /// <inheritdoc/>
    public DateOnly? DiscountValidTo { get; set; }

    /// <inheritdoc/>
    public string DiscountInternalNote { get; set; }
}
