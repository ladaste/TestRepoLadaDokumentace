using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Base;

public class SubscriptionOrderItemGroupModelBase<TValue>
    where TValue : class
{
    /// <summary>
    /// Product identifier
    /// </summary>
    public string ProductId { get; set; }

    /// <summary>
    /// Product name
    /// </summary>         
    public TValue ProductName { get; set; }

    /// <summary>
    /// Product description
    /// </summary>      
    public TValue ProductDescription { get; set; }

    /// <summary>
    /// Item node type line type
    /// </summary>  	
    public string ItemNodeType { get; set; }

    /// <summary>
    /// Order items
    /// </summary>
    public ICollection<SubscriptionOrderItemModelBase<TValue>> Items { get; set; }
}
