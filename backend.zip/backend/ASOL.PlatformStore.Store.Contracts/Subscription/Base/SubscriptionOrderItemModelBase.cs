using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Base;

public class SubscriptionOrderItemModelBase<TValue>
    where TValue : class
{
    /// <summary>
    /// Product identifier
    /// </summary>
    public string ProductId { get; set; }

    /// <summary>
    /// Product name
    /// </summary>         
    public TValue ProductName { get; set; }

    /// <summary>
    /// Product description
    /// </summary>      
    public TValue ProductDescription { get; set; }

    /// <summary>
    /// Item node type line type
    /// </summary>  	
    public string ItemNodeType { get; set; }

    /// <summary>
    /// Sales items associated with the subscription order item
    /// </summary>
    public ICollection<SubscriptionOrderSalesItemModelBase<TValue>> SalesItems { get; set; }
}
