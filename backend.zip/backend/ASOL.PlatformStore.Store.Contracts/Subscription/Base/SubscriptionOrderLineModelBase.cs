using ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Base;

public class SubscriptionOrderLineModelBase<TValue> : ISubscriptionOrderLineModel<TValue>
    where TValue : class
{
    /// <inheritdoc/>          
    public string OrderLineId { get; set; }

    /// <inheritdoc/>          
    public string ParentOrderLineId { get; set; }

    /// <inheritdoc/>          
    public string OrderLineType { get; set; }

    /// <inheritdoc/>          
    public string ProductId { get; set; }

    /// <inheritdoc/>          
    public string ProductCode { get; set; }

    /// <inheritdoc/>          
    public TValue ProductName { get; set; }

    /// <inheritdoc/>          
    public TValue ProductDescription { get; set; }

    /// <inheritdoc/>          
    public string ProductPartCode { get; set; }

    /// <inheritdoc/>          
    public decimal? Price { get; set; }

    /// <inheritdoc/>          
    public decimal? BasePrice { get; set; }

    /// <inheritdoc/>          
    public string BillingPeriodCode { get; set; }

    /// <inheritdoc/>          
    public string SubscriptionPeriod { get; set; }

    /// <inheritdoc/>          
    public string ItemTypeCode { get; set; }

    /// <inheritdoc/>          
    public string OwnershipType { get; set; }

    /// <inheritdoc/>          
    public string UnitOfMeasureCode { get; set; }

    /// <inheritdoc/>          
    public string UnitOfSaleCode { get; set; }

    /// <inheritdoc/>          
    public int? LicenceCount { get; set; }

    /// <inheritdoc/>      
    public int? LicenceTrialDays { get; set; }
}
