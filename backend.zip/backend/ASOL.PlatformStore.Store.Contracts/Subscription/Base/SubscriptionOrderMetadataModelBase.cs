using System;
using ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Base;

public class SubscriptionOrderMetadataModelBase<TValue> :
    ISubscriptionOrderMetadataModel,
    ISubscriptionOrderCustomizationModel,
    ISubscriptionOrderStatusModel,
    ISubscriptionOrderSalesPersonModel,
    ISubscriptionOrderInvoiceModel
    where TValue : class
{
    /// <inheritdoc/>
    public string OrderId { get; set; }

    /// <inheritdoc/>
    public string OrderNumber { get; set; }

    /// <inheritdoc/>
    public string Status { get; set; }

    /// <inheritdoc/>
    public string StatusModifiedBy { get; set; }

    /// <inheritdoc/>
    public DateTime? StatusModifiedOn { get; set; }

    /// <summary>
    /// Status label of the order
    /// </summary>
    public TValue StatusLabel { get; set; }

    /// <inheritdoc/>
    public DateTime OrderDate { get; set; }

    /// <inheritdoc/>
    public string SolutionPartnerId { get; set; }

    /// <inheritdoc/>
    public string SolutionPartnerCode { get; set; }

    /// <inheritdoc/>
    public string SolutionPartnerName { get; set; }

    /// <inheritdoc/>
    public string SolutionRepUserName { get; set; }

    /// <inheritdoc/>
    public string SolutionRepPersonId { get; set; }

    /// <inheritdoc/>
    public string SolutionRepFirstName { get; set; }

    /// <inheritdoc/>
    public string SolutionRepLastName { get; set; }

    /// <inheritdoc/>
    public string SalesUserName { get; set; }

    /// <inheritdoc/>
    public string SalesPersonId { get; set; }

    /// <inheritdoc/>
    public string SalesFirstName { get; set; }

    /// <inheritdoc/>
    public string SalesLastName { get; set; }

    /// <inheritdoc/>
    public string Note { get; set; }

    /// <inheritdoc/>
    public bool IsSystem { get; set; }

    /// <inheritdoc/>
    public string ModifiedBy { get; set; }

    /// <inheritdoc/>
    public DateTime? ModifiedOn { get; set; }

    /// <inheritdoc/>
    public DateTime? LatestInvoiceVatDate { get; set; }

    /// <inheritdoc/>
    public DateTime? LatestInvoiceAccrualDateFrom { get; set; }

    /// <inheritdoc/>
    public DateTime? LatestInvoiceAccrualDateTo { get; set; }

    /// <inheritdoc/>
    public int? OrderInvoiceCount { get; set; }

    /// <inheritdoc/>
    public DateTime? OrderFirstInvoiceVatDate { get; set; }

    /// <inheritdoc/>
    public DateTime? OrderLastInvoiceVatDate { get; set; }

    /// <inheritdoc/>
    public bool TermsAndConditionsAccepted { get; set; }
}
