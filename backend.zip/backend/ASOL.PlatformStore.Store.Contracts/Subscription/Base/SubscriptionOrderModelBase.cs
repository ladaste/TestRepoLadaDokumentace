using System.Collections.Generic;
using ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Base;

public class SubscriptionOrderModelBase<TValue, TOrderLine, TOrderItem, TOrderInfo> : ISubscriptionOrderModel<TValue, TOrderLine, TOrderItem, TOrderInfo>
    where TValue : class
    where TOrderLine : ISubscriptionOrderLineModel<TValue>
    where TOrderItem : SubscriptionOrderItemGroupModelBase<TValue>
    where TOrderInfo : SubscriptionOrderMetadataModelBase<TValue>, new()
{
    /// <inheritdoc/>
    public string TenantId { get; set; }

    /// <inheritdoc/>
    public string OrderId { get; set; }

    /// <inheritdoc/>
    public string OrderNumber { get; set; }

    /// <inheritdoc/>
    public ICollection<TOrderLine> OrderLines { get; set; } = [];

    /// <inheritdoc/>
    public ICollection<TOrderItem> OrderItems { get; set; } = [];

    /// <inheritdoc/>
    public ICollection<SubscriptionOrderPaymentModel> OrderPayments { get; set; } = [];

    /// <inheritdoc/>
    public TOrderInfo OrderInfo { get; set; } = new();
}
