namespace ASOL.PlatformStore.Store.Contracts.Subscription.Base;

public class SubscriptionOrderSalesItemModelBase<TValue>
    where TValue : class
{
    /// <summary>
    /// Product identifier
    /// </summary>
    public string ProductId { get; set; }

    /// <summary>
    /// Product name
    /// </summary>         
    public TValue ProductName { get; set; }

    /// <summary>
    /// Billing period code
    /// </summary>     
    public string BillingPeriodCode { get; set; }

    /// <summary>
    /// Billing period for the subscription
    /// </summary>  
    public string SubscriptionPeriod { get; set; }

    /// <summary>
    /// Total price of the item
    /// </summary>       
    public decimal? Price { get; set; }

    /// <summary>
    /// Base price of the item
    /// </summary>        
    public decimal? BasePrice { get; set; }

    /// <summary>
    /// Unit of measure code
    /// </summary>       
    public string UnitOfMeasureCode { get; set; }

    /// <summary>
    /// Unit of sale code
    /// </summary>    
    public string UnitOfSaleCode { get; set; }

    /// <summary>
    /// Licence count
    /// </summary>          
    public int? LicenceCount { get; set; }

    /// <summary>
    /// Trial days for the licence
    /// </summary>
    public int? LicenceTrialDays { get; set; }
}
