using System.Linq;
using ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Base;

public class SubscriptionOrganizationModelBase : ISubscriptionOrganizationModel
{
    /// <inheritdoc/>  
    public string Id { get; set; }

    /// <inheritdoc/>  
    public string TenantId { get; set; }

    /// <inheritdoc/>  
    public string Name { get; set; }

    /// <inheritdoc/>  
    public string Code { get; set; }

    /// <inheritdoc/>
    public string VatIn { get; set; }

    /// <inheritdoc/>
    public string Line1 { get; set; }

    /// <inheritdoc/>
    public string Line2 { get; set; }

    /// <inheritdoc/>
    public string Line3 { get; set; }

    /// <inheritdoc/>
    public string City { get; set; }

    /// <inheritdoc/>
    public string CountryCode { get; set; }

    /// <inheritdoc/>
    public string ZipCode { get; set; }

    /// <inheritdoc/>
    public string RegistryNumber { get; set; }

    /// <inheritdoc/>
    public string HouseNumber { get; set; }

    /// <inheritdoc/>
    public string StreetName { get; set; }

    /// <summary>
    /// Unique national organization identification number. (ICO etc.)
    /// </summary>
    public string Number => string.IsNullOrEmpty(Code) ? null : Code.Split('|').FirstOrDefault();

    /// <summary>
    /// Addresses of the organization.
    /// </summary>
    public string Addresses =>
        !string.IsNullOrWhiteSpace(StreetName)
            ? $"{StreetName} {HouseNumber}, {ZipCode} {City}, {CountryCode}"
            : !string.IsNullOrWhiteSpace(Line1)
                ? $"{Line1}, {CountryCode}"
                : null;
}
