using System;
using ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Base;

public class SubscriptionSolutionStatusModelBase<TValue> : ISubscriptionSolutionStatusModel
    where TValue : class
{
    /// <inheritdoc/>
    public string SolutionStatus { get; set; }

    /// <summary>
    /// Solution status label
    /// </summary>
    public TValue SolutionStatusLabel { get; set; }

    /// <inheritdoc/>
    public DateOnly? SolutionActiveFrom { get; set; }

    /// <inheritdoc/>
    public string SolutionStatusNote { get; set; }

    /// <inheritdoc/>
    public string SolutionStatusModifiedBy { get; set; }

    /// <inheritdoc/>
    public DateTime? SolutionStatusModifiedOn { get; set; }
}
