using System;
using ASOL.DataGridComponent.Contracts.Annotations.Filter.FilterFields;
using ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Base;

public class SubscriptionSummaryModelBase<TValue> : ISubscriptionSummaryModel<TValue>
    where TValue : class
{
    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public string Id { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public string OrderNumber { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public string PendingOrderNumber { get; set; }

    /// <inheritdoc/>
    public string SubscriptionStatus { get; set; }

    /// <summary>
    /// Status of the subscription description
    /// </summary>
    public TValue SubscriptionStatusLabel { get; set; }

    /// <inheritdoc/>
    public bool IsChangeInProgress { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public string ApplicationSolutionPartnerTenantId { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public string ApplicationSolutionPartnerOrganizationId { get; set; }

    /// <inheritdoc/>
    public string ApplicationSolutionPartnerOrganizationName { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public string DevelopmentPartnerTenantId { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public string DevelopmentPartnerOrganizationId { get; set; }

    /// <inheritdoc/>
    public string DevelopmentPartnerOrganizationName { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public string TenantSolutionPartnerTenantId { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public string TenantSolutionPartnerOrganizationId { get; set; }

    /// <inheritdoc/>
    public string TenantSolutionPartnerOrganizationName { get; set; }

    /// <inheritdoc/>
    public DateTime? OrderDate { get; set; }

    /// <inheritdoc/>
    public DateTime? SubscriptionStatusModifiedOn { get; set; }

    /// <inheritdoc/>
    public DateTime? ValidTo { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public string TenantId { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public string PackageProductId { get; set; }

    /// <inheritdoc/>
    public TValue PackageName { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public TValue PackageShortDescription { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public string PackageCardImageFileId { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public string ApplicationProductId { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public TValue ApplicationName { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public string ApplicationCode { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public TValue ApplicationShortDescription { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public string EditionProductId { get; set; }

    /// <inheritdoc/>
    public TValue EditionName { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public TValue EditionDescription { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public string FrontendUrl { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public string BackendUrl { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public bool IsNative { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public bool IsVisible { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public string CustomerOrganizationId { get; set; }

    /// <inheritdoc/>
    public string CustomerOrganizationName { get; set; }

    /// <inheritdoc/>
    [IgnoreInFilterFilterFieldAnnotation]
    public string PendingOrderDevelopmentStatus { get; set; }

    /// <summary>
    /// Development status of the pending order
    /// </summary>
    [IgnoreInFilterFilterFieldAnnotation]
    public TValue PendingOrderDevelopmentStatusLabel { get; set; }

    /// <inheritdoc/>
    public string DevelopmentStatus { get; set; }

    /// <summary>
    /// Development status of the order
    /// </summary>
    public TValue DevelopmentStatusLabel { get; set; }

    /// <inheritdoc/>
    public string SolutionStatus { get; set; }

    /// <summary>
    /// Solution status of the subscription
    /// </summary>
    public TValue SolutionStatusLabel { get; set; }

    /// <summary>
    /// Indicates whether this is a system subscription
    /// </summary>
    [IgnoreInFilterFilterFieldAnnotation]
    public bool IsSystem { get; set; }
}
