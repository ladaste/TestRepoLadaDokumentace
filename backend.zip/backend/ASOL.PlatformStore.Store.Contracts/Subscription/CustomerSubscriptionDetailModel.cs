using System.Collections.Generic;
using ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

namespace ASOL.PlatformStore.Store.Contracts.Subscription;

public class CustomerSubscriptionDetailModel : ISubscriptionApplicationModel<string>
{
    /// <summary>
    /// Subscription id
    /// </summary>  
    public string Id { get; set; }

    /// <summary>
    /// Tenant identifier
    /// </summary>    
    public string TenantId { get; set; }

    /// <inheritdoc/>          
    public string PackageProductId { get; set; }

    /// <inheritdoc/>          
    public string PackageName { get; set; }

    /// <inheritdoc/>          
    public string PackageShortDescription { get; set; }

    /// <inheritdoc/>          
    public string PackageCardImageFileId { get; set; }

    /// <inheritdoc/>          
    public string ApplicationProductId { get; set; }

    /// <inheritdoc/>          
    public string ApplicationName { get; set; }

    /// <inheritdoc/>   
    public string ApplicationCode { get; set; }

    /// <inheritdoc/>          
    public string ApplicationShortDescription { get; set; }

    /// <inheritdoc/>          
    public string EditionProductId { get; set; }

    /// <inheritdoc/>          
    public string EditionName { get; set; }

    /// <inheritdoc/>          
    public string EditionDescription { get; set; }

    /// <inheritdoc/>   
    public string FrontendUrl { get; set; }

    /// <inheritdoc/>   
    public string BackendUrl { get; set; }

    /// <inheritdoc/>
    public bool IsNative { get; set; }

    /// <inheritdoc/>
    public bool IsVisible { get; set; }

    /// <summary>
    /// Subscription general information
    /// </summary>            
    public SubscriptionMetadataModel SubscriptionMetadata { get; set; }

    /// <summary>
    /// Orders of the subscription
    /// </summary>             
    public ICollection<CustomerSubscriptionOrderModel> Orders { get; set; }

    /// <summary>
    /// Application solution partner of the subscription
    /// </summary>
    public SubscriptionSolutionPartnerModel ApplicationSolutionPartner { get; set; }

    /// <summary>
    /// Development partner of the subscription
    /// </summary>
    public SubscriptionDevelopmentPartnerModel DevelopmentPartner { get; set; }
}
