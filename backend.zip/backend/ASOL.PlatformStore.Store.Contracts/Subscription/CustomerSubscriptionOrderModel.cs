using System.Collections.Generic;
using ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

namespace ASOL.PlatformStore.Store.Contracts.Subscription;

public class CustomerSubscriptionOrderModel : ICustomerSubscriptionOrderModel<string, SubscriptionOrderLineModel, SubscriptionOrderItemGroupModel>, ISubscriptionOrderDisplayValues
{
    /// <inheritdoc/>
    public string TenantId { get; set; }

    /// <inheritdoc/>
    public string OrderId { get; set; }

    /// <inheritdoc cref="ICustomerSubscriptionOrderModel{TValue,TOrderLine,TOrderItem}" />
    public string OrderNumber { get; set; }

    /// <inheritdoc/>
    public string DisplaySubscriptionStatusLabel { get; set; }

    /// <inheritdoc/>
    public string DisplaySubscriptionStatus { get; set; }

    /// <inheritdoc/>
    public string DisplaySubscriptionSolutionStatus { get; set; }

    /// <inheritdoc/>
    public string DisplaySubscriptionSolutionStatusLabel { get; set; }

    /// <inheritdoc/>
    public ICollection<SubscriptionOrderLineModel> OrderLines { get; set; }

    /// <inheritdoc/>
    public ICollection<SubscriptionOrderItemGroupModel> OrderItems { get; set; }

    /// <inheritdoc/>
    public ICollection<SubscriptionOrderPaymentModel> OrderPayments { get; set; }
}
