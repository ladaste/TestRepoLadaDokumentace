using System;
using ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

namespace ASOL.PlatformStore.Store.Contracts.Subscription;

public class CustomerSubscriptionSummaryModel : ICustomerSubscriptionSummaryModel<string>
{
    /// <inheritdoc/>
    public string Id { get; set; }

    /// <inheritdoc/>
    public string OrderNumber { get; set; }

    /// <inheritdoc/>
    public string PendingOrderNumber { get; set; }

    /// <inheritdoc/>
    public string SubscriptionStatus { get; set; }

    /// <summary>
    /// Status of the subscription description
    /// </summary>
    public string SubscriptionStatusLabel { get; set; }

    /// <inheritdoc/>
    public bool IsChangeInProgress { get; set; }

    /// <inheritdoc/>
    public string ApplicationSolutionPartnerOrganizationId { get; set; }

    /// <inheritdoc/>
    public string ApplicationSolutionPartnerOrganizationName { get; set; }

    /// <inheritdoc/>
    public string DevelopmentPartnerOrganizationId { get; set; }

    /// <inheritdoc/>
    public string DevelopmentPartnerOrganizationName { get; set; }

    /// <inheritdoc/>
    public string TenantSolutionPartnerOrganizationId { get; set; }

    /// <inheritdoc/>
    public string TenantSolutionPartnerOrganizationName { get; set; }

    /// <inheritdoc/>
    public DateTime? OrderDate { get; set; }

    /// <inheritdoc/>
    public DateTime? SubscriptionStatusModifiedOn { get; set; }

    /// <inheritdoc/>
    public DateTime? ValidTo { get; set; }

    /// <inheritdoc/>
    public string TenantId { get; set; }

    /// <inheritdoc/>
    public string PackageProductId { get; set; }

    /// <inheritdoc/>
    public string PackageName { get; set; }

    /// <inheritdoc/>
    public string PackageShortDescription { get; set; }

    /// <inheritdoc/>
    public string PackageCardImageFileId { get; set; }

    /// <inheritdoc/>
    public string ApplicationProductId { get; set; }

    /// <inheritdoc/>
    public string ApplicationName { get; set; }

    /// <inheritdoc/>
    public string ApplicationCode { get; set; }

    /// <inheritdoc/>
    public string ApplicationShortDescription { get; set; }

    /// <inheritdoc/>
    public string EditionProductId { get; set; }

    /// <inheritdoc/>
    public string EditionName { get; set; }

    /// <inheritdoc/>
    public string EditionDescription { get; set; }

    /// <inheritdoc/>
    public string FrontendUrl { get; set; }

    /// <inheritdoc/>
    public string BackendUrl { get; set; }

    /// <inheritdoc/>
    public bool IsNative { get; set; }

    /// <inheritdoc/>
    public bool IsVisible { get; set; }

    /// <inheritdoc/>
    public bool IsSystem { get; set; }

    /// <summary>
    /// Gets the subscription number to display based on the subscription status.
    /// </summary>
    public string DisplaySubscriptionNumber => SubscriptionStatus == nameof(Enums.SubscriptionStatus.Pending)
        ? null
        : OrderNumber;
}
