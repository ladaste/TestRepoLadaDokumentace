namespace ASOL.PlatformStore.Store.Contracts.Subscription.Enums;

/// <summary>
/// Represents the status of an invoice for a billing item.
/// </summary>
public enum InvoiceStatus
{
    /// <summary>
    /// No invoice has been generated yet.
    /// </summary>
    NotGenerated = 0,

    /// <summary>
    /// Invoice has been generated but not yet approved.
    /// </summary>
    Generated = 1,

    /// <summary>
    /// Invoice has been approved.
    /// </summary>
    Approved = 2,

    /// <summary>
    /// Billing item was processed but intentionally skipped (e.g., zero-amount invoice).
    /// </summary>
    Skipped = 3
}
