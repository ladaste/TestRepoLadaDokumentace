namespace ASOL.PlatformStore.Store.Contracts.Subscription.Enums;

/// <summary>
/// Subscription status values
/// </summary>
public enum SubscriptionSolutionStatus
{
    /// <summary>
    /// Default status for newly created subscriptions
    /// Neaktivní/Inactive/Neaktívne - non-functional subscription in preparation
    /// </summary>
    Inactive = 1,

    /// <summary>
    /// Subscription is currently running, fully functional and invoiced
    /// Aktivní/Active/Aktivné - subscription that is currently running, fully functional and invoiced
    /// </summary>
    Active,

    /// <summary>
    /// Subscription was terminated after being active
    /// Ukončeno/Expired/Ukončené - subscription was active for a certain period and then terminated
    /// Final state - cannot be changed
    /// </summary>
    Expired,

    /// <summary>
    /// Subscription was cancelled before activation
    /// Zrušeno/Cancelled/Zrušené - subscription cancelled before activation
    /// Final state - cannot be changed
    /// </summary>
    Cancelled
}
