namespace ASOL.PlatformStore.Store.Contracts.Subscription.Enums;

/// <summary>
/// The subscription status is determined by the development and solution statuses.
/// </summary>
public enum SubscriptionStatus
{
    /// <summary>
    /// Pending status indicates that the subscription is awaiting some action or confirmation.
    /// </summary>
    Pending = 1,

    /// <summary>
    /// Running status indicates that the subscription is currently active and operational.
    /// </summary>
    Running = 2,

    /// <summary>
    /// Expired status indicates that the subscription has reached its end date and is no longer active.
    /// </summary>
    Expired = 3
}
