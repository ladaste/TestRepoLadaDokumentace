namespace ASOL.PlatformStore.Store.Contracts.Subscription.Etos;

#nullable enable

public record SubscriptionLicenseCreatedEto
(
    string LicenseId
);
