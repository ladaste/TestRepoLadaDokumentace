namespace ASOL.PlatformStore.Store.Contracts.Subscription.Etos;

public record SubscriptionLicenseDeletedEto
(
    string LicenseId
);
