namespace ASOL.PlatformStore.Store.Contracts.Subscription.Etos;

public record SubscriptionLicenseStatusUpdatedEto
(
    string LicenseId,
    LicenseSystemStatus? Status
);
