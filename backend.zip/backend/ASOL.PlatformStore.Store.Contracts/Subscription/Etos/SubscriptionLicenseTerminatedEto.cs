using System;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Etos;

public record SubscriptionLicenseTerminatedEto
(
    string LicenseId,
    DateOnly TerminationDate
);
