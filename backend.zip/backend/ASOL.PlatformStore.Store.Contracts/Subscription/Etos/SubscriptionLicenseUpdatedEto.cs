using System;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Etos;

#nullable enable

public record SubscriptionLicenseUpdatedEto
(
    string LicenseId,
    DateOnly? ValidFrom,
    DateOnly? ValidTo,
    LicenseSystemStatus? Status,
    int? UserMaxCount
);
