using ASOL.DataGridComponent.Contracts;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Filters;

public record class CustomerSubscriptionSummaryRequest : DataGridRequest
{
}
