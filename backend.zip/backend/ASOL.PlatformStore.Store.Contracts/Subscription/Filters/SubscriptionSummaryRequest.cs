using System.Collections.Generic;
using ASOL.DataGridComponent.Contracts;
using ASOL.PlatformStore.Store.Contracts.Enums;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Filters;

public record class SubscriptionSummaryRequest : DataGridRequest
{
    public List<AccessTypeView> AccessTypeViews { get; set; }
}
