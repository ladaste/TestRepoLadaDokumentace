using System.Collections.Generic;
using ASOL.PlatformStore.Store.Contracts.Subscription.Base;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

public interface ICustomerSubscriptionOrderModel<TValue, TOrderLine, TOrderItem>
    where TValue : class
    where TOrderLine : ISubscriptionOrderLineModel<TValue>
    where TOrderItem : SubscriptionOrderItemGroupModelBase<TValue>
{
    /// <summary>
    /// Tenant identifier
    /// </summary>
    string TenantId { get; }

    /// <summary>
    /// Order id
    /// </summary>        
    string OrderId { get; }

    /// <summary>
    /// Order number
    /// </summary>        
    string OrderNumber { get; }

    /// <summary>
    /// Order lines
    /// </summary>      
    ICollection<TOrderLine> OrderLines { get; }

    /// <summary>
    /// Order items of the subscription
    /// </summary>
    ICollection<TOrderItem> OrderItems { get; }

    /// <summary>
    /// OrderPayment information of the subscription
    /// </summary>    
    ICollection<SubscriptionOrderPaymentModel> OrderPayments { get; }
}
