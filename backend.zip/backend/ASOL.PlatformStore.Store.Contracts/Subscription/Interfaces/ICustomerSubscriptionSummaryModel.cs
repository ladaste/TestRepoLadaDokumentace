using System;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

public interface ICustomerSubscriptionSummaryModel<TValue> : ISubscriptionApplicationModel<TValue>
    where TValue : class
{
    /// <summary>
    /// Subscription identifier
    /// </summary>
    string Id { get; }

    /// <summary>
    /// Tenant identifier
    /// </summary>
    string TenantId { get; }

    /// <summary>
    /// Order number
    /// </summary>
    string OrderNumber { get; }

    /// <summary>
    /// Pending order number
    /// </summary>
    string PendingOrderNumber { get; }

    /// <summary>
    /// Status of the subscription
    /// </summary>
    string SubscriptionStatus { get; }

    /// <summary>
    /// Is the subscription change in progress
    /// </summary>
    bool IsChangeInProgress { get; }

    /// <summary>
    /// Application solution partner organization id
    /// </summary>
    string ApplicationSolutionPartnerOrganizationId { get; }

    /// <summary>
    /// Application solution partner organization name
    /// </summary>
    string ApplicationSolutionPartnerOrganizationName { get; }

    /// <summary>
    /// Development partner organization id
    /// </summary>
    string DevelopmentPartnerOrganizationId { get; }

    /// <summary>
    /// Development partner organization name
    /// </summary>
    string DevelopmentPartnerOrganizationName { get; }

    /// <summary>
    /// Tenant solution partner organization id
    /// </summary>
    string TenantSolutionPartnerOrganizationId { get; }

    /// <summary>
    /// Tenant solution partner organization name
    /// </summary>
    string TenantSolutionPartnerOrganizationName { get; }

    /// <summary>
    /// Order date
    /// </summary>
    DateTime? OrderDate { get; }

    /// <summary>
    /// Subscription status modified on
    /// </summary>
    DateTime? SubscriptionStatusModifiedOn { get; }

    /// <summary>
    /// Expiration date of the subscription
    /// </summary>
    DateTime? ValidTo { get; }

    /// <summary>
    /// Indicates whether this is a system subscription
    /// </summary>
    bool IsSystem { get; }
}
