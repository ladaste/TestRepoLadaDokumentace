namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

public interface ISubscriptionApplicationModel<TValue>
    where TValue : class
{
    /// <summary>
    /// Package product identifier
    /// </summary>
    string PackageProductId { get; }

    /// <summary>
    /// Package name
    /// </summary>
    TValue PackageName { get; }

    /// <summary>
    /// Package short description
    /// </summary>
    TValue PackageShortDescription { get; }

    /// <summary>
    /// Package card image file identifier
    /// </summary>
    string PackageCardImageFileId { get; }

    /// <summary>
    /// A[plication product identifier
    /// </summary>
    string ApplicationProductId { get; }

    /// <summary>
    /// Application name
    /// </summary>
    TValue ApplicationName { get; }

    /// <summary>
    /// Application name
    /// </summary>
    string ApplicationCode { get; }

    /// <summary>
    /// Application short description
    /// </summary>
    TValue ApplicationShortDescription { get; }

    /// <summary>
    /// Edition product identifier
    /// </summary>
    string EditionProductId { get; }

    /// <summary>
    /// Edition name
    /// </summary>
    TValue EditionName { get; }

    /// <summary>
    /// Edition description
    /// </summary>
    TValue EditionDescription { get; }

    /// <summary>
    /// Application frontend URL.
    /// </summary>
    string FrontendUrl { get; }

    /// <summary>
    /// Service backend URL.
    /// </summary>
    string BackendUrl { get; }

    /// <summary>
    /// Gets a value indicating whether the subscription is native.
    /// </summary>
    bool IsNative { get; }

    /// <summary>
    /// Gets a value indicating whether the application is visible.
    /// </summary>
    bool IsVisible { get; }
}
