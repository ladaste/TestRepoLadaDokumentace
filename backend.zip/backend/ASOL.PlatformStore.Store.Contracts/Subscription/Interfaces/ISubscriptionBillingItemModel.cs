using System;
using ASOL.PlatformStore.Store.Contracts.Subscription.Enums;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

/// <summary>
/// Represents a billing item for a subscription, including all necessary data for invoicing.
/// </summary>
public interface ISubscriptionBillingItemModel<TValue> : ISubscriptionDiscountModel
    where TValue : class
{
    /// <summary>
    /// Subscription billing identifier. It is a composite key consisting of SubscriptionId and OrderLineId.
    /// </summary>
    string Id { get; set; }

    /// <summary>
    /// Relation to Subscription entity.
    /// </summary>
    string SubscriptionId { get; set; }

    /// <summary>
    /// Customer organization associated with the subscription.
    /// </summary>
    SubscriptionCustomerModel Customer { get; set; }

    /// <summary>
    /// Order number from which the billing item originates.
    /// </summary>
    string OrderNumber { get; set; }

    /// <summary>
    /// Unique identifier of the order line.
    /// </summary>
    string OrderLineId { get; set; }

    /// <summary>
    /// Unique identifier of the product.
    /// </summary>
    string ProductId { get; set; }

    /// <summary>
    /// Product code.
    /// </summary>
    string ProductCode { get; set; }

    /// <summary>
    /// Localized product name.
    /// </summary>
    TValue ProductName { get; set; }

    /// <summary>
    /// Code of the product part.
    /// </summary>
    string ProductPartCode { get; set; }

    /// <summary>
    /// Base price for the billing item.
    /// </summary>
    decimal? BasePrice { get; set; }

    /// <summary>
    /// Number of licenses or seats included in this billing item.
    /// </summary>
    int? LicenseCount { get; set; }

    /// <summary>
    /// Code of the billing period (OneTime, MonthlyForward, MonthlyBackward, YearlyForward).
    /// </summary>
    string BillingPeriodCode { get; set; }

    /// <summary>
    /// Code of the unit of measure.
    /// </summary>
    string UnitOfMeasureCode { get; set; }

    /// <summary>
    /// Code of the unit of sale.
    /// </summary>
    string UnitOfSaleCode { get; set; }

    /// <summary>
    /// Type of ownership (Own/Rent).
    /// </summary>
    string OwnershipType { get; set; }

    /// <summary>
    /// Code of the item type.
    /// </summary>
    string ItemTypeCode { get; set; }

    /// <summary>
    /// Development partner organization related to the billing item.
    /// </summary>
    SubscriptionDevelopmentPartnerModel DevelopmentPartner { get; set; }

    /// <summary>
    /// Application code related to the billing item.
    /// </summary>
    string ApplicationCode { get; set; }

    /// <summary>
    /// Flag indicating if this is the initial discount imported from the order
    /// </summary>
    bool IsInitialDiscountFromOrder { get; set; }

    /// <summary>
    /// Start date of the billing period for this billing item.
    /// </summary>
    DateOnly? AccrualDateFrom { get; set; }

    /// <summary>
    /// End date of the billing period for this billing item.
    /// </summary>
    DateOnly? AccrualDateTo { get; set; }

    /// <summary>
    /// Date of next invoice.
    /// </summary>
    DateOnly? NextInvoiceExpectedDate { get; set; }

    /// <summary>
    /// Status of the invoice for this billing item.
    /// </summary>
    InvoiceStatus InvoiceStatus { get; set; }
}
