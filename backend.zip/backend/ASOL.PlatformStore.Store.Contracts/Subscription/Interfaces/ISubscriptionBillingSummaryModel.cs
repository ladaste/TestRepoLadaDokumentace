using System;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

public interface ISubscriptionBillingSummaryModel
{
    /// <summary>
    /// Total count of all invoices across all orders in this subscription (computed/aggregated)
    /// </summary>
    int? TotalInvoiceCount { get; set; }

    /// <summary>
    /// Date of the first invoice across all orders in this subscription (MIN of OrderFirstInvoiceVatDate)
    /// </summary>
    DateOnly? FirstInvoiceVatDate { get; set; }

    /// <summary>
    /// Date of the last approved invoice (DUZP) – VatDate
    /// </summary>
    DateOnly? LatestInvoiceVatDate { get; set; }

    /// <summary>
    /// Period of the last approved invoice – AccrualDateFrom
    /// </summary>
    DateOnly? LatestInvoiceAccrualDateFrom { get; set; }

    /// <summary>
    /// Period of the last approved invoice – AccrualDateTo
    /// </summary>
    DateOnly? LatestInvoiceAccrualDateTo { get; set; }

    /// <summary>
    /// Expected date of the next invoice based on the subscription's billing type.
    /// </summary>
    /// <remarks>
    /// The value is derived from <see cref="LatestInvoiceAccrualDateTo"/> and differs depending on billing mode:
    /// <list type="bullet">
    ///   <item>
    ///     <description>
    ///       Forward billing (monthly or yearly): one day after the <see cref="LatestInvoiceAccrualDateTo"/> (i.e. <c>LatestInvoiceAccrualDateTo + 1 day</c>).
    ///     </description>
    ///   </item>
    ///   <item>
    ///     <description>
    ///       Backward monthly billing: the first day of the month following <see cref="LatestInvoiceAccrualDateTo"/>.
    ///     </description>
    ///   </item>
    /// </list>
    /// If <see cref="LatestInvoiceAccrualDateTo"/> is <c>null</c>, the expected date cannot be determined and this property will be <c>null</c>.
    /// </remarks>
    DateOnly? NextInvoiceExpectedDate { get; set; }
}
