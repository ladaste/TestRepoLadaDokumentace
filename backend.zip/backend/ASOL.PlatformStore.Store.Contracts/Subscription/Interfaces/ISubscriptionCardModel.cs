namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

public interface ISubscriptionCardModel<TValue> : ISubscriptionApplicationModel<TValue>
    where TValue : class
{
    /// <summary>
    /// Subscription identifier
    /// </summary>
    string Id { get; }

    /// <summary>
    /// Tenant identifier
    /// </summary>
    string TenantId { get; }

    /// <summary>
    /// Status of the subscription
    /// </summary>
    string SubscriptionStatus { get; }

    /// <summary>
    /// Order number
    /// </summary>
    string OrderNumber { get; }

    /// <summary>
    /// Pending order number
    /// </summary>
    string PendingOrderNumber { get; }

    /// <summary>
    /// Indicates whether this is a system subscription
    /// </summary>
    bool IsSystem { get; }
}
