using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

public interface ISubscriptionCustomerModel : ISubscriptionOrganizationModel
{
    /// <summary>
    /// Invoice email addresses
    /// </summary>    
    ICollection<string> InvoiceEmails { get; }

    /// <summary>
    /// Invoice phone numbers
    /// </summary>
    ICollection<string> InvoicePhones { get; }

    /// <summary>
    /// Invoice language code
    /// </summary>
    string InvoiceLanguageCode { get; }
}
