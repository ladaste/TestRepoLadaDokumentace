using System.Collections.Generic;
using ASOL.PlatformStore.Store.Contracts.Subscription.Base;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

public interface ISubscriptionDetailModel<TValue, TOrder, TOrderLine, TOrderItem, TMetadata, TOrderInfo, TSolutionStatus>
    : ISubscriptionApplicationModel<TValue>
    where TValue : class
    where TOrder : ISubscriptionOrderModel<TValue, TOrderLine, TOrderItem, TOrderInfo>
    where TOrderLine : ISubscriptionOrderLineModel<TValue>
    where TOrderItem : SubscriptionOrderItemGroupModelBase<TValue>
    where TMetadata : SubscriptionMetadataModelBase<TValue>
    where TOrderInfo : SubscriptionOrderMetadataModelBase<TValue>, new()
    where TSolutionStatus : SubscriptionSolutionStatusModelBase<TValue>
{
    /// <summary>
    /// Subscription general information
    /// </summary>
    TMetadata SubscriptionMetadata { get; }

    /// <summary>
    /// Subscription billing (invoicing) summary information
    /// </summary>
    SubscriptionBillingSummaryModel BillingSummaryModel { get; set; }

    /// <summary>
    /// Orders of the subscription
    /// </summary>
    ICollection<TOrder> Orders { get; }

    /// <summary>
    /// Application solution partner of the subscription
    /// </summary>
    SubscriptionSolutionPartnerModel ApplicationSolutionPartner { get; }

    /// <summary>
    /// Development partner of the subscription
    /// </summary>
    SubscriptionDevelopmentPartnerModel DevelopmentPartner { get; }

    /// <summary>
    /// Tenant solution partner of the subscription
    /// </summary>
    SubscriptionSolutionPartnerModel TenantSolutionPartner { get; set; }

    /// <summary>
    /// Customer information of the subscription
    /// </summary>
    SubscriptionCustomerModel Customer { get; }

    /// <summary>
    /// Status history of the subscription
    /// </summary>
    ICollection<TSolutionStatus> StatusHistory { get; }

    /// <summary>
    /// Indicates whether this is a system subscription
    /// </summary>
    bool IsSystem { get; }
}
