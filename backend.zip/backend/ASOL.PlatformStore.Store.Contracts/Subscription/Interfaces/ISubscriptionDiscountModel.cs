using System;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

/// <summary>
/// Interface for subscription discount information
/// </summary>
public interface ISubscriptionDiscountModel
{
    /// <summary>
    /// Discount amount (0 to 1 representing percentage, e.g., 1 = 100%)
    /// </summary>
    decimal? DiscountAmount { get; }

    /// <summary>
    /// Date from which the discount is valid
    /// </summary>
    DateOnly? DiscountValidFrom { get; }

    /// <summary>
    /// Date until which the discount is valid
    /// </summary>
    DateOnly? DiscountValidTo { get; }

    /// <summary>
    /// Internal note about the discount
    /// </summary>
    string DiscountInternalNote { get; }
}
