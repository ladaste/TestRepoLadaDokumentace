namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

public interface ISubscriptionKeyAccountManagerModel
{
    /// <summary>
    /// Key Account Manager UserName
    /// </summary>
    string KeyAccountUserName { get; }

    /// <summary>
    /// Key Account Manager AccountId
    /// </summary>
    string KeyAccountAccountId { get; }

    /// <summary>
    /// Key Account Manager person ID
    /// </summary>
    string KeyAccountPersonId { get; }

    /// <summary>
    /// Key Account Manager first name
    /// </summary>
    string KeyAccountFirstName { get; }

    /// <summary>
    /// Key Account Manager last name
    /// </summary>
    string KeyAccountLastName { get; }
}
