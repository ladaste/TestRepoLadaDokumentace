namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

public interface ISubscriptionMetadataModel :
    ISubscriptionSolutionStatusModel,
    ISubscriptionKeyAccountManagerModel,
    ISubscriptionDiscountModel
{
    /// <summary>
    /// Order number of the valid order of subscription
    /// </summary>
    string OrderNumber { get; }

    /// <summary>
    /// Pending order number in the business integration state.
    /// When you switch to the Done state, it becomes an OrderNumber.
    /// </summary>
    string PendingOrderNumber { get; }

    /// <summary>
    /// Auto invoicing enabled
    /// </summary>
    bool AutoInvoicingEnabled { get; }

    /// <summary>
    /// Is the subscription change in progress
    /// </summary>
    bool IsChangeInProgress { get; }

    /// <summary>
    /// Subscription status
    /// </summary>
    string SubscriptionStatus { get; }
}
