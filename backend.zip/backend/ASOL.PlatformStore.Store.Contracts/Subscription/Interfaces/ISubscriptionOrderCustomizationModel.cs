using System;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

public interface ISubscriptionOrderCustomizationModel
{
    /// <summary>
    /// Solution partner id at sale
    /// </summary>
    string SolutionPartnerId { get; }

    /// <summary>
    /// Solution partner code at sale
    /// </summary>
    string SolutionPartnerCode { get; }

    /// <summary>
    /// Solution partner name at sale
    /// </summary>
    string SolutionPartnerName { get; }

    /// <summary>
    /// Solution partner representative UserName
    /// </summary>
    string SolutionRepUserName { get; }

    /// <summary>
    /// Solution partner representative name
    /// </summary>
    string SolutionRepPersonId { get; }

    /// <summary>
    /// Solution partner representative first name
    /// </summary>
    string SolutionRepFirstName { get; }

    /// <summary>
    /// Solution partner representative last name
    /// </summary>
    string SolutionRepLastName { get; }

    /// <summary>
    /// Note
    /// </summary>
    string Note { get; }

    /// <summary>
    /// Modified by
    /// </summary>
    string ModifiedBy { get; }

    /// <summary>
    /// Modified on
    /// </summary>
    DateTime? ModifiedOn { get; }
}
