namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

public interface ISubscriptionOrderDisplayValues
{
    /// <summary>
    /// Gets the label text that represents the subscription status for this order.
    /// </summary>
    string DisplaySubscriptionStatusLabel { get; set; }

    /// <summary>
    /// Gets the status that represents the subscription status for this order.
    /// </summary>
    string DisplaySubscriptionStatus { get; set; }

    /// <summary>
    /// Gets the status that represents the subscription solution status for this order.
    /// </summary>
    string DisplaySubscriptionSolutionStatus { get; set; }

    /// <summary>
    /// Gets the label text that represents the subscription solution status for this order.
    /// </summary>
    string DisplaySubscriptionSolutionStatusLabel { get; set; }

    /// <summary>
    /// Order number
    /// </summary>
    string OrderNumber { get; }
}
