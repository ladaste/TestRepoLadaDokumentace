using System;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

/// <summary>
/// Invoice-related metadata for a subscription order.
/// </summary>
public interface ISubscriptionOrderInvoiceModel
{
    /// <summary>
    /// Date of the last approved invoice (DUZP) – VatDate
    /// </summary>
    DateTime? LatestInvoiceVatDate { get; }

    /// <summary>
    /// Period of the last approved invoice – AccrualDateFrom
    /// </summary>
    DateTime? LatestInvoiceAccrualDateFrom { get; }

    /// <summary>
    /// Period of the last approved invoice – AccrualDateTo
    /// </summary>
    DateTime? LatestInvoiceAccrualDateTo { get; }

    /// <summary>
    /// Total number of invoices for this order (grouped by OrderNumber)
    /// </summary>
    int? OrderInvoiceCount { get; }

    /// <summary>
    /// Date of the first invoice for this order (OrderNumber)
    /// </summary>
    DateTime? OrderFirstInvoiceVatDate { get; }

    /// <summary>
    /// Date of the last invoice for this order (OrderNumber)
    /// </summary>
    DateTime? OrderLastInvoiceVatDate { get; }
}
