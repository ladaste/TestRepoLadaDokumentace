namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

public interface ISubscriptionOrderLineModel<out TValue>
    where TValue : class
{
    /// <summary>
    /// Order line identifier
    /// </summary>
    string OrderLineId { get; }

    /// <summary>
    /// Parent order line identifier
    /// </summary>
    string ParentOrderLineId { get; }

    /// <summary>
    /// Order line type
    /// </summary>
    string OrderLineType { get; }

    /// <summary>
    /// Product identifier
    /// </summary>
    string ProductId { get; }

    /// <summary>
    /// Product code
    /// </summary>
    string ProductCode { get; }

    /// <summary>
    /// Product name
    /// </summary>
    TValue ProductName { get; }

    /// <summary>
    /// Product description
    /// </summary>
    TValue ProductDescription { get; }

    /// <summary>
    /// Product part code
    /// </summary>
    string ProductPartCode { get; }

    /// <summary>
    /// Total price of the order line
    /// </summary>
    decimal? Price { get; }

    /// <summary>
    /// Base price of the order line
    /// </summary>
    decimal? BasePrice { get; }

    /// <summary>
    /// Billing period code
    /// </summary>
    string BillingPeriodCode { get; }

    /// <summary>
    /// Billing period for the subscription
    /// </summary>
    string SubscriptionPeriod { get; }

    /// <summary>
    /// Item type code
    /// </summary>
    string ItemTypeCode { get; }

    /// <summary>
    /// Ownership type
    /// </summary>
    string OwnershipType { get; }

    /// <summary>
    /// Unit of measure code
    /// </summary>
    string UnitOfMeasureCode { get; }

    /// <summary>
    /// Unit of sale code
    /// </summary>
    string UnitOfSaleCode { get; }

    /// <summary>
    /// Licence count
    /// </summary>
    int? LicenceCount { get; }

    /// <summary>
    /// Trial days for the licence
    /// </summary>
    int? LicenceTrialDays { get; }
}
