using System;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

public interface ISubscriptionOrderMetadataModel
{
    /// <summary>
    /// Order id
    /// </summary>
    string OrderId { get; }

    /// <summary>
    /// Order number
    /// </summary>
    string OrderNumber { get; }

    /// <summary>
    /// Order date
    /// </summary>
    DateTime OrderDate { get; }

    /// <summary>
    /// Indicates if this is a system order that should be hidden from customer/partner queries
    /// </summary>
    bool IsSystem { get; }

    /// <summary>
    /// Indicates whether terms and conditions were accepted for this order
    /// </summary>
    bool TermsAndConditionsAccepted { get; }
}
