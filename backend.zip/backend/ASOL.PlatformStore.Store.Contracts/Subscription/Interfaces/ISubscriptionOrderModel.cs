using ASOL.PlatformStore.Store.Contracts.Subscription.Base;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

public interface ISubscriptionOrderModel<TValue, TOrderLine, TOrderItem, TOrderInfo> : ICustomerSubscriptionOrderModel<TValue, TOrderLine, TOrderItem>
    where TValue : class
    where TOrderLine : ISubscriptionOrderLineModel<TValue>
    where TOrderItem : SubscriptionOrderItemGroupModelBase<TValue>
    where TOrderInfo : SubscriptionOrderMetadataModelBase<TValue>
{
    /// <summary>
    /// Subscription order information
    /// </summary>
    TOrderInfo OrderInfo { get; }
}
