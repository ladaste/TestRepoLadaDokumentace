namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

public interface ISubscriptionOrderSalesPersonModel
{
    /// <summary>
    /// Sales person UserName
    /// </summary>
    string SalesUserName { get; }

    /// <summary>
    /// Sales person name
    /// </summary>
    string SalesPersonId { get; }

    /// <summary>
    /// Sales person first name
    /// </summary>
    string SalesFirstName { get; }

    /// <summary>
    /// Sales person last name
    /// </summary>
    string SalesLastName { get; }
}
