using System;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

public interface ISubscriptionOrderStatusModel
{
    /// <summary>
    /// Status of the subscription
    /// </summary>
    string Status { get; }

    /// <summary>
    /// Status modified by
    /// </summary>
    string StatusModifiedBy { get; }

    /// <summary>
    /// Status modified on
    /// </summary>
    DateTime? StatusModifiedOn { get; }
}
