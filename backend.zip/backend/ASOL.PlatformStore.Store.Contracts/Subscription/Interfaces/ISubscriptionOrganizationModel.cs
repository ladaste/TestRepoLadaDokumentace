namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

public interface ISubscriptionOrganizationModel
{
    /// <summary>
    /// Organization identifier.
    /// </summary>
    string Id { get; }

    /// <summary>
    /// Tenant id
    /// </summary>
    string TenantId { get; }

    /// <summary>
    /// Organization name.
    /// </summary>
    string Name { get; }

    /// <summary>
    /// Organization code.
    /// </summary>
    string Code { get; }

    /// <summary>
    /// Vat identification number.
    /// </summary>
    string VatIn { get; }

    /// <summary>
    /// First line of the person's address to help identify the location.
    /// </summary>
    string Line1 { get; }

    /// <summary>
    /// Second line of the person's address to help identify the location.
    /// </summary>
    string Line2 { get; }

    /// <summary>
    /// Third line of the person's address to help identify the location.
    /// </summary>
    string Line3 { get; }

    /// <summary>
    /// City for the person's address to help identify the location.
    /// </summary>
    public string City { get; }

    /// <summary>
    /// Country ISO 3166
    /// </summary>
    /// <remarks>https://en.wikipedia.org/wiki/List_of_ISO_3166_country_codes</remarks>
    string CountryCode { get; }

    /// <summary>
    /// ZIP Code or postal code for the address.
    /// </summary>
    string ZipCode { get; }

    /// <summary>
    /// Gets the unique registry number associated with the entity.
    /// </summary>
    string RegistryNumber { get; }

    /// <summary>
    /// Gets the house number associated with the address.
    /// </summary>
    string HouseNumber { get; }

    /// <summary>
    /// Gets the name of the street associated with the address.
    /// </summary>
    string StreetName { get; }
}
