using System;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

/// <summary>
/// Interface for subscription status information
/// </summary>
public interface ISubscriptionSolutionStatusModel
{
    /// <summary>
    /// Status of the subscription
    /// </summary>
    string SolutionStatus { get; }

    /// <summary>
    /// Subscription is active from
    /// </summary>
    DateOnly? SolutionActiveFrom { get; }

    /// <summary>
    /// Optional note for the status change
    /// </summary>
    string SolutionStatusNote { get; }

    /// <summary>
    /// Modified by
    /// </summary>
    string SolutionStatusModifiedBy { get; }

    /// <summary>
    /// Modified on
    /// </summary>
    DateTime? SolutionStatusModifiedOn { get; }
}
