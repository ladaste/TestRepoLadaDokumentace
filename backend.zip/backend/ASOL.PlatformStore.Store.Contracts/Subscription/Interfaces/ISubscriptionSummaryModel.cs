namespace ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

public interface ISubscriptionSummaryModel<TValue> : ICustomerSubscriptionSummaryModel<TValue>
    where TValue : class
{
    /// <summary>
    /// Customer organization id
    /// </summary>
    string CustomerOrganizationId { get; }

    /// <summary>
    /// Customer organization name
    /// </summary>
    string CustomerOrganizationName { get; }

    /// <summary>
    /// Application solution partner tenant id
    /// </summary>
    string ApplicationSolutionPartnerTenantId { get; }

    /// <summary>
    /// Tenant solution partner tenant id
    /// </summary>
    string TenantSolutionPartnerTenantId { get; }

    /// <summary>
    /// Development partner tenant id
    /// </summary>
    string DevelopmentPartnerTenantId { get; }

    /// <summary>
    /// Develpment status of the pending order
    /// </summary>
    string PendingOrderDevelopmentStatus { get; }

    /// <summary>
    /// Development status of the order
    /// </summary>
    string DevelopmentStatus { get; }

    /// <summary>
    /// Solution status of the subscription
    /// </summary>
    string SolutionStatus { get; }
}
