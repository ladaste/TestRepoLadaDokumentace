using ASOL.Core.Localization;
using ASOL.PlatformStore.Store.Contracts.Subscription.Base;

namespace ASOL.PlatformStore.Store.Contracts.Subscription;

/// <summary>
/// Represents a billing item for a subscription.
/// </summary>
public class SubscriptionBillingItemModel : SubscriptionBillingItemModelBase<LocalizedValue<string>>
{
}
