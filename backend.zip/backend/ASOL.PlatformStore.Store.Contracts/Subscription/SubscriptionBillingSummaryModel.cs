using System;
using ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

namespace ASOL.PlatformStore.Store.Contracts.Subscription;

public class SubscriptionBillingSummaryModel : ISubscriptionBillingSummaryModel
{
    /// <inheritdoc/>
    public int? TotalInvoiceCount { get; set; }

    /// <inheritdoc/>
    public DateOnly? FirstInvoiceVatDate { get; set; }

    /// <inheritdoc/>
    public DateOnly? LatestInvoiceVatDate { get; set; }

    /// <inheritdoc/>
    public DateOnly? LatestInvoiceAccrualDateFrom { get; set; }

    /// <inheritdoc/>
    public DateOnly? LatestInvoiceAccrualDateTo { get; set; }

    /// <inheritdoc/>
    public DateOnly? NextInvoiceExpectedDate { get; set; }
}
