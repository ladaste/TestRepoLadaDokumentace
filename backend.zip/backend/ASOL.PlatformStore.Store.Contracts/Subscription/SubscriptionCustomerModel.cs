using System.Collections.Generic;
using ASOL.PlatformStore.Store.Contracts.Subscription.Base;
using ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

namespace ASOL.PlatformStore.Store.Contracts.Subscription;

public class SubscriptionCustomerModel : SubscriptionOrganizationModelBase, ISubscriptionCustomerModel
{
    /// <summary>
    /// Invoice email addresses
    /// </summary>    
    public ICollection<string> InvoiceEmails { get; set; } = [];

    /// <summary>
    /// Invoice phone numbers
    /// </summary>
    public ICollection<string> InvoicePhones { get; set; } = [];

    /// <summary>
    /// Invoice language code
    /// </summary>
    public string InvoiceLanguageCode { get; set; }
}
