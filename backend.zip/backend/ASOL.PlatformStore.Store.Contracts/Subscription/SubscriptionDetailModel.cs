using ASOL.PlatformStore.Store.Contracts.Subscription.Base;

namespace ASOL.PlatformStore.Store.Contracts.Subscription;

public class SubscriptionDetailModel : SubscriptionDetailModelBase<string, SubscriptionOrderModel, SubscriptionOrderLineModel, SubscriptionOrderItemGroupModel, SubscriptionMetadataModel, SubscriptionOrderMetadataModel, SubscriptionSolutionStatusModel>
{
}
