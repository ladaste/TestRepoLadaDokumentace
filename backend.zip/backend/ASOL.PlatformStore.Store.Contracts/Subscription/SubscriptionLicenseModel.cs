using System;
using ASOL.Core.Localization;

namespace ASOL.PlatformStore.Store.Contracts.Subscription;

/// <summary>
/// Model for subscription license
/// </summary>
public class SubscriptionLicenseModel
{
    /// <summary>
    /// License id
    /// </summary>
    public string Id { get; set; }

    /// <summary>
    /// Subscription id
    /// </summary>
    public string SubscriptionId { get; set; }

    /// <summary>
    /// Order (number) which created this license.
    /// </summary>
    public string OrderNumber { get; set; }

    /// <summary>
    /// Order line which created this license. Identification within <see cref="OrderNumber"/>
    /// </summary>
    public string? OrderLineId { get; set; }

    /// <summary>
    /// Valid from (inclusive). It can be null, which means it is valid from the beginning of time.
    /// </summary>
    public DateOnly? ValidFrom { get; set; }

    /// <summary>
    /// Valid to (inclusive). It can be null, which means it is valid to end of time.
    /// </summary>
    public DateOnly? ValidTo { get; set; }

    /// <summary>
    /// Package code.
    /// </summary>
    public string PackageCode { get; set; }

    /// <summary>
    /// Package name.
    /// </summary>
    public LocalizedValue<string> PackageName { get; set; }

    /// <summary>
    /// Edition code.
    /// </summary>
    public string EditionCode { get; set; }

    /// <summary>
    /// Application code.
    /// </summary>
    public string ApplicationCode { get; set; }

    /// <summary>
    /// Subscription code.
    /// </summary>
    public string SubscriptionCode { get; set; }

    /// <summary>
    /// Sales item code.
    /// </summary>
    public string SalesItemCode { get; set; }

    /// <summary>
    /// Role code.
    /// </summary>
    public string RoleCode { get; set; }

    /// <summary>
    /// Maximum users allowed in license for this role.
    /// </summary>
    public int? UserMaxCount { get; init; }

    /// <summary>
    /// Current license system status <see cref="LicenseSystemStatus"/>.
    /// </summary>
    public LicenseSystemStatus? Status { get; set; }
}
