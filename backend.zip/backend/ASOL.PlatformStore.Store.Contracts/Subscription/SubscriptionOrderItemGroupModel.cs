using ASOL.PlatformStore.Store.Contracts.Subscription.Base;

namespace ASOL.PlatformStore.Store.Contracts.Subscription;

public class SubscriptionOrderItemGroupModel : SubscriptionOrderItemGroupModelBase<string>
{

}
