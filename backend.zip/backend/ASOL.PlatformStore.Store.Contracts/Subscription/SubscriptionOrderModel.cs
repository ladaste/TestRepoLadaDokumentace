using ASOL.PlatformStore.Store.Contracts.Subscription.Base;
using ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

namespace ASOL.PlatformStore.Store.Contracts.Subscription;

public class SubscriptionOrderModel : SubscriptionOrderModelBase<string, SubscriptionOrderLineModel, SubscriptionOrderItemGroupModel, SubscriptionOrderMetadataModel>, ISubscriptionOrderDisplayValues
{
    /// <inheritdoc/>
    public string DisplaySubscriptionStatusLabel { get; set; }

    /// <inheritdoc/>
    public string DisplaySubscriptionStatus { get; set; }

    /// <inheritdoc/>
    public string DisplaySubscriptionSolutionStatus { get; set; }

    /// <inheritdoc/>
    public string DisplaySubscriptionSolutionStatusLabel { get; set; }
}
