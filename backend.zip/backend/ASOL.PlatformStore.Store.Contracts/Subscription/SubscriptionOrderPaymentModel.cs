namespace ASOL.PlatformStore.Store.Contracts.Subscription;

public class SubscriptionOrderPaymentModel
{
    /// <summary>
    /// Billing period code.
    /// </summary>
    public string BillingPeriodCode { get; set; }

    /// <summary>
    /// The total amount.
    /// </summary>
    public decimal TotalAmount { get; set; }
}
