#nullable enable
using ASOL.DataGridComponent.Contracts.Model.FilterDefinition;
using ASOL.DataGridComponent.Contracts.Model.ViewDefinition;

namespace ASOL.PlatformStore.Store.Contracts.Subscription;

public record SubscriptionSummaryDefinition
(
    ViewDefinitionModel? ViewDefinition,
    FilterDefinitionModel? FilterDefinition
);
