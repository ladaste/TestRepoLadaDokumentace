using ASOL.PlatformStore.Store.Contracts.Subscription.Base;

namespace ASOL.PlatformStore.Store.Contracts.Subscription;

public class SubscriptionSummaryModel : SubscriptionSummaryModelBase<string>
{
    /// <summary>
    /// Gets the subscription number to display based on the subscription status.
    /// </summary>
    public string DisplaySubscriptionNumber => SubscriptionStatus == nameof(Enums.SubscriptionStatus.Pending)
        ? null
        : OrderNumber;
}
