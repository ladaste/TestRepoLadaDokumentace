using System;
using System.ComponentModel.DataAnnotations;
using ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Updates;

public class SubscriptionDiscountUpdateModel : ISubscriptionDiscountModel
{
    /// <inheritdoc/>
    [Range(0, 1, ErrorMessage = "Discount amount must be between 0 and 1.")]
    public decimal? DiscountAmount { get; set; }

    /// <inheritdoc/>
    public DateOnly? DiscountValidFrom { get; set; }

    /// <inheritdoc/>
    public DateOnly? DiscountValidTo { get; set; }

    /// <inheritdoc/>
    public string DiscountInternalNote { get; set; }
}
