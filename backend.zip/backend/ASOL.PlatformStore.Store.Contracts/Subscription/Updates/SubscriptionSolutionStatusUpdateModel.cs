using System;
using System.ComponentModel.DataAnnotations;
using ASOL.PlatformStore.Store.Contracts.Subscription.Enums;

namespace ASOL.PlatformStore.Store.Contracts.Subscription.Updates;

public class SubscriptionSolutionStatusUpdateModel
{
    /// <summary>
    /// Status of the subscription
    /// </summary>
    [Required]
    public SubscriptionSolutionStatus SolutionStatus { get; set; }

    /// <summary>
    /// Subscription is active from
    /// </summary>
    public DateOnly? SolutionActiveFrom { get; set; }

    /// <summary>
    /// Optional note for the status change
    /// </summary>
    public string SolutionStatusNote { get; set; }
}
