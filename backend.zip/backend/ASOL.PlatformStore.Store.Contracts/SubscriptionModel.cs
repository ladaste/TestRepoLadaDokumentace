using System;
using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Model for ordered subscription
/// </summary>
public class SubscriptionModel
{
    /// <summary>
    /// Subscription id
    /// </summary>
    public string Id { get; set; }

    /// <summary>
    /// Part code of licence
    /// </summary>
    public string PartCode { get; set; }

    /// <summary>
    /// Flag is reference is mandatory
    /// </summary>
    public bool IsMandatory { get; set; }

    /// <summary>
    /// Code from ItemType codebook
    /// </summary>
    public string ItemTypeCode { get; set; }

    /// <summary>
    /// OwnershipType
    /// </summary>
    public OwnershipTypeModel? OwnershipType { get; set; }

    /// <summary>
    /// Code from BillingPeriod codebook
    /// </summary>
    public string BillingPeriodCode { get; set; }

    /// <summary>
    /// Unit Of Sale - code
    /// </summary>
    public string UnitOfSaleCode { get; set; }

    /// <summary>
    /// Unit Of Measure - code
    /// </summary>
    public string UnitOfMeasureCode { get; set; }

    /// <summary>
    /// Valid from
    /// </summary>
    public DateTime? ValidFrom { get; set; }

    /// <summary>
    /// Valid to
    /// </summary>
    public DateTime? ValidTo { get; set; }

    /// <summary>
    /// Upgrade type
    /// </summary>
    public UpgradeTypeModel? UpgradeType { get; set; }

    /// <summary>
    /// can be canceled / cannot be canceled
    /// </summary>
    public bool? CanCancel { get; set; }

    /// <summary>
    /// Data of subscription
    /// </summary>
    public object SubscriptionData { get; set; }

    /// <summary>
    /// List of SalesItems
    /// </summary>
    public IList<SalesItemModel> SalesItems { get; set; }

    /// <summary>
    /// Inherits billing period
    /// </summary>
    public bool InheritsBillingPeriod { get; set; }

    /// <summary>
    /// Inherits amount of units
    /// </summary>
    public bool InheritsAmountOfUnits { get; set; }
}
