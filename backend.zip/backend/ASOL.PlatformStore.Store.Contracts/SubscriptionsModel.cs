using System;

namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Model for store item with licence information
/// </summary>
public class SubscriptionsSummaryModel
{
    /// <summary>
    /// Id of the item - id of the aggregated entity in DB
    /// </summary>
    public string Id { get; set; }

    /// <summary>
    /// Id of the item - id of the product
    /// </summary>
    public string ProductCatalogId { get; set; }

    /// <summary>
    /// Localized product name for display in the store
    /// </summary>
    public string Name { get; set; }

    /// <summary>
    /// Order number
    /// </summary>
    public string OrderNumber { get; set; }

    /// <summary>
    /// OrderApprovedByCustomerDate
    /// </summary>
    public DateTime? ApprovedByCustomerOn { get; set; }

    /// <summary>
    ///  Tile short description text
    /// </summary>
    public string ShortDescription { get; set; }

    /// <summary>
    /// Reference to image of the tile
    /// </summary>
    public string CardImageId { get; set; }

    /// <summary>
    /// Application Code
    /// </summary>
    public string ApplicationCode { get; set; }

    /// <summary>
    /// EditionName
    /// </summary>
    public string EditionName { get; set; }

    /// <summary>
    /// Tenant Solution Partner Id
    /// </summary>
    public string TenantSolutionPartnerId { get; set; }

    /// <summary>
    /// Tenant Solution Partner Name
    /// </summary>
    public string TenantSolutionPartnerName { get; set; }

    /// <summary>
    /// Application Solution Partner Id
    /// </summary>
    public string ApplicationSolutionPartnerId { get; set; }

    /// <summary>
    /// Application Solution Partner Name
    /// </summary>
    public string ApplicationSolutionPartnerName { get; set; }

    /// <summary>
    /// Development Partner Id
    /// </summary>
    public string DevelopmentPartnerId { get; set; }

    /// <summary>
    /// Development Partner Name
    /// </summary>
    public string DevelopmentPartnerName { get; set; }

    /// <summary>
    /// Customer Id
    /// </summary>
    public string CustomerId { get; set; }

    /// <summary>
    /// Customer Name
    /// </summary>
    public string CustomerName { get; set; }

    ///// <summary>
    ///// DateOfStatus
    ///// </summary>
    public DateTime? DateOfStatus { get; set; }

    ///// <summary>
    ///// OrderDate
    ///// </summary>
    public DateTime? OrderDate { get; set; }

    ///// <summary>
    ///// LicenseModifiedOn
    ///// </summary>
    public DateTime? LicenseModifiedOn { get; set; }

    ///// <summary>
    ///// DateOfEndedLicense
    ///// </summary>
    public DateTime? DateOfEndedLicense { get; set; }

    /// <summary>
    /// BillingPeriod
    /// </summary>
    public string BillingPeriod { get; set; }

    /// <summary>
    /// 
    /// </summary>
    public string Status { get; set; }

    /// <summary>
    /// Modified On
    /// </summary>
    public DateTime? ModifiedOn { get; set; }
}
