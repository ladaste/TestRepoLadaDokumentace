using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// Unit Of Sale
/// </summary>
public class UnitOfSaleModel
{
    /// <summary>
    /// Id
    /// </summary>
    public string Id { get; set; }

    /// <summary>
    /// Code
    /// </summary>
    public string Code { get; set; }

    /// <summary>
    /// Nominativ
    /// </summary>
    public IList<LocalizedUnitNameModel> Nominativ { get; set; }
}
