namespace ASOL.PlatformStore.Store.Contracts;

/// <summary>
/// NodeReference UpgradeType
/// </summary>
public enum UpgradeTypeModel
{
    /// <summary>
    /// Allowed
    /// </summary>
    Allowed = 1,

    /// <summary>
    /// NotAllowed
    /// </summary>
    NotAllowed = 2,

    /// <summary>
    /// OnlyUpgrade
    /// </summary>
    OnlyUpgrade = 3
}
