using System.Collections.Generic;
using ASOL.PlatformStore.Store.Domain.Extensions;
using Xunit;

namespace ASOL.PlatformStore.Store.Domain.Tests.Extensions;

public sealed class ListExtensions_Tests
{
    [Theory]
    [InlineData(0, 1, new int[] { 1, 0, 2, 3, 4, 5 })]
    [InlineData(0, 5, new int[] { 1, 2, 3, 4, 5, 0 })]
    [InlineData(1, 4, new int[] { 0, 2, 3, 4, 1, 5 })]
    [InlineData(5, 3, new int[] { 0, 1, 2, 5, 3, 4 })]
    [InlineData(3, 2, new int[] { 0, 1, 3, 2, 4, 5 })]
    public void Move_MovesSelectedItem(int initialIndex, int targetIndex, int[] result)
    {
        // Arrange
        var sut = new List<int> { 0, 1, 2, 3, 4, 5 };

        // Act
        sut.Move(initialIndex, targetIndex);

        // Assert
        Assert.Equal(result, sut);
    }
}
