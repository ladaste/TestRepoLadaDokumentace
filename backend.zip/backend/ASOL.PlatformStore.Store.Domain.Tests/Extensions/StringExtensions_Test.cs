using ASOL.PlatformStore.Store.Domain.Extensions;
using Xunit;

namespace ASOL.PlatformStore.Store.Domain.Tests.Extensions;

public sealed class StringExtensions_Test
{
    [Theory]
    [InlineData("Albert Einstein", 2, "AE")]
    [InlineData("Leonardo da Vinci", 2, "LV")]
    [InlineData("John Ronald Reuel Tolkien", 3, "JRR")]
    [InlineData("Marie Skłodowska Curie", 1, "M")]
    public void Initials(string source, int maxCount, string initials)
    {
        var result = source.GetInitials(maxCount);

        //Assert
        Assert.Equal(initials, result);
    }
}
