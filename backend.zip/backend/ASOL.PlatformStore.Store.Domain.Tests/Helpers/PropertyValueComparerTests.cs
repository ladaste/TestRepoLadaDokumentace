using ASOL.Core.Localization;
using ASOL.PlatformStore.Store.Domain.Helpers;
using Xunit;
using Shouldly;

namespace ASOL.PlatformStore.Store.Domain.Tests.Helpers;

public class PropertyValueComparerTests
{
    private sealed class SimpleModel
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }

    private sealed class SimpleLocalizedModel
    {
        public string Name { get; set; }
        public LocalizedValue<string> LocalizedName { get; set; }
    }

    private sealed class NullableModel
    {
        public string Name { get; set; }
        public int? Age { get; set; }
    }

    [Fact]
    public void AreEquivalent_ReturnsTrue_ForIdenticalObjects()
    {
        var a = new SimpleModel { Name = "Alice", Age = 30 };
        var b = new SimpleModel { Name = "Alice", Age = 30 };
        PropertyValueComparer<SimpleModel>.AreEquivalent(a, b).ShouldBeTrue();
    }

    [Fact]
    public void AreEquivalent_ReturnsFalse_ForDifferentObjects()
    {
        var a = new SimpleModel { Name = "Alice", Age = 30 };
        var b = new SimpleModel { Name = "Bob", Age = 30 };

        var test = PropertyValueComparer<SimpleModel>.AreEquivalent(a, b);

        PropertyValueComparer<SimpleModel>.AreEquivalent(a, b).ShouldBeFalse();
    }

    [Fact]
    public void AreEquivalent_ReturnsTrue_ForBothNull()
    {
        SimpleModel a = null;
        SimpleModel b = null;
        PropertyValueComparer<SimpleModel>.AreEquivalent(a, b).ShouldBeTrue();
    }

    [Fact]
    public void AreEquivalent_ReturnsFalse_IfOneIsNull()
    {
        var a = new SimpleModel { Name = "Alice", Age = 30 };
        SimpleModel b = null;

        var test = PropertyValueComparer<SimpleModel>.AreEquivalent(a, b);

        PropertyValueComparer<SimpleModel>.AreEquivalent(a, b).ShouldBeFalse();
        PropertyValueComparer<SimpleModel>.AreEquivalent(b, a).ShouldBeFalse();
    }

    [Fact]
    public void AreEquivalent_WorksWithNullableProperties()
    {
        var a = new NullableModel { Name = null, Age = null };
        var b = new NullableModel { Name = null, Age = null };
        PropertyValueComparer<NullableModel>.AreEquivalent(a, b).ShouldBeTrue();
        b.Age = 1;
        PropertyValueComparer<NullableModel>.AreEquivalent(a, b).ShouldBeFalse();
    }

    [Fact]
    public void AreEquivalent_ReturnsTrue_SimpleLocalizedModel()
    {
        var a = new SimpleLocalizedModel { Name = "PlatformStore Store", LocalizedName = new LocalizedValue<string>(("en-US", "PlatformStore Store"), ("cs-CZ", "PlatformStore Store"), ("sk-SK", "PlatformStore Store")) };
        var b = new SimpleLocalizedModel { Name = "PlatformStore Store", LocalizedName = new LocalizedValue<string>(("en-US", "PlatformStore Store"), ("cs-CZ", "PlatformStore Store"), ("sk-SK", "PlatformStore Store")) };

        PropertyValueComparer<SimpleLocalizedModel>.AreEquivalent(a, b).ShouldBeTrue();
    }

    [Fact]
    public void AreEquivalent_ReturnsFalse_SimpleLocalizedModel()
    {
        var a = new SimpleLocalizedModel { Name = "PlatformStore Store", LocalizedName = new LocalizedValue<string>(("en-US", "PlatformStore"), ("cs-CZ", "PlatformStore"), ("sk-SK", "PlatformStore")) };
        var b = new SimpleLocalizedModel { Name = "PlatformStore Store", LocalizedName = new LocalizedValue<string>(("en-US", "PlatformStore Store"), ("cs-CZ", "PlatformStore Store"), ("sk-SK", "PlatformStore Store")) };

        PropertyValueComparer<SimpleLocalizedModel>.AreEquivalent(a, b).ShouldBeFalse();
    }
}
