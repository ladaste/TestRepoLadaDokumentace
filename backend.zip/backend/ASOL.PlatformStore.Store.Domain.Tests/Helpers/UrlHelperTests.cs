using ASOL.PlatformStore.Store.Domain.Helpers;
using ASOL.PlatformStore.Store.Domain.Options;
using Xunit;

namespace ASOL.PlatformStore.Store.Domain.Tests.Helpers;

public class UrlHelperTests
{
    [Theory]
    [InlineData("https://example.com")]
    [InlineData("https://example.com/")]
    public void MakeAbsoluteUrlIfPossible_ReturnsAbsoluteUrl_WhenGivenRelativeUrl(string hostEnvUrl)
    {
        // Arrange
        var options = new NavigationServiceOptions
        {
            HostingEnvironmentUrl = hostEnvUrl
        };
        var relativeUrl = "/path/to/resource";

        // Act
        var result = UrlHelper.MakeAbsoluteUrlIfPossible(options, relativeUrl);

        // Assert
        Assert.Equal("https://example.com/path/to/resource", result);
    }

    [Theory]
    [InlineData("https://example.com")]
    [InlineData("https://example.com/")]
    public void MakeAbsoluteUrlIfPossible_ReturnsAbsoluteUrl_WhenWithoutGivenUrl_ReturnsNull(string hostEnvUrl)
    {
        // Arrange
        var options = new NavigationServiceOptions
        {
            HostingEnvironmentUrl = hostEnvUrl
        };

        // Act
        var result = UrlHelper.MakeAbsoluteUrlIfPossible(options, null);

        // Assert
        Assert.Null(result);
    }

    [Theory]
    [InlineData("https://example.com", "")]
    [InlineData("https://example.com/", "/")]
    public void MakeAbsoluteUrlIfPossible_ReturnsAbsoluteUrl_WhenWithGivenEmptyUrl_ReturnsHostEnvUrl(string hostEnvUrl, string url)
    {
        // Arrange
        var options = new NavigationServiceOptions
        {
            HostingEnvironmentUrl = hostEnvUrl
        };

        // Act
        var result = UrlHelper.MakeAbsoluteUrlIfPossible(options, url);

        // Assert
        Assert.Equal(hostEnvUrl, result);
    }

    [Theory]
    [InlineData("https://example.com")]
    [InlineData("https://example.com/")]
    public void MakeAbsoluteUrlIfPossible_ReturnsAbsoluteUrl_WhenWithGivenAbsoluteUrl_ReturnsAbsoluteUrl(string hostEnvUrl)
    {
        // Arrange
        var options = new NavigationServiceOptions
        {
            HostingEnvironmentUrl = hostEnvUrl
        };

        // Act
        var result = UrlHelper.MakeAbsoluteUrlIfPossible(options, "https://example.com/path/to/resource");

        // Assert
        Assert.Equal("https://example.com/path/to/resource", result);
    }
}
