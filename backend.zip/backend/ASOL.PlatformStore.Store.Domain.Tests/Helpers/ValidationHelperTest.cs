using System.Collections.Generic;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Domain.Options;
using ASOL.PlatformStore.Store.Domain.Helpers;
using Microsoft.Extensions.DependencyInjection;
using Xunit;
using Shouldly;

namespace ASOL.PlatformStore.Store.Domain.Tests.Helpers;

public class ValidationHelperTest
{
    private static ValidationHelper GetValidationHelper(string stageUrl)
    {
        var services = new ServiceCollection();
        services.AddOptions<AppUrlOptions>().Configure(options => options.BaseUrl = stageUrl);
        services.AddTransient<ValidationHelper>();
        var serviceProvider = services.BuildServiceProvider();
        var validationHelper = serviceProvider.GetRequiredService<ValidationHelper>();
        return validationHelper;
    }

    [Fact]
    public void ValidateDeeplinkBaseurl_WhenUrlIsNull_ShouldAddError()
    {
        var validationHelper = GetValidationHelper("https://localhost");
        var errors = new List<ValidationError>();
        var result = validationHelper.ValidateDeeplinkBaseUrl(errors, null);

        result.ShouldBeFalse();
        errors.ShouldHaveSingleItem();
        errors[0].Message.ShouldBe("Deep Link Url must be defined.");
    }

    [Fact]
    public void ValidateDeeplinkBaseurl_WhenUrlIsNotWhitelisted_ShouldAddError()
    {
        var validationHelper = GetValidationHelper("https://localhost");
        var errors = new List<ValidationError>();
        var result = validationHelper.ValidateDeeplinkBaseUrl(errors, "https://notwhitelisted.com");

        result.ShouldBeFalse();
        errors.ShouldHaveSingleItem();
        errors[0].Message.ShouldBe("Url 'https://notwhitelisted.com' isn't whitelisted.");
    }

    [Fact]
    public void ValidateDeeplinkBaseurl_WhenUrlIsValid_ShouldReturnTrue()
    {
        var validationHelper = GetValidationHelper("https://localhost");
        var errors = new List<ValidationError>();
        var result = validationHelper.ValidateDeeplinkBaseUrl(errors, "https://localhost/somepath");

        result.ShouldBeTrue();
        errors.ShouldBeEmpty();
    }

    [Fact]
    public void ValidateDeeplinkBaseurlWithQuery_WhenUrlIsValid_ShouldReturnTrue()
    {
        var validationHelper = GetValidationHelper("https://localhost");
        var errors = new List<ValidationError>();
        var result = validationHelper.ValidateDeeplinkBaseUrl(errors, "https://localhost?a=v");

        result.ShouldBeTrue();
        errors.ShouldBeEmpty();
    }

    [Fact]
    public void ValidateDeeplinkBaseurl_WhenUrlHasWrongFormat_ShouldAddError()
    {
        var validationHelper = GetValidationHelper("https://localhost");
        var errors = new List<ValidationError>();
        var result = validationHelper.ValidateDeeplinkBaseUrl(errors, "not-a-valid-url");
        result.ShouldBeFalse();
        errors.ShouldHaveSingleItem();
        errors[0].Message.ShouldBe("Url 'not-a-valid-url' isn't whitelisted.");
    }

    [Fact]
    public void ValidateDeeplinkBaseurl_WhenUrlIsEmpty_ShouldAddError()
    {
        var validationHelper = GetValidationHelper("https://localhost");
        var errors = new List<ValidationError>();
        var result = validationHelper.ValidateDeeplinkBaseUrl(errors, "");
        result.ShouldBeFalse();
        errors.ShouldHaveSingleItem();
        errors[0].Message.ShouldBe("Deep Link Url must be defined.");
    }
}
