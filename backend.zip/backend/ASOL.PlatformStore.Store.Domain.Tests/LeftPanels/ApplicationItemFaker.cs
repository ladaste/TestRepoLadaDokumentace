using ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;
using Bogus;

namespace ASOL.PlatformStore.Store.Domain.Tests.LeftPanels;

internal sealed class ApplicationItemFaker : Faker<ApplicationPanelItem>
{
    public const string NotPinned = "NotPinned";
    public const string Pinned = "Pinned";
    public static readonly string AllRules = string.Join(",", NotPinned, Pinned);

    public ApplicationItemFaker()
    {
        var labelFaker = new LabelFaker();
        var iconFaker = new IconFaker();

        RuleSet(NotPinned, _ =>
        {
            CustomInstantiator(_ => new ApplicationPanelItem(
                id: _.Random.String2(10),
                label: labelFaker.Generate(),
                url: _.Internet.Url(),
                icon: iconFaker.Generate(),
                isPinned: false,
                openInSeparateWindow: _.Random.Bool(),
                applicationCode: $"{_.IndexFaker}={_.Random.String2(10)}",
                defaultOrder: _.Date.Past()));
        });

        RuleSet(Pinned, _ =>
        {
            CustomInstantiator(_ => new ApplicationPanelItem(
                id: _.Random.String2(10),
                label: labelFaker.Generate(),
                url: _.Internet.Url(),
                icon: iconFaker.Generate(),
                isPinned: true,
                openInSeparateWindow: _.Random.Bool(),
                applicationCode: $"{_.IndexFaker}={_.Random.String2(10)}",
                defaultOrder: _.Date.Past()));
        });
    }
}

