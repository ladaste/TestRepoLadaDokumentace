using ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;
using Bogus;

namespace ASOL.PlatformStore.Store.Domain.Tests.LeftPanels;

internal sealed class IconFaker : Faker<Icon>
{
    public IconFaker()
    {
        CustomInstantiator(_ =>
        {
            var type = _.PickRandom<IconType>();
            var value = type switch
            {
                IconType.Url => _.Internet.Url(),
                IconType.GoogleName => _.Random.String2(5).ToUpper(),
                IconType.Svg => _.Random.String2(500).ToUpper(),
                _ => _.Random.String2(2).ToUpper()
            };
            return new Icon(value, type);
        });
    }
}
