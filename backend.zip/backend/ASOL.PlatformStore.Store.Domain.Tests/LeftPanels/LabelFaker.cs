using System.Collections.Generic;
using ASOL.Core.Localization;
using Bogus;

namespace ASOL.PlatformStore.Store.Domain.Tests.LeftPanels;

internal sealed class LabelFaker : Faker<LocalizedValue<string>>
{
    private static readonly string[] s_supportedLocales = ["en", "cz", "sk"];

    public LabelFaker()
    {
        CustomInstantiator(faker =>
        {
            var locales = faker.Random.ListItems(s_supportedLocales,
                faker.Random.Int(1, s_supportedLocales.Length));

            var localizedValues = new List<LocalizedValueItem<string>>();

            foreach (var locale in locales)
            {
                faker.Locale = locale;
                localizedValues.Add(new()
                {
                    Locale = locale,
                    Value = faker.Commerce.Product()
                });
            }

            return new LocalizedValue<string>()
            {
                Values = localizedValues
            };
        });
    }
}
