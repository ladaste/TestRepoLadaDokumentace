using ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;
using Bogus;

namespace ASOL.PlatformStore.Store.Domain.Tests.LeftPanels;

internal sealed class LeftPanelFaker : Faker<LeftPanel>
{
    public const string Empty = "Empty";
    public const string ItemsCount_4 = "ItemsCount-4";
    public static readonly string AllRules = string.Join(",", Empty, ItemsCount_4, "default");

    public LeftPanelFaker()
    {
        var panelItemFaker = new PanelItemFaker();

        RuleSet(Empty, _ =>
           _.CustomInstantiator(faker =>
           {
               return new LeftPanel(
                   id: faker.Random.Guid().ToString(),
                   userId: faker.Random.String2(5, 10),
                   tenantId: faker.Random.String2(3, 10),
                   quickAccessItems: [],
                   allApplicationItems: []);
           }));

        RuleSet(ItemsCount_4, _ =>
           _.CustomInstantiator(faker =>
           {
               return new LeftPanel(
                   id: faker.Random.Guid().ToString(),
                   userId: faker.Random.String2(5, 10),
                   tenantId: faker.Random.String2(3, 10),
                   quickAccessItems: panelItemFaker.Generate(4, PanelItemFaker.CustomAndApplicationItems),
                   allApplicationItems: panelItemFaker.Generate(4, PanelItemFaker.CustomAndApplicationItems));
           }));

        CustomInstantiator(faker =>
        {
            return new LeftPanel(
                id: faker.Random.Guid().ToString(),
                userId: faker.Random.String2(5, 10),
                tenantId: faker.Random.String2(3, 10),
                quickAccessItems: panelItemFaker.GenerateBetween(1, 10, PanelItemFaker.CustomAndApplicationItems),
                allApplicationItems: panelItemFaker.GenerateBetween(1, 12, PanelItemFaker.CustomAndApplicationItems));
        });
    }
}
