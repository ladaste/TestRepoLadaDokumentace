using System;
using System.Linq;
using ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;
using Bogus;
using Shouldly;
using Xunit;

namespace ASOL.PlatformStore.Store.Domain.Tests.LeftPanels;

public sealed class LeftPanel_Tests
{
    private readonly Faker _faker = new();
    private readonly PanelItemFaker _panelItemFaker = new();
    private readonly ApplicationItemFaker _applicationItemFaker = new();
    private readonly LeftPanelFaker _leftPanelFaker = new();
    private readonly LabelFaker _labelFaker = new();
    private readonly IconFaker _iconFaker = new();

    [Theory]
    [CombinatorialData]
    public void Updater_AddItem(PanelPart partIndex)
    {
        // Arrange
        var sut = _leftPanelFaker.Generate();
        var initialVersion = sut.Version;

        var item = _panelItemFaker.Generate(PanelItemFaker.CustomAndApplicationItems);
        var index = partIndex == PanelPart.QuickAccess
            ? _faker.Random.Int(0, sut.QuickAccess.Count)
            : _faker.Random.Int(0, sut.AllApplications.Count);
        var position = new PanelItemPosition(partIndex, (uint)index);

        var updater = sut.GetUpdater();

        // Act
        updater.AddItemAt(item, position);
        updater.Complete();

        // Assert
        var part = partIndex == PanelPart.QuickAccess
            ? sut.QuickAccess
            : sut.AllApplications;

        part.ShouldContain(item);
        part[index].ShouldBe(item);
        sut.Version.ShouldBe(initialVersion + 1);
    }


    [Theory]
    [CombinatorialData]
    public void Updater_MoveItem(
        PanelPart sourcePartIndex,
        PanelPart targetPartIndex,
        [CombinatorialRange(from: 0, count: 4)] int sourceIndex,
        [CombinatorialRange(from: 0, count: 4)] int targetIndex)
    {
        // Arrange
        var sut = _leftPanelFaker.Generate(LeftPanelFaker.ItemsCount_4);
        var initialVersion = sut.Version;

        var sourcePart = sourcePartIndex == PanelPart.QuickAccess
            ? sut.QuickAccess
            : sut.AllApplications;

        var sourcePosition = new PanelItemPosition(sourcePartIndex, (uint)sourceIndex);

        var targetPart = targetPartIndex == PanelPart.QuickAccess
            ? sut.QuickAccess
            : sut.AllApplications;

        var targetPosition = new PanelItemPosition(targetPartIndex, (uint)targetIndex);

        var item = sourcePart[sourceIndex];

        var updater = sut.GetUpdater();

        // Act
        updater.MoveItem(sourcePosition, targetPosition);
        updater.Complete();

        // Assert
        var targetItem = targetPart[targetIndex];

        targetItem.ShouldBe(item);
    }

    [Theory]
    [CombinatorialData]
    public void Updater_RemoveItem_ByPosition(
        PanelPart partIndex,
        [CombinatorialRange(from: 0, count: 4)] int index)
    {
        // Arrange
        var sut = _leftPanelFaker.Generate(LeftPanelFaker.ItemsCount_4);
        var initialVersion = sut.Version;

        var position = new PanelItemPosition(partIndex, (uint)index);

        var item = partIndex == PanelPart.QuickAccess
            ? sut.QuickAccess[index]
            : sut.AllApplications[index];

        var updater = sut.GetUpdater();

        // Act
        updater.RemoveItem(position);
        updater.Complete();

        // Assert
        sut.QuickAccess.ShouldNotContain(item);
        sut.AllApplications.ShouldNotContain(item);
        sut.Version.ShouldBe(initialVersion + 1);
    }

    [Theory]
    [CombinatorialData]
    public void Updater_RemoveItem_ByItem(
        PanelPart partIndex,
        [CombinatorialRange(from: 0, count: 4)] int index)
    {
        // Arrange
        var sut = _leftPanelFaker.Generate(LeftPanelFaker.ItemsCount_4);
        var initialVersion = sut.Version;

        var item = partIndex == PanelPart.QuickAccess
            ? sut.QuickAccess[index]
            : sut.AllApplications[index];

        var updater = sut.GetUpdater();

        // Act
        updater.RemoveItem(item);
        updater.Complete();

        // Assert
        sut.QuickAccess.ShouldNotContain(item);
        sut.AllApplications.ShouldNotContain(item);
        sut.Version.ShouldBe(initialVersion + 1);
    }

    [Fact]
    public void Updater_AddLastAllApplicationsItem()
    {
        // Arrange
        var sut = _leftPanelFaker.Generate();
        var initialVersion = sut.Version;

        var item = _panelItemFaker.Generate(PanelItemFaker.CustomAndApplicationItems);

        var updater = sut.GetUpdater();

        // Act
        updater.AddAllApplicationsItem(item);
        updater.Complete();

        // Assert
        sut.AllApplications[

        // Assert
        sut.AllApplications.Count - 1].ShouldBe(item);
        sut.Version.ShouldBe(initialVersion + 1);
    }

    [Fact]
    public void Updater_Dispose_WithoutChanges()
    {
        // Arrange
        var sut = _leftPanelFaker.Generate();
        var initialVersion = sut.Version;

        var updater = sut.GetUpdater();

        // Act
        updater.Complete();

        // Assert
        sut.QuickAccess.ShouldBe(sut.QuickAccess);
        sut.AllApplications.ShouldBe(sut.AllApplications);
        sut.Version.ShouldBe(initialVersion);
    }

    [Theory]
    [CombinatorialData]
    public void Updater_ThrowsOnDuplicateApplicationItems(PanelPart partIndex)
    {
        // Arrange
        // Use pinned ApplicationPanelItems to ensure they stay in place after normalization
        var sut = new LeftPanel(
            id: _faker.Random.Guid().ToString(),
            userId: _faker.Random.String(5, 10),
            tenantId: _faker.Random.String(3, 10),
            quickAccessItems:
            [
                .. _applicationItemFaker.Generate(LeftPanel.MinQuickAccessLength, ApplicationItemFaker.Pinned)
            ],
            allApplicationItems:
            [
                .. _applicationItemFaker.Generate(LeftPanel.MinQuickAccessLength, ApplicationItemFaker.Pinned)
            ]);

        var part = partIndex == PanelPart.QuickAccess
            ? sut.QuickAccess
            : sut.AllApplications;
        var item = part
            .OfType<ApplicationPanelItem>()
            .First();

        var duplicateItem = new ApplicationPanelItem(
            id: _faker.Random.String2(10),
            label: _labelFaker.Generate(),
            url: _faker.Internet.Url(),
            icon: _iconFaker.Generate(),
            isPinned: _faker.Random.Bool(),
            openInSeparateWindow: _faker.Random.Bool(),
            applicationCode: item.ApplicationCode,
            defaultOrder: _faker.Date.Past());

        var updater = sut.GetUpdater();
        updater.AddItemAt(duplicateItem, new PanelItemPosition(partIndex, 0));

        // Act & Assert
        Should.Throw<BusinessException>(updater.Complete)
            .Message.StartsWith("Duplicate application items");
    }


    [Fact]
    public void Updater_ItemUpdater_SetOpenInSeparateWindow()
    {
        // Arrange
        var sut = _leftPanelFaker.Generate();
        var initialVersion = sut.Version;

        var updater = sut.GetUpdater();
        var itemUpdater = updater.GetItemUpdater(new(PanelPart.QuickAccess, 0));
        var openInSeparateWindow = itemUpdater.Item.OpenInSeparateWindow;

        // Act
        itemUpdater.SetOpenInSeparateWindow(!openInSeparateWindow);
        updater.Complete();

        // Assert
        itemUpdater.Item.OpenInSeparateWindow.ShouldNotBe(openInSeparateWindow);
        sut.Version.ShouldBe(initialVersion + 1);
    }

    [Fact]
    public void Updater_ItemUpdater_SetLabel()
    {
        // Arrange
        var sut = _leftPanelFaker.Generate();
        var initialVersion = sut.Version;

        var updater = sut.GetUpdater();
        var itemUpdater = updater.GetItemUpdater(new(PanelPart.QuickAccess, 0));
        var originalLabel = itemUpdater.Item.Label;
        var newLabel = _labelFaker.Generate();

        // Act
        itemUpdater.SetLabel(newLabel);
        updater.Complete();

        // Assert
        itemUpdater.Item.Label.ShouldBe(newLabel);
        sut.Version.ShouldBe(initialVersion + 1);
    }

    [Fact]
    public void Updater_ItemUpdater_SetUrl()
    {
        // Arrange
        var sut = _leftPanelFaker.Generate();
        var initialVersion = sut.Version;

        var updater = sut.GetUpdater();
        var itemUpdater = updater.GetItemUpdater(new(PanelPart.QuickAccess, 0));
        var originalUrl = itemUpdater.Item.Url;
        var newUrl = _faker.Internet.Url();

        // Act
        itemUpdater.SetUrl(newUrl);
        updater.Complete();

        // Assert
        itemUpdater.Item.Url.ShouldBe(newUrl);
        sut.Version.ShouldBe(initialVersion + 1);
    }

    [Fact]
    public void Updater_ItemUpdater_SetIcon()
    {
        // Arrange
        var sut = _leftPanelFaker.Generate();
        var initialVersion = sut.Version;

        var updater = sut.GetUpdater();
        var itemUpdater = updater.GetItemUpdater(new(PanelPart.QuickAccess, 0));
        var newIcon = _iconFaker.Generate();

        // Act
        itemUpdater.SetIcon(newIcon);
        updater.Complete();

        // Assert
        itemUpdater.Item.Icon.ShouldBe(newIcon);
        sut.Version.ShouldBe(initialVersion + 1);
    }

    [Fact]
    public void Updater_ItemUpdater_MultipleChanges()
    {
        // Arrange
        var sut = _leftPanelFaker.Generate();
        var initialVersion = sut.Version;

        var updater = sut.GetUpdater();
        var itemUpdater = updater.GetItemUpdater(new(PanelPart.QuickAccess, 0));
        var originalOpenInSeparateWindow = itemUpdater.Item.OpenInSeparateWindow;

        var newLabel = _labelFaker.Generate();
        var newUrl = _faker.Internet.Url();
        var newIcon = _iconFaker.Generate();

        // Act
        itemUpdater.SetLabel(newLabel);
        itemUpdater.SetUrl(newUrl);
        itemUpdater.SetIcon(newIcon);
        itemUpdater.SetOpenInSeparateWindow(!originalOpenInSeparateWindow);
        updater.Complete();

        // Assert
        itemUpdater.Item.Label.ShouldBe(newLabel);
        itemUpdater.Item.Url.ShouldBe(newUrl);
        itemUpdater.Item.Icon.ShouldBe(newIcon);
        itemUpdater.Item.OpenInSeparateWindow.ShouldBe(!originalOpenInSeparateWindow);
        sut.Version.ShouldBe(initialVersion + 1);
    }

    [Fact]
    public void Updater_ItemUpdater_NoChanges()
    {
        // Arrange
        var sut = _leftPanelFaker.Generate();
        var initialVersion = sut.Version;

        var updater = sut.GetUpdater();
        var itemUpdater = updater.GetItemUpdater(new(PanelPart.QuickAccess, 0));

        // Act - getting the updater but not making any changes
        updater.Complete();

        // Assert
        sut.Version.ShouldBe(initialVersion); // Version should remain the same
    }

    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(LeftPanel.MinQuickAccessLength)]
    [InlineData(LeftPanel.MinQuickAccessLength + 7)]
    public void Updater_Normalized_QuickAccess_IsFilledToMinimalSizeFromAllApplications(int itemsCount)
    {
        var sut = _leftPanelFaker.Generate(LeftPanelFaker.Empty);

        // Act
        var updater = sut.GetUpdater();
        updater.AddAllApplicationsItems(
        [
            .. _applicationItemFaker.Generate(itemsCount, ApplicationItemFaker.NotPinned)
        ]);
        updater.Complete();

        // Assert
        sut.QuickAccess.Count.ShouldBe(Math.Min(itemsCount, LeftPanel.MinQuickAccessLength));
        sut.AllApplications.Count.ShouldBe(Math.Max(0, itemsCount - LeftPanel.MinQuickAccessLength));
    }

    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(LeftPanel.MinQuickAccessLength)]
    [InlineData(LeftPanel.MinQuickAccessLength + 5)]
    public void Updater_Normalized_AllApplications_AreFilledFromQuickAccess(int itemsCount)
    {
        var sut = _leftPanelFaker.Generate(LeftPanelFaker.Empty);

        // Act
        var updater = sut.GetUpdater();
        updater.AddQuickAccessItems(
        [
            .. _applicationItemFaker.Generate(itemsCount, ApplicationItemFaker.NotPinned)
        ]);
        updater.Complete();

        // Assert
        sut.QuickAccess.Count.ShouldBe(Math.Min(itemsCount, LeftPanel.MinQuickAccessLength));
        sut.AllApplications.Count.ShouldBe(Math.Max(0, itemsCount - LeftPanel.MinQuickAccessLength));
    }

    [Theory]
    [InlineData(LeftPanel.MinQuickAccessLength)]
    [InlineData(LeftPanel.MinQuickAccessLength + 5)]
    public void Updater_Normalized_QuickAccess_PinnedItemsAreNotMoved(int pinnedItemsCount)
    {
        var sut = _leftPanelFaker.Generate(LeftPanelFaker.Empty);

        // Act
        var updater = sut.GetUpdater();
        updater.AddQuickAccessItems(
        [
            .. _applicationItemFaker.Generate(pinnedItemsCount, ApplicationItemFaker.Pinned),
            _applicationItemFaker.Generate(ApplicationItemFaker.NotPinned)
        ]);
        updater.Complete();

        // Assert
        sut.QuickAccess.Count.ShouldBe(pinnedItemsCount);
        sut.AllApplications.Count.ShouldBe(1);
    }


    [Theory]
    [InlineData(1)]
    [InlineData(LeftPanel.MinQuickAccessLength)]
    [InlineData(LeftPanel.MinQuickAccessLength + 4)]
    public void Updater_Normalized_AllApplications_PinnedItemsAreNotMoved(int pinnedItemsCount)
    {
        var sut = _leftPanelFaker.Generate(LeftPanelFaker.Empty);

        // Act
        var updater = sut.GetUpdater();
        updater.AddAllApplicationsItems(
        [
            .._applicationItemFaker.Generate(pinnedItemsCount, ApplicationItemFaker.Pinned),
           _applicationItemFaker.Generate(ApplicationItemFaker.NotPinned)
        ]);
        updater.Complete();

        // Assert
        sut.QuickAccess.Count.ShouldBe(1);
        sut.AllApplications.Count.ShouldBe(pinnedItemsCount);
    }

    [Fact]
    public void Updater_Normalized_QuickAccess_AllItemsUpToLastPinnedAreGotPinned()
    {
        var sut = _leftPanelFaker.Generate(LeftPanelFaker.Empty);

        // Act
        var updater = sut.GetUpdater();
        updater.AddQuickAccessItems(
        [
            _applicationItemFaker.Generate(ApplicationItemFaker.Pinned),
            _applicationItemFaker.Generate(ApplicationItemFaker.NotPinned),
            _applicationItemFaker.Generate(ApplicationItemFaker.NotPinned),
            _applicationItemFaker.Generate(ApplicationItemFaker.Pinned),
            _applicationItemFaker.Generate(ApplicationItemFaker.NotPinned),
            _applicationItemFaker.Generate(ApplicationItemFaker.Pinned),
            _applicationItemFaker.Generate(ApplicationItemFaker.NotPinned),
            _applicationItemFaker.Generate(ApplicationItemFaker.Pinned),
        ]);
        updater.Complete();

        // Assert
        sut.QuickAccess.Count.ShouldBe(8);
        sut.QuickAccess
            .OfType<ApplicationPanelItem>()
            .ShouldAllBe(appItem => appItem.IsPinned);
    }

    [Fact]
    public void Updater_Normalized_AllApplication_AllItemsUpToLastPinnedAreGotPinned()
    {
        var sut = _leftPanelFaker.Generate(LeftPanelFaker.Empty);

        // Act
        var updater = sut.GetUpdater();
        updater.AddQuickAccessItems(
        [
            .. _applicationItemFaker.Generate(LeftPanel.MinQuickAccessLength, ApplicationItemFaker.Pinned),
        ]);
        updater.AddAllApplicationsItems(
        [
            _applicationItemFaker.Generate(ApplicationItemFaker.Pinned),
            _applicationItemFaker.Generate(ApplicationItemFaker.NotPinned),
            _applicationItemFaker.Generate(ApplicationItemFaker.NotPinned),
            _applicationItemFaker.Generate(ApplicationItemFaker.Pinned),
            _applicationItemFaker.Generate(ApplicationItemFaker.NotPinned),
            _applicationItemFaker.Generate(ApplicationItemFaker.Pinned),
            _applicationItemFaker.Generate(ApplicationItemFaker.NotPinned),
            _applicationItemFaker.Generate(ApplicationItemFaker.NotPinned),
        ]);
        updater.Complete();

        // Assert
        sut.AllApplications.Count.ShouldBe(8);
        sut.AllApplications
            .Take(6)
            .OfType<ApplicationPanelItem>()
            .ShouldAllBe(appItem => appItem.IsPinned);
        sut.AllApplications
            .Skip(6)
            .OfType<ApplicationPanelItem>()
            .ShouldAllBe(appItem => !appItem.IsPinned);
    }
}
