using ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;
using Bogus;

namespace ASOL.PlatformStore.Store.Domain.Tests.LeftPanels;

internal sealed class PanelItemFaker : Faker<PanelItem>
{
    public const string CustomPanelItem = "CustomPanelItem";
    public const string ApplicationPanelItem = "ApplicationPanelItem";
    public static readonly string CustomAndApplicationItems = string.Join(",", CustomPanelItem, ApplicationPanelItem);

    public PanelItemFaker()
    {
        var applicationItemFaker = new ApplicationItemFaker();
        var labelFaker = new LabelFaker();
        var iconFaker = new IconFaker();

        RuleSet(CustomPanelItem, _ =>
        {
            CustomInstantiator(_ => new PanelItem(
                id: _.Random.String2(10),
                label: labelFaker.Generate(),
                url: _.Internet.Url(),
                icon: iconFaker.Generate(),
                openInSeparateWindow: _.Random.Bool()));
        });

        RuleSet(ApplicationPanelItem, _ =>
        {
            CustomInstantiator(_ => applicationItemFaker
                .Generate(ApplicationItemFaker.AllRules));
        });
    }
}
