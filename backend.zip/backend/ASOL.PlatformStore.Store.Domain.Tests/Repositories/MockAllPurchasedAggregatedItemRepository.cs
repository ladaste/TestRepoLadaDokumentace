using ASOL.Core.Multitenancy.MongoDb;
using ASOL.Core.Persistence.MongoDb;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Tests.Support;

namespace ASOL.PlatformStore.Store.Domain.Tests.Repositories;

public class MockAllPurchasedAggregatedItemRepository : MockHybridRepository<AllPurchasedAggregatedItem, string>, IAllPurchasedAggregatedItemRepository
{
    public MockAllPurchasedAggregatedItemRepository(ITenantDbContext dbContext, MockHybridRepositoryData<AllPurchasedAggregatedItem> items) : base(dbContext, items)
    {
    }

    public MockAllPurchasedAggregatedItemRepository(IDbContext dbContext, MockHybridRepositoryData<AllPurchasedAggregatedItem> items) : base(dbContext, items)
    {
    }
}
