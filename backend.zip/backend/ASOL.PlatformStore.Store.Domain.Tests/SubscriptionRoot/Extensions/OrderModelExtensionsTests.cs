using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.Serialization;
using ASOL.PlatformStore.Order.Contracts;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Extensions;
using Moq;
using Shouldly;
using Xunit;

namespace ASOL.PlatformStore.Store.Domain.Tests.SubscriptionRoot.Extensions;

/// <summary>
/// Tests for <see cref="OrderModelExtensions"/> focusing on discount mapping.
/// </summary>
public class OrderModelExtensionsTests
{
    [Fact]
    public void ToSubscriptionOrder_WithFullDiscount_MapsDiscountPropertiesCorrectly()
    {
        // Arrange
        var orderDate = new DateTime(2025, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        var order = CreateTestOrderModel(
            discountAmount: 1.0m,
            discountDuration: 4,
            discountInternalNote: "100% discount for 4 months",
            orderDate: orderDate
        );

        var catalogRepo = CreateMockProductCatalogRepository(order);

        // Act
        var result = order.ToSubscriptionOrder(catalogRepo.Object);

        // Assert
        result.DiscountAmount.ShouldBe(1.0m);
        result.DiscountDurationMonths.ShouldBe(4);
        result.DiscountInternalNote.ShouldBe("100% discount for 4 months");
        result.IsInitialDiscountFromOrder.ShouldBeTrue();
    }

    [Fact]
    public void ToSubscriptionOrder_WithPartialDiscount_MapsDiscountPropertiesCorrectly()
    {
        // Arrange
        var orderDate = new DateTime(2025, 2, 15, 0, 0, 0, DateTimeKind.Utc);
        var order = CreateTestOrderModel(
            discountAmount: 0.5m,
            discountDuration: 2,
            discountInternalNote: "50% discount for 2 months",
            orderDate: orderDate
        );

        var catalogRepo = CreateMockProductCatalogRepository(order);

        // Act
        var result = order.ToSubscriptionOrder(catalogRepo.Object);

        // Assert
        result.DiscountAmount.ShouldBe(0.5m);
        result.DiscountDurationMonths.ShouldBe(2);
        result.DiscountInternalNote.ShouldBe("50% discount for 2 months");
        result.IsInitialDiscountFromOrder.ShouldBeTrue();
    }

    [Fact]
    public void ToSubscriptionOrder_WithoutDiscount_LeavesDiscountPropertiesNull()
    {
        // Arrange
        var order = CreateTestOrderModel(
            discountAmount: null,
            discountDuration: null,
            discountInternalNote: null
        );

        var catalogRepo = CreateMockProductCatalogRepository(order);

        // Act
        var result = order.ToSubscriptionOrder(catalogRepo.Object);

        // Assert
        result.DiscountAmount.ShouldBeNull();
        result.DiscountDurationMonths.ShouldBeNull();
        result.DiscountInternalNote.ShouldBeNull();
        result.IsInitialDiscountFromOrder.ShouldBeFalse();
    }

    [Fact]
    public void ToSubscriptionOrder_WithZeroDurationDiscount_DoesNotSetDates()
    {
        // Arrange
        var order = CreateTestOrderModel(
            discountAmount: 1.0m,
            discountDuration: 0,
            discountInternalNote: "Discount with zero duration"
        );

        var catalogRepo = CreateMockProductCatalogRepository(order);

        // Act
        var result = order.ToSubscriptionOrder(catalogRepo.Object);

        // Assert
        result.DiscountAmount.ShouldBe(1.0m);
        result.DiscountDurationMonths.ShouldBe(0);
        result.DiscountInternalNote.ShouldBe("Discount with zero duration");
        result.IsInitialDiscountFromOrder.ShouldBeTrue();
    }

    [Fact]
    public void ToSubscriptionOrder_MapsBasicOrderPropertiesCorrectly()
    {
        // Arrange
        var order = CreateTestOrderModel(
            discountAmount: 1.0m,
            discountDuration: 3,
            discountInternalNote: "Test discount"
        );

        var catalogRepo = CreateMockProductCatalogRepository(order);

        // Act
        var result = order.ToSubscriptionOrder(catalogRepo.Object);

        // Assert
        result.TenantId.ShouldBe(order.Customer.TenantId);
        result.OrderId.ShouldBe(order.Id);
        result.OrderNumber.ShouldBe(order.OrderNumber);
        result.OrderDate.ShouldBe(order.CreatedOn);
        result.IsSystem.ShouldBe(order.IsSystem);
        result.OrderLines.ShouldNotBeEmpty();
    }

    private static OrderModel CreateTestOrderModel(
        decimal? discountAmount,
        int? discountDuration,
        string discountInternalNote,
        DateTime? orderDate = null)
    {
        var orderId = Guid.NewGuid().ToString();
        var tenantId = "test-tenant-id";
        var orderNumber = "ORD-2025-001";

        var order = new OrderModel
        {
            Id = orderId,
            OrderNumber = orderNumber,
            CreatedOn = orderDate ?? DateTime.UtcNow,
            IsSystem = false,
            Customer = new CustomerModel
            {
                TenantId = tenantId,
                Code = "12345678|CZ",
                Name = "Test Customer"
            },
            CurrentStatusInfo = new OrderStatusInfoModel
            {
                SystemStatus = "Validation",
                ModifiedBy = "test-user",
                ModifiedOn = DateTime.UtcNow
            },
            OrderLines =
            [
                new()
                {
                    Id = Guid.NewGuid().ToString(),
                    OrderLineType = "Application",
                    ProductId = "app-product-id",
                    ProductCode = "APP-CODE",
                    ProductPartCode = "TestApp-AP-",
                    Price = 100m,
                    BasePrice = 100m
                },
                new()
                {
                    Id = Guid.NewGuid().ToString(),
                    OrderLineType = "Package",
                    ProductId = "pkg-product-id",
                    ProductCode = "PKG-CODE",
                    ProductPartCode = "TestApp-PKG",
                    Price = 200m,
                    BasePrice = 200m
                },
                new()
                {
                    Id = Guid.NewGuid().ToString(),
                    OrderLineType = "SalesItem",
                    ProductId = "sales-product-id",
                    ProductCode = "SALES-CODE",
                    ProductPartCode = "TestApp-SALES-SI",
                    Price = 50m,
                    BasePrice = 50m,
                    BillingPeriodCode = "MonthlyForward"
                }
            ]
        };

        if (discountAmount.HasValue || discountDuration.HasValue || !string.IsNullOrEmpty(discountInternalNote))
        {
            order.Discount = new DiscountModel
            {
                Amount = discountAmount ?? 0m,
                Duration = discountDuration,
                InternalNote = discountInternalNote
            };
        }

        return order;
    }

    private static Mock<IProductCatalogReadOnlyRepository> CreateMockProductCatalogRepository(OrderModel order)
    {
        var catalogRepo = new Mock<IProductCatalogReadOnlyRepository>();

        // Create a simple dictionary-based lookup
        var catalogDict = order.OrderLines.ToDictionary(
            ol => ol.ProductId,
            ol => new
            {
                ProductId = ol.ProductId,
                Code = ol.ProductCode,
                PartCode = ol.ProductPartCode
            });

        catalogRepo
            .Setup(r => r.Get(It.IsAny<Expression<Func<ProductCatalog, bool>>>()))
            .Returns((Expression<Func<ProductCatalog, bool>> predicate) =>
            {
                // Create minimal ProductCatalog objects using reflection to bypass constructor
                var catalogs = new List<ProductCatalog>();

                foreach (var ol in order.OrderLines)
                {
                    var catalog = FormatterServices
                        .GetUninitializedObject(typeof(ProductCatalog)) as ProductCatalog;

                    // Set properties using reflection
                    typeof(ProductCatalog).GetProperty("Id")!
                        .SetValue(catalog, ol.ProductId);
                    typeof(ProductCatalog).GetProperty("Code")!
                        .SetValue(catalog, ol.ProductCode);
                    typeof(ProductCatalog).GetProperty("PartCode")!
                        .SetValue(catalog, ol.ProductPartCode);
                    typeof(ProductCatalog).GetProperty("Name")!
                        .SetValue(catalog, $"Product {ol.ProductCode}");
                    typeof(ProductCatalog).GetProperty("CustomAttributes")!
                        .SetValue(catalog, new System.Dynamic.ExpandoObject());

                    catalogs.Add(catalog);
                }

                return catalogs.AsQueryable().Where(predicate);
            });

        return catalogRepo;
    }
}
