using System;
using ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Extensions;
using Xunit;
using Shouldly;

namespace ASOL.PlatformStore.Store.Domain.Tests.SubscriptionRoot.Extensions;

public class SubscriptionCopyExtensionsTests
{
    private sealed class TestOrganizationModel : ISubscriptionOrganizationModel
    {
        public string Id { get; set; }
        public string TenantId { get; set; }
        public string OrganizationRelationshipId { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public string VatIn { get; set; }
        public string Line1 { get; set; }
        public string Line2 { get; set; }
        public string Line3 { get; set; }
        public string City { get; set; }
        public string CountryCode { get; set; }
        public string ZipCode { get; set; }
        public string RegistryNumber { get; set; }
        public string HouseNumber { get; set; }
        public string StreetName { get; set; }
    }

    [Fact]
    public void CopyFrom_ISubscriptionOrganizationModel_CopiesProperties()
    {
        var source = new TestOrganizationModel
        {
            Id = "id1",
            Name = "OrgName",
            Code = "Code1",
            VatIn = "VAT123",
            Line1 = "Addr1"
        };
        var target = new TestOrganizationModel();
        target.CopyFrom(source);
        target.Id.ShouldBe(source.Id);
        target.Name.ShouldBe(source.Name);
        target.Code.ShouldBe(source.Code);
        target.VatIn.ShouldBe(source.VatIn);
        target.Line1.ShouldBe(source.Line1);
    }

    private sealed class TestOrderStatusModel : ISubscriptionOrderStatusModel
    {
        public string Status { get; set; }
        public string StatusModifiedBy { get; set; }
        public DateTime? StatusModifiedOn { get; set; }
    }

    [Fact]
    public void CopyFrom_ISubscriptionOrderStatusModel_CopiesProperties()
    {
        var source = new TestOrderStatusModel
        {
            Status = "Active",
            StatusModifiedBy = "user1",
            StatusModifiedOn = DateTime.UtcNow
        };
        var target = new TestOrderStatusModel();
        target.CopyFrom(source);
        target.Status.ShouldBe(source.Status);
        target.StatusModifiedBy.ShouldBe(source.StatusModifiedBy);
        target.StatusModifiedOn.ShouldBe(source.StatusModifiedOn);
    }
}
