using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using ASOL.PlatformStore.Store.Contracts.Subscription;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Queries;
using EventFlow.Queries;

namespace ASOL.PlatformStore.Store.Domain.Tests.SubscriptionRoot.Fakes;

/// <summary>
/// Fake query handler used in domain tests to avoid dependency on MongoDb project.
/// Returns empty collection so termination logic becomes a no-op.
/// </summary>
public class FakeGetSubscriptionLicensesByPackageCodeQueryHandler
    : IQueryHandler<GetSubscriptionLicensesByPackageCodeQuery, List<SubscriptionLicenseModel>>
{
    public Task<List<SubscriptionLicenseModel>> ExecuteQueryAsync(GetSubscriptionLicensesByPackageCodeQuery query, CancellationToken cancellationToken)
    {
        return Task.FromResult(new List<SubscriptionLicenseModel>());
    }
}
