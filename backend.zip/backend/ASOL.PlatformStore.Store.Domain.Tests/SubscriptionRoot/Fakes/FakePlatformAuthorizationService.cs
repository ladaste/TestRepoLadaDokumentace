using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Identity.Authorization;

namespace ASOL.PlatformStore.Store.Domain.Tests.SubscriptionRoot.Fakes;

public class FakePlatformAuthorizationService : IPlatformAuthorizationService
{
    public Task AuthorizeAsync(RightObjectAuthorizationRequirement requirement, CancellationToken ct = default)
    {
        return Task.CompletedTask;
    }

    public Task AuthorizeByRoleAsync(string roleCode, CancellationToken ct = default)
    {
        return Task.CompletedTask;
    }

    public Task AuthorizeSpaceOwnerRoleAsync(CancellationToken ct = default)
    {
        return Task.CompletedTask;
    }

    public Task AuthorizeTenantOwnerRoleAsync(CancellationToken ct = default)
    {
        return Task.CompletedTask;
    }

    public Task<ICollection<string>> GetRolesAsync(CancellationToken ct = default)
    {
        throw new NotImplementedException();
    }

    public Task<bool> IsInRoleAsync(string roleCode, CancellationToken ct = default)
    {
        throw new NotImplementedException();
    }

    public Task<bool> IsSpaceOwnerRoleAsync(CancellationToken ct = default)
    {
        throw new NotImplementedException();
    }

    public Task<bool> IsTenantOwnerRoleAsync(CancellationToken ct = default)
    {
        return Task.FromResult(false);
    }

    public void ResetCache()
    {
        throw new NotImplementedException();
    }
}
