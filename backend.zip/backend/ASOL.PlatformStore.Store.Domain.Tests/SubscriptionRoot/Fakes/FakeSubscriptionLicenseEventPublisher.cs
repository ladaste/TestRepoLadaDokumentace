using System.Threading;
using System.Threading.Tasks;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Events;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Publishers;

namespace ASOL.PlatformStore.Store.Domain.Tests.SubscriptionRoot.Fakes;

/// <summary>
/// Fake implementation for ISubscriptionLicenseEventPublisher for unit testing.
/// </summary>
public class FakeSubscriptionLicenseEventPublisher : ISubscriptionLicenseEventPublisher
{
    public Task PublishSubscriptionLicenseCreatedAsync(SubscriptionLicenseCreatedEvent createdEvent, CancellationToken cancellationToken)
    {
        // No-op for tests
        return Task.CompletedTask;
    }

    public Task PublishSubscriptionLicenseDeletedAsync(SubscriptionLicenseDeletedEvent deletedEvent, CancellationToken cancellationToken)
    {
        // No-op for tests
        return Task.CompletedTask;
    }

    public Task PublishSubscriptionLicenseStatusUpdatedAsync(SubscriptionLicenseStatusUpdatedEvent statusUpdatedEvent, CancellationToken cancellationToken)
    {
        // No-op for tests
        return Task.CompletedTask;
    }

    public Task PublishSubscriptionLicenseTerminatedAsync(SubscriptionLicenseTerminatedEvent terminatedEvent, CancellationToken cancellationToken)
    {
        // No-op for tests
        return Task.CompletedTask;
    }

    public Task PublishSubscriptionLicenseUpdatedAsync(SubscriptionLicenseUpdatedEvent updatedEvent, CancellationToken cancellationToken)
    {
        // No-op for tests
        return Task.CompletedTask;
    }
}
