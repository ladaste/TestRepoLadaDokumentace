using System;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Helpers;
using Shouldly;
using Xunit;

namespace ASOL.PlatformStore.Store.Domain.Tests.SubscriptionRoot.Helpers;

/// <summary>
/// Unit tests for <see cref="NextInvoiceDateCalculator"/>
/// </summary>
public class NextInvoiceDateCalculatorTests
{
    #region CalculateNextInvoiceDate Tests (Subsequent Invoices)

    [Fact]
    public void CalculateNextInvoiceDate_ForwardBilling_MonthEnd_ReturnsNextDay()
    {
        // Arrange
        var lastAccrualDate = new DateOnly(2025, 1, 31);
        var isForwardBilling = true;

        // Act
        var result = NextInvoiceDateCalculator.CalculateNextInvoiceDate(lastAccrualDate, isForwardBilling);

        // Assert
        result.ShouldBe(new DateOnly(2025, 2, 1));
    }

    [Fact]
    public void CalculateNextInvoiceDate_ForwardBilling_MonthlyMidMonth_ReturnsNextDay()
    {
        // Arrange
        var lastAccrualDate = new DateOnly(2025, 6, 15);
        var isForwardBilling = true;

        // Act
        var result = NextInvoiceDateCalculator.CalculateNextInvoiceDate(lastAccrualDate, isForwardBilling);

        // Assert
        result.ShouldBe(new DateOnly(2025, 6, 16));
    }

    [Fact]
    public void CalculateNextInvoiceDate_ForwardBilling_YearEnd_ReturnsNextDay()
    {
        // Arrange
        var lastAccrualDate = new DateOnly(2025, 12, 31);
        var isForwardBilling = true;

        // Act
        var result = NextInvoiceDateCalculator.CalculateNextInvoiceDate(lastAccrualDate, isForwardBilling);

        // Assert
        result.ShouldBe(new DateOnly(2026, 1, 1));
    }

    [Fact]
    public void CalculateNextInvoiceDate_BackwardBilling_MonthEnd_ReturnsFirstDayOfMonthAfterNext()
    {
        // Arrange
        var lastAccrualDate = new DateOnly(2025, 1, 31);
        var isForwardBilling = false;

        // Act
        var result = NextInvoiceDateCalculator.CalculateNextInvoiceDate(lastAccrualDate, isForwardBilling);

        // Assert
        // Last period ended 31.1 -> Next invoice for February issued on 1.3
        result.ShouldBe(new DateOnly(2025, 2, 1));
    }

    [Fact]
    public void CalculateNextInvoiceDate_BackwardBilling_MidMonth_ReturnsFirstDayOfMonthAfterNext()
    {
        // Arrange
        var lastAccrualDate = new DateOnly(2025, 6, 15);
        var isForwardBilling = false;

        // Act
        var result = NextInvoiceDateCalculator.CalculateNextInvoiceDate(lastAccrualDate, isForwardBilling);

        // Assert
        // Last period ended 15.6 -> Next invoice period starts 1.7
        result.ShouldBe(new DateOnly(2025, 7, 1));
    }

    [Fact]
    public void CalculateNextInvoiceDate_BackwardBilling_DecemberEnd_ReturnsFirstDayOfNextYear()
    {
        // Arrange
        var lastAccrualDate = new DateOnly(2025, 12, 31);
        var isForwardBilling = false;

        // Act
        var result = NextInvoiceDateCalculator.CalculateNextInvoiceDate(lastAccrualDate, isForwardBilling);

        // Assert
        // Last period ended 31.12 -> Next invoice for January issued on 1.2.2026
        result.ShouldBe(new DateOnly(2026, 1, 1));
    }

    #endregion

    #region CalculateFirstInvoiceDate Tests

    [Fact]
    public void CalculateFirstInvoiceDate_ForwardBilling_ActivatedMidMonth_ReturnsFirstOfNextMonth()
    {
        // Arrange
        var activationDate = new DateOnly(2025, 10, 9); // Activated on October 9th
        var isForwardBilling = true;

        // Act
        var result = NextInvoiceDateCalculator.CalculateFirstInvoiceDate(activationDate, isForwardBilling);

        // Assert
        // October (1.10 - 31.10) is treated as "free" period
        // First invoice should be issued on 1.11.2025
        result.ShouldBe(new DateOnly(2025, 11, 1));
    }

    [Fact]
    public void CalculateFirstInvoiceDate_BackwardBilling_ActivatedMidMonth_ReturnsFirstOfNextMonth()
    {
        // Arrange
        var activationDate = new DateOnly(2025, 10, 9); // Activated on October 9th
        var isForwardBilling = false;

        // Act
        var result = NextInvoiceDateCalculator.CalculateFirstInvoiceDate(activationDate, isForwardBilling);

        // Assert
        // October (1.10 - 31.10) is treated as "virtual" accrual period
        // First invoice should be for October usage, issued on 1.11.2025
        result.ShouldBe(new DateOnly(2025, 11, 1));
    }

    [Fact]
    public void CalculateFirstInvoiceDate_ForwardBilling_ActivatedFirstDay_ReturnsFirstOfNextMonth()
    {
        // Arrange
        var activationDate = new DateOnly(2025, 10, 1); // Activated on October 1st
        var isForwardBilling = true;

        // Act
        var result = NextInvoiceDateCalculator.CalculateFirstInvoiceDate(activationDate, isForwardBilling);

        // Assert
        // October (1.10 - 31.10) is treated as "free" period
        // First invoice should be issued on 1.11.2025
        result.ShouldBe(new DateOnly(2025, 11, 1));
    }

    [Fact]
    public void CalculateFirstInvoiceDate_BackwardBilling_ActivatedLastDay_ReturnsFirstOfNextMonth()
    {
        // Arrange
        var activationDate = new DateOnly(2025, 10, 31); // Activated on October 31st
        var isForwardBilling = false;

        // Act
        var result = NextInvoiceDateCalculator.CalculateFirstInvoiceDate(activationDate, isForwardBilling);

        // Assert
        // October (1.10 - 31.10) is treated as "virtual" accrual period
        // First invoice should be for October usage, issued on 1.11.2025
        result.ShouldBe(new DateOnly(2025, 11, 1));
    }

    [Fact]
    public void CalculateFirstInvoiceDate_ForwardBilling_ActivatedInDecember_ReturnsFirstOfJanuary()
    {
        // Arrange
        var activationDate = new DateOnly(2025, 12, 15); // Activated on December 15th
        var isForwardBilling = true;

        // Act
        var result = NextInvoiceDateCalculator.CalculateFirstInvoiceDate(activationDate, isForwardBilling);

        // Assert
        // December (1.12 - 31.12) is treated as "free" period
        // First invoice should be issued on 1.1.2026
        result.ShouldBe(new DateOnly(2026, 1, 1));
    }

    [Fact]
    public void CalculateFirstInvoiceDate_BackwardBilling_ActivatedInFebruary_ReturnsFirstOfMarch()
    {
        // Arrange
        var activationDate = new DateOnly(2025, 2, 20); // Activated on February 20th (non-leap year)
        var isForwardBilling = false;

        // Act
        var result = NextInvoiceDateCalculator.CalculateFirstInvoiceDate(activationDate, isForwardBilling);

        // Assert
        // February (1.2 - 28.2) is treated as "virtual" accrual period
        // First invoice should be for February usage, issued on 1.3.2025
        result.ShouldBe(new DateOnly(2025, 3, 1));
    }

    [Fact]
    public void CalculateFirstInvoiceDate_ForwardBilling_ActivatedInLeapYearFebruary_ReturnsFirstOfMarch()
    {
        // Arrange
        var activationDate = new DateOnly(2024, 2, 15); // Activated on February 15th (leap year)
        var isForwardBilling = true;

        // Act
        var result = NextInvoiceDateCalculator.CalculateFirstInvoiceDate(activationDate, isForwardBilling);

        // Assert
        // February (1.2 - 29.2) is treated as "free" period
        // First invoice should be issued on 1.3.2024
        result.ShouldBe(new DateOnly(2024, 3, 1));
    }

    #endregion

    #region IsForwardBilling Tests

    [Theory]
    [InlineData("MonthlyForward", true)]
    [InlineData("YearlyForward", true)]
    [InlineData("QuarterlyForward", true)]
    [InlineData("monthlyforward", true)]
    [InlineData("YEARLYFORWARD", true)]
    public void IsForwardBilling_ForwardCodes_ReturnsTrue(string billingPeriodCode, bool expected)
    {
        // Act
        var result = NextInvoiceDateCalculator.IsForwardBilling(billingPeriodCode);

        // Assert
        result.ShouldBe(expected);
    }

    [Theory]
    [InlineData("MonthlyBackward", false)]
    [InlineData("YearlyBackward", false)]
    [InlineData("QuarterlyBackward", false)]
    [InlineData("Monthly", false)]
    [InlineData("Yearly", false)]
    [InlineData(null, false)]
    [InlineData("", false)]
    [InlineData("   ", false)]
    public void IsForwardBilling_NonForwardCodes_ReturnsFalse(string billingPeriodCode, bool expected)
    {
        // Act
        var result = NextInvoiceDateCalculator.IsForwardBilling(billingPeriodCode);

        // Assert
        result.ShouldBe(expected);
    }

    #endregion
}
