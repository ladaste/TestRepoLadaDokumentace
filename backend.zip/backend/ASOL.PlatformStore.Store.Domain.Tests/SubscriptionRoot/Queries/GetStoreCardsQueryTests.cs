using ASOL.Core.Paging.Contracts.Filters;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Queries;
using Shouldly;
using Xunit;

namespace ASOL.PlatformStore.Store.Domain.Tests.SubscriptionRoot.Queries;

public class GetStoreCardsQueryTests
{
    [Fact]
    public void Constructor_WithValidPagingFilter_ShouldSetProperty()
    {
        // Arrange
        var pagingFilter = new PagingFilter { Offset = 10, Limit = 20 };

        // Act
        var query = new GetStoreCardsQuery(pagingFilter);

        // Assert
        query.PagingFilter.ShouldNotBeNull();
        query.PagingFilter.Offset.ShouldBe(10);
        query.PagingFilter.Limit.ShouldBe(20);
    }

    [Fact]
    public void Constructor_WithNullPagingFilter_ShouldCreateDefaultPagingFilter()
    {
        // Arrange
        PagingFilter pagingFilter = null;

        // Act
        var query = new GetStoreCardsQuery(pagingFilter);

        // Assert
        query.PagingFilter.ShouldNotBeNull();
        query.PagingFilter.ShouldBeOfType<PagingFilter>();
    }

    [Fact]
    public void Constructor_WithDefaultPagingFilter_ShouldUseDefaultValues()
    {
        // Arrange
        var pagingFilter = new PagingFilter();

        // Act
        var query = new GetStoreCardsQuery(pagingFilter);

        // Assert
        query.PagingFilter.ShouldNotBeNull();
        query.PagingFilter.Offset.ShouldBe(0);
        query.PagingFilter.Limit.ShouldBe(100); // Default limit is 100
    }
}
