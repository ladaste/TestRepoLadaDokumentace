using System;
using ASOL.Core.Localization;
using ASOL.PlatformStore.Store.Contracts.Subscription;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Events;
using Shouldly;
using Xunit;

namespace ASOL.PlatformStore.Store.Domain.Tests.SubscriptionRoot;

/// <summary>
/// Contains unit tests for subscription billing item events.
/// </summary>
public class SubscriptionBillingItemEventsTests
{
    /// <summary>
    /// Tests that SubscriptionBillingItemCreatedEvent stores all required data correctly.
    /// </summary>
    [Fact]
    public void SubscriptionBillingItemCreatedEvent_StoresDataCorrectly()
    {
        // Arrange & Act
        var @event = new SubscriptionBillingItemCreatedEvent(
            id: "billing-item-1",
            subscriptionId: "subscription-1",
            orderNumber: "ORDER-001",
            orderLineId: "line-1",
            productId: "product-1",
            productCode: "PROD-001",
            basePrice: 100m,
            licenseCount: 5,
            customer: new SubscriptionCustomerModel { Id = "customer-1", Name = "Test Customer" },
            productName: new LocalizedValue<string>(("en-US", "Test Product")),
            productPartCode: "PART-001",
            billingPeriodCode: "MonthlyForward",
            unitOfMeasureCode: "Count",
            unitOfSaleCode: "License",
            ownershipType: "Rent",
            itemTypeCode: "Service",
            developmentPartner: new SubscriptionDevelopmentPartnerModel { Id = "dev-1", Name = "Dev Partner" },
            applicationCode: "app-code",
            solutionActiveFrom: new DateOnly(2024, 1, 1),
            nextExpectedInvoiceDate: new DateOnly(2024, 2, 1),
            discountAmount: 0.1m,
            discountValidFrom: new DateOnly(2024, 1, 1),
            discountValidTo: new DateOnly(2024, 12, 31),
            discountInternalNote: "Test discount",
            isInitialDiscountFromOrder: true,
            initialFreeMonths: 3);

        // Assert
        @event.Id.ShouldBe("billing-item-1");
        @event.SubscriptionId.ShouldBe("subscription-1");
        @event.OrderNumber.ShouldBe("ORDER-001");
        @event.OrderLineId.ShouldBe("line-1");
        @event.ProductId.ShouldBe("product-1");
        @event.ProductCode.ShouldBe("PROD-001");
        @event.BasePrice.ShouldBe(100m);
        @event.LicenseCount.ShouldBe(5);
        @event.Customer.Id.ShouldBe("customer-1");
        @event.ProductName.Translate("en-US", null).ShouldBe("Test Product");
        @event.BillingPeriodCode.ShouldBe("MonthlyForward");
        @event.NextInvoiceExpectedDate.ShouldBe(new DateOnly(2024, 2, 1));
        @event.DiscountAmount.ShouldBe(0.1m);
        @event.DiscountValidFrom.ShouldBe(new DateOnly(2024, 1, 1));
        @event.DiscountValidTo.ShouldBe(new DateOnly(2024, 12, 31));
        @event.IsInitialDiscountFromOrder.ShouldBeTrue();
        @event.InitialFreeMonths.ShouldBe(3);
    }

    /// <summary>
    /// Tests that SubscriptionBillingItemCreatedEvent accepts null discount values.
    /// </summary>
    [Fact]
    public void SubscriptionBillingItemCreatedEvent_AcceptsNullDiscountValues()
    {
        // Arrange & Act
        var @event = new SubscriptionBillingItemCreatedEvent(
            id: "billing-item-1",
            subscriptionId: "subscription-1",
            orderNumber: "ORDER-001",
            orderLineId: "line-1",
            productId: "product-1",
            productCode: "PROD-001",
            basePrice: 100m,
            licenseCount: 5,
            customer: new SubscriptionCustomerModel { Id = "customer-1" },
            productName: new LocalizedValue<string>(("en-US", "Test Product")),
            productPartCode: "PART-001",
            billingPeriodCode: "MonthlyForward",
            unitOfMeasureCode: "Count",
            unitOfSaleCode: "License",
            ownershipType: "Rent",
            itemTypeCode: "Service",
            developmentPartner: new SubscriptionDevelopmentPartnerModel { Id = "dev-1" },
            applicationCode: "app-code",
            solutionActiveFrom: new DateOnly(2024, 1, 1),
            nextExpectedInvoiceDate: new DateOnly(2024, 2, 1),
            discountAmount: null,
            discountValidFrom: null,
            discountValidTo: null,
            discountInternalNote: null,
            isInitialDiscountFromOrder: false,
            initialFreeMonths: null);

        // Assert
        @event.DiscountAmount.ShouldBeNull();
        @event.DiscountValidFrom.ShouldBeNull();
        @event.DiscountValidTo.ShouldBeNull();
        @event.DiscountInternalNote.ShouldBeNull();
        @event.IsInitialDiscountFromOrder.ShouldBeFalse();
        @event.InitialFreeMonths.ShouldBeNull();
    }

    /// <summary>
    /// Tests that SubscriptionBillingItemTerminatedEvent stores data correctly.
    /// </summary>
    [Fact]
    public void SubscriptionBillingItemTerminatedEvent_StoresDataCorrectly()
    {
        // Arrange & Act
        var @event = new SubscriptionBillingItemTerminatedEvent(
            id: "billing-item-1",
            validTo: new DateOnly(2024, 12, 31));

        // Assert
        @event.Id.ShouldBe("billing-item-1");
        @event.ValidTo.ShouldBe(new DateOnly(2024, 12, 31));
    }

    /// <summary>
    /// Tests that SubscriptionBillingItemInvoiceGeneratedEvent stores data correctly.
    /// </summary>
    [Fact]
    public void SubscriptionBillingItemInvoiceGeneratedEvent_StoresDataCorrectly()
    {
        // Arrange & Act
        var @event = new SubscriptionBillingItemInvoiceGeneratedEvent(
            id: "billing-item-1",
            orderNumber: "ORDER-001",
            orderLineId: "line-1",
            accrualDateFrom: new DateOnly(2024, 1, 1),
            accrualDateTo: new DateOnly(2024, 1, 31));

        // Assert
        @event.Id.ShouldBe("billing-item-1");
        @event.OrderNumber.ShouldBe("ORDER-001");
        @event.OrderLineId.ShouldBe("line-1");
        @event.AccrualDateFrom.ShouldBe(new DateOnly(2024, 1, 1));
        @event.AccrualDateTo.ShouldBe(new DateOnly(2024, 1, 31));
    }

    /// <summary>
    /// Tests that SubscriptionBillingItemInvoiceGeneratedEvent accepts null accrual dates.
    /// </summary>
    [Fact]
    public void SubscriptionBillingItemInvoiceGeneratedEvent_AcceptsNullAccrualDates()
    {
        // Arrange & Act
        var @event = new SubscriptionBillingItemInvoiceGeneratedEvent(
            id: "billing-item-1",
            orderNumber: "ORDER-001",
            orderLineId: "line-1",
            accrualDateFrom: null,
            accrualDateTo: null);

        // Assert
        @event.AccrualDateFrom.ShouldBeNull();
        @event.AccrualDateTo.ShouldBeNull();
    }

    /// <summary>
    /// Tests that SubscriptionBillingItemInvoiceSkippedEvent stores data correctly.
    /// </summary>
    [Fact]
    public void SubscriptionBillingItemInvoiceSkippedEvent_StoresDataCorrectly()
    {
        // Arrange & Act
        var @event = new SubscriptionBillingItemInvoiceSkippedEvent(
            id: "billing-item-1",
            orderNumber: "ORDER-001",
            orderLineId: "line-1",
            accrualDateFrom: new DateOnly(2024, 1, 1),
            accrualDateTo: new DateOnly(2024, 1, 31),
            reason: "ZeroAmount");

        // Assert
        @event.Id.ShouldBe("billing-item-1");
        @event.OrderNumber.ShouldBe("ORDER-001");
        @event.OrderLineId.ShouldBe("line-1");
        @event.AccrualDateFrom.ShouldBe(new DateOnly(2024, 1, 1));
        @event.AccrualDateTo.ShouldBe(new DateOnly(2024, 1, 31));
        @event.Reason.ShouldBe("ZeroAmount");
    }

    /// <summary>
    /// Tests that SubscriptionBillingItemInvoiceDeletedEvent stores data correctly.
    /// </summary>
    [Fact]
    public void SubscriptionBillingItemInvoiceDeletedEvent_StoresDataCorrectly()
    {
        // Arrange & Act
        var @event = new SubscriptionBillingItemInvoiceDeletedEvent(
            id: "billing-item-1",
            orderNumber: "ORDER-001",
            orderLineId: "line-1");

        // Assert
        @event.Id.ShouldBe("billing-item-1");
        @event.OrderNumber.ShouldBe("ORDER-001");
        @event.OrderLineId.ShouldBe("line-1");
    }

    /// <summary>
    /// Tests that SubscriptionOrderInvoiceInfoUpdatedEvent stores all invoice information correctly.
    /// </summary>
    [Fact]
    public void SubscriptionOrderInvoiceInfoUpdatedEvent_StoresAllInvoiceInformationCorrectly()
    {
        // Arrange
        var latestInvoiceVatDate = new DateTime(2024, 2, 1);
        var latestInvoiceAccrualFrom = new DateTime(2024, 1, 1);
        var latestInvoiceAccrualTo = new DateTime(2024, 1, 31);
        var orderFirstInvoiceVatDate = new DateTime(2024, 1, 15);
        var orderLastInvoiceVatDate = new DateTime(2024, 2, 1);

        // Act
        var @event = new SubscriptionOrderInvoiceInfoUpdatedEvent(
            id: "billing-item-1",
            orderNumber: "ORDER-001",
            latestInvoiceVatDate: latestInvoiceVatDate,
            latestInvoiceAccrualDateFrom: latestInvoiceAccrualFrom,
            latestInvoiceAccrualDateTo: latestInvoiceAccrualTo,
            orderInvoiceCount: 2,
            orderFirstInvoiceVatDate: orderFirstInvoiceVatDate,
            orderLastInvoiceVatDate: orderLastInvoiceVatDate);

        // Assert
        @event.Id.ShouldBe("billing-item-1");
        @event.OrderNumber.ShouldBe("ORDER-001");
        @event.LatestInvoiceVatDate.ShouldBe(latestInvoiceVatDate);
        @event.LatestInvoiceAccrualDateFrom.ShouldBe(latestInvoiceAccrualFrom);
        @event.LatestInvoiceAccrualDateTo.ShouldBe(latestInvoiceAccrualTo);
        @event.OrderInvoiceCount.ShouldBe(2);
        @event.OrderFirstInvoiceVatDate.ShouldBe(orderFirstInvoiceVatDate);
        @event.OrderLastInvoiceVatDate.ShouldBe(orderLastInvoiceVatDate);
    }

    /// <summary>
    /// Tests that SubscriptionOrderInvoiceInfoUpdatedEvent accepts null values.
    /// </summary>
    [Fact]
    public void SubscriptionOrderInvoiceInfoUpdatedEvent_AcceptsNullValues()
    {
        // Arrange & Act
        var @event = new SubscriptionOrderInvoiceInfoUpdatedEvent(
            id: "billing-item-1",
            orderNumber: "ORDER-001",
            latestInvoiceVatDate: null,
            latestInvoiceAccrualDateFrom: null,
            latestInvoiceAccrualDateTo: null,
            orderInvoiceCount: null,
            orderFirstInvoiceVatDate: null,
            orderLastInvoiceVatDate: null);

        // Assert
        @event.LatestInvoiceVatDate.ShouldBeNull();
        @event.LatestInvoiceAccrualDateFrom.ShouldBeNull();
        @event.LatestInvoiceAccrualDateTo.ShouldBeNull();
        @event.OrderInvoiceCount.ShouldBeNull();
        @event.OrderFirstInvoiceVatDate.ShouldBeNull();
        @event.OrderLastInvoiceVatDate.ShouldBeNull();
    }
}
