using System;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot;
using Shouldly;
using Xunit;

namespace ASOL.PlatformStore.Store.Domain.Tests.SubscriptionRoot;

/// <summary>
/// Contains unit tests for <see cref="SubscriptionBillingItemId"/>.
/// </summary>
public class SubscriptionBillingItemIdTests
{
    /// <summary>
    /// Tests that FromSubscriptionOrderLineAndDateFrom creates a deterministic ID.
    /// </summary>
    [Fact]
    public void FromSubscriptionOrderLineAndDateFrom_CreatesDeterministicId()
    {
        // Arrange
        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode("tenant-1", "app-1");
        var orderLineId = "order-line-123";
        var accrualDateFrom = new DateOnly(2024, 1, 15);

        // Act
        var billingItemId1 = SubscriptionBillingItemId.FromSubscriptionOrderLineAndDateFrom(subscriptionId, orderLineId, accrualDateFrom);
        var billingItemId2 = SubscriptionBillingItemId.FromSubscriptionOrderLineAndDateFrom(subscriptionId, orderLineId, accrualDateFrom);

        // Assert
        billingItemId1.Value.ShouldBe(billingItemId2.Value);
    }

    /// <summary>
    /// Tests that FromSubscriptionOrderLineAndDateFrom creates different IDs for different dates.
    /// </summary>
    [Fact]
    public void FromSubscriptionOrderLineAndDateFrom_CreatesDifferentIdsForDifferentDates()
    {
        // Arrange
        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode("tenant-1", "app-1");
        var orderLineId = "order-line-123";
        var date1 = new DateOnly(2024, 1, 15);
        var date2 = new DateOnly(2024, 2, 15);

        // Act
        var billingItemId1 = SubscriptionBillingItemId.FromSubscriptionOrderLineAndDateFrom(subscriptionId, orderLineId, date1);
        var billingItemId2 = SubscriptionBillingItemId.FromSubscriptionOrderLineAndDateFrom(subscriptionId, orderLineId, date2);

        // Assert
        billingItemId1.Value.ShouldNotBe(billingItemId2.Value);
    }

    /// <summary>
    /// Tests that FromSubscriptionOrderLineAndDateFrom creates different IDs for different order lines.
    /// </summary>
    [Fact]
    public void FromSubscriptionOrderLineAndDateFrom_CreatesDifferentIdsForDifferentOrderLines()
    {
        // Arrange
        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode("tenant-1", "app-1");
        var orderLineId1 = "order-line-123";
        var orderLineId2 = "order-line-456";
        var accrualDateFrom = new DateOnly(2024, 1, 15);

        // Act
        var billingItemId1 = SubscriptionBillingItemId.FromSubscriptionOrderLineAndDateFrom(subscriptionId, orderLineId1, accrualDateFrom);
        var billingItemId2 = SubscriptionBillingItemId.FromSubscriptionOrderLineAndDateFrom(subscriptionId, orderLineId2, accrualDateFrom);

        // Assert
        billingItemId1.Value.ShouldNotBe(billingItemId2.Value);
    }

    /// <summary>
    /// Tests that FromSubscriptionOrderLineAndDateFrom accepts SubscriptionId type.
    /// </summary>
    [Fact]
    public void FromSubscriptionOrderLineAndDateFrom_AcceptsSubscriptionIdType()
    {
        // Arrange
        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode("tenant-1", "app-1");
        var orderLineId = "order-line-123";
        var accrualDateFrom = new DateOnly(2024, 1, 15);

        // Act & Assert
        var billingItemId = SubscriptionBillingItemId.FromSubscriptionOrderLineAndDateFrom(subscriptionId, orderLineId, accrualDateFrom);
        billingItemId.ShouldNotBeNull();
    }

    /// <summary>
    /// Tests that FromSubscriptionOrderLineAndDateFrom accepts string type.
    /// </summary>
    [Fact]
    public void FromSubscriptionOrderLineAndDateFrom_AcceptsStringType()
    {
        // Arrange
        var subscriptionId = "subscription-id-string";
        var orderLineId = "order-line-123";
        var accrualDateFrom = new DateOnly(2024, 1, 15);

        // Act & Assert
        var billingItemId = SubscriptionBillingItemId.FromSubscriptionOrderLineAndDateFrom(subscriptionId, orderLineId, accrualDateFrom);
        billingItemId.ShouldNotBeNull();
    }

    /// <summary>
    /// Tests that FromSubscriptionOrderLineAndDateFrom throws for unsupported types.
    /// </summary>
    [Fact]
    public void FromSubscriptionOrderLineAndDateFrom_ThrowsForUnsupportedType()
    {
        // Arrange
        var subscriptionId = 12345; // Invalid type
        var orderLineId = "order-line-123";
        var accrualDateFrom = new DateOnly(2024, 1, 15);

        // Act & Assert
        Should.Throw<ArgumentException>(() =>
            SubscriptionBillingItemId.FromSubscriptionOrderLineAndDateFrom(subscriptionId, orderLineId, accrualDateFrom));
    }

    /// <summary>
    /// Tests that FromSubscriptionIdAndOrderLineId creates a deterministic ID (legacy method).
    /// </summary>
    [Fact]
    public void FromSubscriptionIdAndOrderLineId_CreatesDeterministicId()
    {
        // Arrange
        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode("tenant-1", "app-1");
        var orderLineId = "order-line-123";

        // Act
        var billingItemId1 = SubscriptionBillingItemId.FromSubscriptionIdAndOrderLineId(subscriptionId, orderLineId);
        var billingItemId2 = SubscriptionBillingItemId.FromSubscriptionIdAndOrderLineId(subscriptionId, orderLineId);

        // Assert
        billingItemId1.Value.ShouldBe(billingItemId2.Value);
    }

    /// <summary>
    /// Tests that FromSubscriptionOrderLineAndDateFrom and FromSubscriptionIdAndOrderLineId produce different IDs.
    /// </summary>
    [Fact]
    public void FromSubscriptionOrderLineAndDateFrom_ProducesDifferentIdThanLegacyMethod()
    {
        // Arrange
        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode("tenant-1", "app-1");
        var orderLineId = "order-line-123";
        var accrualDateFrom = new DateOnly(2024, 1, 15);

        // Act
        var newBillingItemId = SubscriptionBillingItemId.FromSubscriptionOrderLineAndDateFrom(subscriptionId, orderLineId, accrualDateFrom);
        var legacyBillingItemId = SubscriptionBillingItemId.FromSubscriptionIdAndOrderLineId(subscriptionId, orderLineId);

        // Assert
        newBillingItemId.Value.ShouldNotBe(legacyBillingItemId.Value);
    }
}
