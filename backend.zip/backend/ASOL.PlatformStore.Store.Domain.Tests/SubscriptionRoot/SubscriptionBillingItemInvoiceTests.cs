using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Localization;
using ASOL.PlatformStore.Order.Contracts.Primitives;
using ASOL.PlatformStore.Store.Contracts.Subscription;
using ASOL.PlatformStore.Store.Contracts.Subscription.Enums;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Enums;
using EventFlow;
using EventFlow.Aggregates;
using Microsoft.Extensions.DependencyInjection;
using Shouldly;
using Xunit;

namespace ASOL.PlatformStore.Store.Domain.Tests.SubscriptionRoot;

/// <summary>
/// Contains unit tests for subscription billing item invoice-related commands.
/// </summary>
public class SubscriptionBillingItemInvoiceTests : SubscriptionTestBase
{
    /// <summary>
    /// Tests that SubscriptionBillingItemInvoiceGeneratedCommand emits correct event and creates next billing item for recurring billing.
    /// </summary>
    [Fact]
    public async Task SubscriptionBillingItemInvoiceGeneratedCommand_EmitsEventAndCreatesNextBillingItemForRecurring()
    {
        // Arrange
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var orderModel = CreateSampleSubscriptionOrder();
        var subscriptionId = await CreateAndActivateSubscriptionAsync(commandBus, orderModel);

        // Get first recurring order line
        var recurringOrderLine = orderModel.OrderLines.FirstOrDefault(l => 
            l.OrderLineType == "SalesItem" && 
            !string.IsNullOrEmpty(l.BillingPeriodCode) && 
            l.BillingPeriodCode != "OneTime");
        
        recurringOrderLine.ShouldNotBeNull();

        var accrualDateFrom = new DateOnly(2024, 1, 1);
        var accrualDateTo = new DateOnly(2024, 1, 31);

        var invoiceGeneratedCommand = new SubscriptionBillingItemInvoiceGeneratedCommand(
            subscriptionId,
            orderModel.OrderNumber,
            recurringOrderLine.OrderLineId,
            accrualDateFrom,
            accrualDateTo);

        // Act
        var result = await commandBus.PublishAsync(invoiceGeneratedCommand, CancellationToken.None);

        // Assert
        result.IsSuccess.ShouldBeTrue();
        
        var aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        aggregate.ShouldNotBeNull();
    }

    /// <summary>
    /// Tests that SubscriptionBillingItemInvoiceGeneratedCommand handles forward billing correctly.
    /// </summary>
    [Fact]
    public async Task SubscriptionBillingItemInvoiceGeneratedCommand_HandlesForwardBillingCorrectly()
    {
        // Arrange
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();

        var orderModel = CreateSampleSubscriptionOrder();
        
        // Find a forward billing order line (MonthlyForward)
        var forwardBillingLine = orderModel.OrderLines.FirstOrDefault(l => 
            l.OrderLineType == "SalesItem" && 
            l.BillingPeriodCode == "MonthlyForward");

        if (forwardBillingLine == null)
        {
            // Add one if it doesn't exist
            forwardBillingLine = new SubscriptionOrderLine
            {
                OrderLineId = Guid.NewGuid().ToString(),
                OrderLineType = "SalesItem",
                ProductId = "test-product-id",
                ProductCode = "TEST-FORWARD",
                ProductName = new LocalizedValue<string>(("en-US", "Test Forward Product")),
                BillingPeriodCode = "MonthlyForward",
                BasePrice = 100m,
                LicenceCount = 1
            };
            orderModel.OrderLines.Add(forwardBillingLine);
        }

        var subscriptionId = await CreateAndActivateSubscriptionAsync(commandBus, orderModel);

        var accrualDateFrom = new DateOnly(2024, 1, 1);
        var accrualDateTo = new DateOnly(2024, 1, 31);

        var command = new SubscriptionBillingItemInvoiceGeneratedCommand(
            subscriptionId,
            orderModel.OrderNumber,
            forwardBillingLine.OrderLineId,
            accrualDateFrom,
            accrualDateTo);

        // Act
        var result = await commandBus.PublishAsync(command, CancellationToken.None);

        // Assert
        result.IsSuccess.ShouldBeTrue();
    }

    /// <summary>
    /// Tests that SubscriptionBillingItemInvoiceGeneratedCommand does not create next item for OneTime billing.
    /// </summary>
    [Fact]
    public async Task SubscriptionBillingItemInvoiceGeneratedCommand_DoesNotCreateNextItemForOneTime()
    {
        // Arrange
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();

        var orderModel = CreateSampleSubscriptionOrder();
        
        // Add a OneTime billing line
        var oneTimeLine = new SubscriptionOrderLine
        {
            OrderLineId = Guid.NewGuid().ToString(),
            OrderLineType = "SalesItem",
            ProductId = "test-product-id",
            ProductCode = "TEST-ONETIME",
            ProductName = new LocalizedValue<string>(("en-US", "Test OneTime Product")),
            BillingPeriodCode = "OneTime",
            BasePrice = 500m,
            LicenceCount = 1
        };
        orderModel.OrderLines.Add(oneTimeLine);

        var subscriptionId = await CreateAndActivateSubscriptionAsync(commandBus, orderModel);

        var accrualDateFrom = new DateOnly(2024, 1, 1);
        var accrualDateTo = new DateOnly(2024, 1, 1);

        var command = new SubscriptionBillingItemInvoiceGeneratedCommand(
            subscriptionId,
            orderModel.OrderNumber,
            oneTimeLine.OrderLineId,
            accrualDateFrom,
            accrualDateTo);

        // Act
        var result = await commandBus.PublishAsync(command, CancellationToken.None);

        // Assert
        result.IsSuccess.ShouldBeTrue();
    }

    /// <summary>
    /// Tests that SubscriptionBillingItemInvoiceGeneratedCommand fails when order is not found.
    /// </summary>
    [Fact]
    public async Task SubscriptionBillingItemInvoiceGeneratedCommand_FailsWhenOrderNotFound()
    {
        // Arrange
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();

        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode("test-tenant", "test-app");
        var command = new SubscriptionBillingItemInvoiceGeneratedCommand(
            subscriptionId,
            "non-existent-order",
            "order-line-id",
            new DateOnly(2024, 1, 1),
            new DateOnly(2024, 1, 31));

        // Act
        var result = await commandBus.PublishAsync(command, CancellationToken.None);

        // Assert
        result.IsSuccess.ShouldBeFalse();
    }

    /// <summary>
    /// Tests that SubscriptionBillingItemInvoiceGeneratedCommand fails when order line is not found.
    /// </summary>
    [Fact]
    public async Task SubscriptionBillingItemInvoiceGeneratedCommand_FailsWhenOrderLineNotFound()
    {
        // Arrange
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();

        var orderModel = CreateSampleSubscriptionOrder();
        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode(orderModel.TenantId, orderModel.ApplicationCode);

        await commandBus.PublishAsync(SubscriptionOrderUpdateCommand.Create(subscriptionId, orderModel), CancellationToken.None);

        var command = new SubscriptionBillingItemInvoiceGeneratedCommand(
            subscriptionId,
            orderModel.OrderNumber,
            "non-existent-order-line-id",
            new DateOnly(2024, 1, 1),
            new DateOnly(2024, 1, 31));

        // Act
        var result = await commandBus.PublishAsync(command, CancellationToken.None);

        // Assert
        result.IsSuccess.ShouldBeFalse();
    }

    /// <summary>
    /// Tests that SubscriptionBillingItemInvoiceDeletedCommand emits correct event.
    /// </summary>
    [Fact]
    public async Task SubscriptionBillingItemInvoiceDeletedCommand_EmitsEvent()
    {
        // Arrange
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var orderModel = CreateSampleSubscriptionOrder();
        var subscriptionId = await CreateAndActivateSubscriptionAsync(commandBus, orderModel);

        var salesItemLine = orderModel.OrderLines.First(l => l.OrderLineType == "SalesItem");
        var accrualDateFrom = new DateOnly(2024, 1, 1);
        var accrualDateTo = new DateOnly(2024, 1, 31);

        var command = new SubscriptionBillingItemInvoiceDeletedCommand(
            subscriptionId,
            orderModel.OrderNumber,
            salesItemLine.OrderLineId,
            accrualDateFrom,
            accrualDateTo);

        // Act
        var result = await commandBus.PublishAsync(command, CancellationToken.None);

        // Assert
        result.IsSuccess.ShouldBeTrue();
        
        var aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        aggregate.ShouldNotBeNull();
    }

    /// <summary>
    /// Tests that SubscriptionBillingItemInvoiceDeletedCommand fails when order is not found.
    /// </summary>
    [Fact]
    public async Task SubscriptionBillingItemInvoiceDeletedCommand_FailsWhenOrderNotFound()
    {
        // Arrange
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();

        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode("test-tenant", "test-app");
        var command = new SubscriptionBillingItemInvoiceDeletedCommand(
            subscriptionId,
            "non-existent-order",
            "order-line-id",
            new DateOnly(2024, 1, 1),
            new DateOnly(2024, 1, 31));

        // Act
        var result = await commandBus.PublishAsync(command, CancellationToken.None);

        // Assert
        result.IsSuccess.ShouldBeFalse();
    }

    /// <summary>
    /// Tests that SubscriptionBillingItemInvoiceDeletedCommand fails when order line is not found.
    /// </summary>
    [Fact]
    public async Task SubscriptionBillingItemInvoiceDeletedCommand_FailsWhenOrderLineNotFound()
    {
        // Arrange
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();

        var orderModel = CreateSampleSubscriptionOrder();
        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode(orderModel.TenantId, orderModel.ApplicationCode);

        await commandBus.PublishAsync(SubscriptionOrderUpdateCommand.Create(subscriptionId, orderModel), CancellationToken.None);

        var command = new SubscriptionBillingItemInvoiceDeletedCommand(
            subscriptionId,
            orderModel.OrderNumber,
            "non-existent-order-line-id",
            new DateOnly(2024, 1, 1),
            new DateOnly(2024, 1, 31));

        // Act
        var result = await commandBus.PublishAsync(command, CancellationToken.None);

        // Assert
        result.IsSuccess.ShouldBeFalse();
    }

    /// <summary>
    /// Tests that SubscriptionBillingItemInvoiceGeneratedCommand handles backward billing correctly.
    /// </summary>
    [Fact]
    public async Task SubscriptionBillingItemInvoiceGeneratedCommand_HandlesBackwardBillingCorrectly()
    {
        // Arrange
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();

        var orderModel = CreateSampleSubscriptionOrder();
        
        // Add a backward billing line
        var backwardBillingLine = new SubscriptionOrderLine
        {
            OrderLineId = Guid.NewGuid().ToString(),
            OrderLineType = "SalesItem",
            ProductId = "test-product-id",
            ProductCode = "TEST-BACKWARD",
            ProductName = new LocalizedValue<string>(("en-US", "Test Backward Product")),
            BillingPeriodCode = "MonthlyBackward",
            BasePrice = 100m,
            LicenceCount = 1
        };
        orderModel.OrderLines.Add(backwardBillingLine);

        var subscriptionId = await CreateAndActivateSubscriptionAsync(commandBus, orderModel);

        var accrualDateFrom = new DateOnly(2024, 1, 1);
        var accrualDateTo = new DateOnly(2024, 1, 31);

        var command = new SubscriptionBillingItemInvoiceGeneratedCommand(
            subscriptionId,
            orderModel.OrderNumber,
            backwardBillingLine.OrderLineId,
            accrualDateFrom,
            accrualDateTo);

        // Act
        var result = await commandBus.PublishAsync(command, CancellationToken.None);

        // Assert
        result.IsSuccess.ShouldBeTrue();
    }

    /// <summary>
    /// Creates a sample <see cref="SubscriptionOrder"/> for use in tests.
    /// </summary>
    private static SubscriptionOrder CreateSampleSubscriptionOrder()
    {
        return new SubscriptionOrder(SubscriptionOrderId.New)
        {
            TenantId = "test-tenant-id",
            OrderId = "test-order-id",
            OrderNumber = "202501150001",
            PackageProductId = "package-product-id",
            PackageName = new LocalizedValue<string>(("en-US", "Test Package")),
            PackageShortDescription = new LocalizedValue<string>(("en-US", "Test Description")),
            ApplicationProductId = "app-product-id",
            ApplicationName = new LocalizedValue<string>(("en-US", "Test App")),
            ApplicationCode = "test-app-code",
            EditionProductId = "edition-product-id",
            EditionName = new LocalizedValue<string>(("en-US", "Test Edition")),
            OrderDate = DateTime.UtcNow,
            OrderLines =
            [
                new()
                {
                    OrderLineId = "sales-item-1",
                    OrderLineType = "SalesItem",
                    ProductId = "product-1",
                    ProductCode = "PROD-001",
                    ProductName = new LocalizedValue<string>(("en-US", "Product 1")),
                    BillingPeriodCode = "MonthlyForward",
                    BasePrice = 100m,
                    LicenceCount = 5
                }
            ]
        };
    }

    /// <summary>
    /// Helper method to create and activate a subscription for testing.
    /// </summary>
    private static async Task<SubscriptionId> CreateAndActivateSubscriptionAsync(
        ICommandBus commandBus,
        SubscriptionOrder orderModel)
    {
        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode(orderModel.TenantId, orderModel.ApplicationCode);

        // Create subscription with order
        await commandBus.PublishAsync(SubscriptionOrderUpdateCommand.Create(subscriptionId, orderModel), CancellationToken.None);
        
        // Set order as main order
        await commandBus.PublishAsync(new SubscriptionProgressUpdateCommand(
            subscriptionId,
            SubscriptionProgressType.OrderAssigned,
            orderModel.OrderNumber), CancellationToken.None);

        // Set order status to Done
        await commandBus.PublishAsync(new SubscriptionOrderStatusUpdateCommand(
            subscriptionId,
            orderModel.OrderId,
            orderModel.OrderNumber,
            OrderSystemStatus.Done), CancellationToken.None);

        // Activate subscription
        await commandBus.PublishAsync(new SubscriptionSolutionStatusUpdateCommand(
            subscriptionId,
            SubscriptionSolutionStatusUpdateSource.System,
            nameof(SubscriptionSolutionStatus.Active),
            DateOnly.FromDateTime(DateTime.UtcNow),
            null,
            "System",
            DateTime.UtcNow), CancellationToken.None);

        return subscriptionId;
    }
}
