using ASOL.PlatformStore.Store.Domain.SubscriptionRoot;
using Shouldly;
using Xunit;

namespace ASOL.PlatformStore.Store.Domain.Tests.SubscriptionRoot;

public class SubscriptionIdTests
{
    [Fact]
    public void FromTenantAndApplicationCode_ReturnsDeterministicId()
    {
        // Arrange
        var tenantId = "tenant-1";
        var applicationCode = "app-1";

        // Act
        var id1 = SubscriptionId.FromTenantAndApplicationCode(tenantId, applicationCode);
        var id2 = SubscriptionId.FromTenantAndApplicationCode(tenantId, applicationCode);

        // Assert
        id1.ShouldBe(id2);
        string.IsNullOrWhiteSpace(id1.Value).ShouldBeFalse();
    }

    [Fact]
    public void FromTenantAndApplicationCode_DifferentInputs_ProduceDifferentIds()
    {
        // Arrange
        var tenantId1 = "tenant-1";
        var tenantId2 = "tenant-2";
        var applicationCode = "app-1";

        // Act
        var id1 = SubscriptionId.FromTenantAndApplicationCode(tenantId1, applicationCode);
        var id2 = SubscriptionId.FromTenantAndApplicationCode(tenantId2, applicationCode);

        // Assert
        id1.ShouldNotBe(id2);
    }

    [Fact]
    public void SubscriptionId_Value_IsNotNullOrWhiteSpace()
    {
        // Arrange
        var tenantId = "tenant-1";
        var applicationCode = "app-1";

        // Act
        var id = SubscriptionId.FromTenantAndApplicationCode(tenantId, applicationCode);

        // Assert
        string.IsNullOrWhiteSpace(id.Value).ShouldBeFalse();
    }
}
