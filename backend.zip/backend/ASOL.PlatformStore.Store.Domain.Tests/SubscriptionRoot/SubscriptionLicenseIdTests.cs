using System;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot;
using Shouldly;
using Xunit;

namespace ASOL.PlatformStore.Store.Domain.Tests.SubscriptionRoot;

public class SubscriptionLicenseIdTests
{
    private const string ValidSubscriptionId = "subscription-123e4567-e89b-12d3-a456-426614174000";
    private const string RoleCode = "ADMIN";
    private const string OrderNumber = "ORD-456";

    [Fact]
    public void FromSubscriptionIdRoleCodeAndOrderNumber_SystemOrder_CreatesDeterministicId()
    {
        // Arrange
        var orderRef = OrderNumberReference.System(OrderNumber);

        // Act
        var id1 = SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(ValidSubscriptionId, RoleCode, orderRef);
        var id2 = SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(ValidSubscriptionId, RoleCode, orderRef);

        // Assert
        id1.ShouldNotBeNull();
        id2.ShouldNotBeNull();
        id1.Value.ShouldBe(id2.Value);
    }

    [Fact]
    public void FromSubscriptionIdRoleCodeAndOrderNumber_NonSystemOrder_CreatesDeterministicId()
    {
        // Arrange
        var orderRef = OrderNumberReference.NonSystem(OrderNumber);

        // Act
        var id1 = SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(ValidSubscriptionId, RoleCode, orderRef);
        var id2 = SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(ValidSubscriptionId, RoleCode, orderRef);

        // Assert
        id1.ShouldNotBeNull();
        id2.ShouldNotBeNull();
        id1.Value.ShouldBe(id2.Value);
    }

    [Fact]
    public void FromSubscriptionIdRoleCodeAndOrderNumber_SubscriptionIdObject_Works()
    {
        // Arrange
        var subscriptionId = new SubscriptionId(ValidSubscriptionId);
        var orderRef = OrderNumberReference.NonSystem(OrderNumber);

        // Act
        var id = SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(subscriptionId, RoleCode, orderRef);

        // Assert
        id.ShouldNotBeNull();
    }

    [Fact]
    public void FromSubscriptionIdRoleCodeAndOrderNumber_ThrowsOnNullOrderNumberReference()
    {
        // Act & Assert
        Should.Throw<ArgumentNullException>(() =>
            SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(ValidSubscriptionId, RoleCode, null!));
    }

    [Fact]
    public void FromSubscriptionIdRoleCodeAndOrderNumber_ThrowsOnEmptyOrderNumber_WhenNotSystem()
    {
        // Arrange
        var orderRef = OrderNumberReference.NonSystem("");

        // Act & Assert
        Should.Throw<ArgumentException>(() =>
            SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(ValidSubscriptionId, RoleCode, orderRef));
    }

    [Fact]
    public void FromSubscriptionIdRoleCodeAndOrderNumber_ThrowsOnUnsupportedSubscriptionIdType()
    {
        // Arrange
        var orderRef = OrderNumberReference.NonSystem(OrderNumber);

        // Act & Assert
        Should.Throw<ArgumentException>(() =>
            SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(123, RoleCode, orderRef));
    }
}
