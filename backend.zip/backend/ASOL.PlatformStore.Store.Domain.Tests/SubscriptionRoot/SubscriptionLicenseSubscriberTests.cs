using System;
using System.Threading;
using System.Threading.Tasks;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Events;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Publishers;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Subscribers;
using EventFlow.Aggregates;
using Moq;
using Xunit;

namespace ASOL.PlatformStore.Store.Domain.Tests.SubscriptionRoot;

public class SubscriptionLicenseSubscriberTests
{
    [Fact]
    public async Task HandleAsync_WhenSubscriptionLicenseCreatedEventIsReceived_PublishesEventViaPublisher()
    {
        // Arrange
        var publisherMock = new Mock<ISubscriptionLicenseEventPublisher>();
        var subscriber = new SubscriptionLicenseCreatedSubscriber(publisherMock.Object);

        var @event = new SubscriptionLicenseCreatedEvent(
            tenantId: "tenant",
            subscriptionLicenseId: SubscriptionLicenseId.New,
            orderLineId: "line",
            orderNumber: "order",
            packageCode: "pkg",
            packageName: null,
            applicationCode: "app",
            editionCode: null,
            subscriptionCode: "sub",
            salesItemCode: "sales",
            roleCode: "role",
            validFrom: null,
            validTo: null,
            status: null,
            userMaxCount: null
        );

        var domainEventMock = new Mock<IDomainEvent<Subscription, SubscriptionId, SubscriptionLicenseCreatedEvent>>();
        _ = domainEventMock.SetupGet(x => x.AggregateEvent).Returns(@event);

        // Act
        await subscriber.HandleAsync(domainEventMock.Object, CancellationToken.None);

        // Assert
        publisherMock.Verify(x => x.PublishSubscriptionLicenseCreatedAsync(@event, It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task HandleAsync_WhenSubscriptionLicenseUpdatedEventIsReceived_PublishesEventViaPublisher()
    {
        // Arrange
        var publisherMock = new Mock<ISubscriptionLicenseEventPublisher>();
        var subscriber = new SubscriptionLicenseUpdatedSubscriber(publisherMock.Object);

        var @event = new SubscriptionLicenseUpdatedEvent(
            tenantId: "tenant",
            subscriptionLicenseId: SubscriptionLicenseId.New,
            validFrom: null,
            validTo: null,
            status: null
        );

        var domainEventMock = new Mock<IDomainEvent<Subscription, SubscriptionId, SubscriptionLicenseUpdatedEvent>>();
        _ = domainEventMock.SetupGet(x => x.AggregateEvent).Returns(@event);

        // Act
        await subscriber.HandleAsync(domainEventMock.Object, CancellationToken.None);

        // Assert
        publisherMock.Verify(x => x.PublishSubscriptionLicenseUpdatedAsync(@event, It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task HandleAsync_WhenSubscriptionLicenseStatusUpdatedEventIsReceived_PublishesEventViaPublisher()
    {
        // Arrange
        var publisherMock = new Mock<ISubscriptionLicenseEventPublisher>();
        var subscriber = new SubscriptionLicenseStatusUpdatedSubscriber(publisherMock.Object);

        var @event = new SubscriptionLicenseStatusUpdatedEvent(
            subscriptionLicenseId: SubscriptionLicenseId.New,
            status: LicenseSystemStatus.Done
        );

        var domainEventMock = new Mock<IDomainEvent<Subscription, SubscriptionId, SubscriptionLicenseStatusUpdatedEvent>>();
        _ = domainEventMock.SetupGet(x => x.AggregateEvent).Returns(@event);

        // Act
        await subscriber.HandleAsync(domainEventMock.Object, CancellationToken.None);

        // Assert
        publisherMock.Verify(x => x.PublishSubscriptionLicenseStatusUpdatedAsync(@event, It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task HandleAsync_WhenSubscriptionLicenseDeletedEventIsReceived_PublishesEventViaPublisher()
    {
        // Arrange
        var publisherMock = new Mock<ISubscriptionLicenseEventPublisher>();
        var subscriber = new SubscriptionLicenseDeletedSubscriber(publisherMock.Object);

        var @event = new SubscriptionLicenseDeletedEvent(
            subscriptionLicenseId: SubscriptionLicenseId.New
        );

        var domainEventMock = new Mock<IDomainEvent<Subscription, SubscriptionId, SubscriptionLicenseDeletedEvent>>();
        _ = domainEventMock.SetupGet(x => x.AggregateEvent).Returns(@event);

        // Act
        await subscriber.HandleAsync(domainEventMock.Object, CancellationToken.None);

        // Assert
        publisherMock.Verify(x => x.PublishSubscriptionLicenseDeletedAsync(@event, It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task HandleAsync_WhenSubscriptionLicenseTerminatedEventIsReceived_PublishesEventViaPublisher()
    {
        // Arrange
        var publisherMock = new Mock<ISubscriptionLicenseEventPublisher>();
        var subscriber = new SubscriptionLicenseTerminatedSubscriber(publisherMock.Object);

        var @event = new SubscriptionLicenseTerminatedEvent(
            subscriptionLicenseId: SubscriptionLicenseId.New,
            terminationDate: DateOnly.FromDateTime(DateTime.UtcNow.AddDays(7))
        );

        var domainEventMock = new Mock<IDomainEvent<Subscription, SubscriptionId, SubscriptionLicenseTerminatedEvent>>();
        _ = domainEventMock.SetupGet(x => x.AggregateEvent).Returns(@event);

        // Act
        await subscriber.HandleAsync(domainEventMock.Object, CancellationToken.None);

        // Assert
        publisherMock.Verify(x => x.PublishSubscriptionLicenseTerminatedAsync(@event, It.IsAny<CancellationToken>()), Times.Once);
    }
}
