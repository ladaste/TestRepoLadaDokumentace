using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Identity.Contexts;
using ASOL.Core.Localization;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Events;
using EventFlow;
using EventFlow.Aggregates;
using EventFlow.EventStores;
using Microsoft.Extensions.DependencyInjection;
using Shouldly;
using Xunit;

namespace ASOL.PlatformStore.Store.Domain.Tests.SubscriptionRoot;

public class SubscriptionLicenseTests : SubscriptionTestBase
{
    /// <summary>
    /// Tests that <see cref="SubscriptionLicenseCreateCommand"/> emits the correct event and creates the license in the aggregate.
    /// </summary>
    [Fact]
    public async Task SubscriptionLicenseCreateCommand_EmitsEventAndCreatesLicense()
    {
        // Arrange
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var eventStore = serviceProvider.GetRequiredService<IEventStore>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var tenantId = "test-tenant-id";
        var applicationCode = "APP-CODE";
        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode(tenantId, applicationCode);

        var packageName = new LocalizedValue<string>(("en-US", "Test Package"));
        var validFrom = DateOnly.FromDateTime(DateTime.UtcNow);
        var validTo = validFrom.AddYears(2);

        var orderNumber = "ORD-001";
        var orderLineId = "order-line-1";
        var packageCode = "PKG-CODE";
        var editionCode = "ED-CODE";
        var subscriptionCode = "SUB-CODE";
        var salesItemCode = "SALES-ITEM-CODE";
        var roleCode = "ROLE-CODE";
        var userMaxCount = 10;

        var licenseId = SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(subscriptionId, roleCode, new OrderNumberReference(orderNumber, false));

        var command = new SubscriptionLicenseCreateCommand(
            subscriptionId,
            licenseId,
            orderLineId,
            orderNumber,
            packageCode,
            packageName,
            applicationCode,
            editionCode,
            subscriptionCode,
            salesItemCode,
            roleCode,
            validFrom,
            validTo,
            LicenseSystemStatus.Validation,
            userMaxCount
        );

        // Act
        var result = await commandBus.PublishAsync(command, CancellationToken.None);

        // Assert (event emitted)
        result.IsSuccess.ShouldBeTrue();
        var events = await eventStore.LoadEventsAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        events.ShouldNotBeEmpty();
        events.ShouldContain(e => e is IDomainEvent<Subscription, SubscriptionId, SubscriptionLicenseCreatedEvent>);

        // Assert (aggregate updated)
        var aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        var license = aggregate.Licenses.ShouldHaveSingleItem();
        license.OrderLineId.ShouldBe(orderLineId);
        license.OrderNumber.ShouldBe(orderNumber);
        license.PackageCode.ShouldBe(packageCode);
        license.PackageName.Translate(LocalizationContext.DefaultLanguageCode, null).ShouldBe(packageName.Translate(LocalizationContext.DefaultLanguageCode, null));
        license.ApplicationCode.ShouldBe(applicationCode);
        license.EditionCode.ShouldBe(editionCode);
        license.SubscriptionCode.ShouldBe(subscriptionCode);
        license.SalesItemCode.ShouldBe(salesItemCode);
        license.RoleCode.ShouldBe(roleCode);
        license.ValidFrom.ShouldBe(validFrom);
        license.ValidTo.ShouldBe(validTo);
        license.Status.ShouldBe(LicenseSystemStatus.Validation);
        license.UserMaxCount.ShouldBe(userMaxCount);
    }

    /// <summary>
    /// Tests that multiple <see cref="SubscriptionLicenseCreateCommand"/> calls add multiple licenses.
    /// </summary>
    [Fact]
    public async Task SubscriptionLicenseCreateCommand_CanAddMultipleLicenses()
    {
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode("test-tenant-id", "test-application-code");
        var validFrom = DateOnly.FromDateTime(DateTime.UtcNow);
        var validTo = validFrom.AddYears(1);

        var command1 = new SubscriptionLicenseCreateCommand(
            subscriptionId,
            SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(subscriptionId, "ROLE-CODE-1", new OrderNumberReference("ORD-001", false)),
            "order-line-1",
            "ORD-001",
            "PKG-CODE-1",
            new LocalizedValue<string>(("en-US", "Package 1")),
            "APP-CODE-1",
            "ED-CODE-1",
            "SUB-CODE-1",
            "SALES-ITEM-CODE-1",
            "ROLE-CODE-1",
            validFrom,
            validTo,
            LicenseSystemStatus.Validation,
            10
        );

        var command2 = new SubscriptionLicenseCreateCommand(
            subscriptionId,
            SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(subscriptionId, "ROLE-CODE-2", new OrderNumberReference("ORD-002", false)),
            "order-line-2",
            "ORD-002",
            "PKG-CODE-2",
            new LocalizedValue<string>(("en-US", "Package 2")),
            "APP-CODE-2",
            "ED-CODE-2",
            "SUB-CODE-2",
            "SALES-ITEM-CODE-2",
            "ROLE-CODE-2",
            validFrom,
            validTo,
            LicenseSystemStatus.Validation,
            10
        );

        var result1 = await commandBus.PublishAsync(command1, CancellationToken.None);
        var result2 = await commandBus.PublishAsync(command2, CancellationToken.None);
        result1.IsSuccess.ShouldBeTrue();
        result2.IsSuccess.ShouldBeTrue();

        var aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        aggregate.Licenses.Count.ShouldBe(2);
        aggregate.Licenses.ShouldContain(l => l.OrderLineId == "order-line-1");
        aggregate.Licenses.ShouldContain(l => l.OrderLineId == "order-line-2");
    }

    /// <summary>
    /// Tests that <see cref="SubscriptionLicenseCreateCommand"/> allows null ValidFrom or ValidTo.
    /// </summary>
    [Fact]
    public async Task SubscriptionLicenseCreateCommand_AllowsNullValidFromOrValidTo()
    {
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode("test-tenant-id", "test-application-code");
        var validFrom = DateOnly.FromDateTime(DateTime.UtcNow);
        var validTo = validFrom.AddYears(1);

        // 1) validFrom == null, validTo != null
        var commandNullValidFrom = new SubscriptionLicenseCreateCommand(
            subscriptionId,
            SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(subscriptionId, "ROLE-NULL-VALIDFROM", new OrderNumberReference("ORD-NULL-VALIDFROM", false)),
            "order-line-null-validfrom",
            "ORD-NULL-VALIDFROM",
            "PKG-NULL-VALIDFROM",
            new LocalizedValue<string>(("en-US", "Package Null ValidFrom")),
            "APP-NULL-VALIDFROM",
            "ED-NULL-VALIDFROM",
            "SUB-NULL-VALIDFROM",
            "SALES-NULL-VALIDFROM",
            "ROLE-NULL-VALIDFROM",
            null,
            validTo,
            LicenseSystemStatus.Validation,
            10
        );
        var resultNullValidFrom = await commandBus.PublishAsync(commandNullValidFrom, CancellationToken.None);
        resultNullValidFrom.IsSuccess.ShouldBeTrue();
        var aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        var licenseNullValidFrom = aggregate.Licenses.FirstOrDefault(l => l.OrderLineId == "order-line-null-validfrom");
        licenseNullValidFrom.ShouldNotBeNull();
        licenseNullValidFrom!.ValidFrom.ShouldBeNull();
        licenseNullValidFrom.ValidTo.ShouldBe(validTo);

        // 2) validFrom != null, validTo == null
        var commandNullValidTo = new SubscriptionLicenseCreateCommand(
            subscriptionId,
            SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(subscriptionId, "ROLE-NULL-VALIDTO", new OrderNumberReference("ORD-NULL-VALIDTO", false)),
            "order-line-null-validto",
            "ORD-NULL-VALIDTO",
            "PKG-NULL-VALIDTO",
            new LocalizedValue<string>(("en-US", "Package Null ValidTo")),
            "APP-NULL-VALIDTO",
            "ED-NULL-VALIDTO",
            "SUB-NULL-VALIDTO",
            "SALES-NULL-VALIDTO",
            "ROLE-NULL-VALIDTO",
            validFrom,
            null,
            LicenseSystemStatus.Validation,
            10
        );
        var resultNullValidTo = await commandBus.PublishAsync(commandNullValidTo, CancellationToken.None);
        resultNullValidTo.IsSuccess.ShouldBeTrue();
        aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        var licenseNullValidTo = aggregate.Licenses.FirstOrDefault(l => l.OrderLineId == "order-line-null-validto");
        licenseNullValidTo.ShouldNotBeNull();
        licenseNullValidTo!.ValidFrom.ShouldBe(validFrom);
        licenseNullValidTo.ValidTo.ShouldBeNull();

        // 3) validFrom == null, validTo == null
        var commandNullBoth = new SubscriptionLicenseCreateCommand(
            subscriptionId,
            SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(subscriptionId, "ROLE-NULL-BOTH", new OrderNumberReference("ORD-NULL-BOTH", false)),
            "order-line-null-both",
            "ORD-NULL-BOTH",
            "PKG-NULL-BOTH",
            new LocalizedValue<string>(("en-US", "Package Null Both")),
            "APP-NULL-BOTH",
            "ED-NULL-BOTH",
            "SUB-NULL-BOTH",
            "SALES-NULL-BOTH",
            "ROLE-NULL-BOTH",
            null,
            null,
            LicenseSystemStatus.Validation,
            10
        );
        var resultNullBoth = await commandBus.PublishAsync(commandNullBoth, CancellationToken.None);
        resultNullBoth.IsSuccess.ShouldBeTrue();
        aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        var licenseNullBoth = aggregate.Licenses.FirstOrDefault(l => l.OrderLineId == "order-line-null-both");
        licenseNullBoth.ShouldNotBeNull();
        licenseNullBoth!.ValidFrom.ShouldBeNull();
        licenseNullBoth.ValidTo.ShouldBeNull();
    }

    /// <summary>
    /// Tests that SubscriptionLicenseCreateCommand fails when validTo is less than validFrom.
    /// </summary>
    [Fact]
    public async Task SubscriptionLicenseCreateCommand_ValidToLessThanValidFrom_Fails()
    {
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode("test-tenant-id", "test-application-code");
        var validFrom = DateOnly.FromDateTime(DateTime.UtcNow);
        var validTo = validFrom.AddDays(-1);

        var command = new SubscriptionLicenseCreateCommand(
            subscriptionId,
            SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(subscriptionId, "ROLE-INVALID", new OrderNumberReference("ORD-INVALID", false)),
            "order-line-invalid",
            "ORD-INVALID",
            "PKG-INVALID",
            new LocalizedValue<string>(("en-US", "Package Invalid")),
            "APP-INVALID",
            "ED-INVALID",
            "SUB-INVALID",
            "SALES-INVALID",
            "ROLE-INVALID",
            validFrom,
            validTo,
            LicenseSystemStatus.Validation,
            10
        );
        var result = await commandBus.PublishAsync(command, CancellationToken.None);
        result.IsSuccess.ShouldBeFalse();
    }

    /// <summary>
    /// Tests that <see cref="SubscriptionLicenseUpdateCommand"/> emits the correct event and updates the aggregate.
    /// </summary>
    [Fact]
    public async Task SubscriptionLicenseUpdateCommand_EmitsEventAndUpdatesAggregate()
    {
        // Arrange
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var eventStore = serviceProvider.GetRequiredService<IEventStore>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var tenantId = "test-tenant-id";
        var applicationCode = "test-application-code";
        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode(tenantId, applicationCode);

        var validFrom = DateOnly.FromDateTime(DateTime.UtcNow);
        var random = new Random();
        var yearsToAdd = random.Next(1, 6);
        var validTo = validFrom.AddYears(yearsToAdd);

        var licenseId = SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(subscriptionId, "ROLE-CODE", new OrderNumberReference("ORD-001", false));

        // First, create the license
        var createCommand = new SubscriptionLicenseCreateCommand(
            subscriptionId,
            licenseId,
            "order-line-1",
            "ORD-001",
            "PKG-CODE",
            new LocalizedValue<string>(("en-US", "Test Package")),
            applicationCode,
            "ED-CODE",
            "SUB-CODE",
            "SALES-ITEM-CODE",
            "ROLE-CODE",
            validFrom,
            validTo,
            LicenseSystemStatus.Validation,
            10
        );
        var createResult = await commandBus.PublishAsync(createCommand, CancellationToken.None);
        createResult.IsSuccess.ShouldBeTrue();

        // Now perform the update
        var updateValidFrom = validFrom.AddDays(1);
        var updateValidTo = validTo.AddYears(1);
        var updateStatus = LicenseSystemStatus.Done;
        var updateUserMaxCount = 20;
        var updateCommand = new SubscriptionLicenseUpdateCommand(
            subscriptionId,
            licenseId,
            updateValidFrom,
            updateValidTo,
            updateStatus,
            updateUserMaxCount);

        // Act
        var result = await commandBus.PublishAsync(updateCommand, CancellationToken.None);

        // Assert (event emitted)
        result.IsSuccess.ShouldBeTrue();
        var events = await eventStore.LoadEventsAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        events.ShouldNotBeEmpty();
        events.ShouldContain(e => e is IDomainEvent<Subscription, SubscriptionId, SubscriptionLicenseUpdatedEvent>);

        // Assert (aggregate updated)
        var aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        var license = aggregate.Licenses.ShouldHaveSingleItem();
        license.ValidFrom.ShouldBe(updateValidFrom);
        license.ValidTo.ShouldBe(updateValidTo);
        license.UserMaxCount.ShouldBe(updateUserMaxCount);
        license.Status.ShouldBe(updateStatus);
        // Check that other properties remain unchanged
        license.OrderLineId.ShouldBe(createCommand.OrderLineId);
        license.OrderNumber.ShouldBe(createCommand.OrderNumber);
        license.PackageCode.ShouldBe(createCommand.PackageCode);
        license.PackageName.Translate(LocalizationContext.DefaultLanguageCode, null).ShouldBe(createCommand.PackageName.Translate(LocalizationContext.DefaultLanguageCode, null));
        license.ApplicationCode.ShouldBe(createCommand.ApplicationCode);
        license.EditionCode.ShouldBe(createCommand.EditionCode);
        license.SubscriptionCode.ShouldBe(createCommand.SubscriptionCode);
        license.SalesItemCode.ShouldBe(createCommand.SalesItemCode);
        license.RoleCode.ShouldBe(createCommand.RoleCode);
    }

    /// <summary>
    /// Tests that multiple <see cref="SubscriptionLicenseUpdateCommand"/> calls add multiple licenses.
    /// </summary>
    [Fact]
    public async Task SubscriptionLicenseUpdateCommand_CanAddMultipleLicenses()
    {
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode("test-tenant-id", "test-application-code");
        var validFrom = DateOnly.FromDateTime(DateTime.UtcNow);
        var validTo = validFrom.AddYears(1);

        // First, create both licenses
        var licenseId1 = SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(subscriptionId, "ROLE-CODE-1", new OrderNumberReference("ORD-001", false));
        var createCommand1 = new SubscriptionLicenseCreateCommand(
            subscriptionId,
            licenseId1,
            "order-line-1",
            "ORD-001",
            "PKG-CODE-1",
            new LocalizedValue<string>(("en-US", "Package 1")),
            "APP-CODE-1",
            "ED-CODE-1",
            "SUB-CODE-1",
            "SALES-ITEM-CODE-1",
            "ROLE-CODE-1",
            validFrom,
            validTo,
            LicenseSystemStatus.Validation,
            10
        );
        var createResult1 = await commandBus.PublishAsync(createCommand1, CancellationToken.None);
        createResult1.IsSuccess.ShouldBeTrue();

        var licenseId2 = SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(subscriptionId, "ROLE-CODE-2", new OrderNumberReference("ORD-002", false));
        var createCommand2 = new SubscriptionLicenseCreateCommand(
            subscriptionId,
            licenseId2,
            "order-line-2",
            "ORD-002",
            "PKG-CODE-2",
            new LocalizedValue<string>(("en-US", "Package 2")),
            "APP-CODE-2",
            "ED-CODE-2",
            "SUB-CODE-2",
            "SALES-ITEM-CODE-2",
            "ROLE-CODE-2",
            validFrom,
            validTo,
            LicenseSystemStatus.Validation,
            10
        );
        var createResult2 = await commandBus.PublishAsync(createCommand2, CancellationToken.None);
        createResult2.IsSuccess.ShouldBeTrue();

        // Now update both licenses
        var updateCommand1 = new SubscriptionLicenseUpdateCommand(
            subscriptionId,
            licenseId1,
            validFrom.AddDays(1),
            validTo.AddYears(1),
            LicenseSystemStatus.Done,
            20);
        var updateCommand2 = new SubscriptionLicenseUpdateCommand(
            subscriptionId,
            licenseId2,
            validFrom.AddDays(2),
            validTo.AddYears(2),
            LicenseSystemStatus.Done,
            30);

        var result1 = await commandBus.PublishAsync(updateCommand1, CancellationToken.None);
        var result2 = await commandBus.PublishAsync(updateCommand2, CancellationToken.None);
        result1.IsSuccess.ShouldBeTrue();
        result2.IsSuccess.ShouldBeTrue();

        var aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        aggregate.Licenses.Count.ShouldBe(2);
        var license1 = aggregate.Licenses.First(l => l.Id == licenseId1);
        var license2 = aggregate.Licenses.First(l => l.Id == licenseId2);
        license1.ValidFrom.ShouldBe(validFrom.AddDays(1));
        license1.ValidTo.ShouldBe(validTo.AddYears(1));
        license1.Status.ShouldBe(LicenseSystemStatus.Done);
        license1.UserMaxCount.ShouldBe(20);
        license2.ValidFrom.ShouldBe(validFrom.AddDays(2));
        license2.ValidTo.ShouldBe(validTo.AddYears(2));
        license2.Status.ShouldBe(LicenseSystemStatus.Done);
        license2.UserMaxCount.ShouldBe(30);
    }

    /// <summary>
    /// Tests that <see cref="SubscriptionLicenseUpdateCommand"/> updates an existing license when LicenseId is provided.
    /// </summary>
    [Fact]
    public async Task SubscriptionLicenseUpdateCommand_UpdatesExistingLicense()
    {
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode("test-tenant-id", "test-application-code");
        var validFrom = DateOnly.FromDateTime(DateTime.UtcNow);
        var validTo = validFrom.AddYears(1);

        // First, create the license
        var licenseId = SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(subscriptionId, "ROLE-CODE-1", new OrderNumberReference("ORD-001", false));
        var createCommand = new SubscriptionLicenseCreateCommand(
            subscriptionId,
            licenseId,
            "order-line-1",
            "ORD-001",
            "PKG-CODE-1",
            new LocalizedValue<string>(("en-US", "Package 1")),
            "APP-CODE-1",
            "ED-CODE-1",
            "SUB-CODE-1",
            "SALES-ITEM-CODE-1",
            "ROLE-CODE-1",
            validFrom,
            validTo,
            LicenseSystemStatus.Validation,
            10
        );
        var createResult = await commandBus.PublishAsync(createCommand, CancellationToken.None);
        createResult.IsSuccess.ShouldBeTrue();

        // Get the created license
        var aggregateAfterCreate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        var existingLicense = aggregateAfterCreate.Licenses.First(l => l.Id == licenseId);

        // Update the license with different values and status
        var updatedStatus = LicenseSystemStatus.Done;
        var updateCommand = new SubscriptionLicenseUpdateCommand(
            subscriptionId,
            existingLicense.Id,
            validFrom.AddDays(1),
            validTo.AddYears(1),
            updatedStatus,
            20);
        var updateResult = await commandBus.PublishAsync(updateCommand, CancellationToken.None);
        updateResult.IsSuccess.ShouldBeTrue();

        var aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        aggregate.Licenses.ShouldHaveSingleItem();
        var license = aggregate.Licenses.First();
        license.ValidFrom.ShouldBe(validFrom.AddDays(1));
        license.ValidTo.ShouldBe(validTo.AddYears(1));
        license.Status.ShouldBe(updatedStatus);
        license.UserMaxCount.ShouldBe(20);
    }

    /// <summary>
    /// Tests that <see cref="SubscriptionLicenseUpdateCommand"/> allows null ValidFrom or ValidTo.
    /// </summary>
    [Fact]
    public async Task SubscriptionLicenseUpdateCommand_AllowsNullValidFromOrValidTo()
    {
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode("test-tenant-id", "test-application-code");
        var validFrom = DateOnly.FromDateTime(DateTime.UtcNow);
        var validTo = validFrom.AddYears(1);

        // 1) validFrom == null, validTo != null
        var licenseId1 = SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(subscriptionId, "ROLE-NULL-VALIDFROM", new OrderNumberReference("ORD-NULL-VALIDFROM", false));
        var createCommand1 = new SubscriptionLicenseCreateCommand(
            subscriptionId,
            licenseId1,
            "order-line-null-validfrom",
            "ORD-NULL-VALIDFROM",
            "PKG-NULL-VALIDFROM",
            new LocalizedValue<string>(("en-US", "Package Null ValidFrom")),
            "APP-NULL-VALIDFROM",
            "ED-NULL-VALIDFROM",
            "SUB-NULL-VALIDFROM",
            "SALES-NULL-VALIDFROM",
            "ROLE-NULL-VALIDFROM",
            null,
            validTo,
            LicenseSystemStatus.Validation,
            10
        );
        var createResult1 = await commandBus.PublishAsync(createCommand1, CancellationToken.None);
        createResult1.IsSuccess.ShouldBeTrue();
        var updateCommandNullValidFrom = new SubscriptionLicenseUpdateCommand(
            subscriptionId,
            licenseId1,
            null,
            validTo,
            null,
            10);
        var resultNullValidFrom = await commandBus.PublishAsync(updateCommandNullValidFrom, CancellationToken.None);
        resultNullValidFrom.IsSuccess.ShouldBeTrue();
        var aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        var licenseNullValidFrom = aggregate.Licenses.FirstOrDefault(l => l.Id == updateCommandNullValidFrom.SubscriptionLicenseId);
        licenseNullValidFrom.ShouldNotBeNull();
        licenseNullValidFrom!.ValidFrom.ShouldBeNull();
        licenseNullValidFrom.ValidTo.ShouldBe(validTo);

        // 2) validFrom != null, validTo == null
        var licenseId2 = SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(subscriptionId, "ROLE-NULL-VALIDTO", new OrderNumberReference("ORD-NULL-VALIDTO", false));
        var createCommand2 = new SubscriptionLicenseCreateCommand(
            subscriptionId,
            licenseId2,
            "order-line-null-validto",
            "ORD-NULL-VALIDTO",
            "PKG-NULL-VALIDTO",
            new LocalizedValue<string>(("en-US", "Package Null ValidTo")),
            "APP-NULL-VALIDTO",
            "ED-NULL-VALIDTO",
            "SUB-NULL-VALIDTO",
            "SALES-NULL-VALIDTO",
            "ROLE-NULL-VALIDTO",
            validFrom,
            null,
            LicenseSystemStatus.Validation,
            10
        );
        var createResult2 = await commandBus.PublishAsync(createCommand2, CancellationToken.None);
        createResult2.IsSuccess.ShouldBeTrue();
        var updateCommandNullValidTo = new SubscriptionLicenseUpdateCommand(
            subscriptionId,
            licenseId2,
            validFrom,
            null,
            null,
            10);
        var resultNullValidTo = await commandBus.PublishAsync(updateCommandNullValidTo, CancellationToken.None);
        resultNullValidTo.IsSuccess.ShouldBeTrue();
        aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        var licenseNullValidTo = aggregate.Licenses.FirstOrDefault(l => l.Id == updateCommandNullValidTo.SubscriptionLicenseId);
        licenseNullValidTo.ShouldNotBeNull();
        licenseNullValidTo!.ValidFrom.ShouldBe(validFrom);
        licenseNullValidTo.ValidTo.ShouldBeNull();

        // 3) validFrom == null, validTo == null
        var licenseId3 = SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(subscriptionId, "ROLE-NULL-BOTH", new OrderNumberReference("ORD-NULL-BOTH", false));
        var createCommand3 = new SubscriptionLicenseCreateCommand(
            subscriptionId,
            licenseId3,
            "order-line-null-both",
            "ORD-NULL-BOTH",
            "PKG-NULL-BOTH",
            new LocalizedValue<string>(("en-US", "Package Null Both")),
            "APP-NULL-BOTH",
            "ED-NULL-BOTH",
            "SUB-NULL-BOTH",
            "SALES-NULL-BOTH",
            "ROLE-NULL-BOTH",
            null,
            null,
            LicenseSystemStatus.Validation,
            10
        );
        var createResult3 = await commandBus.PublishAsync(createCommand3, CancellationToken.None);
        createResult3.IsSuccess.ShouldBeTrue();
        var updateCommandNullBoth = new SubscriptionLicenseUpdateCommand(
            subscriptionId,
            licenseId3,
            null,
            null,
            null,
            10);
        var resultNullBoth = await commandBus.PublishAsync(updateCommandNullBoth, CancellationToken.None);
        resultNullBoth.IsSuccess.ShouldBeTrue();
        aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        var licenseNullBoth = aggregate.Licenses.FirstOrDefault(l => l.Id == updateCommandNullBoth.SubscriptionLicenseId);
        licenseNullBoth.ShouldNotBeNull();
        licenseNullBoth!.ValidFrom.ShouldBeNull();
        licenseNullBoth.ValidTo.ShouldBeNull();
    }

    /// <summary>
    /// Tests that SubscriptionLicenseUpdateCommand fails when validTo is less than validFrom.
    /// </summary>
    [Fact]
    public async Task SubscriptionLicenseUpdateCommand_ValidToLessThanValidFrom_Fails()
    {
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode("test-tenant-id", "test-application-code");
        var validFrom = DateOnly.FromDateTime(DateTime.UtcNow);
        var validTo = validFrom.AddDays(-1);

        var licenseId = SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(subscriptionId, "ROLE-INVALID", new OrderNumberReference("ORD-INVALID", false));
        var command = new SubscriptionLicenseUpdateCommand(
            subscriptionId,
            licenseId,
            validFrom,
            validTo,
            null,
            10);
        var result = await commandBus.PublishAsync(command, CancellationToken.None);
        result.IsSuccess.ShouldBeFalse();
    }

    /// <summary>
    /// Tests that SubscriptionLicenseStatusUpdateCommand updates the status of an existing license.
    /// </summary>
    [Fact]
    public async Task SubscriptionLicenseStatusUpdateCommand_UpdatesLicenseStatus()
    {
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode("test-tenant-id", "test-application-code");
        var validFrom = DateOnly.FromDateTime(DateTime.UtcNow);
        var validTo = validFrom.AddYears(1);

        // First, create the license
        var orderNumber = "ORD-STATUS";
        var orderNumberReference = new OrderNumberReference(orderNumber, false);
        var licenseId = SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(subscriptionId, "ROLE-STATUS", orderNumberReference);
        var createCommand = new SubscriptionLicenseCreateCommand(
            subscriptionId,
            licenseId,
            "order-line-status",
            orderNumber,
            "PKG-STATUS",
            new LocalizedValue<string>(("en-US", "Package Status")),
            "APP-STATUS",
            "ED-STATUS",
            "SUB-STATUS",
            "SALES-ITEM-STATUS",
            "ROLE-STATUS",
            validFrom,
            validTo,
            LicenseSystemStatus.Validation,
            10
        );
        var createResult = await commandBus.PublishAsync(createCommand, CancellationToken.None);
        createResult.IsSuccess.ShouldBeTrue();

        var aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        var license = aggregate.Licenses.FirstOrDefault(l => l.OrderLineId == "order-line-status");
        license.ShouldNotBeNull();

        // Change the status
        var newStatus = LicenseSystemStatus.Done;
        var statusCommand = new SubscriptionLicenseStatusUpdateCommand(
            subscriptionId,
            license!.Id,
            newStatus
        );
        var statusResult = await commandBus.PublishAsync(statusCommand, CancellationToken.None);
        statusResult.IsSuccess.ShouldBeTrue();

        aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        license = aggregate.Licenses.FirstOrDefault(l => l.Id == license!.Id);
        license.ShouldNotBeNull();
        license!.Status.ShouldBe(newStatus);
    }

    /// <summary>
    /// Tests that SubscriptionLicenseStatusUpdateCommand allows status to be set to null.
    /// </summary>
    [Fact]
    public async Task SubscriptionLicenseStatusUpdateCommand_AllowsNullStatus()
    {
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode("test-tenant-id", "test-application-code");
        var validFrom = DateOnly.FromDateTime(DateTime.UtcNow);
        var validTo = validFrom.AddYears(1);

        // First, create the license with status
        var orderNumber = "ORD-NULL-STATUS";
        var orderNumberReference = new OrderNumberReference(orderNumber, false);
        var licenseId = SubscriptionLicenseId.FromSubscriptionIdRoleCodeAndOrderNumber(subscriptionId, "ROLE-NULL-STATUS", orderNumberReference);
        var createCommand = new SubscriptionLicenseCreateCommand(
            subscriptionId,
            licenseId,
            "order-line-null-status",
            orderNumber,
            "PKG-NULL-STATUS",
            new LocalizedValue<string>(("en-US", "Package Null Status")),
            "APP-NULL-STATUS",
            "ED-NULL-STATUS",
            "SUB-NULL-STATUS",
            "SALES-ITEM-NULL-STATUS",
            "ROLE-NULL-STATUS",
            validFrom,
            validTo,
            LicenseSystemStatus.Confirmed,
            10
        );
        var createResult = await commandBus.PublishAsync(createCommand, CancellationToken.None);
        createResult.IsSuccess.ShouldBeTrue();

        var aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        var license = aggregate.Licenses.FirstOrDefault(l => l.OrderLineId == "order-line-null-status");
        license.ShouldNotBeNull();
        license!.Status.ShouldBe(LicenseSystemStatus.Confirmed);

        // Change the status to null
        var statusCommand = new SubscriptionLicenseStatusUpdateCommand(
            subscriptionId,
            license.Id,
            null
        );
        var statusResult = await commandBus.PublishAsync(statusCommand, CancellationToken.None);
        statusResult.IsSuccess.ShouldBeTrue();

        aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        license = aggregate.Licenses.FirstOrDefault(l => l.Id == license!.Id);
        license.ShouldNotBeNull();
        license!.Status.ShouldBeNull();
    }

    /// <summary>
    /// Tests that SubscriptionLicenseStatusUpdateCommand fails for non-existing license.
    /// </summary>
    [Fact]
    public async Task SubscriptionLicenseStatusUpdateCommand_NonExistingLicense_Fails()
    {
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode("test-tenant-id", "test-application-code");
        var nonExistingLicenseId = SubscriptionLicenseId.New;
        var statusCommand = new SubscriptionLicenseStatusUpdateCommand(
            subscriptionId,
            nonExistingLicenseId,
            LicenseSystemStatus.Done
        );

        var result = await commandBus.PublishAsync(statusCommand, CancellationToken.None);
        result.IsSuccess.ShouldBeFalse();
    }
}
