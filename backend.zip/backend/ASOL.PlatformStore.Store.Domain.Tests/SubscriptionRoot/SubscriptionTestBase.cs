using System.Collections.Generic;
using ASOL.Core.Identity.Authorization;
using ASOL.Core.Paging.Contracts;
using ASOL.PlatformStore.Store.Contracts.Subscription;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Publishers;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Queries;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Services;
using ASOL.PlatformStore.Store.Domain.Tests.SubscriptionRoot.Fakes;
using EventFlow.EventStores;
using EventFlow.EventStores.InMemory;
using EventFlow.Extensions;
using EventFlow.Queries;
using Microsoft.Extensions.DependencyInjection;

namespace ASOL.PlatformStore.Store.Domain.Tests.SubscriptionRoot;

public abstract class SubscriptionTestBase
{
    /// <summary>
    /// Builds a <see cref="ServiceProvider"/> with all required services for testing the Subscription aggregate.
    /// </summary>
    protected static ServiceProvider BuildServiceProvider()
    {
        var services = new ServiceCollection();
        services.AddLogging();
        services.AddEventFlow(options =>
        {
            options
                .RegisterServices(s =>
                {
                    s.AddSingleton<InMemoryEventPersistence>();
                    s.AddSingleton<IEventPersistence>(r => r.GetRequiredService<InMemoryEventPersistence>());
                })
                .AddDefaults(typeof(Subscription).Assembly);
        });

        services.AddScoped<SubscriptionLicenseDomainService>();
        services.AddScoped<IQueryHandler<GetSubscriptionLicensesByPackageCodeQuery, List<SubscriptionLicenseModel>>, FakeGetSubscriptionLicensesByPackageCodeQueryHandler>();
        services.AddScoped<IQueryHandler<GetAllSubscriptionLicensesQuery, CollectionResult<SubscriptionLicenseModel>>, FakeGetAllSubscriptionLicensesQueryHandler>();

        services.AddScoped<ISubscriptionLicenseEventPublisher, FakeSubscriptionLicenseEventPublisher>();
        services.AddScoped<IPlatformAuthorizationService, FakePlatformAuthorizationService>();

        return services.BuildServiceProvider();
    }
}
