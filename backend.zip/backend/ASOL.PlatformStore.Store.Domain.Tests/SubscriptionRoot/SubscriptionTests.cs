using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Identity.Contexts;
using ASOL.Core.Localization;
using ASOL.PlatformStore.Store.Contracts.Subscription;
using ASOL.PlatformStore.Store.Contracts.Subscription.Enums;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Enums;
using EventFlow;
using EventFlow.Aggregates;
using Microsoft.Extensions.DependencyInjection;
using Shouldly;
using Xunit;

namespace ASOL.PlatformStore.Store.Domain.Tests.SubscriptionRoot;

/// <summary>
/// Contains unit tests for the <see cref="Subscription"/> aggregate and its related commands and events.
/// </summary>
public class SubscriptionTests : SubscriptionTestBase
{
    /// <summary>
    /// Tests that <see cref="SubscriptionOrderUpdateCommand"/> emits the correct event and updates the aggregate.
    /// </summary>
    [Fact]
    public async Task SubscriptionOrderUpdateCommand_EmitsEventAndUpdatesAggregate()
    {
        // Arrange
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var orderModel = CreateSampleSubscriptionOrder();

        var applicationCode = orderModel.ApplicationCode;
        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode(orderModel.TenantId, applicationCode);

        var command = SubscriptionOrderUpdateCommand.Create(
            subscriptionId,
            orderModel
        );

        // Act
        var result = await commandBus.PublishAsync(command, CancellationToken.None);

        // Assert
        result.IsSuccess.ShouldBeTrue();

        var aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        aggregate.SubscriptionMetadata.IsChangeInProgress.ShouldBeTrue();
        aggregate.TenantId.ShouldBe(orderModel.TenantId);
        aggregate.SubscriptionMetadata.PendingOrderNumber.ShouldBe(orderModel.OrderNumber);
        aggregate.SubscriptionApplicationProfile.PackageName.Translate(LocalizationContext.DefaultLanguageCode, null)
            .ShouldBe(orderModel.PackageName.Translate(LocalizationContext.DefaultLanguageCode, null));
        aggregate.SubscriptionApplicationProfile.PackageShortDescription.Translate(LocalizationContext.DefaultLanguageCode, null)
            .ShouldBe(orderModel.PackageShortDescription.Translate(LocalizationContext.DefaultLanguageCode, null));
        aggregate.SubscriptionApplicationProfile.PackageCardImageFileId.ShouldBe(orderModel.PackageCardImageFileId);
        aggregate.SubscriptionApplicationProfile.ApplicationProductId.ShouldBe(orderModel.ApplicationProductId);
        aggregate.SubscriptionApplicationProfile.ApplicationName.Translate(LocalizationContext.DefaultLanguageCode, null)
            .ShouldBe(orderModel.ApplicationName.Translate(LocalizationContext.DefaultLanguageCode, null));
        aggregate.SubscriptionApplicationProfile.ApplicationCode.ShouldBe(orderModel.ApplicationCode);
        aggregate.SubscriptionApplicationProfile.EditionProductId.ShouldBe(orderModel.EditionProductId);
        aggregate.SubscriptionApplicationProfile.EditionName.Translate(LocalizationContext.DefaultLanguageCode, null)
            .ShouldBe(orderModel.EditionName.Translate(LocalizationContext.DefaultLanguageCode, null));
        aggregate.SubscriptionApplicationProfile.EditionDescription.Translate(LocalizationContext.DefaultLanguageCode, null)
            .ShouldBe(orderModel.EditionDescription.Translate(LocalizationContext.DefaultLanguageCode, null));
        aggregate.SubscriptionApplicationProfile.FrontendUrl.ShouldBe(orderModel.FrontendUrl);
        aggregate.SubscriptionApplicationProfile.BackendUrl.ShouldBe(orderModel.BackendUrl);
        aggregate.SubscriptionMetadata.IsChangeInProgress.ShouldBeTrue();

        var order = aggregate.Orders.FirstOrDefault(o => o.OrderId == orderModel.OrderId);
        order.ShouldNotBeNull();
        order.OrderNumber.ShouldBe(orderModel.OrderNumber);
        order.PackageName.Translate(LocalizationContext.DefaultLanguageCode, null)
            .ShouldBe(orderModel.PackageName.Translate(LocalizationContext.DefaultLanguageCode, null));
        order.PackageShortDescription.Translate(LocalizationContext.DefaultLanguageCode, null)
            .ShouldBe(orderModel.PackageShortDescription.Translate(LocalizationContext.DefaultLanguageCode, null));
        order.PackageCardImageFileId.ShouldBe(orderModel.PackageCardImageFileId);
        order.ApplicationProductId.ShouldBe(orderModel.ApplicationProductId);
        order.ApplicationName.Translate(LocalizationContext.DefaultLanguageCode, null)
            .ShouldBe(orderModel.ApplicationName.Translate(LocalizationContext.DefaultLanguageCode, null));
        order.ApplicationCode.ShouldBe(orderModel.ApplicationCode);
        order.EditionProductId.ShouldBe(orderModel.EditionProductId);
        order.EditionName.Translate(LocalizationContext.DefaultLanguageCode, null)
            .ShouldBe(orderModel.EditionName.Translate(LocalizationContext.DefaultLanguageCode, null));
        order.EditionDescription.Translate(LocalizationContext.DefaultLanguageCode, null)
            .ShouldBe(orderModel.EditionDescription.Translate(LocalizationContext.DefaultLanguageCode, null));
        order.FrontendUrl.ShouldBe(orderModel.FrontendUrl);
        order.BackendUrl.ShouldBe(orderModel.BackendUrl);
        order.OrderLines.Count.ShouldBe(orderModel.OrderLines.Count);
    }

    /// <summary>
    /// Tests that <see cref="SubscriptionApplicationProfileUpdateCommand"/> emits the correct event and updates the aggregate.
    /// </summary>
    [Fact]
    public async Task SubscriptionApplicationProfileUpdateCommand_EmitsEventAndUpdatesAggregate()
    {
        // Arrange
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var orderModel = CreateSampleSubscriptionOrder();

        var applicationCode = orderModel.ApplicationCode;

        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode(orderModel.TenantId, applicationCode);

        await commandBus.PublishAsync(SubscriptionOrderUpdateCommand.Create(
                subscriptionId,
                orderModel),
            CancellationToken.None);

        var command = new SubscriptionApplicationProfileUpdateCommand(subscriptionId, orderModel.OrderId);

        // Act
        var result = await commandBus.PublishAsync(command, CancellationToken.None);

        // Assert
        result.IsSuccess.ShouldBeTrue();

        var aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        aggregate.SubscriptionApplicationProfile.PackageName.Translate(LocalizationContext.DefaultLanguageCode, null)
            .ShouldBe(orderModel.PackageName.Translate(LocalizationContext.DefaultLanguageCode, null));
        aggregate.SubscriptionApplicationProfile.PackageShortDescription.Translate(LocalizationContext.DefaultLanguageCode, null)
            .ShouldBe(orderModel.PackageShortDescription.Translate(LocalizationContext.DefaultLanguageCode, null));
        aggregate.SubscriptionApplicationProfile.PackageCardImageFileId.ShouldBe(orderModel.PackageCardImageFileId);
        aggregate.SubscriptionApplicationProfile.ApplicationProductId.ShouldBe(orderModel.ApplicationProductId);
        aggregate.SubscriptionApplicationProfile.ApplicationName.Translate(LocalizationContext.DefaultLanguageCode, null)
            .ShouldBe(orderModel.ApplicationName.Translate(LocalizationContext.DefaultLanguageCode, null));
        aggregate.SubscriptionApplicationProfile.ApplicationCode.ShouldBe(orderModel.ApplicationCode);
        aggregate.SubscriptionApplicationProfile.EditionProductId.ShouldBe(orderModel.EditionProductId);
        aggregate.SubscriptionApplicationProfile.EditionName.Translate(LocalizationContext.DefaultLanguageCode, null)
            .ShouldBe(orderModel.EditionName.Translate(LocalizationContext.DefaultLanguageCode, null));
        aggregate.SubscriptionApplicationProfile.EditionDescription.Translate(LocalizationContext.DefaultLanguageCode, null)
            .ShouldBe(orderModel.EditionDescription.Translate(LocalizationContext.DefaultLanguageCode, null));
        aggregate.SubscriptionApplicationProfile.FrontendUrl.ShouldBe(orderModel.FrontendUrl);
        aggregate.SubscriptionApplicationProfile.BackendUrl.ShouldBe(orderModel.BackendUrl);
    }

    /// <summary>
    /// Tests that <see cref="SubscriptionCustomerUpdateCommand"/> emits the correct event and updates the aggregate.
    /// </summary>
    [Fact]
    public async Task SubscriptionCustomerUpdateCommand_EmitsEventAndUpdatesAggregate()
    {
        // Arrange
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var tenantId = "test-tenant-id";
        var applicationCode = "test-application-code";
        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode(tenantId, applicationCode);

        var customer = new SubscriptionCustomerModel
        {
            Id = "customer-1",
            Name = "Test Customer",
            Code = "12345678|CZ",
            VatIn = "CZ12345678",
            Line1 = "Test Address 123, Prague"
        };

        var command = new SubscriptionCustomerUpdateCommand(subscriptionId, customer);

        // Act
        var result = await commandBus.PublishAsync(command, CancellationToken.None);

        // Assert
        result.IsSuccess.ShouldBeTrue();
        var aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        aggregate.Customer.Id.ShouldBe(customer.Id);
        aggregate.Customer.Name.ShouldBe(customer.Name);
        aggregate.Customer.Code.ShouldBe(customer.Code);
        aggregate.Customer.VatIn.ShouldBe(customer.VatIn);
        aggregate.Customer.Line1.ShouldBe(customer.Line1);
    }

    /// <summary>
    /// Tests that <see cref="SubscriptionApplicationSolutionPartnerUpdateCommand"/> emits the correct event and updates the aggregate.
    /// </summary>
    [Fact]
    public async Task SubscriptionApplicationSolutionPartnerUpdateCommand_EmitsEventAndUpdatesAggregate()
    {
        // Arrange
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var tenantId = "test-tenant-id";
        var applicationCode = "test-application-code";
        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode(tenantId, applicationCode);

        var partner = new SubscriptionSolutionPartner
        {
            Id = "partner-1",
            Name = "Test Application Solution Partner",
            Code = "PARTNER-001|CZ",
            VatIn = "CZ87654321",
            Line1 = "Partner Address 456, Brno"
        };

        var command = new SubscriptionApplicationSolutionPartnerUpdateCommand(subscriptionId, partner);

        // Act
        var result = await commandBus.PublishAsync(command, CancellationToken.None);

        // Assert
        result.IsSuccess.ShouldBeTrue();
        var aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        aggregate.ApplicationSolutionPartner.Id.ShouldBe(partner.Id);
        aggregate.ApplicationSolutionPartner.Name.ShouldBe(partner.Name);
        aggregate.ApplicationSolutionPartner.Code.ShouldBe(partner.Code);
        aggregate.ApplicationSolutionPartner.VatIn.ShouldBe(partner.VatIn);
        aggregate.ApplicationSolutionPartner.Line1.ShouldBe(partner.Line1);
    }

    /// <summary>
    /// Tests that <see cref="SubscriptionDevelopmentPartnerUpdateCommand"/> emits the correct event and updates the aggregate.
    /// </summary>
    [Fact]
    public async Task SubscriptionDevelopmentPartnerUpdateCommand_EmitsEventAndUpdatesAggregate()
    {
        // Arrange
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var tenantId = "test-tenant-id";
        var applicationCode = "test-application-code";
        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode(tenantId, applicationCode);

        var partner = new SubscriptionDevelopmentPartnerModel
        {
            Id = "devpartner-1",
            Name = "Test Development Partner",
            Code = "DEV-001|CZ",
            VatIn = "CZ11223344",
            Line1 = "Dev Address 789, Ostrava"
        };

        var command = new SubscriptionDevelopmentPartnerUpdateCommand(subscriptionId, partner);

        // Act
        var result = await commandBus.PublishAsync(command, CancellationToken.None);

        // Assert
        result.IsSuccess.ShouldBeTrue();
        var aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        aggregate.DevelopmentPartner.Id.ShouldBe(partner.Id);
        aggregate.DevelopmentPartner.Name.ShouldBe(partner.Name);
        aggregate.DevelopmentPartner.Code.ShouldBe(partner.Code);
        aggregate.DevelopmentPartner.VatIn.ShouldBe(partner.VatIn);
        aggregate.DevelopmentPartner.Line1.ShouldBe(partner.Line1);
    }

    /// <summary>
    /// Tests that <see cref="SubscriptionOrderStatusUpdateCommand"/> emits the correct event and updates the aggregate.
    /// </summary>
    [Fact]
    public async Task SubscriptionOrderStatusUpdateCommand_EmitsEventAndUpdatesAggregate()
    {
        // Arrange
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var orderModel = CreateSampleSubscriptionOrder();
        var tenantId = orderModel.TenantId;
        var applicationCode = orderModel.ApplicationCode;

        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode(tenantId, applicationCode);

        var createCommand = SubscriptionOrderUpdateCommand.Create(
            subscriptionId,
            orderModel
        );
        await commandBus.PublishAsync(createCommand, CancellationToken.None);

        var statusCommand = new SubscriptionOrderStatusUpdateCommand(
            subscriptionId,
            orderModel.OrderId,
            orderModel.OrderNumber,
            Order.Contracts.Primitives.OrderSystemStatus.Done
        );
        var result = await commandBus.PublishAsync(statusCommand, CancellationToken.None);

        // Assert
        result.IsSuccess.ShouldBeTrue();
        var aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        var order = aggregate.Orders.FirstOrDefault(o => o.OrderId == orderModel.OrderId);
        order.ShouldNotBeNull();
        order.Status.ShouldBe(Order.Contracts.Primitives.OrderSystemStatus.Done.ToString());
    }

    /// <summary>
    /// Tests that <see cref="SubscriptionSolutionStatusUpdateCommand"/> emits the correct event and updates the aggregate.
    /// </summary>
    [Fact]
    public async Task SubscriptionSolutionStatusUpdateCommand_EmitsEventAndUpdatesAggregate()
    {
        // Arrange
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var orderModel = CreateSampleSubscriptionOrder();
        var tenantId = orderModel.TenantId;
        var applicationCode = orderModel.ApplicationCode;

        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode(tenantId, applicationCode);
        await commandBus.PublishAsync(SubscriptionOrderUpdateCommand.Create(
            subscriptionId,
            orderModel
        ), CancellationToken.None);

        await commandBus.PublishAsync(new SubscriptionOrderStatusUpdateCommand(
            subscriptionId,
            orderModel.OrderId,
            orderModel.OrderNumber,
            Order.Contracts.Primitives.OrderSystemStatus.Done
        ), CancellationToken.None);

        var statusCommand = new SubscriptionSolutionStatusUpdateCommand(
            subscriptionId, SubscriptionSolutionStatusUpdateSource.SalesUser, nameof(SubscriptionSolutionStatus.Active),
            null,
            "Test",
            "User",
            DateTime.Now);

        // Act
        var result = await commandBus.PublishAsync(statusCommand, CancellationToken.None);

        // Assert
        result.IsSuccess.ShouldBeTrue();
        var aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);

        aggregate.SubscriptionMetadata.SolutionStatus.ShouldBe(nameof(SubscriptionSolutionStatus.Active));
        aggregate.SubscriptionMetadata.SolutionStatusNote.ShouldBe("Test");
        aggregate.SubscriptionMetadata.SolutionStatusModifiedBy.ShouldBe("User");
    }

    /// <summary>
    /// Tests that <see cref="SubscriptionOrderResponsiblePersonUpdateCommand"/> emits the correct event and updates the aggregate.
    /// </summary>
    [Fact]
    public async Task SubscriptionOrderResponsiblePersonUpdateCommand_EmitsEventAndUpdatesAggregate()
    {
        // Arrange
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var orderModel = CreateSampleSubscriptionOrder();
        var tenantId = orderModel.TenantId;
        var applicationCode = orderModel.ApplicationCode;

        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode(tenantId, applicationCode);

        var createCommand = SubscriptionOrderUpdateCommand.Create(
            subscriptionId,
            orderModel
        );
        await commandBus.PublishAsync(createCommand, CancellationToken.None);

        var salesUserName = "paul.newman";
        var salesPersonId = "123456789";
        var salesFirstName = "Paul";
        var salesLastName = "Newman";
        var statusCommand = new SubscriptionOrderResponsiblePersonUpdateCommand(
            subscriptionId,
            orderModel.OrderId,
            salesUserName,
            salesPersonId,
            salesFirstName,
            salesLastName
        );
        var result = await commandBus.PublishAsync(statusCommand, CancellationToken.None);

        // Assert
        result.IsSuccess.ShouldBeTrue();
        var aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        var order = aggregate.Orders.FirstOrDefault(o => o.OrderId == orderModel.OrderId);
        order.ShouldNotBeNull();
        order.SalesUserName.ShouldBe(salesUserName);
        order.SalesPersonId.ShouldBe(salesPersonId);
        order.SalesFirstName.ShouldBe(salesFirstName);
        order.SalesLastName.ShouldBe(salesLastName);
    }

    /// <summary>
    /// Tests that <see cref="SubscriptionOrderNoteUpdateCommand"/> emits the correct event and updates the aggregate.
    /// </summary>
    [Fact]
    public async Task SubscriptionOrderNoteUpdateCommand_EmitsEventAndUpdatesAggregate()
    {
        // Arrange
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var orderModel = CreateSampleSubscriptionOrder();
        var tenantId = orderModel.TenantId;
        var applicationCode = orderModel.ApplicationCode;

        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode(tenantId, applicationCode);

        var createCommand = SubscriptionOrderUpdateCommand.Create(
            subscriptionId,
            orderModel
        );
        await commandBus.PublishAsync(createCommand, CancellationToken.None);

        var orderNote = "Test note";
        var statusCommand = new SubscriptionOrderNoteUpdateCommand(
            subscriptionId,
            orderModel.OrderId,
            orderNote
        );
        var result = await commandBus.PublishAsync(statusCommand, CancellationToken.None);

        // Assert
        result.IsSuccess.ShouldBeTrue();
        var aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        var order = aggregate.Orders.FirstOrDefault(o => o.OrderId == orderModel.OrderId);
        order.ShouldNotBeNull();
        order.Note.ShouldBe(orderNote);
    }

    /// <summary>
    /// Tests that <see cref="SubscriptionOrderDeleteCommand"/> emits the correct event and updates the aggregate.
    /// </summary>
    [Fact]
    public async Task SubscriptionOrderDeleteCommand_EmitsEventAndUpdatesAggregate()
    {
        // Arrange
        var serviceProvider = BuildServiceProvider();
        var commandBus = serviceProvider.GetRequiredService<ICommandBus>();
        var aggregateStore = serviceProvider.GetRequiredService<IAggregateStore>();

        var orderModel = CreateSampleSubscriptionOrder();
        var tenantId = orderModel.TenantId;
        var applicationCode = orderModel.ApplicationCode;

        var subscriptionId = SubscriptionId.FromTenantAndApplicationCode(tenantId, applicationCode);

        var createCommand = SubscriptionOrderUpdateCommand.Create(
            subscriptionId,
            orderModel
        );
        await commandBus.PublishAsync(createCommand, CancellationToken.None);

        var deleteCommand = new SubscriptionOrderDeleteCommand(
            subscriptionId,
            orderModel.OrderId
        );
        var result = await commandBus.PublishAsync(deleteCommand, CancellationToken.None);

        // Assert
        result.IsSuccess.ShouldBeTrue();
        var aggregate = await aggregateStore.LoadAsync<Subscription, SubscriptionId>(subscriptionId, CancellationToken.None);
        var order = aggregate.Orders.FirstOrDefault(o => o.OrderId == orderModel.OrderId);
        order.ShouldNotBeNull();
        order.Deleted.ShouldBeTrue();
    }

    /// <summary>
    /// Creates a sample <see cref="SubscriptionOrder"/> for use in tests.
    /// </summary>
    /// <returns>A sample <see cref="SubscriptionOrder"/> instance.</returns>
    private static SubscriptionOrder CreateSampleSubscriptionOrder()
    {
        return new SubscriptionOrder(SubscriptionOrderId.New)
        {
            TenantId = "test-tenant-id",
            OrderId = "eca6a8cc-d5b2-4e33-b352-0b283854e848",
            OrderNumber = "202506110002",
            PackageProductId = "f3e86f69-5b55-441c-bd2b-a0b9179cd799",
            PackageName = new LocalizedValue<string>(
                ("en-US", "Geetoo S3"),
                ("cs-CZ", "Geetoo S3"),
                ("sk-SK", "Geetoo S3")
            ),
            PackageShortDescription = new LocalizedValue<string>(
                ("en-US", "Smart and safe cloud backup for HELIOS and all your data."),
                ("cs-CZ", "Zálohování HELIOS a všech vašich dat v bezpečném cloudovém úložišti."),
                ("sk-SK", "Zálohujte HELIOS a všetky svoje dáta v bezpečnom cloudovom úložišti.")
            ),
            PackageCardImageFileId = "67356e5d-7c6b-4a0a-92f7-53cf668d2a74",
            ApplicationProductId = "affd2fb8-811d-4047-bc58-28d5187c53cd",
            ApplicationName = new LocalizedValue<string>(("en-US", "S3")),
            ApplicationCode = "Geetoo-S3-AP-",
            EditionProductId = "084cef2f-5f3c-4064-8ba5-ec79424b38db",
            EditionName = new LocalizedValue<string>(
                ("en-US", "Geetoo S3 Backup"),
                ("cs-CZ", "Geetoo S3 Backup"),
                ("sk-SK", "Geetoo S3 Backup")
            ),
            EditionDescription = new LocalizedValue<string>(
                ("en-US", null),
                ("cs-CZ", null),
                ("sk-SK", null)
            ),
            FrontendUrl = "https://www.geetoo.com/geetoo-s3/",
            BackendUrl = null,
            OrderDate = new DateTime(2025, 6, 11, 19, 5, 57, 532, DateTimeKind.Utc),
            OrderLines =
            [
                new()
                {
                    OrderLineId = "24d3a192-c0fd-403a-88af-1be6a304bb20",
                    OrderLineType = "Package",
                    ProductId = "f3e86f69-5b55-441c-bd2b-a0b9179cd799",
                    ProductCode = "S3",
                    ProductName = new LocalizedValue<string>(
                        ("en-US", "Geetoo S3"),
                        ("cs-CZ", "Geetoo S3"),
                        ("sk-SK", "Geetoo S3")
                    ),
                    ProductDescription = new LocalizedValue<string>(
                        ("en-US", "Smart and safe cloud backup for HELIOS and all your data."),
                        ("cs-CZ", "Zálohování HELIOS a všech vašich dat v bezpečném cloudovém úložišti."),
                        ("sk-SK", "Zálohujte HELIOS a všetky svoje dáta v bezpečnom cloudovom úložišti.")
                    ),
                    ProductPartCode = "Geetoo-S3-PA"
                },
                new()
                {
                    OrderLineId = "26b41367-8129-4f9c-9731-d3f50edd3f5a",
                    ParentOrderLineId = "24d3a192-c0fd-403a-88af-1be6a304bb20",
                    OrderLineType = "Application",
                    ProductId = "affd2fb8-811d-4047-bc58-28d5187c53cd",
                    ProductCode = "S3",
                    ProductName = new LocalizedValue<string>(("en-US", "S3")),
                    ProductPartCode = "Geetoo-S3-AP-"
                },
                new()
                {
                    OrderLineId = "a8b246b2-123b-4d52-a6ee-09a4ec461269",
                    ParentOrderLineId = "24d3a192-c0fd-403a-88af-1be6a304bb20",
                    OrderLineType = "Edition",
                    ProductId = "084cef2f-5f3c-4064-8ba5-ec79424b38db",
                    ProductCode = "S3.GeetooS3Backup",
                    ProductName = new LocalizedValue<string>(
                        ("en-US", "Geetoo S3 Backup"),
                        ("cs-CZ", "Geetoo S3 Backup"),
                        ("sk-SK", "Geetoo S3 Backup")
                    ),
                    ProductDescription = new LocalizedValue<string>(
                        ("en-US", null),
                        ("cs-CZ", null),
                        ("sk-SK", null)
                    ),
                    ProductPartCode = "Geetoo-S3.GeetooS3Backup-ED"
                },
                new()
                {
                    OrderLineId = "b818b2c4-ea71-4060-abbf-e6c5c992261c",
                    ParentOrderLineId = "a8b246b2-123b-4d52-a6ee-09a4ec461269",
                    OrderLineType = "Extension",
                    ProductId = "a78db045-d04a-4ec0-96bc-e352e60b3cac",
                    ProductCode = "VeemBackup-Replication",
                    ProductName = new LocalizedValue<string>(
                        ("en-US", "Veeam Backup & Replication"),
                        ("cs-CZ", "Veeam Backup & Replication"),
                        ("sk-SK", "Veeam Backup & Replication")
                    ),
                    ProductDescription = new LocalizedValue<string>(
                        ("en-US", "A backup application developed for virtual environments based on hypervisors."),
                        ("cs-CZ", "Zálohovací aplikace vyvinutá pro virtuální prostředí postavená na hypervizorech."),
                        ("sk-SK", "Aplikácia na zálohovanie vyvinutá pre virtuálne prostredia založené na hypervízoroch.")
                    ),
                    ProductPartCode = "Geetoo-VeemBackup-Replication-Ex"
                },
                new()
                {
                    OrderLineId = "fe341ecc-68ad-46c9-929b-9fccd4c6bb5f",
                    ParentOrderLineId = "a8b246b2-123b-4d52-a6ee-09a4ec461269",
                    OrderLineType = "Extension",
                    ProductId = "8402f167-fed8-4682-aed1-b695133dbc1f",
                    ProductCode = "VeemBackup-M365",
                    ProductName = new LocalizedValue<string>(
                        ("en-US", "Veeam Backup for M365"),
                        ("cs-CZ", "Veeam Backup for M365"),
                        ("sk-SK", "Veeam Backup for M365")
                    ),
                    ProductDescription = new LocalizedValue<string>(
                        ("en-US", "Secure backup solution for MS Office 365."),
                        ("cs-CZ", "Bezpečné řešení pro zálohování MS Office 365."),
                        ("sk-SK", "Bezpečné zálohovanie pre MS Office 365.")
                    ),
                    ProductPartCode = "Geetoo-VeemBackup-M365-Ex"
                },
                new()
                {
                    OrderLineId = "ac373499-a02e-4fab-8d75-348961f91b03",
                    ParentOrderLineId = "a8b246b2-123b-4d52-a6ee-09a4ec461269",
                    OrderLineType = "Subscription",
                    ProductId = "fd7e6dda-56e2-43d1-a1ec-fcc6ecc6b7dc",
                    ProductCode = "S3-Geetoo-BackUp-Monthly",
                    ProductName = new LocalizedValue<string>(("en-US", "S3-Geetoo-BackUp-Monthly")),
                    ProductPartCode = "Geetoo-S3-Geetoo-BackUp-Monthly-SU",
                    BillingPeriodCode = "MonthlyForward",
                    Price = null,
                    BasePrice = null,
                    UnitOfMeasureCode = null,
                    UnitOfSaleCode = null,
                    LicenceCount = null,
                    LicenceTrialDays = null
                },
                new()
                {
                    OrderLineId = "82585812-cf8c-4b21-b6b0-aa13f4615c4f",
                    ParentOrderLineId = "ac373499-a02e-4fab-8d75-348961f91b03",
                    OrderLineType = "SalesItem",
                    ProductId = "4fd16363-7f4b-4e65-a13d-eca048058c4d",
                    ProductCode = "S3-Geetoo-BackUp-Monthly-SA",
                    ProductName = new LocalizedValue<string>(("en-US", "S3-Geetoo-BackUp-Monthly-SA")),
                    ProductPartCode = "Geetoo-S3-Geetoo-BackUp-Monthly-SA-SI",
                    Price = 40.00m,
                    BasePrice = 0.066667m,
                    BillingPeriodCode = "MonthlyForward",
                    UnitOfMeasureCode = "Count",
                    UnitOfSaleCode = "GB",
                    LicenceCount = 600,
                    LicenceTrialDays = null,
                    RoleCode = "Geetoo-S3-AP-.LICENCE.USER-LC-"
                },
                new()
                {
                    OrderLineId = "f6f38932-9daf-47d1-9733-42fde3d40ad9",
                    ParentOrderLineId = "b818b2c4-ea71-4060-abbf-e6c5c992261c",
                    OrderLineType = "Subscription",
                    ProductId = "68b386f5-c5d9-46ad-b073-6585a296695c",
                    ProductCode = "VeemBackup-Replication-SU",
                    ProductName = new LocalizedValue<string>(("en-US", "VeemBackup-Replication-SU")),
                    ProductPartCode = "Geetoo-VeemBackup-Replication-SU-SU",
                    BillingPeriodCode = "MonthlyForward"
                },
                new()
                {
                    OrderLineId = "cf985647-42be-446c-ad6b-65bdbc11aec0",
                    ParentOrderLineId = "f6f38932-9daf-47d1-9733-42fde3d40ad9",
                    OrderLineType = "SalesItem",
                    ProductId = "3dac4542-eee1-4399-9316-71509bf4cec0",
                    ProductCode = "VeemBackup-Replication-SA",
                    ProductName = new LocalizedValue<string>(("en-US", "VeemBackup-Replication-SA")),
                    ProductPartCode = "Geetoo-VeemBackup-Replication-SA-SI",
                    Price = 38.00m,
                    BasePrice = 9.50m,
                    BillingPeriodCode = "MonthlyForward",
                    UnitOfMeasureCode = "Count",
                    UnitOfSaleCode = "License",
                    LicenceCount = 4,
                    RoleCode = "ASOLEU-BankApp-AP-.User"
                },
                new()
                {
                    OrderLineId = "cf557feb-d39c-4a3d-a0fe-e70677eefc1a",
                    ParentOrderLineId = "fe341ecc-68ad-46c9-929b-9fccd4c6bb5f",
                    OrderLineType = "Subscription",
                    ProductId = "8fbfb4a9-e38d-4b93-bb22-cfc8ab446c1e",
                    ProductCode = "VeemBackup-M365-SU",
                    ProductName = new LocalizedValue<string>(("en-US", "VeemBackup-M365-SU")),
                    ProductPartCode = "Geetoo-VeemBackup-M365-SU-SU",
                    BillingPeriodCode = "MonthlyForward"
                },
                new()
                {
                    OrderLineId = "41ccac02-aa7c-4126-ac50-60fc310c0290",
                    ParentOrderLineId = "cf557feb-d39c-4a3d-a0fe-e70677eefc1a",
                    OrderLineType = "SalesItem",
                    ProductId = "03e27173-8054-45a3-a657-00718caeaa46",
                    ProductCode = "VeemBackup-M365-SA",
                    ProductName = new LocalizedValue<string>(("en-US", "VeemBackup-M365-SA")),
                    ProductPartCode = "Geetoo-VeemBackup-M365-SA-SI",
                    Price = 6.32m,
                    BasePrice = 1.58m,
                    BillingPeriodCode = "MonthlyForward",
                    UnitOfMeasureCode = "Count",
                    UnitOfSaleCode = "License",
                    LicenceCount = 4,
                    RoleCode = "RINGIL-RINGILprepravaApp-AP-.LICENCE.USER-LC-"
                },
                new()
                {
                    OrderLineId = "79474f8d-55a5-4edd-88e8-cf7b030b243c",
                    ParentOrderLineId = "a8b246b2-123b-4d52-a6ee-09a4ec461269",
                    OrderLineType = "Feature",
                    ProductId = "39333d68-e781-440f-84f0-816bd0d7413e",
                    ProductCode = "S3.HELIOSBackup",
                    ProductName = new LocalizedValue<string>(("en-US", "S3.HELIOS Backup")),
                    ProductPartCode = "Geetoo-S3.HELIOSBackup-FE"
                },
                new()
                {
                    OrderLineId = "10157641-f119-4e48-a883-f768eb7ea5fa",
                    ParentOrderLineId = "a8b246b2-123b-4d52-a6ee-09a4ec461269",
                    OrderLineType = "Feature",
                    ProductId = "9bb50226-0c23-4bf4-97d7-80ca7971beae",
                    ProductCode = "S3.ObjectLock",
                    ProductName = new LocalizedValue<string>(("en-US", "S3.Object Lock")),
                    ProductPartCode = "Geetoo-S3.ObjectLock-FE"
                },
                new()
                {
                    OrderLineId = "fbf7cdf0-7ef1-4025-bfaa-d04ed7b7aebf",
                    ParentOrderLineId = "a8b246b2-123b-4d52-a6ee-09a4ec461269",
                    OrderLineType = "Feature",
                    ProductId = "5ec9c2d2-8e1a-4ed2-a6ad-54a601ad2e72",
                    ProductCode = "S3.Testing",
                    ProductName = new LocalizedValue<string>(("en-US", "S3.Testing")),
                    ProductPartCode = "Geetoo-S3.Testing-FE"
                },
                new()
                {
                    OrderLineId = "aab4b658-5d9a-47ee-8244-f2649cc03049",
                    ParentOrderLineId = "a8b246b2-123b-4d52-a6ee-09a4ec461269",
                    OrderLineType = "Feature",
                    ProductId = "1aa8f652-7370-474d-9f29-33101c460251",
                    ProductCode = "S3.Development",
                    ProductName = new LocalizedValue<string>(("en-US", "S3.Development")),
                    ProductPartCode = "Geetoo-S3.Development-FE"
                },
                new()
                {
                    OrderLineId = "5875fbd0-713a-4ef6-b9af-ec743f160364",
                    ParentOrderLineId = "a8b246b2-123b-4d52-a6ee-09a4ec461269",
                    OrderLineType = "Feature",
                    ProductId = "72fcfedd-f340-4e35-8c28-05fc2e3f106d",
                    ProductCode = "S3.Backup",
                    ProductName = new LocalizedValue<string>(("en-US", "S3.Backup")),
                    ProductPartCode = "Geetoo-S3.Backup-FE"
                },
                new()
                {
                    OrderLineId = "de898cd2-ff1b-436c-a3ce-b20a45f7bb1e",
                    ParentOrderLineId = "a8b246b2-123b-4d52-a6ee-09a4ec461269",
                    OrderLineType = "Feature",
                    ProductId = "29ee2572-fcf3-4742-8524-e5750ca2882e",
                    ProductCode = "S3.HighLatency",
                    ProductName = new LocalizedValue<string>(("en-US", "S3.High Latency")),
                    ProductPartCode = "Geetoo-S3.HighLatency-FE"
                }
            ]
        };
    }
}
