using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using EventFlow.Aggregates;
using EventFlow.Core;
using EventFlow.EventStores;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.Domain.Tests.Support;

public class InMemoryEventPersistence(ILogger<InMemoryEventPersistence> logger) : IEventPersistence
{
    public ConcurrentDictionary<string, List<ICommittedDomainEvent>> Store { get; } = new();

    public Task<IReadOnlyCollection<ICommittedDomainEvent>> CommitEventsAsync(
         IIdentity id,
         IReadOnlyCollection<SerializedEvent> serializedEvents,
         CancellationToken cancellationToken)
    {
        var list = new List<ICommittedDomainEvent>();
        foreach (var (e, index) in serializedEvents.Select((e, i) => (e, i)))
        {
            var committed = new CommittedDomainEvent(
                id,
                e.Metadata[MetadataKeys.AggregateName],
                e.AggregateSequenceNumber,
                e.SerializedMetadata,
                e.SerializedData);
            list.Add(committed);
        }

        Store.AddOrUpdate(
            id.Value,
            _ => list,
            (_, existing) => { existing.AddRange(list); return existing; });

        return Task.FromResult<IReadOnlyCollection<ICommittedDomainEvent>>(list);
    }

    public Task<IReadOnlyCollection<ICommittedDomainEvent>> LoadCommittedEventsAsync(
           IIdentity id, int fromEventSequenceNumber, CancellationToken cancellationToken)
    {
        if (!Store.TryGetValue(id.Value, out var events))
        {
            return Task.FromResult<IReadOnlyCollection<ICommittedDomainEvent>>(new List<ICommittedDomainEvent>());
        }

        return Task.FromResult<IReadOnlyCollection<ICommittedDomainEvent>>(
            events.Where(e => e.AggregateSequenceNumber >= fromEventSequenceNumber).ToList());
    }

    public Task<IReadOnlyCollection<ICommittedDomainEvent>> LoadCommittedEventsAsync(
        IIdentity id, int fromEventSequenceNumber, int toEventSequenceNumber, CancellationToken cancellationToken)
    {
        if (!Store.TryGetValue(id.Value, out var events))
        {
            return Task.FromResult<IReadOnlyCollection<ICommittedDomainEvent>>(new List<ICommittedDomainEvent>());
        }

        return Task.FromResult<IReadOnlyCollection<ICommittedDomainEvent>>(
            events.Where(e => e.AggregateSequenceNumber >= fromEventSequenceNumber &&
                              e.AggregateSequenceNumber <= toEventSequenceNumber).ToList());
    }

    public Task<AllCommittedEventsPage> LoadAllCommittedEvents(
        GlobalPosition globalPosition,
        int pageSize,
        CancellationToken cancellationToken)
    {
        var startPosition = globalPosition.IsStart
            ? 0
            : long.Parse(globalPosition.Value);

        var allEvents = Store
            .SelectMany(kvp => kvp.Value)
            .Where(e => e.AggregateSequenceNumber >= startPosition)
            .OrderBy(e => e.AggregateSequenceNumber)
            .Take(pageSize)
            .ToList();

        var nextPosition = allEvents.Count != 0
            ? allEvents.Max(e => e.AggregateSequenceNumber) + 1
            : startPosition;

        return Task.FromResult(new AllCommittedEventsPage(new GlobalPosition(nextPosition.ToString()), allEvents));
    }

    public Task DeleteEventsAsync(IIdentity id, CancellationToken cancellationToken)
    {
        Store.TryRemove(id.Value, out _);
        return Task.CompletedTask;
    }

    private sealed class CommittedDomainEvent(
        IIdentity id,
        string aggregateName,
        int aggregateSequenceNumber,
        string metadata,
        string data) : ICommittedDomainEvent
    {
        public string AggregateId { get; } = id.Value;
        public string AggregateName { get; } = aggregateName;
        public int AggregateSequenceNumber { get; } = aggregateSequenceNumber;
        public string Metadata { get; } = metadata;
        public string Data { get; } = data;

        public override string ToString() =>
            $"{AggregateName}#{AggregateSequenceNumber} - {Metadata} / {Data}";
    }
}
