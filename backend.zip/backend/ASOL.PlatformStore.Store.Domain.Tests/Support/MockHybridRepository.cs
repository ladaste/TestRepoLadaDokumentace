using ASOL.Core.Domain;
using ASOL.Core.Multitenancy.MongoDb;
using ASOL.Core.Persistence.MongoDb;
using ASOL.Core.QA.TestSupport.ApiService;

namespace ASOL.PlatformStore.Store.Domain.Tests.Support;

public class MockHybridRepository<TEntity, TKey> : MockRepository<TEntity, TKey>
        where TEntity : class, IEntity<TKey>, new()
{
    public MockHybridRepository(IDbContext dbContext, MockHybridRepositoryData<TEntity> items) : base(items.GetOrCreateMasterData())
    {
    }

    public MockHybridRepository(ITenantDbContext dbContext, MockHybridRepositoryData<TEntity> items) : base(items.GetOrCreateTenantData())
    {
    }
}
