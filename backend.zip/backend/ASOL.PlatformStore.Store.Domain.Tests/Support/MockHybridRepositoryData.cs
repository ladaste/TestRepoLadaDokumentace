using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using ASOL.Core.Identity;

namespace ASOL.PlatformStore.Store.Domain.Tests.Support;

public class MockHybridRepositoryData<TEntity>(IRuntimeContext context)
{
    public IRuntimeContext Context { get; } = context;

    public ConcurrentDictionary<string, List<TEntity>> Data { get; set; } = new ConcurrentDictionary<string, List<TEntity>>();

    public List<TEntity> GetOrCreateMasterData()
    {
        if (Context == null)
        {
            throw new InvalidOperationException("Runtime context is not valid!");
        }
        return Data.GetOrAdd(".MASTER.", (tid) =>
        {
            return [];
        });
    }

    public List<TEntity> GetOrCreateTenantData()
    {
        if (Context?.Security?.TenantId == null)
        {
            throw new InvalidOperationException("Runtime context, or security context or tenant in security context is not valid!");
        }
        return Data.GetOrAdd(Context.Security.TenantId, (tid) =>
        {
            return [];
        });
    }
}
