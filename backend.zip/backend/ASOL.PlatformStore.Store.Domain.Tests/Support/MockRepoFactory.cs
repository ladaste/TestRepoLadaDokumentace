using System;
using System.Linq;
using ASOL.Core.Domain;
using ASOL.Core.Multitenancy.MongoDb;
using ASOL.Core.Persistence;
using ASOL.Core.Persistence.MongoDb;
using Microsoft.Extensions.DependencyInjection;

namespace ASOL.PlatformStore.Store.Domain.Tests.Support;

/// <summary>
/// .ctor
/// </summary>
internal sealed class MockRepoFactory(
    IServiceProvider serviceProvider) : IRepoFactory
{
    private readonly IServiceProvider _serviceProvider = serviceProvider;
    private ITenantDbContext _tenantDbContext;
    private IDbContext _masterDbContext;

    /// <summary>
    /// Get or create Tenant DbContext.
    /// </summary>
    /// <returns>The tenant db-context</returns>
    public ITenantDbContext GetOrCreateTenantDbContext()
    {
        if (_tenantDbContext != null)
        {
            return _tenantDbContext;
        }
        _tenantDbContext = _serviceProvider.GetRequiredService<ITenantDbContext>();
        return _tenantDbContext;
    }

    /// <summary>
    /// Get or create Master DbContext.
    /// </summary>
    /// <returns>The master db-context</returns>
    public IDbContext GetOrCreateMasterDbContext()
    {
        if (_masterDbContext != null)
        {
            return _masterDbContext;
        }
        var moq = new Moq.Mock<IDbContext>();
        moq.SetupGet(r => r.DatabaseName).Returns("MASTER");
        _masterDbContext = moq.Object;
        return _masterDbContext;
    }

    public IDbContext GetOrCreateMasterDbContextByType(Type type)
    {
        throw new NotImplementedException();
    }

    public ITenantDbContext GetOrCreateTenantDbContextByType(Type type)
    {
        throw new NotImplementedException();
    }

    /// <summary>
    /// Repository for tenant entities.
    /// </summary>
    /// <typeparam name="T">The entity type</typeparam>
    /// <returns>The created instance of repository.</returns>
    public IRepository<T> CreateTenantRepository<T>() where T : class, new()
    {
        throw new NotImplementedException();
    }

    /// <summary>
    /// Repository for tenant entities.
    /// </summary>
    /// <typeparam name="TEntity">The entity type</typeparam>
    /// <typeparam name="TKey">The entity key type</typeparam>
    /// <returns>The created instance of repository.</returns>
    public IRepository<TEntity, TKey> CreateTenantRepository<TEntity, TKey>() where TEntity : class, IEntity<TKey>, new()
    {
        throw new NotImplementedException();
    }

    /// <summary>
    /// Repository for tenant entities.
    /// </summary>
    /// <typeparam name="T">The repository type</typeparam>
    /// <returns>The created instance of repository.</returns>
    public T CreateTenantRepositoryByType<T>() where T : class, IRepository
    {
        var entityType = typeof(T).BaseType.GetGenericArguments().FirstOrDefault();

        var repositoryDataType = typeof(MockHybridRepositoryData<>).MakeGenericType(entityType);
        dynamic repositoryData = _serviceProvider.GetRequiredService(repositoryDataType);

        var tenantDbContext = GetOrCreateTenantDbContext();
        var result = ActivatorUtilities.CreateInstance(_serviceProvider, typeof(T), tenantDbContext, repositoryData);
        return (T)result;
    }

    /// <summary>
    /// Repository for master entities.
    /// </summary>
    /// <typeparam name="T">The entity type</typeparam>
    /// <returns>The created instance of repository.</returns>
    public IRepository<T> CreateMasterRepository<T>() where T : class, new()
    {
        throw new NotImplementedException();
    }

    /// <summary>
    /// Repository for master entities.
    /// </summary>
    /// <typeparam name="TEntity">The entity type</typeparam>
    /// <typeparam name="TKey">The entity key type</typeparam>
    /// <returns>The created instance of repository.</returns>
    public IRepository<TEntity, TKey> CreateMasterRepository<TEntity, TKey>() where TEntity : class, IEntity<TKey>, new()
    {
        throw new NotImplementedException();
    }

    /// <summary>
    /// Repository for master entities.
    /// </summary>
    /// <typeparam name="T">The repository type</typeparam>
    /// <returns>The created instance of repository.</returns>
    public T CreateMasterRepositoryByType<T>() where T : class, IRepository
    {
        var entityType = typeof(T).BaseType.GetGenericArguments().First();

        var repositoryDataType = typeof(MockHybridRepositoryData<>).MakeGenericType(entityType);
        dynamic repositoryData = _serviceProvider.GetRequiredService(repositoryDataType);

        var masterDbContext = GetOrCreateMasterDbContext();
        var result = ActivatorUtilities.CreateInstance(_serviceProvider, typeof(T), masterDbContext, repositoryData);
        return (T)result;
    }

    public object CreateMasterRepositoryByType(Type type)
    {
        var entityType = type.BaseType.GetGenericArguments().FirstOrDefault();

        var repositoryDataType = typeof(MockHybridRepositoryData<>).MakeGenericType(entityType);
        dynamic repositoryData = _serviceProvider.GetRequiredService(repositoryDataType);

        var masterDbContext = GetOrCreateMasterDbContext();
        var result = ActivatorUtilities.CreateInstance(_serviceProvider, type, masterDbContext, repositoryData);
        return result;
    }

    public object CreateTenantRepositoryByType(Type type)
    {
        var entityType = type.BaseType.GetGenericArguments().FirstOrDefault();

        var repositoryDataType = typeof(MockHybridRepositoryData<>).MakeGenericType(entityType);
        dynamic repositoryData = _serviceProvider.GetRequiredService(repositoryDataType);

        var tenantDbContext = GetOrCreateTenantDbContext();
        var result = ActivatorUtilities.CreateInstance(_serviceProvider, type, tenantDbContext, repositoryData);
        return result;
    }
}
