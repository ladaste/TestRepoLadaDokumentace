using ASOL.Core.Multitenancy;
using ASOL.Core.Multitenancy.MongoDb;
using ASOL.Core.Multitenancy.MongoDb.Extensions;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Persistence.MongoDb.Extensions;
using ASOL.Core.Persistence.MongoDb.Options;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Tests.Repositories;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace ASOL.PlatformStore.Store.Domain.Tests.Support;

internal static class ServiceCollectionExtensions
{
    public static IServiceCollection AddMockRepositories(this IServiceCollection services)
    {
        services.AddScoped(sp =>
        {
            var opt = new Moq.Mock<IOptions<MongoDbConnectionOptions>>();
            opt.SetupGet(r => r.Value).Returns(new MongoDbConnectionOptions
            {
            });

            var db = new Moq.Mock<ITenantDbContext>();
            db.SetupGet(r => r.DatabaseName).Returns(sp.GetRequiredService<ITenantContext>().TenantId);
            db.SetupGet(r => r.TenantContext).Returns(sp.GetRequiredService<ITenantContext>());
            return db.Object;
        });

        // data storage for repositories
        services.AddScoped<MockHybridRepositoryData<AllPurchasedAggregatedItem>>();

        services.AddScoped<IRepoFactory, MockRepoFactory>();
        services.AddScoped(typeof(IDbScopeSelector<>), typeof(DbScopeSelector<>));
        services.AddMongoDbApplicationInfo();

        // both tenant master access
        services.AddHybridRepositoryAccessor<IAllPurchasedAggregatedItemRepository, IAllPurchasedAggregatedItemReadOnlyRepository, MockAllPurchasedAggregatedItemRepository>();

        return services;
    }
}
