using System;
using System.Security.Claims;
using ASOL.Core.Identity;
using ASOL.Core.Identity.Contexts;
using ASOL.Core.Multitenancy;
using Microsoft.Extensions.DependencyInjection;

namespace ASOL.PlatformStore.Store.Domain.Tests.Support;

internal static class ServiceProviderHelper
{
    internal static IRuntimeContextScope CreateMasterScope(this IServiceProvider serviceProvider, ClaimsPrincipal user)
    {
        var scope = serviceProvider.GetRequiredService<IRuntimeContextScope>();

        var languageHolder = scope.ScopeProvider.GetRequiredService<ScopedContextHolder<ILocalizationContext>>();
        languageHolder.Context = new LocalizationContext(user);

        var securityHolder = scope.ScopeProvider.GetRequiredService<ScopedContextHolder<IRequestSecurityContext>>();
        securityHolder.Context = new RequestSecurityContext(user);

        var traceHolder = scope.ScopeProvider.GetRequiredService<ScopedContextHolder<ITraceContext>>();
        traceHolder.Context = new TraceContext("123");

        return scope;
    }

    internal static IServiceScope CreateTenantScope(this IServiceProvider serviceProvider, ClaimsPrincipal user)
    {
        var scope = serviceProvider.CreateScope();

        var tenantHolder = scope.ServiceProvider.GetRequiredService<ITenantContextHolder>();
        tenantHolder.TenantContext = CreateTestTenantContext(user.GetTenantId());

        var languageHolder = scope.ServiceProvider.GetRequiredService<ScopedContextHolder<ILocalizationContext>>();
        languageHolder.Context = new LocalizationContext(user);

        var securityHolder = scope.ServiceProvider.GetRequiredService<ScopedContextHolder<IRequestSecurityContext>>();
        securityHolder.Context = new RequestSecurityContext(user);

        var traceHolder = scope.ServiceProvider.GetRequiredService<ScopedContextHolder<ITraceContext>>();
        traceHolder.Context = new TraceContext("123");

        return scope;
    }

    internal static ClaimsPrincipal CreateClient(string clientId = "service", string tenantId = "Tests")
    {
        return ClaimsPrincipalBuilder.CreateClientPrincipal(clientId, tenantId)
            .AddAuthenticateType()
            .Build();
    }

    internal static ClaimsPrincipal CreateUser(string userId = "user", string tenantId = "Tests", string userName = "UNIT TEST USER")
    {
        return ClaimsPrincipalBuilder.CreateUserPrincipal(userId, tenantId, userName)
            .AddAuthenticateType()
            .Build();
    }

    public static ITenantContext CreateTestTenantContext(string tenantId = "Tests")
    {
        var tenantContext = new TenantContext { Tenant = new TenantInfo(tenantId, "test") };
        return tenantContext;
    }

    //Test runtime context with virtual test user
    public static IServiceCollection AddTestRuntimeContext(this IServiceCollection services)
    {
        services.AddSingleton<IRuntimeContext>(sp => new TestRuntimeContext());
        return services;
    }

    private sealed class TestRuntimeContext : IRuntimeContext
    {
        private ClaimsPrincipal FakeUser { get; } = ClaimsPrincipalBuilder
            .CreateUserPrincipal("account", "tenant", "user")
            .AddAuthenticateType("Platform")
            .AddLocale("en-US")
            .AddPersonId("person")
            .AddGivenName("tester")
            .AddSurname("tester")
            .Build();

        public ILocalizationContext Localization => throw new NotImplementedException();

        public ITraceContext Trace => throw new NotImplementedException();

        public IRequestSecurityContext Security => new RequestSecurityContext(FakeUser);
    }
}
