using System;
using System.Security.Claims;
using ASOL.Core.Identity.Extensions;
using ASOL.Core.Multitenancy.AspNetCore;
using ASOL.Core.Multitenancy.Extensions;
using ASOL.Core.Persistence;
using ASOL.Core.Processing;
using ASOL.Core.QA.TestSupport.Logging;
using ASOL.PlatformStore.Store.Domain.Events;
using ASOL.PlatformStore.Store.Domain.Queries;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using NSubstitute;
using Xunit.Abstractions;

namespace ASOL.PlatformStore.Store.Domain.Tests.Support;

public class TestBase
{
    protected ITestOutputHelper Output { get; }

    protected IServiceProvider ServiceProvider { get; }

    public TestBase(ITestOutputHelper output)
    {
        Output = output;

        var services = new ServiceCollection();
        ConfigureServices(services);
        ServiceProvider = services.BuildServiceProvider(true);

        var loggerFactory = ServiceProvider.GetRequiredService<ILoggerFactory>();
        loggerFactory.AddXUnit(output);
    }

    protected virtual void ConfigureServices(ServiceCollection services)
    {
        services.AddSingleton<ILoggerFactory, LoggerFactory>();
        services.AddLogging();
        services.AddMemoryCache();
        services.AddMultitenancyCore();
        services.AddRuntimeContexts();
        services.AddRuntimeContextScope<MultitenancyRuntimeContextScope>();
        services.AddMockRepositories();
        services
            .AddScoped(_ => Substitute.For<IUnitOfWork>())
            .AddScoped(_ => Substitute.For<IDomainEventCollector>());
    }

    protected static IServiceCollection AddProcessingQueryAndCommands(IServiceCollection services)
    {
        services.AddTransient(sp => sp.GetRequiredService<ILoggerFactory>().CreateLogger<CommandProcessor>());

        services.Scan(scan =>
        {
            scan.FromAssembliesOf(typeof(AggregateAllPurchasedDataCommand))
                .AddClasses(classes => classes.AssignableTo(typeof(ICommandHandler<,>)))
                    .AsImplementedInterfaces()
                    .WithTransientLifetime();
            scan.FromAssembliesOf(typeof(GetAllPurchasedDataQuery))
                .AddClasses(classes => classes.AssignableTo(typeof(IQueryHandler<,>)))
                    .AsImplementedInterfaces()
                    .WithTransientLifetime();
        });

        services.AddScoped<ICommandHandlerProvider, CommandHandlerProvider>();
        services.AddScoped<ICommandProcessor, CommandProcessor>();
        services.AddScoped<IQueryHandlerProvider, QueryHandlerProvider>();
        services.AddScoped<IQueryProcessor, QueryProcessor>();

        return services;
    }

    protected virtual void PrepareDefaultScopedData(IServiceProvider provider)
    {
    }

    protected IServiceScope CreateTenantScope(ClaimsPrincipal user)
    {
        var scope = ServiceProvider.CreateTenantScope(user);
        PrepareDefaultScopedData(scope.ServiceProvider);
        return scope;
    }
}
