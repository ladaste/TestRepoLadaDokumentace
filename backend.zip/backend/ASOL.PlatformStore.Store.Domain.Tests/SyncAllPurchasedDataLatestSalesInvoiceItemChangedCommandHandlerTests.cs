using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Processing;
using ASOL.Core.QA.TestSupport.ApiService;
using ASOL.PlatformStore.Store.Domain.CommandHandlers;
using ASOL.PlatformStore.Store.Domain.Tests.Support;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Xunit;
using Xunit.Abstractions;
using Shouldly;

namespace ASOL.PlatformStore.Store.Domain.Tests;

public class SyncAllPurchasedDataLatestSalesInvoiceItemChangedCommandHandlerTests(ITestOutputHelper output) : TestBase(output)
{
    #region supplementary stuff

    private ClaimsPrincipal User { get; } = ServiceProviderHelper.CreateUser();

    protected override void ConfigureServices(ServiceCollection services)
    {
        base.ConfigureServices(services);
        services.AddTransient(sp => sp.GetRequiredService<ILoggerFactory>().CreateLogger<SyncAllPurchasedDataLatestSalesInvoiceItemChangedCommandHandler>());
        services.AddTransient<SyncAllPurchasedDataLatestSalesInvoiceItemChangedCommandHandler>();
    }

    protected override void PrepareDefaultScopedData(IServiceProvider provider)
    {
        base.PrepareDefaultScopedData(provider);

        var allPurchasedAggregatedItems = provider.GetRequiredService<MockHybridRepositoryData<AllPurchasedAggregatedItem>>();
        var item = new AllPurchasedAggregatedItem(Guid.NewGuid().ToString(), User)
        {
            Licenses =
            [
                new()
                {
                    OrderLineId = "orderLineId",
                }
            ]
        };
        item.SetAsReleased(User);
        allPurchasedAggregatedItems.GetOrCreateMasterData().Add(item);
    }

    private static ICommandHandler<SyncAllPurchasedDataLatestSalesInvoiceItemChangedCommand, bool> GetCommandHandler(IServiceScope scope)
    {
        return scope.ServiceProvider.GetRequiredService<SyncAllPurchasedDataLatestSalesInvoiceItemChangedCommandHandler>();
    }

    #endregion

    [Fact]
    public async Task ValidateAsync_ShouldReturnErrors_WhenCommandIsInvalid()
    {
        // Arrange
        using var scope = CreateTenantScope(User);
        var command = new SyncAllPurchasedDataLatestSalesInvoiceItemChangedCommand(null, null, null, null, null, false);

        // Act
        var validationResult = await GetCommandHandler(scope).ValidateAsync(command, CancellationToken.None);

        // Assert
        validationResult.Succeeded.ShouldBeFalse();
        validationResult.Errors.ShouldContain(e => e.MemberNames.Contains(nameof(command.OrderNumber)));
        validationResult.Errors.ShouldContain(e => e.MemberNames.Contains(nameof(command.OrderLineId)));
    }

    [Fact]
    public async Task HandleAsync_ShouldUpdateLicenseAccrualDates_WhenCommandIsValid()
    {
        // Arrange
        using var scope = CreateTenantScope(User);
        var command = new SyncAllPurchasedDataLatestSalesInvoiceItemChangedCommand(
            "salesInvoiceItemId",
            "orderNumber",
            "orderLineId",
            DateTime.Now.AddDays(-5),
            DateTime.Now.AddDays(5),
            false
        );
        var handler = GetCommandHandler(scope);

        // Act
        var result = await handler.HandleAsync(command, CancellationToken.None);

        // Assert
        result.Value.ShouldBeTrue();

        var allPurchasedAggregatedItems = scope.ServiceProvider.GetRequiredService<MockHybridRepositoryData<AllPurchasedAggregatedItem>>();
        var updatedItem = allPurchasedAggregatedItems.GetOrCreateMasterData().Find(x => x.Licenses.Exists(l => l.OrderLineId == "orderLineId"));

        updatedItem.ShouldNotBeNull();
        var updatedLicense = updatedItem.Licenses.Find(l => l.OrderLineId == "orderLineId");
        updatedLicense.ShouldNotBeNull();
        updatedLicense.LatestInvoiceAccrualDateFrom.ShouldBe(command.AccrualDateFrom);
        updatedLicense.LatestInvoiceAccrualDateTo.ShouldBe(command.AccrualDateTo);
    }
}
