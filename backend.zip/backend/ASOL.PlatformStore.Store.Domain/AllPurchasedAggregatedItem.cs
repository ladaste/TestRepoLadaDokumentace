using System;
using System.Collections.Generic;
using System.Security.Claims;
using ASOL.Core.CustomAttributes.Domain.Entities.Definition;
using ASOL.Core.Domain;
using ASOL.Core.Localization;

namespace ASOL.PlatformStore.Store.Domain;

/// <summary>
/// Root entity for this domain.
/// </summary>
public class AllPurchasedAggregatedItem : BaseEntity<string>
{
    /// <summary>
    /// Constructor for serialize/deserialize. Don't use it directly.
    /// </summary>
    public AllPurchasedAggregatedItem()
    {
    }

    /// <summary>
    /// Initialize new <see cref="AllPurchasedAggregatedItem"/> entity instance with mandatory parameters.
    /// </summary>
    /// <param name="id">Unique identifier for this entity instance. It can be Guid.NewGuid() for example.</param>
    /// <param name="user">Current principal.</param>
    public AllPurchasedAggregatedItem(string id, ClaimsPrincipal user)
        : base(id, user)
    {
    }

    public string TenantId { get; set; }

    public string ProductCatalogId { get; set; }

    public string SolutionPackageName { get; set; }

    public string SolutionPackageCode { get; set; }

    public string EditionCode { get; set; }

    public string EditionName { get; set; }

    public string ApplicationCode { get; set; }

    public LocalizedValue<string> Name { get; set; }

    public string OrderNumber { get; set; }

    public DateTime? ApprovedByCustomerOn { get; set; }

    public LocalizedValue<string> ShortDescription { get; set; }

    public string CardImageId { get; set; }

    public string FrontendUrl { get; set; }

    public string BackendUrl { get; set; }

    public bool HasAccesibleByRole { get; set; }

    public string OranizationRelationshipId { get; set; }

    public string OrganizationRelationshipDataId { get; set; }

    public string TenantSolutionPartnerId { get; set; }

    public string TenantSolutionPartnerName { get; set; }

    public string ApplicationSolutionPartnerId { get; set; }

    public string ApplicationSolutionPartnerName { get; set; }

    public string DevelopmentPartnerId { get; set; }

    public string DevelopmentPartnerName { get; set; }

    public string CustomerId { get; set; }

    public string CustomerName { get; set; }

    public string BillingPeriod { get; set; }

    public string Status { get; set; }

    public DateTime? DateOfStatus { get; set; }

    public DateTime? OrderDate { get; set; }

    public DateTime? LicenseModifiedOn { get; set; }

    public DateTime? DateOfEndedLicense { get; set; }

    public Category Category { get; set; }

    public List<Category> IntegrationCategories { get; set; }

    public List<License> Licenses { get; set; }

    public string StatusDescription { get; set; }

    public string AllowedOperation { get; set; }

    public bool IsSourceLicense { get; set; }

    public bool Published { get; set; }
}
