using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Identity;
using ASOL.Core.Persistence;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Domain.Queries;
using ASOL.PlatformStore.Store.Domain.Services.AllPurchased;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.Domain.CommandHandlers;

public class AggregateAllPurchasedDataCommandHandler(
    ILogger<AggregateAllPurchasedDataCommandHandler> logger,
    IRuntimeContext context,
    ISyncAllPurchasedDataService syncAllPurchasedDataService,
    IUnitOfWork unitOfWork) : ICommandHandler<AggregateAllPurchasedDataCommand, bool>
{
    protected ILogger<AggregateAllPurchasedDataCommandHandler> Logger { get; } = logger;
    protected IRuntimeContext Context { get; } = context;
    protected ISyncAllPurchasedDataService SyncAllPurchasedDataService { get; } = syncAllPurchasedDataService;
    protected IUnitOfWork UnitOfWork { get; } = unitOfWork;

    public async Task<ExecutionResult<bool>> HandleAsync(AggregateAllPurchasedDataCommand command, CancellationToken ct = default)
    {
        await SyncAllPurchasedDataService.SyncAllPurchasedData(SyncTriggerType.Global, command.RequestId.ToString(), ct: ct);
        await UnitOfWork.CompleteAsync(ct);
        return new ExecutionResult<bool>(true);
    }

    public Task<ValidationResult> ValidateAsync(AggregateAllPurchasedDataCommand command, CancellationToken ct = default)
    {
        var errors = new List<ValidationError>();

        return errors.Count != 0
            ? Task.FromResult(new ValidationResult(errors))
            : ValidationResult.SuccessfulResultTask;
    }
}
