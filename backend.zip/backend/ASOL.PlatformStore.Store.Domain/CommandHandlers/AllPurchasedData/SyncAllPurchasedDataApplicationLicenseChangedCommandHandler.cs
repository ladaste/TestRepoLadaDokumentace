using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Identity;
using ASOL.Core.Persistence;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Domain.Queries;
using ASOL.PlatformStore.Store.Domain.Resources;
using ASOL.PlatformStore.Store.Domain.Services.AllPurchased;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.Domain.CommandHandlers;

public class SyncAllPurchasedDataApplicationLicenseChangedCommandHandler(
    ILogger<SyncAllPurchasedDataApplicationLicenseChangedCommandHandler> logger,
    IRuntimeContext context,
    ISyncAllPurchasedDataService syncAllPurchasedDataService,
    IUnitOfWork unitOfWork
        ) : ICommandHandler<SyncAllPurchasedDataApplicationLicenseChangedCommand, bool>
{
    protected ILogger<SyncAllPurchasedDataApplicationLicenseChangedCommandHandler> Logger { get; } = logger;
    protected IRuntimeContext Context { get; } = context;
    protected ISyncAllPurchasedDataService SyncAllPurchasedDataService { get; } = syncAllPurchasedDataService;
    protected IUnitOfWork UnitOfWork { get; } = unitOfWork;

    public async Task<ExecutionResult<bool>> HandleAsync(SyncAllPurchasedDataApplicationLicenseChangedCommand command, CancellationToken ct = default)
    {
        await SyncAllPurchasedDataService.SyncAllPurchasedData(SyncTriggerType.ApplicationLicenseChanged, Guid.NewGuid().ToString(), command.LicenseId, command.ApplicationCode, command.EditionCode, ct: ct);

        await UnitOfWork.CompleteAsync(ct);
        return new ExecutionResult<bool>(true);
    }

    public Task<ValidationResult> ValidateAsync(SyncAllPurchasedDataApplicationLicenseChangedCommand command, CancellationToken ct = default)
    {
        var errors = new List<ValidationError>();

        if (string.IsNullOrWhiteSpace(command.LicenseId))
        {
            Logger.LogError($"{nameof(SyncAllPurchasedDataApplicationLicenseChangedCommandHandler)}: LicenseId '{command.LicenseId}' can not be null.");
            errors.Add(new ValidationError
            {
                Message = string.Format(ValidationResultMessages.InvalidOrMissingId, nameof(command.LicenseId)),
                MemberNames = [nameof(command.LicenseId)]
            });
        }

        if (string.IsNullOrWhiteSpace(command.ApplicationCode))
        {
            Logger.LogError($"{nameof(SyncAllPurchasedDataApplicationLicenseChangedCommandHandler)}: ApplicationCode '{command.ApplicationCode}' can not be null.");
            errors.Add(new ValidationError
            {
                Message = string.Format(ValidationResultMessages.InvalidOrMissingValue, nameof(command.ApplicationCode)),
                MemberNames = [nameof(command.ApplicationCode)]
            });
        }

        if (string.IsNullOrWhiteSpace(command.EditionCode))
        {
            Logger.LogError($"{nameof(SyncAllPurchasedDataApplicationLicenseChangedCommandHandler)}: EditionCode '{command.EditionCode}' can not be null.");
            errors.Add(new ValidationError
            {
                Message = string.Format(ValidationResultMessages.InvalidOrMissingValue, nameof(command.EditionCode)),
                MemberNames = [nameof(command.EditionCode)]
            });
        }

        return errors.Count != 0
            ? Task.FromResult(new ValidationResult(errors))
            : ValidationResult.SuccessfulResultTask;
    }
}
