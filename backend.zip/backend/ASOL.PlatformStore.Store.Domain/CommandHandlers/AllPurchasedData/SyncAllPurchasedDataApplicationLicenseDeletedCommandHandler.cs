using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Identity;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Persistence;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Resources;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.Domain.CommandHandlers;

public class SyncAllPurchasedDataApplicationLicenseDeletedCommandHandler(
    ILogger<SyncAllPurchasedDataApplicationLicenseDeletedCommandHandler> logger,
    IRuntimeContext runtimeContext,
    IDbScopeSelector<IAllPurchasedAggregatedItemRepository> allPurchasedAggregatedItems,
    IUnitOfWork unitOfWork) : ICommandHandler<SyncAllPurchasedDataApplicationLicenseDeletedCommand, bool>
{
    protected ILogger Logger { get; } = logger;
    protected IRuntimeContext RuntimeContext { get; } = runtimeContext;
    protected IDbScopeSelector<IAllPurchasedAggregatedItemRepository> AllPurchasedAggregatedItems { get; } = allPurchasedAggregatedItems;
    protected IUnitOfWork UnitOfWork { get; } = unitOfWork;

    public async Task<ExecutionResult<bool>> HandleAsync(SyncAllPurchasedDataApplicationLicenseDeletedCommand command, CancellationToken ct = default)
    {
        Logger.LogInformation($"Processing deletion of {nameof(AllPurchasedAggregatedItem)} in tenant '{command.TenantId}', licenses are being deleted for application with code '{command.ApplicationCode}'.");

        var items = AllPurchasedAggregatedItems
            .GetRepository(DataAccessLevel.Public)
            .Get(r => r.ApplicationCode == command.ApplicationCode
                      && r.EditionCode == command.EditionCode
                      && r.TenantId == command.TenantId);

        foreach (var item in items)
        {
            item.Licenses.RemoveAll(i => i.LicenseId == command.LicenseId);

            if (item.Licenses.Count != 0)
            {
                item.Touched(RuntimeContext.Security.User);
                await AllPurchasedAggregatedItems.GetRepository(DataAccessLevel.Public).UpdateAsync(item, ct);

                Logger.LogInformation($"{nameof(AllPurchasedAggregatedItem)} {item.Id} has been updated.");
            }
            else
            {
                item.MarkAsDeleted(RuntimeContext.Security.User);
                await AllPurchasedAggregatedItems.GetRepository(DataAccessLevel.Public).UpdateAsync(item, ct);

                Logger.LogInformation($"{nameof(AllPurchasedAggregatedItem)} {item.Id} marked as deleted.");
            }
        }

        await UnitOfWork.CompleteAsync(ct);
        return new ExecutionResult<bool>(true);
    }

    public Task<ValidationResult> ValidateAsync(SyncAllPurchasedDataApplicationLicenseDeletedCommand command, CancellationToken ct = default)
    {
        var errors = new List<ValidationError>();

        if (string.IsNullOrWhiteSpace(command.LicenseId))
        {
            Logger.LogError($"{nameof(SyncAllPurchasedDataApplicationLicenseDeletedCommandHandler)}: LicenseId '{command.LicenseId}' can not be null.");
            errors.Add(new ValidationError
            {
                Message = string.Format(ValidationResultMessages.InvalidOrMissingId, nameof(command.LicenseId)),
                MemberNames = [nameof(command.LicenseId)]
            });
        }

        if (string.IsNullOrWhiteSpace(command.ApplicationCode))
        {
            Logger.LogError($"{nameof(SyncAllPurchasedDataApplicationLicenseDeletedCommandHandler)}: ApplicationCode '{command.ApplicationCode}' can not be null.");
            errors.Add(new ValidationError
            {
                Message = string.Format(ValidationResultMessages.InvalidOrMissingValue, nameof(command.ApplicationCode)),
                MemberNames = [nameof(command.ApplicationCode)]
            });
        }

        if (string.IsNullOrWhiteSpace(command.EditionCode))
        {
            Logger.LogError($"{nameof(SyncAllPurchasedDataApplicationLicenseDeletedCommandHandler)}: EditionCode '{command.EditionCode}' can not be null.");
            errors.Add(new ValidationError
            {
                Message = string.Format(ValidationResultMessages.InvalidOrMissingValue, nameof(command.EditionCode)),
                MemberNames = [nameof(command.EditionCode)]
            });
        }

        if (string.IsNullOrWhiteSpace(command.TenantId))
        {
            Logger.LogError($"{nameof(SyncAllPurchasedDataApplicationLicenseDeletedCommandHandler)}: TenantId '{command.TenantId}' can not be null.");
            errors.Add(new ValidationError
            {
                Message = string.Format(ValidationResultMessages.InvalidOrMissingValue, nameof(command.TenantId)),
                MemberNames = [nameof(command.TenantId)]
            });
        }

        return errors.Count != 0
            ? Task.FromResult(new ValidationResult(errors))
            : ValidationResult.SuccessfulResultTask;
    }
}
