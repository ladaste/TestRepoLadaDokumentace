using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Domain;
using ASOL.Core.Domain.Contracts;
using ASOL.Core.Identity;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Persistence;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Resources;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.Domain.CommandHandlers;

/// <summary>
/// Command handler to synchronize all purchased data when the latest sales invoice item has been changed.
/// </summary>
public class SyncAllPurchasedDataLatestSalesInvoiceItemChangedCommandHandler(
    ILogger<SyncAllPurchasedDataLatestSalesInvoiceItemChangedCommandHandler> logger,
    IRuntimeContext runtimeContext,
    IDbScopeSelector<IAllPurchasedAggregatedItemRepository> allPurchasedAggregatedItems,
    IUnitOfWork unitOfWork) : ICommandHandler<SyncAllPurchasedDataLatestSalesInvoiceItemChangedCommand, bool>
{
    protected ILogger Logger { get; } = logger;

    protected IRuntimeContext RuntimeContext { get; } = runtimeContext;

    protected IDbScopeSelector<IAllPurchasedAggregatedItemRepository> AllPurchasedAggregatedItems { get; } = allPurchasedAggregatedItems;

    protected IUnitOfWork UnitOfWork { get; } = unitOfWork;

    public async Task<ExecutionResult<bool>> HandleAsync(SyncAllPurchasedDataLatestSalesInvoiceItemChangedCommand command, CancellationToken ct)
    {

        var items = AllPurchasedAggregatedItems
            .GetRepository(DataAccessLevel.Public)
            .GetAll()
            .Where(r => r.Licenses != null && r.Licenses.Any(i => i.OrderLineId == command.OrderLineId))
            .ApplyBaseEntityFilter(BaseEntityFilter.Default)
            .ToList();

        foreach (var item in items)
        {
            foreach (var license in item.Licenses.Where(i => i.OrderLineId == command.OrderLineId))
            {
                license.LatestInvoiceAccrualDateFrom = command.AccrualDateFrom;
                license.LatestInvoiceAccrualDateTo = command.AccrualDateTo;
                license.IsFree = command.IsFree;

                Logger.LogInformation($"Update of {nameof(AllPurchasedAggregatedItem)} for tenant '{item.TenantId}', accrual date of {nameof(license.OrderLineId)} '{license.OrderLineId}' has been changed in the application with code '{item.ApplicationCode}'.");
            }

            item.Touched(RuntimeContext.Security.User);

            await AllPurchasedAggregatedItems
                .GetRepository(DataAccessLevel.Public)
                .UpdateAsync(item, ct);
        }

        await UnitOfWork.CompleteAsync(ct);
        return new ExecutionResult<bool>(true);
    }

    public Task<ValidationResult> ValidateAsync(SyncAllPurchasedDataLatestSalesInvoiceItemChangedCommand command, CancellationToken ct)
    {
        var errors = new List<ValidationError>();

        if (string.IsNullOrWhiteSpace(command.OrderNumber))
        {
            Logger.LogError($"{nameof(SyncAllPurchasedDataLatestSalesInvoiceItemChangedCommandHandler)}: {nameof(command.OrderNumber)} can not be null.");
            errors.Add(new ValidationError
            {
                Message = string.Format(ValidationResultMessages.InvalidOrMissingValue, nameof(command.OrderNumber)),
                MemberNames = [nameof(command.OrderNumber)]
            });
        }

        if (string.IsNullOrWhiteSpace(command.OrderLineId))
        {
            Logger.LogError($"{nameof(SyncAllPurchasedDataLatestSalesInvoiceItemChangedCommandHandler)}: {nameof(command.OrderLineId)} can not be null.");
            errors.Add(new ValidationError
            {
                Message = string.Format(ValidationResultMessages.InvalidOrMissingId, nameof(command.OrderLineId)),
                MemberNames = [nameof(command.OrderLineId)]
            });
        }

        return errors.Count != 0
            ? Task.FromResult(new ValidationResult(errors))
            : ValidationResult.SuccessfulResultTask;
    }
}
