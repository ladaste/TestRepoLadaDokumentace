using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Identity;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Persistence;
using ASOL.Core.Processing;
using ASOL.IdentityManager.Connector;
using ASOL.PlatformStore.Store.Domain.Consts;
using ASOL.PlatformStore.Store.Domain.Queries;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Resources;
using ASOL.PlatformStore.Store.Domain.Services.AllPurchased;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.Domain.CommandHandlers;

public class SyncAllPurchasedDataLicenseRoleMemberChangedCommandHandler(
    ILogger<SyncAllPurchasedDataLicenseRoleMemberChangedCommandHandler> logger,
    IRuntimeContext context,
    IDbScopeSelector<IAllPurchasedAggregatedItemRepository> allPurchasedAggregatedItems,
    ISyncAllPurchasedDataService syncAllPurchasedDataService,
    IIdentityManagerClient identityManagerClient,
    IUnitOfWork unitOfWork
        ) : ICommandHandler<SyncAllPurchasedDataLicenseRoleMemberChangedCommand, bool>
{
    protected ILogger<SyncAllPurchasedDataLicenseRoleMemberChangedCommandHandler> Logger { get; } = logger;
    protected IRuntimeContext Context { get; } = context;
    protected IAllPurchasedAggregatedItemRepository AllPurchasedAggregatedItems { get; } = allPurchasedAggregatedItems.GetRepository(DataAccessLevel.Public);
    protected ISyncAllPurchasedDataService SyncAllPurchasedDataService { get; } = syncAllPurchasedDataService;
    protected IIdentityManagerClient IdentityManagerClient { get; } = identityManagerClient;
    protected IUnitOfWork UnitOfWork { get; } = unitOfWork;

    public async Task<ExecutionResult<bool>> HandleAsync(SyncAllPurchasedDataLicenseRoleMemberChangedCommand command, CancellationToken ct = default)
    {
        Logger.LogInformation($"Starting sync of AllPurchasedData for licenseId {command.LicenseId}, roleCode: '{command.RoleCode}'.");

        var allPurchasedAggregatedItem = AllPurchasedAggregatedItems
            .Get(x => x.Licenses.Any(y => y.LicenseId == command.LicenseId)
                && x.TenantId == Context.Security.TenantId
                && !x.Deleted)
            .FirstOrDefault();
        if (allPurchasedAggregatedItem is null)
        {
            return ExecutionResult<bool>.Skipped;
        }

        var licenseModel = await IdentityManagerClient.Licenses
            .GetByIdAsync(command.LicenseId, ct);

        if (licenseModel == null)
        {
            Logger.LogError($"License with Id '{command.LicenseId}' can not be found.");
            return new ExecutionResult<bool>(false);
        }

        var includedLincese = allPurchasedAggregatedItem.Licenses
            .FirstOrDefault(x => x.LicenseId == command.LicenseId);

        includedLincese.Code = licenseModel.Code;
        includedLincese.OrderNumber = licenseModel.OrderNumber;
        includedLincese.OrderLineId = licenseModel.OrderLineId;
        includedLincese.FormatVersion = licenseModel.FormatVersion;
        includedLincese.Role = licenseModel.Role == null
            ? null
            : new LicenseRole
            {
                RoleCode = licenseModel.Role.RoleCode,
                RoleName = licenseModel.Role.RoleName,
                IsTrial = licenseModel.Role.IsTrial,
                UserMaxCount = licenseModel.Role.UserMaxCount,
                UserCount = licenseModel.Role.UserCount,
            };
        includedLincese.Status = licenseModel.Status;
        includedLincese.ValidFrom = licenseModel.ValidFrom;
        includedLincese.ValidTo = licenseModel.ValidTo;

        var allowedOperations = new List<string>();

        if (allPurchasedAggregatedItem.AllowedOperation != StoreItemAllowedOperation.Create)
        {
            foreach (var item in allPurchasedAggregatedItem.Licenses)
            {
                if (item.ValidFrom is null)
                {
                    continue;
                }

                var durationInMonths =
                    ((DateTime.UtcNow.Year - item.ValidFrom.Value.Year) * 12) +
                    DateTime.UtcNow.Month - item.ValidFrom.Value.Month;

                if (durationInMonths >= 1)
                {
                    if (allPurchasedAggregatedItem.BillingPeriod == PeriodTypes.Yearly)
                    {
                        if (durationInMonths >= 11)
                        {
                            allowedOperations.Add(StoreItemAllowedOperation.Create);
                        }
                        else
                        {
                            allowedOperations.Add(StoreItemAllowedOperation.Modify);
                        }
                    }
                    else
                    {
                        allowedOperations.Add(StoreItemAllowedOperation.Create);
                    }
                }

                if (allowedOperations.Any(x => x == StoreItemAllowedOperation.Create))
                {
                    allPurchasedAggregatedItem.AllowedOperation = StoreItemAllowedOperation.Create;
                }
                else if (allowedOperations.Any(x => x == StoreItemAllowedOperation.Modify))
                {
                    allPurchasedAggregatedItem.AllowedOperation = StoreItemAllowedOperation.Modify;
                }
                else
                {
                    allPurchasedAggregatedItem.AllowedOperation = StoreItemAllowedOperation.None;
                }
            }
        }

        await AllPurchasedAggregatedItems.UpdateAsync(allPurchasedAggregatedItem, ct);
        await UnitOfWork.CompleteAsync(ct);
        return new ExecutionResult<bool>(true);
    }

    public Task<ValidationResult> ValidateAsync(SyncAllPurchasedDataLicenseRoleMemberChangedCommand command, CancellationToken ct = default)
    {
        var errors = new List<ValidationError>();

        if (string.IsNullOrWhiteSpace(command.LicenseId))
        {
            Logger.LogError($"{nameof(SyncAllPurchasedDataLicenseRoleMemberChangedCommandHandler)}: LicenseId '{command.LicenseId}' can not be null.");
            errors.Add(new ValidationError
            {
                Message = string.Format(ValidationResultMessages.InvalidOrMissingId, nameof(command.LicenseId)),
                MemberNames = [nameof(command.LicenseId)]
            });
        }

        return errors.Count != 0
            ? Task.FromResult(new ValidationResult(errors))
            : ValidationResult.SuccessfulResultTask;
    }
}
