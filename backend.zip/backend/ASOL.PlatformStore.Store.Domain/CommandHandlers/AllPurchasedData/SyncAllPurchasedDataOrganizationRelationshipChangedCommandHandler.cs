using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Identity;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Persistence;
using ASOL.Core.Processing;
using ASOL.IdentityProvider.Connector;
using ASOL.IdentityProvider.Contracts.Filters;
using ASOL.PlatformStore.Store.Domain.Queries;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Resources;
using ASOL.PlatformStore.Store.Domain.Services;
using ASOL.PlatformStore.Store.Domain.Services.AllPurchased;
using ASOL.SubjectManager.Connector;
using ASOL.SubjectManager.Contracts.Model;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.Domain.CommandHandlers;

public class SyncAllPurchasedDataOrganizationRelationshipChangedCommandHandler(
    ILogger<SyncAllPurchasedDataOrganizationRelationshipChangedCommandHandler> logger,
    IRuntimeContext context,
    IDbScopeSelector<IAllPurchasedAggregatedItemRepository> allPurchasedAggregatedItems,
    ISyncAllPurchasedDataService syncAllPurchasedDataService,
    IImpersonateService impersonateService
        ) : ICommandHandler<SyncAllPurchasedDataOrganizationRelationshipChangedCommand, bool>
{
    protected ILogger<SyncAllPurchasedDataOrganizationRelationshipChangedCommandHandler> Logger { get; } = logger;
    protected IRuntimeContext Context { get; } = context;
    protected IAllPurchasedAggregatedItemRepository AllPurchasedAggregatedItems { get; } = allPurchasedAggregatedItems.GetRepository(DataAccessLevel.Public);
    protected ISyncAllPurchasedDataService SyncAllPurchasedDataService { get; } = syncAllPurchasedDataService;
    protected IImpersonateService ImpersonateService { get; } = impersonateService;
    private Dictionary<string, OrganizationModel> Organizations { get; set; }
    private Dictionary<string, List<OrganizationRelationshipModel>> OrganizationRelationshipModels { get; set; }

    private const string TENANT_SOLUTION_PARTNER_CODE = "Platform";

    public async Task<ExecutionResult<bool>> HandleAsync(SyncAllPurchasedDataOrganizationRelationshipChangedCommand command, CancellationToken ct = default)
    {
        var requestId = Guid.NewGuid().ToString();
        Logger.LogInformation($"{nameof(SyncAllPurchasedDataOrganizationRelationshipChangedCommandHandler)}-RequestId: '{requestId}'. Starting sync of AllPurchasedData based on OrganizationRelationshipId {command.OrganizationRelationshipId}.");

        try
        {
            using (var scope = ImpersonateService.GetImpersonatedContext())
            {
                var idpClient = scope.ScopeProvider.GetRequiredService<IIdentityProviderClient>();
                var idmsmClient = scope.ScopeProvider.GetRequiredService<ISubjectManagerClient>();
                var spaceOwnerOrg = await idmsmClient.GetSpaceOwnerOrganizationAsync(false, ct);
                var spaceOwnerTenantId = spaceOwnerOrg.SpaceOwnerTenantId;

                var oranizationRelationship = await idmsmClient.OrganizationRelationships.GetOrganizationRelationshipByIdAsync(DataAccessLevel.Public, command.OrganizationRelationshipId, true, ct);
                var organizationCode = oranizationRelationship.ChildOrganizationCode;

                var tenantFilter = new TenantFilter()
                {
                    OrganizationCode = organizationCode
                };

                var tenants = await idpClient.Tenants.GetTenantsAsync(tenantFilter, ct);
                var tenant = tenants.Items.FirstOrDefault();

                var allPurchasedItems = AllPurchasedAggregatedItems
                    .Get(x => x.TenantId == tenant.Id && !x.Deleted)
                    .ToList();

                using (var spaceOwnerScope = ImpersonateService.GetTenantContext(spaceOwnerTenantId))
                {
                    if (allPurchasedItems != null && allPurchasedItems.Count != 0)
                    {
                        foreach (var allPurchasedItem in allPurchasedItems)
                        {
                            Organizations ??= [];

                            foreach (var data in oranizationRelationship.Data)
                            {
                                if (data.GetType() == typeof(OrganizationRelationshipSolutionPartnerDataModel))
                                {
                                    var model = (OrganizationRelationshipSolutionPartnerDataModel)data;

                                    if (string.IsNullOrWhiteSpace(allPurchasedItem.ApplicationSolutionPartnerId) && model.ApplicationCode == allPurchasedItem.ApplicationCode)
                                    {
                                        if (!Organizations.TryGetValue(oranizationRelationship.ParentOrganizationId, out var organization))
                                        {
                                            // the key isn't in the dictionary.
                                            organization = await idmsmClient.GetOrganizationByIdAsync(oranizationRelationship.ParentOrganizationId, false, DataAccessLevel.Public, false, ct);
                                            if (organization == null)
                                            {
                                                Logger.LogError($"{nameof(SyncAllPurchasedDataOrganizationRelationshipChangedCommandHandler)}-RequestId: '{requestId}'. Parent Organization with Id '{oranizationRelationship.ParentOrganizationId}' does not exist.");
                                                continue;
                                            }
                                            Organizations.Add(organization.Id, organization);
                                        }

                                        allPurchasedItem.OrganizationRelationshipDataId = data.Id;

                                        allPurchasedItem.ApplicationSolutionPartnerId = organization.Id;
                                        allPurchasedItem.ApplicationSolutionPartnerName = organization.Name;
                                    }
                                    else if (string.IsNullOrWhiteSpace(allPurchasedItem.TenantSolutionPartnerId) && model.ApplicationCode == TENANT_SOLUTION_PARTNER_CODE)
                                    {
                                        if (!Organizations.TryGetValue(oranizationRelationship.ParentOrganizationId, out var organization))
                                        {
                                            // the key isn't in the dictionary.
                                            organization = await idmsmClient.GetOrganizationByIdAsync(oranizationRelationship.ParentOrganizationId, false, DataAccessLevel.Public, false, ct);
                                            if (organization == null)
                                            {
                                                Logger.LogError($"{nameof(SyncAllPurchasedDataOrganizationRelationshipChangedCommandHandler)}-RequestId: '{requestId}'. Organization with Id '{oranizationRelationship.ParentOrganizationId}' does not exist.");
                                                continue;
                                            }
                                            Organizations.Add(organization.Id, organization);
                                        }

                                        allPurchasedItem.OrganizationRelationshipDataId = data.Id;

                                        allPurchasedItem.TenantSolutionPartnerId = organization.Id;
                                        allPurchasedItem.TenantSolutionPartnerName = organization.Name;
                                    }
                                }

                                if (!string.IsNullOrWhiteSpace(allPurchasedItem.ApplicationSolutionPartnerId) &&
                                    !string.IsNullOrWhiteSpace(allPurchasedItem.TenantSolutionPartnerId))
                                {
                                    break;
                                }
                            }

                            allPurchasedItem.Touched(Context.Security.User);
                            await AllPurchasedAggregatedItems.UpdateAsync(allPurchasedItem, ct);
                        }

                        var unitOfWork = spaceOwnerScope.ScopeProvider.GetRequiredService<IUnitOfWork>();
                        await unitOfWork.CompleteAsync(ct);
                    }
                    else
                    {
                        using (var tenatScope = ImpersonateService.GetTenantContext(tenant.Id))
                        {
                            var syncAllPurchasedDataService = tenatScope.ScopeProvider.GetRequiredService<ISyncAllPurchasedDataService>();

                            await syncAllPurchasedDataService
                                .SyncAllPurchasedData(SyncTriggerType.OrganizationRelationshipChanged, requestId, ct: ct);

                            var unitOfWork = tenatScope.ScopeProvider.GetRequiredService<IUnitOfWork>();
                            await unitOfWork.CompleteAsync(ct);
                        }
                    }
                }
            }

            return new ExecutionResult<bool>(true);
        }
        catch (Exception ex)
        {
            Logger.LogError($"{nameof(SyncAllPurchasedDataOrganizationRelationshipChangedCommandHandler)}-RequestId: '{requestId}'. Exception thrown {ex.Message}.");
            return new ExecutionResult<bool>(false);
        }
    }

    public Task<ValidationResult> ValidateAsync(SyncAllPurchasedDataOrganizationRelationshipChangedCommand command, CancellationToken ct = default)
    {
        var errors = new List<ValidationError>();

        if (string.IsNullOrWhiteSpace(command.OrganizationRelationshipId))
        {
            Logger.LogError($"{nameof(SyncAllPurchasedDataOrganizationRelationshipChangedCommandHandler)}: OrganizationRelationship with Id '{command.OrganizationRelationshipId}' can not be null.");
            errors.Add(new ValidationError
            {
                Message = string.Format(ValidationResultMessages.InvalidOrMissingId, nameof(command.OrganizationRelationshipId)),
                MemberNames = [nameof(command.OrganizationRelationshipId)]
            });
        }

        return errors.Count != 0
            ? Task.FromResult(new ValidationResult(errors))
            : ValidationResult.SuccessfulResultTask;
    }
}
