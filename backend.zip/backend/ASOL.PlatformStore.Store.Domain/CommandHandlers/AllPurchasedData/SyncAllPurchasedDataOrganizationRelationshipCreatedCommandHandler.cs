using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Identity;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Persistence;
using ASOL.Core.Processing;
using ASOL.IdentityProvider.Connector;
using ASOL.IdentityProvider.Contracts.Filters;
using ASOL.PlatformStore.Store.Domain.Queries;
using ASOL.PlatformStore.Store.Domain.Resources;
using ASOL.PlatformStore.Store.Domain.Services;
using ASOL.PlatformStore.Store.Domain.Services.AllPurchased;
using ASOL.SubjectManager.Connector;
using ASOL.SubjectManager.Contracts.Model;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.Domain.CommandHandlers;

public class SyncAllPurchasedDataOrganizationRelationshipCreatedCommandHandler(
    ILogger<SyncAllPurchasedDataOrganizationRelationshipCreatedCommandHandler> logger,
    IRuntimeContext context,
    ISyncAllPurchasedDataService syncAllPurchasedDataService,
    IImpersonateService impersonateService
        ) : ICommandHandler<SyncAllPurchasedDataOrganizationRelationshipCreatedCommand, bool>
{
    protected ILogger<SyncAllPurchasedDataOrganizationRelationshipCreatedCommandHandler> Logger { get; } = logger;
    protected IRuntimeContext Context { get; } = context;
    protected ISyncAllPurchasedDataService SyncAllPurchasedDataService { get; } = syncAllPurchasedDataService;
    protected IImpersonateService ImpersonateService { get; } = impersonateService;

    private Dictionary<string, OrganizationModel> Organizations { get; set; }
    private Dictionary<string, List<OrganizationRelationshipModel>> OrganizationRelationshipModels { get; set; }

    private const string TENANT_SOLUTION_PARTNER_CODE = "Platform";

    public async Task<ExecutionResult<bool>> HandleAsync(SyncAllPurchasedDataOrganizationRelationshipCreatedCommand command, CancellationToken ct = default)
    {
        var requestId = Guid.NewGuid().ToString();
        Logger.LogInformation($"{nameof(SyncAllPurchasedDataOrganizationRelationshipCreatedCommandHandler)}-RequestId: '{requestId}'. Starting sync of AllPurchasedData based on OrganizationRelationshipId {command.OrganizationRelationshipId}.");

        using (var scope = ImpersonateService.GetImpersonatedContext())
        {
            var idmsClient = scope.ScopeProvider.GetRequiredService<ISubjectManagerClient>();
            var idpClient = scope.ScopeProvider.GetRequiredService<IIdentityProviderClient>();

            var oranizationRelationship = await idmsClient.OrganizationRelationships.GetOrganizationRelationshipByIdAsync(DataAccessLevel.Public, command.OrganizationRelationshipId, true, ct);
            var organizationCode = oranizationRelationship.ChildOrganizationCode;

            var tenantFilter = new TenantFilter()
            {
                OrganizationCode = organizationCode
            };

            var tenants = await idpClient.Tenants.GetTenantsAsync(tenantFilter, ct);
            var tenant = tenants.Items.FirstOrDefault();

            using (var tenatScope = ImpersonateService.GetTenantContext(tenant.Id))
            {
                var syncAllPurchasedDataService = tenatScope.ScopeProvider.GetRequiredService<ISyncAllPurchasedDataService>();

                await syncAllPurchasedDataService
                    .SyncAllPurchasedData(SyncTriggerType.OrganizationRelationshipCreated, requestId, ct: ct);

                var unitOfWork = tenatScope.ScopeProvider.GetRequiredService<IUnitOfWork>();
                await unitOfWork.CompleteAsync(ct);
            }
        }


        return new ExecutionResult<bool>(true);
    }

    public Task<ValidationResult> ValidateAsync(SyncAllPurchasedDataOrganizationRelationshipCreatedCommand command, CancellationToken ct = default)
    {
        var errors = new List<ValidationError>();

        if (string.IsNullOrWhiteSpace(command.OrganizationRelationshipId))
        {
            Logger.LogError($"{nameof(SyncAllPurchasedDataOrganizationRelationshipCreatedCommandHandler)}: OrganizationRelationship with Id '{command.OrganizationRelationshipId}' can not be null.");
            errors.Add(new ValidationError
            {
                Message = string.Format(ValidationResultMessages.InvalidOrMissingId, nameof(command.OrganizationRelationshipId)),
                MemberNames = [nameof(command.OrganizationRelationshipId)]
            });
        }

        if (command.AccessLevel != DataAccessLevel.Public)
        {
            Logger.LogInformation($"{nameof(SyncAllPurchasedDataOrganizationRelationshipCreatedCommandHandler)}: OrganizationRelationship with Id '{command.OrganizationRelationshipId}' has to by public to trigger sync.");
        }

        return errors.Count != 0
            ? Task.FromResult(new ValidationResult(errors))
            : ValidationResult.SuccessfulResultTask;
    }
}
