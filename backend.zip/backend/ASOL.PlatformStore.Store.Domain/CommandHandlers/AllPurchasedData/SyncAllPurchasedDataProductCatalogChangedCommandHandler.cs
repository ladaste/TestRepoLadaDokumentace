using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Identity;
using ASOL.Core.Localization;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Persistence;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Domain.Extensions;
using ASOL.PlatformStore.Store.Domain.Helpers;
using ASOL.PlatformStore.Store.Domain.Options;
using ASOL.PlatformStore.Store.Domain.Queries;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Resources;
using ASOL.PlatformStore.Store.Domain.Services.AllPurchased;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace ASOL.PlatformStore.Store.Domain.CommandHandlers;

public class SyncAllPurchasedDataProductCatalogChangedCommandHandler(
    ILogger<SyncAllPurchasedDataProductCatalogChangedCommandHandler> logger,
    IRuntimeContext context,
    IDbScopeSelector<IAllPurchasedAggregatedItemRepository> allPurchasedAggregatedItems,
    IDbScopeSelector<IProductCatalogRepository> productCatalogRepository,
    ISyncAllPurchasedDataService syncAllPurchasedDataService,
    IOptions<NavigationServiceOptions> navOptions,
    IUnitOfWork unitOfWork
        ) : ICommandHandler<SyncAllPurchasedDataProductCatalogChangedCommand, bool>
{
    protected ILogger<SyncAllPurchasedDataProductCatalogChangedCommandHandler> Logger { get; } = logger;
    protected IRuntimeContext Context { get; } = context;
    protected IAllPurchasedAggregatedItemRepository AllPurchasedAggregatedItems { get; } = allPurchasedAggregatedItems.GetRepository(DataAccessLevel.Public);
    protected IProductCatalogRepository ProductCatalogRepository { get; } = productCatalogRepository.GetRepository(DataAccessLevel.Public);
    protected ISyncAllPurchasedDataService SyncAllPurchasedDataService { get; } = syncAllPurchasedDataService;
    protected IUnitOfWork UnitOfWork { get; } = unitOfWork;
    protected NavigationServiceOptions NavOptions { get; } = navOptions.Value;

    public async Task<ExecutionResult<bool>> HandleAsync(SyncAllPurchasedDataProductCatalogChangedCommand command, CancellationToken ct = default)
    {
        var productCatalog = ProductCatalogRepository.GetById(command.ProductCatalogId);
        var itemsToupdate = AllPurchasedAggregatedItems.Get(x => x.ProductCatalogId == command.ProductCatalogId);

        foreach (var item in itemsToupdate)
        {
            item.Name = productCatalog != null
                ? productCatalog.GetLocalizedName()
                : new LocalizedValue<string>(("en-US", item.SolutionPackageCode), ("cs-CZ", item.SolutionPackageCode), ("sk-SK", item.SolutionPackageCode));

            item.ShortDescription = productCatalog.GetLocalizedShortDescription();
            item.CardImageId = productCatalog.GetPackageCardImageId();

            var feUrl = productCatalog.GetFrontendUrl();
            var beUrl = productCatalog.GetBackendUrl();

            item.FrontendUrl = UrlHelper.MakeAbsoluteUrlIfPossible(NavOptions, feUrl);
            item.BackendUrl = UrlHelper.MakeAbsoluteUrlIfPossible(NavOptions, beUrl);

            await AllPurchasedAggregatedItems.UpdateAsync(item, ct);
        }

        await UnitOfWork.CompleteAsync(ct);
        return new ExecutionResult<bool>(true);
    }

    public Task<ValidationResult> ValidateAsync(SyncAllPurchasedDataProductCatalogChangedCommand command, CancellationToken ct = default)
    {
        var errors = new List<ValidationError>();

        if (string.IsNullOrWhiteSpace(command.ProductCatalogId))
        {
            Logger.LogError($"{nameof(SyncAllPurchasedDataProductCatalogChangedCommandHandler)}: ProductCatalogId '{command.ProductCatalogId}' can not be null.");
            errors.Add(new ValidationError
            {
                Message = string.Format(ValidationResultMessages.InvalidOrMissingId, nameof(command.ProductCatalogId)),
                MemberNames = [nameof(command.ProductCatalogId)]
            });
        }

        return errors.Count != 0
            ? Task.FromResult(new ValidationResult(errors))
            : ValidationResult.SuccessfulResultTask;
    }
}
