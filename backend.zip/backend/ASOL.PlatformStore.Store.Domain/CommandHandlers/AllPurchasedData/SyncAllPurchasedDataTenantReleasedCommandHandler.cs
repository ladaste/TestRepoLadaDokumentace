using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Identity;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Persistence;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Domain.Queries;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Resources;
using ASOL.PlatformStore.Store.Domain.Services;
using ASOL.PlatformStore.Store.Domain.Services.AllPurchased;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.Domain.CommandHandlers;

public class SyncAllPurchasedDataTenantReleasedCommandHandler(
    ILogger<SyncAllPurchasedDataTenantReleasedCommandHandler> logger,
    IRuntimeContext context,
    IDbScopeSelector<IAllPurchasedAggregatedItemRepository> allPurchasedAggregatedItems,
    IImpersonateService impersonateService
        ) : ICommandHandler<SyncAllPurchasedDataTenantReleasedCommand, bool>
{
    protected ILogger<SyncAllPurchasedDataTenantReleasedCommandHandler> Logger { get; } = logger;
    protected IRuntimeContext Context { get; } = context;
    protected IAllPurchasedAggregatedItemRepository AllPurchasedAggregatedItems { get; } = allPurchasedAggregatedItems.GetRepository(DataAccessLevel.Public);
    protected IImpersonateService ImpersonateService { get; } = impersonateService;

    public async Task<ExecutionResult<bool>> HandleAsync(SyncAllPurchasedDataTenantReleasedCommand command, CancellationToken ct = default)
    {
        using (var scope = ImpersonateService.GetTenantContext(command.TenantId))
        {
            var syncAllPurchasedDataService = scope.ScopeProvider.GetRequiredService<ISyncAllPurchasedDataService>();

            await syncAllPurchasedDataService
                .SyncAllPurchasedData(SyncTriggerType.TenantReleased, Guid.NewGuid().ToString(), null, null, null, null, null, ct: ct);

            var unitOfWork = scope.ScopeProvider.GetRequiredService<IUnitOfWork>();
            await unitOfWork.CompleteAsync(ct);
            return new ExecutionResult<bool>(true);
        }
    }

    public Task<ValidationResult> ValidateAsync(SyncAllPurchasedDataTenantReleasedCommand command, CancellationToken ct = default)
    {
        var errors = new List<ValidationError>();

        if (string.IsNullOrWhiteSpace(command.TenantId))
        {
            Logger.LogError($"{nameof(SyncAllPurchasedDataTenantReleasedCommandHandler)}: TenantId '{command.TenantId}' can not be null.");
            errors.Add(new ValidationError
            {
                Message = string.Format(ValidationResultMessages.InvalidOrMissingId, nameof(command.TenantId)),
                MemberNames = [nameof(command.TenantId)]
            });
        }

        return errors.Count != 0
            ? Task.FromResult(new ValidationResult(errors))
            : ValidationResult.SuccessfulResultTask;
    }
}
