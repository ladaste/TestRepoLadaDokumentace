using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Identity;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Processing;
using ASOL.MessageProvider.Connector;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Domain.Commands;
using ASOL.PlatformStore.Store.Domain.Helpers;
using ASOL.PlatformStore.Store.Domain.Publishers;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Services;
using ASOL.PlatformStore.Store.Domain.Services.Helpdesk;
using ASOL.SubjectManager.Connector;
using ASOL.SubjectManager.Contracts.Enums;
using ASOL.SubjectManager.Contracts.Model;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.Domain.CommandHandlers;

public class ContactUsCommandHandler(
    ValidationHelper validationHelper,
    ILogger<ContactUsCommandHandler> logger,
    IRuntimeContext context,
    IMessageProviderClient messageProviderClient,
    ISubjectManagerClient subjectManager,
    IMappingService mappingService,
    IDbScopeSelector<IProductCatalogRepository> productCatalogs,
    IHelpdeskService helpdeskService,
    IStoreEventPublisher storeEventPublisher) : ContactUsCommandHandlerBase(validationHelper, logger, context, messageProviderClient, mappingService, productCatalogs, helpdeskService, storeEventPublisher), ICommandHandler<ContactUsCommand>
{
    protected ISubjectManagerClient SubjectManager { get; } = subjectManager;

    public async Task<ExecutionResult> HandleAsync(ContactUsCommand command, CancellationToken ct = default)
    {
        var bodyData = command.ContactRequestType is ContactRequestType.Application or ContactRequestType.ApplicationQuestion ?
            await SetBodyData(command, true) :
            await SetBodyData(command);

        var user = await SubjectManager.GetCurrentPersonAsync(ct: ct);
        var customerName = $"{user.Name.FirstName} {user.Name.Surname}";
        var confirmationBodyData = new { customerName };

        return await SendMessage(command, Context.Security.User.GetEmail(), bodyData, confirmationBodyData, ct);
    }

    public Task<ValidationResult> ValidateAsync(ContactUsCommand command, CancellationToken ct = default)
    {
        var errors = new List<ValidationError>();

        Validate(errors, command.ContactRequestType, command.Subject, command.Message, command.ProductId, command.DeeplinkBaseUrl, command.ApplicationCode, command.CurrentUrl);

        return errors.Count != 0
            ? Task.FromResult(new ValidationResult(errors))
            : ValidationResult.SuccessfulResultTask;
    }

    private async Task<object> SetBodyData(ContactUsCommand command, bool isApplicationType = false)
    {
        var deepLinkUrl = $"{command.DeeplinkBaseUrl}/apps/product/store?appCode={command.ProductId}";

        var user = await SubjectManager.GetCurrentPersonAsync();
        var email = user.Email;

        if (string.IsNullOrWhiteSpace(email))
        {
            email = Context.Security.User.GetEmail();
        }

        var contactTypes = await SubjectManager.GetContactTypesAsync();

        var phoneNumberType = contactTypes.Items.FirstOrDefault(
            item => item.ContactValueType == ContactValueType.PhoneNumber);

        var phone = string.Empty;

        if (phoneNumberType != null)
        {
            var phoneContact = user.Contacts?
                .FirstOrDefault(contact => contact.ContactTypeId == phoneNumberType.Id);

            if (phoneContact != null && !string.IsNullOrWhiteSpace(phoneContact.Value))
            {
                phone = phoneContact.Value;
            }
        }

        var organization = await SubjectManager.GetCurrentOrganizationAsync();

        return GetBodyObject(isApplicationType,
            $"{user.Name.FirstName} {user.Name.Surname}",
            email,
            phone,
            organization.Name,
            command.Subject,
            command.Message,
            command.ChatId,
            deepLinkUrl,
            command.ProductId);
    }
}
