using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.CustomAttributes.Domain.Extensions;
using ASOL.Core.Identity;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Processing;
using ASOL.MessageProvider.Connector;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Domain.Commands;
using ASOL.PlatformStore.Store.Domain.Consts;
using ASOL.PlatformStore.Store.Domain.Helpers;
using ASOL.PlatformStore.Store.Domain.Publishers;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Resources;
using ASOL.PlatformStore.Store.Domain.Services;
using ASOL.PlatformStore.Store.Domain.Services.Helpdesk;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.Domain.CommandHandlers;

public class ContactUsCommandHandlerBase(
    ValidationHelper validationHelper,
    ILogger<ContactUsCommandHandlerBase> logger,
    IRuntimeContext context,
    IMessageProviderClient messageProviderClient,
    IMappingService mappingService,
    IDbScopeSelector<IProductCatalogRepository> productCatalogs,
    IHelpdeskService helpdeskService,
    IStoreEventPublisher storeEventPublisher)
{
    protected ValidationHelper ValidationHelper { get; } = validationHelper;

    protected ILogger Logger { get; } = logger;

    protected IRuntimeContext Context { get; } = context;

    protected IMessageProviderClient MessageProviderClient { get; } = messageProviderClient;

    protected IProductCatalogRepository ProductCatalogs { get; } = productCatalogs.GetRepository(DataAccessLevel.Public);

    protected IMappingService MappingService { get; } = mappingService;

    protected IHelpdeskService HelpdeskService { get; } = helpdeskService;

    protected IStoreEventPublisher StoreEventPublisher { get; } = storeEventPublisher;

    public async Task<ExecutionResult> SendMessage(
        ContactUsCommand command,
        string confirmationEmail,
        object bodyData,
        object confirmationBodyData,
        CancellationToken ct = default)
    {
        string recipientEmail = null;
        string confirmationEmailTemplate = null;
        string recipientEmailTemplate = null;
        object subjectData = new { };

        string appName = null;

        switch (command.ContactRequestType)
        {
            case ContactRequestType.Partner:
                recipientEmail = ProductCatalogs.Get(x => x.Code == StorePackageCodes.Portal && x.NodeType == NodeTypeModel.Package).FirstOrDefault()
                    .GetCustomAttributeValue<string>(StoreAttributeGroupCodes.Contacts, StoreAttributeCodes.PartnerContactEmail);

                recipientEmailTemplate = StoreMessageProviderCodes.PartnerTemplateCode;
                confirmationEmailTemplate = StoreMessageProviderCodes.PartnerConfirmationTemplateCode;
                break;
            case ContactRequestType.General:
                recipientEmail = ProductCatalogs.Get(x => x.Code == StorePackageCodes.Portal && x.NodeType == NodeTypeModel.Package).FirstOrDefault()
                    .GetCustomAttributeValue<string>(StoreAttributeGroupCodes.Contacts, StoreAttributeCodes.GeneralContactEmail);

                recipientEmailTemplate = StoreMessageProviderCodes.GeneralTemplateCode;
                confirmationEmailTemplate = StoreMessageProviderCodes.GeneralAndApplicationConfirmationTemplateCode;
                break;
            case ContactRequestType.Application:
                var product = ProductCatalogs.Single(item => item.Id == command.ProductId);
                appName = product.Name;
                recipientEmail = product.GetCustomAttributeValue<string>(StoreAttributeGroupCodes.StoreItem, StoreAttributeCodes.Contact);

                subjectData = new { appName };
                recipientEmailTemplate = StoreMessageProviderCodes.ApplicationTemplateCode;
                confirmationEmailTemplate = StoreMessageProviderCodes.GeneralAndApplicationConfirmationTemplateCode;
                break;
            case ContactRequestType.Support:

                //Notify all needed Helpdesk APIs
                await StoreEventPublisher.PublishHelpdeskRequestAsync(command.Subject, command.Message, command.ApplicationCode, command.CurrentUrl, ct);

                recipientEmail = ProductCatalogs.Get(x => x.Code == StorePackageCodes.Portal && x.NodeType == NodeTypeModel.Package).FirstOrDefault()
                    .GetCustomAttributeValue<string>(StoreAttributeGroupCodes.Contacts, StoreAttributeCodes.SupportContactEmail);

                recipientEmailTemplate = StoreMessageProviderCodes.SupportTemplateCode;
                confirmationEmailTemplate = StoreMessageProviderCodes.GeneralAndApplicationConfirmationTemplateCode;
                break;
            case ContactRequestType.ApplicationQuestion:
                var productCatalog = ProductCatalogs.Single(item => item.Id == command.ProductId);
                appName = productCatalog.Name;
                recipientEmail = EmailConsts.Sales;

                subjectData = new { appName };
                recipientEmailTemplate = StoreMessageProviderCodes.ApplicationTemplateCode;
                confirmationEmailTemplate = StoreMessageProviderCodes.GeneralAndApplicationConfirmationTemplateCode;
                break;
            default:
                Logger.LogError($"{nameof(ContactUsCommandHandlerBase)} failed for sending contact us email because of unsupported ContactRequestType");
                return new ExecutionResult(ExecutionStatus.Error);
        }

        try
        {
            await MessageProviderClient.SendEmailAsync([recipientEmail], subjectData, bodyData, StoreMessageProviderCodes.MessageSourceCode, recipientEmailTemplate, Context.Localization.LanguageCode, ct: ct);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, $"{nameof(ContactUsCommandHandlerBase)} failed for sending contact us recipient email with template {recipientEmailTemplate}.");
            throw;
        }

        try
        {
            await MessageProviderClient.SendEmailAsync([confirmationEmail], new { }, confirmationBodyData, StoreMessageProviderCodes.MessageSourceCode, confirmationEmailTemplate, Context.Localization.LanguageCode, ct: ct);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, $"{nameof(ContactUsCommandHandlerBase)} failed for sending contact us confirmation email with template {confirmationEmailTemplate}.");
            throw;
        }

        return new ExecutionResult(ExecutionStatus.Success);
    }

    public Task<ValidationResult> Validate(List<ValidationError> errors,
        ContactRequestType contactRequestType,
        string subject,
        string message,
        string productId,
        string deeplinkBaseUrl,
        string applicationCode,
        string currentUrll)
    {
        if (string.IsNullOrEmpty(subject))
        {
            errors.Add(new ValidationError(ValidationResultMessages.UndefinedSubject, [nameof(subject)]));
        }

        if (string.IsNullOrEmpty(message))
        {
            errors.Add(new ValidationError(ValidationResultMessages.UndefinedMessage, [nameof(message)]));
        }

        if (contactRequestType == ContactRequestType.Support)
        {
            if (string.IsNullOrWhiteSpace(applicationCode))
            {
                errors.Add(new ValidationError(ValidationResultMessages.UndefinedApplicationCode, [nameof(productId)]));
            }

            if (string.IsNullOrWhiteSpace(currentUrll))
            {
                errors.Add(new ValidationError(ValidationResultMessages.UndefinedCurrentUrl, [nameof(productId)]));
            }
        }

        if (contactRequestType is ContactRequestType.Application or ContactRequestType.ApplicationQuestion)
        {
            if (string.IsNullOrWhiteSpace(productId))
            {
                errors.Add(new ValidationError(ValidationResultMessages.UndefinedProductId, [nameof(productId)]));
            }
            else
            {
                var product = ProductCatalogs.GetById(productId);

                if (product == null)
                {
                    errors.Add(new ValidationError(ValidationResultMessages.ProductDoesntExist, [nameof(productId)]));
                }
            }

            ValidationHelper.ValidateDeeplinkBaseUrl(errors, deeplinkBaseUrl);
        }
        else if (contactRequestType == ContactRequestType.None)
        {
            errors.Add(new ValidationError($"ContactRequestType can not be none"));
        }

        return errors.Count != 0
            ? Task.FromResult(new ValidationResult(errors))
            : ValidationResult.SuccessfulResultTask;
    }

    public object GetBodyObject(bool isApplicationType,
        string name,
        string email,
        string phone,
        string companyName,
        string subject,
        string message,
        string chatId,
        string deepLinkUrl,
        string productId = null)
    {
        chatId = string.IsNullOrWhiteSpace(chatId) ? string.Empty : chatId;

        if (isApplicationType)
        {
            var appName = MappingService.GetStoreItemName(productId);
            return new { appName, name, email, phone, companyName, subject, message, chatId, deepLinkUrl };
        }
        else
        {
            return new { name, email, phone, companyName, subject, message, chatId };
        }
    }
}
