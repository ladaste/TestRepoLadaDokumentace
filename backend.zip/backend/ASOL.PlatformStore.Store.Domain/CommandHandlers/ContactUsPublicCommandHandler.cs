using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Identity;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Processing;
using ASOL.MessageProvider.Connector;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Domain.Commands;
using ASOL.PlatformStore.Store.Domain.Helpers;
using ASOL.PlatformStore.Store.Domain.Publishers;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Resources;
using ASOL.PlatformStore.Store.Domain.Services;
using ASOL.PlatformStore.Store.Domain.Services.Helpdesk;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.Domain.CommandHandlers;

public class ContactUsPublicCommandHandler(
    ValidationHelper validationHelper,
    ILogger<ContactUsPublicCommandHandler> logger,
    IRuntimeContext context,
    IMessageProviderClient messageProviderClient,
    IMappingService mappingService,
    IDbScopeSelector<IProductCatalogRepository> productCatalogs,
    IHelpdeskService helpdeskService,
    IStoreEventPublisher storeEventPublisher) : ContactUsCommandHandlerBase(validationHelper, logger, context, messageProviderClient, mappingService, productCatalogs, helpdeskService, storeEventPublisher), ICommandHandler<ContactUsPublicCommand>
{
    public async Task<ExecutionResult> HandleAsync(ContactUsPublicCommand command, CancellationToken ct = default)
    {
        var bodyData = command.ContactRequestType is ContactRequestType.Application or ContactRequestType.ApplicationQuestion ?
            SetBodyData(command, true) :
            SetBodyData(command);

        var customerName = command.Name;
        var confirmationBodyData = new { customerName };

        return await SendMessage(command, command.Email, bodyData, confirmationBodyData, ct);
    }

    public Task<ValidationResult> ValidateAsync(ContactUsPublicCommand command, CancellationToken ct = default)
    {
        var errors = new List<ValidationError>();

        if (string.IsNullOrEmpty(command.Name))
        {
            errors.Add(new ValidationError(ValidationResultMessages.UndefinedName, [nameof(command.Name)]));
        }

        if (string.IsNullOrEmpty(command.Email))
        {
            errors.Add(new ValidationError(ValidationResultMessages.UndefinedEmail, [nameof(command.Email)]));
        }

        if (string.IsNullOrEmpty(command.CompanyName))
        {
            errors.Add(new ValidationError(ValidationResultMessages.UndefinedCompanyName, [nameof(command.CompanyName)]));
        }

        if (string.IsNullOrEmpty(command.PhoneNumber))
        {
            errors.Add(new ValidationError(ValidationResultMessages.UndefinedPhoneNumber, [nameof(command.PhoneNumber)]));
        }

        Validate(errors, command.ContactRequestType, command.Subject, command.Message, command.ProductId, command.DeeplinkBaseUrl, command.ApplicationCode, command.CurrentUrl);

        return errors.Count != 0
            ? Task.FromResult(new ValidationResult(errors))
            : ValidationResult.SuccessfulResultTask;
    }

    private object SetBodyData(ContactUsPublicCommand command, bool isApplicationType = false)
    {
        var deepLinkUrl = $"{command.DeeplinkBaseUrl}/apps/product/store?appCode={command.ProductId}";

        return GetBodyObject(isApplicationType,
            command.Name,
            command.Email,
            command.PhoneNumber,
            command.CompanyName,
            command.Subject,
            command.Message,
            command.ChatId,
            deepLinkUrl,
            command.ProductId);
    }
}
