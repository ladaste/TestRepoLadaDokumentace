using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Contracts.Primitives;
using ASOL.PlatformStore.Store.Domain.Commands;
using ASOL.PlatformStore.Store.Domain.Consts;
using ASOL.PlatformStore.Store.Domain.Helpers;
using ASOL.PlatformStore.Store.Domain.Resources;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.Domain.CommandHandlers;

public class InvalidateStoreCacheCommandHandler(ILogger<InvalidateStoreCacheCommandHandler> logger,
    IMemoryCache memoryCache) : ICommandHandler<InvalidateStoreCacheCommand>
{
    protected ILogger Logger { get; } = logger;
    protected IMemoryCache Cache { get; } = memoryCache;

    public Task<ExecutionResult> HandleAsync(InvalidateStoreCacheCommand command, CancellationToken ct)
    {
        switch (command.InvalidateCacheEventType)
        {
            case InvalidateCacheEventType.ApplicationLicenseChanged:
                InvalidateTokenBasedOnKey($"{CacheKeys.GetStoreItemsToken}-{command.TenantId}");
                break;
            case InvalidateCacheEventType.LicenseRoleMemberChanged:
                InvalidateTokenBasedOnKey($"{CacheKeys.GetStoreItemsToken}-{CacheKeys.AllPurchased}-{command.TenantId}-{command.AccountId}");
                break;
            default:
                Cache.ClearCache();
                break;
        }

        return Task.FromResult(new ExecutionResult(ExecutionStatus.Success));
    }

    public Task<ValidationResult> ValidateAsync(InvalidateStoreCacheCommand command, CancellationToken ct)
    {
        var errors = new List<ValidationError>();

        if (command.InvalidateCacheEventType is InvalidateCacheEventType.ApplicationRecentChanged or
            InvalidateCacheEventType.LicenseRoleMemberChanged)
        {
            if (string.IsNullOrWhiteSpace(command.TenantId) || string.IsNullOrWhiteSpace(command.AccountId))
            {
                errors.Add(new ValidationError(ValidationResultMessages.InvalidOrMissingId, [nameof(command.TenantId), nameof(command.AccountId)]));
            }
        }
        else if (command.InvalidateCacheEventType == InvalidateCacheEventType.ApplicationLicenseChanged)
        {
            if (string.IsNullOrWhiteSpace(command.TenantId))
            {
                errors.Add(new ValidationError(ValidationResultMessages.InvalidOrMissingId, [nameof(command.TenantId)]));
            }
        }

        return errors.Count != 0
            ? Task.FromResult(new ValidationResult(errors))
            : ValidationResult.SuccessfulResultTask;
    }

    private void InvalidateTokenBasedOnKey(string key)
    {
        var cancelationTokenSource = Cache.Get<CancellationTokenSource>(key);
        cancelationTokenSource?.Cancel();
        Cache.Remove(key);
    }
}
