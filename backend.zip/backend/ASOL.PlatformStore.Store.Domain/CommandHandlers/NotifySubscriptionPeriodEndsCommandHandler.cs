using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Domain;
using ASOL.Core.Domain.Contracts;
using ASOL.Core.Identity;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.Core.Processing;
using ASOL.IdentityManager.Connector;
using ASOL.IdentityManager.Contracts;
using ASOL.IdentityProvider.Connector;
using ASOL.MessageProvider.Connector;
using ASOL.PlatformStore.Domain.Options;
using ASOL.PlatformStore.PDM.Connector;
using ASOL.PlatformStore.Store.Contracts.Enums;
using ASOL.PlatformStore.Store.Domain.Commands;
using ASOL.PlatformStore.Store.Domain.Consts;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Services;
using ASOL.SubjectManager.Connector;
using ASOL.SubjectManager.Contracts.Enums;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace ASOL.PlatformStore.Store.Domain.CommandHandlers;

/// <summary>
/// Command handler for notify user before subscription period ends.
/// </summary>
public class NotifySubscriptionPeriodEndsCommandHandler(
    ILogger<NotifySubscriptionPeriodEndsCommandHandler> logger,
    IRuntimeContext runtimeContext,
    IMessageProviderClient messageProviderClient,
    IPlatformStorePdmClient platformStorePdmClient,
    ISubjectManagerClient idmsmClient,
    IDbScopeSelector<IAllPurchasedAggregatedItemRepository> allPurchasedAggregatedItems,
    IImpersonateService impersonateService,
    IOptions<AppUrlOptions> appUrlOptions) : ICommandHandler<NotifySubscriptionPeriodEndsCommand, bool>
{
    protected ILogger<NotifySubscriptionPeriodEndsCommandHandler> Logger { get; } = logger;

    protected AppUrlOptions AppUrlOptions { get; } = appUrlOptions.Value;

    protected IRuntimeContext RuntimeContext { get; } = runtimeContext;

    protected IMessageProviderClient MessageProviderClient = messageProviderClient;

    protected IPlatformStorePdmClient PlatformStorePdmClient { get; } = platformStorePdmClient;

    protected ISubjectManagerClient IdmsmClient { get; } = idmsmClient;

    protected IAllPurchasedAggregatedItemRepository AllPurchasedItems { get; } = allPurchasedAggregatedItems.GetRepository(DataAccessLevel.Public);

    protected IImpersonateService ImpersonateService { get; } = impersonateService;

    /// <summary>
    /// Notify customers based on ending subscriptions order command
    /// </summary>
    /// <param name="command">Command data</param>
    /// <param name="ct">Cancellation token</param>
    public async Task<ExecutionResult<bool>> HandleAsync(NotifySubscriptionPeriodEndsCommand command, CancellationToken ct)
    {
        Logger.LogInformation($"Executing {nameof(NotifySubscriptionPeriodEndsCommandHandler)}");

        var allPurchasedItems = AllPurchasedItems
          .Get(i => i.Status == AllPurchasedStates.Done.ToString()
            && i.OrderNumber != null
            && i.OrderDate < DateTime.Now.AddMonths(-10))
          .ApplyBaseEntityFilter(BaseEntityFilter.Default)
          .ToList();

        var baseUrl = AppUrlOptions.BaseUrl;
        var subscriptionInfoLink = $"{baseUrl}/apps/portal/app/tenant/current/subscriptions/list";

        Dictionary<string, string> platformInvoicingEmails = null;
        foreach (var allPurchasedItem in allPurchasedItems)
        {
            using var scope = ImpersonateService.GetTenantContext(allPurchasedItem.TenantId);

            Dictionary<string, string> customerStoreBuyersEmailsWithLocales = null;
            var yearlyInvoicedLicenses = allPurchasedItem.Licenses.Where(l => l.LatestInvoiceAccrualDateFrom.HasValue && l.LatestInvoiceAccrualDateTo.HasValue
                && l.BillingPeriodCode == "YearlyForward"
                && l.IsFree != null && l.IsFree == false
                && l.LatestInvoiceAccrualDateTo.Value < l.ValidTo.GetValueOrDefault(DateTime.MaxValue));

            foreach (var license in yearlyInvoicedLicenses)
            {
                var monthsFromLatestInvoice = ((DateTime.UtcNow.Year - license.LatestInvoiceAccrualDateFrom.Value.Year) * 12) + DateTime.UtcNow.Month - license.LatestInvoiceAccrualDateFrom.Value.Month;
                if (monthsFromLatestInvoice == 10)
                {
                    customerStoreBuyersEmailsWithLocales ??= await GetCustomerTenantAdminEmails(scope, ct);

                    platformInvoicingEmails ??= await GetSpaceOwnerInvoicingEmails();

                    var recipientsWithLocales = customerStoreBuyersEmailsWithLocales.Concat(platformInvoicingEmails);

                    var successfullySentEmails = 0;

                    foreach (var recipientWithLocale in recipientsWithLocales)
                    {
                        var recipientEmail = recipientWithLocale.Key;
                        var recipientLocale = recipientWithLocale.Value;
                        var appName = allPurchasedItem.Name?.Values?.FirstOrDefault(v => v.Locale == recipientLocale)?.Value;
                        var customerName = allPurchasedItem.CustomerName;
                        var expirationDate = license.LatestInvoiceAccrualDateTo.Value.ToString("d", new CultureInfo(recipientLocale));
                        var subjectData = new { appName };
                        var bodyData = new { appName, customerName, expirationDate, subscriptionInfoLink };

                        try
                        {
                            await MessageProviderClient.SendEmailAsync([recipientEmail], subjectData, bodyData, StoreMessageProviderCodes.MessageSourceCode, StoreMessageProviderCodes.SubscriptionExpiresReminderTemplateCode, recipientLocale, ct: ct);

                            successfullySentEmails++;
                        }
                        catch (Exception ex)
                        {
                            Logger.LogError(ex, $"{nameof(NotifySubscriptionPeriodEndsCommandHandler)} failed for sending email of subscription remainder of order '{license.OrderNumber}' to customer.");
                        }
                    }

                    Logger.LogInformation($"{nameof(NotifySubscriptionPeriodEndsCommandHandler)}: Successfully sent emails {successfullySentEmails}/{recipientsWithLocales.Count()} [CustomerName: '{allPurchasedItem.CustomerName}', AppName: '{allPurchasedItem.Name?.Values?.FirstOrDefault(v => v.Locale == "en-US")?.Value}']");
                }
            }
        }
        return new ExecutionResult<bool>(true);
    }



    private async Task<Dictionary<string, string>> GetSpaceOwnerInvoicingEmails()
    {

        var spaceOwnerOrg = await IdmsmClient.GetSpaceOwnerOrganizationAsync(false);

        var contacts = await IdmsmClient.ContactEntries.GetOrganizationContactsAsync(SchedulerConfigs.NotifySubscriptionInvoicingEmailContactGroup, spaceOwnerOrg.Id, DataAccessLevel.Public);

        var emails = contacts.Items.SelectMany(i => i.Values)
            .Where(v => v.TypeCode == ContactValueType.Email.ToString())
            .ToDictionary(i => i.Value, _ => "en-US");

        if (emails.Count == 0)
        {
            Logger.LogWarning($"{nameof(NotifySubscriptionPeriodEndsCommandHandler)}: SpaceOwner emails are not available.");
        }

        return emails;
    }

    private async Task<Dictionary<string, string>> GetCustomerTenantAdminEmails(IRuntimeContextScope scope, CancellationToken ct = default)
    {
        var emailsWithLocale = new Dictionary<string, string>();
        var idmClient = scope.ScopeProvider.GetRequiredService<IIdentityManagerClient>();
        var idpClient = scope.ScopeProvider.GetRequiredService<IIdentityProviderClient>();
        var roleMemberFilter = new RoleMemberFilter
        {
            Kind = RoleMemberFilterKind.Account,
            IncludeIndirectAccounts = true
        };

        var pagingFilter = new PagingFilter
        {
            Offset = 0,
            Limit = int.MaxValue
        };

        var roleMembers = await idmClient.Roles.GetMembersForRoleCodeAsync(BuiltInRoles.TenantAdmin, roleMemberFilter, pagingFilter, ct);

        foreach (var roleMember in roleMembers.Items)
        {
            var email = roleMember.Person.Email;
            if (!emailsWithLocale.ContainsKey(email))
            {
                if (!string.IsNullOrEmpty(roleMember.Person.PersonId))
                {
                    var userInfo = await idpClient.GetUserInfoAsync(roleMember.Id, true, ct);

                    emailsWithLocale.Add(email, userInfo?.Locale ?? "en-US");
                }
            }
        }

        if (emailsWithLocale.Count == 0)
        {
            Logger.LogWarning($"{nameof(NotifySubscriptionPeriodEndsCommandHandler)}: TenantAdmins emails are not available [TenantId: '{scope.RuntimeContext.Security.TenantId}'].");
        }

        return emailsWithLocale;
    }

    /// <summary>
    /// Validates the command.
    /// </summary>
    /// <param name="command">Command to validate</param>
    /// <param name="ct">Cancellation token</param>
    /// <returns>Validation result</returns>
    public async Task<ValidationResult> ValidateAsync(NotifySubscriptionPeriodEndsCommand command, CancellationToken ct)
    {
        var errors = new List<ValidationError>();

        return errors.Count != 0
            ? new ValidationResult(errors)
            : await ValidationResult.SuccessfulResultTask;
    }
}
