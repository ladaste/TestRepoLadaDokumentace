using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Identity;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.Core.Processing;
using ASOL.IdentityProvider.Connector;
using ASOL.IdentityProvider.Contracts.Tenant;
using ASOL.PlatformStore.Store.Domain.Publishers;
using ASOL.PlatformStore.Store.Domain.Queries;
using ASOL.PlatformStore.Store.Domain.Services;
using ASOL.SubjectManager.Connector;
using AutoMapper;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.Domain.CommandHandlers;

public class RequestAggregateAllPurchasedDataSyncCommandHandler(
    IRuntimeContext runtimeContext,
    IImpersonateService impersonateService,
    ILogger<RequestAggregateAllPurchasedDataSyncCommandHandler> logger,
    IMapper mapper) : ICommandHandler<RequestAggregateAllPurchasedDataSyncCommand, string>
{
    protected ILogger Logger { get; } = logger;
    protected IMapper Mapper { get; } = mapper;

    /// <inheritdoc cref="IRuntimeContext"/>
    protected IRuntimeContext RuntimeContext { get; } = runtimeContext;

    /// <inheritdoc cref="IImpersonateService"/>
    protected IImpersonateService ImpersonateService { get; } = impersonateService;

    public async Task<ExecutionResult<string>> HandleAsync(RequestAggregateAllPurchasedDataSyncCommand command, CancellationToken ct = default)
    {
        var requestId = Guid.NewGuid();

        if (!string.IsNullOrWhiteSpace(command.TenantId))
        {
            using (var scope = ImpersonateService.GetTenantContext(command.TenantId))
            {
                var eventPublisher = scope.ScopeProvider.GetRequiredService<IStoreEventPublisher>();
                await eventPublisher.PublishAggregateAllPurchasedDataSyncRequestAsync(requestId, ct);
                return new ExecutionResult<string>(requestId.ToString());
            }
        }

        var tenants = new List<TenantModel2>();

        using (var scope = ImpersonateService.GetImpersonatedContext())
        {
            var idmsmClient = scope.ScopeProvider.GetRequiredService<ISubjectManagerClient>();

            var spaceOwnerOrg = await idmsmClient.GetSpaceOwnerOrganizationAsync(false, ct);
            var spaceOwnerTenantId = spaceOwnerOrg.SpaceOwnerTenantId;

            using (var spaceOwnerScope = ImpersonateService.GetTenantContext(spaceOwnerTenantId))
            {
                var idpSpaceOwnerClient = spaceOwnerScope.ScopeProvider.GetRequiredService<IIdentityProviderClient>();

                CollectionResult<TenantModel2> tenantsResoult;

                int offset = 0, limit = 500;

                do
                {
                    tenantsResoult = await idpSpaceOwnerClient.Tenants.GetTenantsAsync(new PagingFilter { Limit = limit, Offset = offset }, ct);

                    if (tenantsResoult == null || tenantsResoult.Items == null || tenantsResoult.Items.Count == 0)
                    {
                        break;
                    }

                    tenants.AddRange(tenantsResoult.Items);
                    offset += limit;

                } while (tenantsResoult.Items.Count == limit);
            }
        }

        // Trigger event for each tenant in loop
        foreach (var tenant in tenants)
        {
            using (var scope = ImpersonateService.GetTenantContext(tenant.Id))
            {
                var eventPublisher = scope.ScopeProvider.GetRequiredService<IStoreEventPublisher>();
                await eventPublisher.PublishAggregateAllPurchasedDataSyncRequestAsync(requestId, ct);
            }
        }

        return new ExecutionResult<string>(requestId.ToString());
    }

    public Task<ValidationResult> ValidateAsync(RequestAggregateAllPurchasedDataSyncCommand command, CancellationToken ct = default)
    {
        var errors = new List<ValidationError>();

        return errors.Count != 0
            ? Task.FromResult(new ValidationResult(errors))
            : ValidationResult.SuccessfulResultTask;
    }
}
