using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.CustomAttributes.Domain.Entities.Definition;
using ASOL.Core.CustomAttributes.Domain.Repositories;
using ASOL.Core.Identity;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Processing;
using ASOL.CustomAttributes.Connector;
using ASOL.PlatformStore.Store.Domain.Commands;
using AutoMapper;

namespace ASOL.PlatformStore.Store.Domain.CommandHandlers;

public class SyncAttributeGroupCommandHandler(
    IRuntimeContext context,
    IDbScopeSelector<IAttributeGroupRepository> attributeGroups,
    ICustomAttributesClient client,
    IMapper mapper
        ) : ICommandHandler<SyncAttributeGroupCommand>
{
    protected IAttributeGroupRepository AttributeGroups { get; } = attributeGroups.GetRepository(DataAccessLevel.Public);

    protected ICustomAttributesClient Client { get; } = client;

    protected IRuntimeContext Context { get; } = context;

    protected IMapper Mapper { get; } = mapper;

    public async Task<ExecutionResult> HandleAsync(SyncAttributeGroupCommand command, CancellationToken ct = default)
    {
        if (command.Delete)
        {
            await DeleteRecord(command.Id);
            return new ExecutionResult(ExecutionStatus.Success);
        }

        var attributeGroupModel = await Client.GetAttributeGroupByIdAsync(command.Id, ct);
        if (attributeGroupModel == null)
        {
            await DeleteRecord(command.Id);
            return new ExecutionResult(ExecutionStatus.Success);
        }

        var attributeGroup = AttributeGroups.GetById(command.Id);
        if (attributeGroup == null)
        {
            attributeGroup = new AttributeGroup(
            attributeGroupModel.Id,
            Context.Security.User,
            attributeGroupModel.Code);
            Mapper.Map(attributeGroupModel, attributeGroup);
            attributeGroup.MarkAsReleased(Context.Security.User);
            await AttributeGroups.AddAsync(attributeGroup, ct);
        }
        else
        {
            Mapper.Map(attributeGroupModel, attributeGroup);
            attributeGroup.Touched(Context.Security.User);
            await AttributeGroups.UpdateAsync(attributeGroup, ct);
        }

        return new ExecutionResult(ExecutionStatus.Success);
    }

    private async Task DeleteRecord(string id)
    {
        var toDelete = AttributeGroups.GetById(id);
        if (toDelete != null)
        {
            toDelete.MarkAsDeleted(Context.Security.User);
            await AttributeGroups.UpdateAsync(toDelete);
        }
    }

    public Task<ValidationResult> ValidateAsync(SyncAttributeGroupCommand command, CancellationToken ct = default)
    {
        return ValidationResult.SuccessfulResultTask;
    }
}
