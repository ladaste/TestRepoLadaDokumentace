using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.CustomAttributes.Domain.Entities.Definition;
using ASOL.Core.CustomAttributes.Domain.Repositories;
using ASOL.Core.Identity;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Processing;
using ASOL.CustomAttributes.Connector;
using ASOL.PlatformStore.Store.Domain.Commands;
using AutoMapper;

namespace ASOL.PlatformStore.Store.Domain.CommandHandlers;

public class SyncCategoryCommandHandler(
    IRuntimeContext context,
    IDbScopeSelector<ICategoryRepository> categories,
    ICustomAttributesClient client,
    IMapper mapper
        ) : ICommandHandler<SyncCategoryCommand>
{
    protected ICategoryRepository Categories { get; } = categories.GetRepository(DataAccessLevel.Public);

    protected ICustomAttributesClient Client { get; } = client;

    protected IRuntimeContext Context { get; } = context;

    protected IMapper Mapper { get; } = mapper;

    public async Task<ExecutionResult> HandleAsync(SyncCategoryCommand command, CancellationToken ct = default)
    {
        if (command.Delete)
        {
            await DeleteRecord(command.Id);
            return new ExecutionResult(ExecutionStatus.Success);
        }

        var categoryModel = await Client.GetCategoryByIdAsync(command.Id, ct);
        if (categoryModel == null)
        {
            await DeleteRecord(command.Id);
            return new ExecutionResult(ExecutionStatus.Success);
        }

        var category = Categories.GetById(command.Id);
        if (category == null)
        {
            category = new Category(
            categoryModel.Id,
            Context.Security.User,
            categoryModel.Code);
            Mapper.Map(categoryModel, category);
            category.MarkAsReleased(Context.Security.User);
            await Categories.AddAsync(category, ct);
        }
        else
        {
            Mapper.Map(categoryModel, category);
            category.Touched(Context.Security.User);
            await Categories.UpdateAsync(category, ct);
        }

        return new ExecutionResult(ExecutionStatus.Success);
    }

    private async Task DeleteRecord(string id)
    {
        var toDelete = Categories.GetById(id);
        if (toDelete != null)
        {
            toDelete.MarkAsDeleted(Context.Security.User);
            await Categories.UpdateAsync(toDelete);
        }
    }

    public Task<ValidationResult> ValidateAsync(SyncCategoryCommand command, CancellationToken ct = default)
    {
        return ValidationResult.SuccessfulResultTask;
    }
}
