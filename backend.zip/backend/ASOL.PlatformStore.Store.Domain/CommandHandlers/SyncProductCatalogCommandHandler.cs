using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.CustomAttributes.Domain.Extensions;
using ASOL.Core.CustomAttributes.Domain.Repositories;
using ASOL.Core.Identity;
using ASOL.Core.Localization;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Processing;
using ASOL.PlatformStore.PDM.Connector;
using ASOL.PlatformStore.Store.Domain.Commands;
using ASOL.PlatformStore.Store.Domain.Consts;
using ASOL.PlatformStore.Store.Domain.Repositories;
using AutoMapper;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.Domain.CommandHandlers;

public class SyncProductCatalogCommandHandler(ILogger<SyncProductCatalogCommandHandler> logger,
    IRuntimeContext context,
    IDbScopeSelector<IProductCatalogRepository> productCatalogs,
    IDbScopeSelector<IFulltextSearchRepository> fulltextSearches,
    IDbScopeSelector<IAttributeGroupRepository> attributeGroups,
    IDbScopeSelector<ICategoryRepository> categories,
    IPlatformStorePdmClient client,
    IMapper mapper
        ) : ICommandHandler<SyncProductCatalogCommand>
{
    protected ILogger Logger { get; } = logger;

    protected IProductCatalogRepository ProductCatalogs { get; } = productCatalogs.GetRepository(DataAccessLevel.Public);

    protected IFulltextSearchRepository FulltextSearches { get; } = fulltextSearches.GetRepository(DataAccessLevel.Public);

    protected IAttributeGroupRepository AttributeGroups { get; } = attributeGroups.GetRepository(DataAccessLevel.Public);

    protected ICategoryRepository Categories { get; } = categories.GetRepository(DataAccessLevel.Public);

    protected IPlatformStorePdmClient Client { get; } = client;

    protected IRuntimeContext Context { get; } = context;

    protected IMapper Mapper { get; } = mapper;

    public async Task<ExecutionResult> HandleAsync(SyncProductCatalogCommand command, CancellationToken ct = default)
    {
        if (command.Delete)
        {
            await DeleteProductCatalogRecord(command.Id);
            return new ExecutionResult(ExecutionStatus.Success);
        }

        var productCatalogModel = await Client.ProductCatalog.GetProductCatalogByIdAsync(command.Id, ct);
        if (productCatalogModel == null)
        {
            await DeleteProductCatalogRecord(command.Id);
            return new ExecutionResult(ExecutionStatus.Success);
        }

        var productCatalog = ProductCatalogs.GetById(command.Id);

        if (productCatalog == null)
        {
            productCatalog = new ProductCatalog(
                productCatalogModel.Id,
                Context.Security.User,
                productCatalogModel.Code);
            Mapper.Map(productCatalogModel, productCatalog);
            productCatalog.MarkAsReleased(Context.Security.User);
            await ProductCatalogs.AddAsync(productCatalog, ct);
        }
        else
        {
            // If product was for some reason deleted in store DB, undelete it
            productCatalog.MarkAsUndeleted(Context.Security.User);
            Mapper.Map(productCatalogModel, productCatalog);
            productCatalog.Touched(Context.Security.User);
            await ProductCatalogs.UpdateAsync(productCatalog, ct);
        }

        var storeItemCattegory = Categories.Get(x => x.Code == StoreCategoryCodes.StoreItem).FirstOrDefault();

        if (productCatalog.Categories != null &&
            productCatalog.Categories.Any(x => x.CategoryId == storeItemCattegory?.Id))
        {
            await CreateFulltextRecords(productCatalog);
        }

        return new ExecutionResult(ExecutionStatus.Success);
    }

    private async Task CreateFulltextRecords(ProductCatalog productCatalog)
    {
        var fulltextSearchDataCollection = FulltextSearches.Get(x => x.ProductId == productCatalog.Id);

        if (fulltextSearchDataCollection != null && fulltextSearchDataCollection.Any())
        {
            await DeleteFulltextSearchRecords(productCatalog.Id);
        }

        var locallizedStrings = GetLocalizedStrings(productCatalog);

        foreach (var entry in locallizedStrings)
        {
            var fulltextSearchData = new FulltextSearch(
                Guid.NewGuid().ToString(),
                Context.Security.User,
                productCatalog.Id
            )
            {
                LanguageCode = entry.Key,
                FulltextData = entry.Value
            };
            fulltextSearchData.MarkAsReleased(Context.Security.User);

            await FulltextSearches.AddAsync(fulltextSearchData);
        }
    }

    private Dictionary<string, List<string>> GetLocalizedStrings(ProductCatalog productCatalog)
    {
        var locallizedStrings = new Dictionary<string, List<string>>();

        var attributeGroup = AttributeGroups
            .Get(x => x.Code == StoreAttributeGroupCodes.StoreItem)
            .FirstOrDefault();

        if (attributeGroup == null)
        {
            Logger.LogError($"There is no AttributeGroup with Code {StoreCategoryCodes.StoreItem} for FulltextSearch sync of ProductId {productCatalog.Id}");
            return locallizedStrings;
        }

        foreach (var attribute in attributeGroup.Attributes)
        {
            if (attribute.ProcessingFlags.Contains("FulltextSearch"))
            {
                var attributeLocalizations = productCatalog.GetCustomAttributeValue<LocalizedValue<string>>(attributeGroup.Code, attribute.Code);

                if (attributeLocalizations == null)
                {
                    Logger.LogError($"There are no no Localizations of attribute with Code {attribute.Code} for FulltextSearch sync of ProductId {productCatalog.Id}");
                    continue;
                }

                foreach (var item in attributeLocalizations.Values)
                {
                    if (locallizedStrings.TryGetValue(item.Locale, out var value))
                    {
                        value.Add(item.Value);
                    }
                    else
                    {
                        locallizedStrings[item.Locale] = [item.Value];
                    }
                }
            }
        }

        return locallizedStrings;
    }

    private async Task DeleteProductCatalogRecord(string id)
    {
        var toDelete = ProductCatalogs.GetById(id);
        if (toDelete != null)
        {
            toDelete.MarkAsDeleted(Context.Security.User);
            await ProductCatalogs.UpdateAsync(toDelete);
        }

        await DeleteFulltextSearchRecords(id);
    }

    private async Task DeleteFulltextSearchRecords(string productId)
    {
        Logger.LogInformation($"Deleting all FulltextSearch Records with ProductId {productId}");
        var fulltextSearchResults = FulltextSearches.Get(x => x.ProductId == productId);

        foreach (var item in fulltextSearchResults)
        {
            await FulltextSearches.DeleteAsync(item.Id);
        }
    }

    public Task<ValidationResult> ValidateAsync(SyncProductCatalogCommand command, CancellationToken ct = default)
    {
        return ValidationResult.SuccessfulResultTask;
    }
}
