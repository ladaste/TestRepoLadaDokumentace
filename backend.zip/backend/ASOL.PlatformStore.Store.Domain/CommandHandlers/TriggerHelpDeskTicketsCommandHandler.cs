using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Identity;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Domain.Commands;
using ASOL.PlatformStore.Store.Domain.Services.Helpdesk;
using ASOL.PlatformStore.Store.Domain.Services.Helpdesk.Models;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.Domain.CommandHandlers;

public class TriggerHelpDeskTicketsCommandHandler(
    ILogger<TriggerHelpDeskTicketsCommandHandler> logger,
    IRuntimeContext context,
    IHelpdeskService helpdeskService) : ICommandHandler<TriggerHelpDeskTicketsCommand, bool>
{
    protected ILogger Logger { get; } = logger;

    protected IRuntimeContext Context { get; } = context;

    protected IHelpdeskService HelpdeskService { get; } = helpdeskService;

    public async Task<ExecutionResult<bool>> HandleAsync(TriggerHelpDeskTicketsCommand command, CancellationToken ct = default)
    {
        Logger.LogInformation($"Triggered {nameof(TriggerHelpDeskTicketsCommandHandler)} for tenant: '{Context.Security.TenantId}' and ApplicationCode: '{command.ApplicationCode}'");

        //Create golden ticket
        var goldenTicketId = await HelpdeskService.PostGoldenTicketAsync(command.ApplicationCode, ct);

        if (goldenTicketId is null)
        {
            Logger.LogError("Helpdesk of API for GoldenTicket failed. Skipping all further helpdesk calls");
            return new ExecutionResult<bool>(false);
        }

        var allowedAttemptsCounter = 4;
        HelpdeskApplication helpdeskApplication;
        do
        {
            helpdeskApplication = await HelpdeskService.GetApplicationByCodeAsync(command.ApplicationCode, ct);
            if (helpdeskApplication == null || helpdeskApplication.Id == null)
            {
                allowedAttemptsCounter--;
                await Task.Delay(3000, ct);
            }
        } while (helpdeskApplication == null && allowedAttemptsCounter != 0);

        if (helpdeskApplication is null || helpdeskApplication.Id is null)
        {
            Logger.LogError("Helpdesk API for GetApplicationByCode failed. Skipping all further helpdesk calls");
            return new ExecutionResult<bool>(false);
        }

        var ticketRequest = new TicketRequest
        {
            TicketProductApplication = new TicketProductApplication
            {
                SourceApplicationCode = helpdeskApplication.Id,
                SourceApplicationType = "ApplicationCode"
            },
            Title = command.Subject,
            Description = $"Message: {command.Message}. CurrentUrl: {command.CurrentUrl}",
            PluginVersion = string.Empty,
            ApplicationVersion = string.Empty,
            LicenseCode = string.Empty,
            Type = new TicketType
            {
                Type = "TicketTypeRequirement"
            },
            Issuer = new Issuer
            {
                Type = string.Empty,
                Email = Context.Security.User.GetEmail(),
                FullName = Context.Security.User.GetName(),
                PhoneNumber = string.Empty,
            },
            State = "Draft"
        };

        var ticketResponse = await HelpdeskService.PostTicketAsync(ticketRequest, ct);

        var workflowTicketCompleted = await HelpdeskService.PostWorkflowTicketAsync(ticketResponse.Id, ct);
        if (!workflowTicketCompleted)
        {
            Logger.LogError("Helpdesk of API for PostWorkflowTicketAsync failed. Skipping all further helpdesk calls");
            return new ExecutionResult<bool>(false);
        }

        return new ExecutionResult<bool>(true);
    }

    public Task<ValidationResult> ValidateAsync(TriggerHelpDeskTicketsCommand command, CancellationToken ct = default)
    {
        var errors = new List<ValidationError>();

        return errors.Count != 0
            ? Task.FromResult(new ValidationResult(errors))
            : ValidationResult.SuccessfulResultTask;
    }
}
