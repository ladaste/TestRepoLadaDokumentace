using System;
using ASOL.Core.Processing;

namespace ASOL.PlatformStore.Store.Domain.Queries;

public class AggregateAllPurchasedDataCommand(Guid requestId) : ICommand<bool>
{
    public Guid RequestId { get; set; } = requestId;
}
