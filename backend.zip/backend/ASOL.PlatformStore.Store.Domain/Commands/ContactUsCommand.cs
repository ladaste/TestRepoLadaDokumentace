using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Contracts;

namespace ASOL.PlatformStore.Store.Domain.Commands;

public class ContactUsCommand(
    string subject,
    string message,
    string deeplinkBaseUrl,
    string productId,
    string chatId,
    ContactRequestType contactRequestType,
    string applicationCode,
    string currentUrl,
    string currentAppId) : ICommand
{
    public string Subject { get; set; } = subject;

    public string Message { get; set; } = message;

    public string DeeplinkBaseUrl { get; set; } = deeplinkBaseUrl;

    public string ProductId { get; set; } = productId;

    public ContactRequestType ContactRequestType { get; set; } = contactRequestType;

    public string ApplicationCode { get; set; } = applicationCode;

    public string CurrentUrl { get; set; } = currentUrl;

    public string CurrentAppId { get; set; } = currentAppId;

    public string ChatId { get; set; } = chatId;
};
