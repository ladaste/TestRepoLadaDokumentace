using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Contracts;

namespace ASOL.PlatformStore.Store.Domain.Commands;

public class ContactUsPublicCommand(
    string name,
    string email,
    string companyName,
    string phoneNumber,
    string subject,
    string message,
    string deeplinkBaseUrl,
    string productId,
    string chatId,
    ContactRequestType contactRequestType) : ContactUsCommand(subject, message, deeplinkBaseUrl, productId, chatId, contactRequestType, null, null, null), ICommand
{
    public string Name { get; set; } = name;

    public string Email { get; set; } = email;

    public string CompanyName { get; set; } = companyName;

    public string PhoneNumber { get; set; } = phoneNumber;
}
