using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Contracts.Primitives;

namespace ASOL.PlatformStore.Store.Domain.Commands;

/// <summary>
/// Initializes the instance
/// </summary>      
public class InvalidateStoreCacheCommand(InvalidateCacheEventType? invalidateCacheEventType, string tenantId, string accountId) : ICommand
{
    public string TenantId { get; set; } = tenantId;
    public string AccountId { get; set; } = accountId;
    public InvalidateCacheEventType? InvalidateCacheEventType { get; set; } = invalidateCacheEventType;
}
