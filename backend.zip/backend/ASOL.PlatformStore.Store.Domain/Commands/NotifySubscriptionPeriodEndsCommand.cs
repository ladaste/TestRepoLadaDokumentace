using ASOL.Core.Processing;

namespace ASOL.PlatformStore.Store.Domain.Commands;

/// <summary>
/// Command for set order status
/// </summary>
public class NotifySubscriptionPeriodEndsCommand : ICommand<bool>
{
    /// <summary>
    /// Initializes the instance
    /// </summary>        
    public NotifySubscriptionPeriodEndsCommand()
    {
    }
}
