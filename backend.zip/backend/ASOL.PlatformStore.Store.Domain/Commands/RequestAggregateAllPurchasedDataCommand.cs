using ASOL.Core.Processing;

namespace ASOL.PlatformStore.Store.Domain.Queries;

public class RequestAggregateAllPurchasedDataSyncCommand(string tenantId) : ICommand<string>
{
    public string TenantId { get; set; } = tenantId;
}
