using ASOL.Core.Processing;

namespace ASOL.PlatformStore.Store.Domain.Queries;

public class SyncAllPurchasedDataApplicationLicenseChangedCommand(string applicationCode,
    string editionCode,
    string licenseId) : ICommand<bool>
{
    public string ApplicationCode { get; set; } = applicationCode;
    public string EditionCode { get; set; } = editionCode;
    public string LicenseId { get; set; } = licenseId;
}
