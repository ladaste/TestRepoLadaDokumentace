using ASOL.Core.Processing;

public class SyncAllPurchasedDataApplicationLicenseDeletedCommand(
    string applicationCode,
    string editionCode,
    string licenceCode,
    string licenseId,
    string solutionPackageCode,
    string tenantId) : ICommand<bool>
{
    public string ApplicationCode { get; } = applicationCode;
    public string EditionCode { get; } = editionCode;
    public string LicenceCode { get; } = licenceCode;
    public string LicenseId { get; } = licenseId;
    public string SolutionPackageCode { get; } = solutionPackageCode;
    public string TenantId { get; } = tenantId;
}
