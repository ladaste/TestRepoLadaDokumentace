using System;
using ASOL.Core.Processing;

/// <summary>
/// Command to sync all purchased data when the latest sales invoice item has been changed.
/// </summary>
/// <remarks>
/// Initializes a new instance of the <see cref="SyncAllPurchasedDataLatestSalesInvoiceItemChangedCommand"/> class.
/// </remarks>
/// <param name="salesInvoiceItemId"></param>
/// <param name="orderNumber"></param>
/// <param name="orderLineId"></param>
/// <param name="accrualDateFrom"></param>
/// <param name="accrualDateTo"></param>
/// <param name="isFree"></param>
public class SyncAllPurchasedDataLatestSalesInvoiceItemChangedCommand(
    string salesInvoiceItemId,
    string orderNumber,
    string orderLineId,
    DateTime? accrualDateFrom,
    DateTime? accrualDateTo,
    bool isFree) : ICommand<bool>
{

    /// <summary>
    /// Gets the sales invoice item ID.
    /// </summary>
    public string SalesInvoiceItemId { get; } = salesInvoiceItemId;

    /// <summary>
    /// Gets the order number.
    /// </summary>
    public string OrderNumber { get; } = orderNumber;

    /// <summary>
    /// Gets the order line ID.
    /// </summary>
    public string OrderLineId { get; } = orderLineId;

    /// <summary>
    /// Gets the accrual date from.
    /// </summary>
    public DateTime? AccrualDateFrom { get; } = accrualDateFrom;

    /// <summary>
    /// Gets the accrual date to.
    /// </summary>
    public DateTime? AccrualDateTo { get; } = accrualDateTo;

    /// <summary>
    /// Gets or sets a value indicating whether the item is free of charge.
    /// </summary>
    public bool IsFree { get; set; } = isFree;
}
