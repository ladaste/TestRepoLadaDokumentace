using ASOL.Core.Processing;

namespace ASOL.PlatformStore.Store.Domain.Queries;

public class SyncAllPurchasedDataLicenseRoleMemberChangedCommand(string accountId,
    bool assigned,
    string licenseCode,
    string licenseId,
    string roleCode,
    string roleId) : ICommand<bool>
{
    public string AccountId { get; set; } = accountId;
    public bool Assigned { get; set; } = assigned;
    public string LicenseCode { get; set; } = licenseCode;
    public string LicenseId { get; set; } = licenseId;
    public string RoleCode { get; set; } = roleCode;
    public string RoleId { get; set; } = roleId;
}
