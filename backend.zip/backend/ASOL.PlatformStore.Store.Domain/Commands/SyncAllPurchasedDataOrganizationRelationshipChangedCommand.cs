using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Processing;

namespace ASOL.PlatformStore.Store.Domain.Queries;

public class SyncAllPurchasedDataOrganizationRelationshipChangedCommand(DataAccessLevel accessLevel,
    string organizationRelationshipId,
    string organizationRelationshipDataId) : ICommand<bool>
{
    public DataAccessLevel AccessLevel { get; set; } = accessLevel;
    public string OrganizationRelationshipId { get; set; } = organizationRelationshipId;
    public string OrganizationRelationshipDataId { get; set; } = organizationRelationshipDataId;

}
