using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Processing;

namespace ASOL.PlatformStore.Store.Domain.Queries;

public class SyncAllPurchasedDataOrganizationRelationshipDeletedCommand(DataAccessLevel accessLevel,
    string organizationRelationshipId) : ICommand<bool>
{
    public DataAccessLevel AccessLevel { get; set; } = accessLevel;
    public string OrganizationRelationshipId { get; set; } = organizationRelationshipId;

}
