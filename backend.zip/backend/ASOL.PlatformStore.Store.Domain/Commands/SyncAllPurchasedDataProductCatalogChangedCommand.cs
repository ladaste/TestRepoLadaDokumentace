using ASOL.Core.Processing;

namespace ASOL.PlatformStore.Store.Domain.Queries;

public class SyncAllPurchasedDataProductCatalogChangedCommand(string productCatalogId) : ICommand<bool>
{
    public string ProductCatalogId { get; set; } = productCatalogId;
}
