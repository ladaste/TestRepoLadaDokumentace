using ASOL.Core.Processing;

namespace ASOL.PlatformStore.Store.Domain.Queries;

public class SyncAllPurchasedDataTenantReleasedCommand(string tenantId) : ICommand<bool>
{
    public string TenantId { get; set; } = tenantId;
}
