using ASOL.Core.Processing;

namespace ASOL.PlatformStore.Store.Domain.Commands;

public class SyncCategoryCommand(string id) : ICommand
{
    public bool Delete { get; set; }

    public string Id { get; } = id;
}
