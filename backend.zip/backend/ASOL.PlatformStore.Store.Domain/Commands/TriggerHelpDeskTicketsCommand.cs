using ASOL.Core.Processing;

namespace ASOL.PlatformStore.Store.Domain.Commands;

public class TriggerHelpDeskTicketsCommand(
    string subject,
    string message,
    string applicationCode,
    string currentUrl) : ICommand<bool>
{
    public string Subject { get; set; } = subject;

    public string Message { get; set; } = message;

    public string ApplicationCode { get; set; } = applicationCode;

    public string CurrentUrl { get; set; } = currentUrl;
};
