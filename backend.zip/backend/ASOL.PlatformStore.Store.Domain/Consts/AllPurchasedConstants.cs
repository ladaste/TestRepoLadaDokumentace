namespace ASOL.PlatformStore.Store.Domain.Consts;

public static class AllPurchasedConstants
{
    public const string PlatformApplicationCode = "Platform";

    public const string PortalApplicationCode = "ASOLEU-Portal-AP-";

    public const string PublicPortalApplicationCode = "ASOLEU-Public-portal-AP-";

    public const string RightObjectGroupNavigationOptions = "RightObjectGroupNavigationOptions";
}
