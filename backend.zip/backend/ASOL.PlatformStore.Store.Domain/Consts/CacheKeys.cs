namespace ASOL.PlatformStore.Store.Domain.Consts;

public static class CacheKeys
{
    public const string AllPurchased = "allPurchased";
    public const string IsDefaultSubscriptionSearch = "isDefaultSubscriptionSearch";
    public const string GetStoreItemsToken = "getStoreItemsToken";
}
