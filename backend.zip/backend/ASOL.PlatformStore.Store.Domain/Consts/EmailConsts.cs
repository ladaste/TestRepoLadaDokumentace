namespace ASOL.PlatformStore.Store.Domain.Consts;

public static class EmailConsts
{
    public const string Sales = "sales@avaplace.com";
}
