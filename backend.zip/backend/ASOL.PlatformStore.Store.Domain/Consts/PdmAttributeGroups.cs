namespace ASOL.PlatformStore.Store.Domain.Consts;

public static class PdmAttributeGroups
{
    public static class PDM_EDITION
    {
        public const string Name = "name";
        public const string SortOrder = "sortOrder";
        public const string Default = "default";
        public const string Description = "description";
    }

    public static class PDM_FEATURE
    {
        public const string Name = "name";
    }

    public static class PDM_LICENCE
    {
        public const string LicenceData = "licenceData";
        public const string LicenceData2 = "licenceData2";
    }

    public static class PDM_EXTENSION
    {
        public const string ExtensionData = "extensionData";
        public const string Name = "name";
        public const string Description = "description";
        public const string LongDescriptionTitle = "longDescriptionTitle";
        public const string LongDescription = "longDescription";
        public const string SliderTitle = "sliderTitle";
        public const string SliderDescription = "sliderDescription";
    }

    public static class PDM_VENDOR
    {
        public const string VendorCode = "vendorCode";
        public const string VendorTenant = "vendorTenant";
        public const string LegalDocuments = "legalDocuments";
        public const string LicenseProvider = "licenseProvider";
    }

    public static class PDM_MEDIAFILE
    {
        public const string Type = "type";
        public const string ContentFile = "contentFile";
        public const string PosterFile = "posterFile";
    }

    public static class PDM_DATAITEM
    {
        public const string Text = "text";
    }

    public static class PDM_FEATUREITEM_DESCRIPTION
    {
        public const string Text = "text";
    }

    public static class PDM_FEATUREITEM_SUBJECT
    {
        public const string Text = "text";
    }

    public static class PDM_FEATUREITEM
    {
        public const string Subject = "subject";
        public const string Description = "description";
        public const string ContentImage = "contentImage";
        public const string ImageRedirectUrl = "imageRedirectUrl";
    }

    public static class PDM_STOREITEM
    {
        public const string Name = "name";
        public const string ShortDescription = "shortDescription";
        public const string Description = "description";
        public const string MediaFilesStructure = "mediaFilesStructure";
        public const string Version = "version";
        public const string DetailDescriptionStructure = "detailDescriptionStructure";
        public const string MediaFiles = "mediaFiles";
        public const string SliderDefinition = "sliderDefinition";
        public const string DetailDescription = "detailDescription";
        public const string Contact = "contact";
        public const string PartnerContact = "partnerContact";
        public const string NavigateToEditionVisible = "navigateToEditionVisible";
        public const string NavigateToEditionText = "navigateToEditionText";
        public const string NavigateToEditionPartCode = "navigateToEditionPartCode";
        public const string CardImage = "cardImage";
        public const string MarketingClaim = "marketingClaim";
        public const string LegalDisclaimerShort = "legalDisclaimerShort";
        public const string DefaultEditionId = "defaultEditionId";
        public const string DefaultLicenceId = "defaultLicenceId";
        public const string IsHidden = "isHidden";
    }

    public static class PDM_CONTACTS
    {
        public const string PartnerContactEmail = "partnerContactEmail";
        public const string GeneralContactEmail = "generalContactEmail";
        public const string SupportContactEmail = "supportContactEmail";
    }

    public static class PDM_PRODUCT
    {
        public const string IsVirtual = "isVirtual";
        public const string IsNative = "isNative";
        public const string ParentTemplateGlobalApplicationCode = "parentTemplateGlobalApplicationCode";
        public const string ApplicationCode = "applicationCode";
        public const string GlobalApplicationCode = "globalApplicationCode";
        public const string ApplicationShortName = "applicationShortName";
        public const string ApplicationName = "applicationName";
        public const string Icon = "icon";
        public const string Url = "url";
        public const string Logo = "logo";
        public const string BackendUrl = "backendUrl";
    }

    public static class PDM_SUBSCRIPTION
    {
        public const string SubscriptionData = "subscriptionData";
    }

    public static class PDM_RECOMMENDED
    {
        public const string SortOrder = "sortOrder";
    }

    public static class PDM_SALES_ITEM
    {
        public const string Name = "name";
        public const string RoleCode = "roleCode";
    }

    public static class PUBLIC_MARKETING_LIST
    {
        public const string ListData = "listData";
        public const string Header = "header";
    }

    public static class PUBLIC_HEADER_BANNER
    {
        public const string Data = "data";
    }

    public static class PRIVATE_HEADER_BANNER
    {
        public const string Data = "data";
    }

    public static class HELPDESK_INFO
    {
        public const string AdditionalApps = "additionalApps";
    }
}
