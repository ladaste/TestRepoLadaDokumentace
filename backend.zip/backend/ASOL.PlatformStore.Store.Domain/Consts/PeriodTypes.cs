namespace ASOL.PlatformStore.Store.Domain.Consts;

public static class PeriodTypes
{
    public const string Yearly = "Days365";
    public const string Monthly = "Days30";
}
