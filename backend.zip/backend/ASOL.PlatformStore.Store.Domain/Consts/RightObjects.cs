namespace ASOL.PlatformStore.Store.Domain.Consts;

public static class RightObjects
{
    public const string CrossTenantStoreAccess = "CrossTenantStoreAccess";
    public const string EditorRoleAccess = "ASOLEU-Product-AP-.ProductEditor";
    public const string StoreBuyer = "ASOLEU-PlatformStore-AP-.StoreBuyer";
    public const string SalesRep = "ASOLEU-PlatformStore-AP-.SalesRep";
    public const string SystemSubscriptionReadAccess = "SystemSubscriptionReadAccess";
    public const string AllSubscriptionsReadAccess = "AllSubscriptionsReadAccess";
}
