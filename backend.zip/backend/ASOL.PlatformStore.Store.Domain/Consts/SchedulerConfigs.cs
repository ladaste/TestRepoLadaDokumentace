namespace ASOL.PlatformStore.Store.Domain.Consts;

public static class SchedulerConfigs
{
    public const string ApplicationCode = "ASOLEU-PlatformStore-AP-";
    public const string CustomCodeNotifySubscriptionPeriodEnds = "NotifySubscriptionPeriodEnds";
    public const string ActivationPolicyType = "CronFormatPolicyModel";
    public const string NotifySubscriptionInvoicingEmailContactGroup = "ASOLEU-InvoiceApp-AP-";
}
