namespace ASOL.PlatformStore.Store.Domain.Consts;

public static class StoreAttributeCodes
{
    public const string Name = "name";
    public const string Contact = "contact";
    public const string PartnerContactEmail = "partnerContactEmail";
    public const string GeneralContactEmail = "generalContactEmail";
    public const string SupportContactEmail = "supportContactEmail";
    public const string Description = "description";
    public const string DetailDescription = "detailDescription";
    public const string DetailDescriptionStructure = "detailDescriptionStructure";
    public const string MediaFiles = "mediaFiles";
    public const string MediaFilesStructure = "mediaFilesStructure";
    public const string NavigateToEditionVisible = "navigateToEditionVisible";
    public const string NavigateToEditionText = "navigateToEditionText";
    public const string NavigateToEditionPartCode = "navigateToEditionPartCode";
    public const string MarketingClaim = "marketingClaim";
    public const string LegalDisclaimerShort = "legalDisclaimerShort";
    public const string DefaultEditionId = "defaultEditionId";
    public const string DefaultLicenceId = "defaultLicenceId";
    public const string VendorLicenseProvider = "licenseProvider";
    public const string VendorLegalDocuments = "legalDocuments";
    public const string SliderDefinition = "sliderDefinition";
    public const string Version = "version";
    public const string IsHidden = "isHidden";
    public const string CarouselCategories = "carouselCategories";
    public const string SortOrder = "sortOrder";

    public const string GlobalApplicationCode = "globalApplicationCode";
    public const string ApplicationName = "applicationName";
    public const string Url = "url";
}
