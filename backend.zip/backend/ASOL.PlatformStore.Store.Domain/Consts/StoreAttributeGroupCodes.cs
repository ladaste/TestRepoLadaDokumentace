namespace ASOL.PlatformStore.Store.Domain.Consts;

public static class StoreAttributeGroupCodes
{
    public const string StoreItem = "PDM_STOREITEM";
    public const string Vendor = "PDM_VENDOR";
    public const string Edition = "PDM_EDITION";
    public const string Feature = "PDM_FEATURE";
    public const string Licence = "PDM_LICENCE";
    public const string Subscription = "PDM_SUBSCRIPTION";
    public const string Extension = "PDM_EXTENSION";
    public const string Contacts = "PDM_CONTACTS";
    public const string Recommended = "PDM_RECOMMENDED";
    public const string PublicPortalLandingItem = "PUBLIC-PORTAL-LANDING-ITEM";
    public const string SalesItem = "PDM_SALES_ITEM";
    public const string Product = "PDM_PRODUCT";
}
