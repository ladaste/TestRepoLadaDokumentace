namespace ASOL.PlatformStore.Store.Domain.Consts;

public class StoreCategoryCodes
{
    public const string StoreItem = "PDM.STOREITEM";
    public const string Integration = "PDM.INTEGRATION";
    public const string StoreItemPrimary = "PDM.CATEGORY.PRIMARY";
    public const string Recommended = "PDM.CATEGORY.RECOMMENDED";
    public const string Bestselling = "PDM.CATEGORY.BESTSELLING";
    public const string ComingSoon = "PDM.CATEGORY.COMINGSOON";
    public const string PublicLandingPages = "Public_landing_pages";
    public const string All = "ALL";
}
