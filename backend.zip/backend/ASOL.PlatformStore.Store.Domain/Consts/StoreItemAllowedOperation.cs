namespace ASOL.PlatformStore.Store.Domain.Consts;

public class StoreItemAllowedOperation
{
    public const string Create = "Create";
    public const string Modify = "Modify";
    public const string None = "None";
}
