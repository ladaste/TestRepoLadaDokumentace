namespace ASOL.PlatformStore.Store.Domain.Consts;

public static class StoreMessageProviderCodes
{
    public const string MessageSourceCode = "ASOLEU-PLATFORMSTORE-STORE-AP-";

    public const string ApplicationTemplateCode = "Application";
    public const string ApplicationTemplateHtmlCode = "Application.Email.Html";

    public const string GeneralTemplateCode = "General";
    public const string GeneralTemplateHtmlCode = "General.Email.Html";

    public const string PartnerTemplateCode = "Partner";
    public const string PartnerTemplateHtmlCode = "Partner.Email.Html";

    public const string GeneralAndApplicationConfirmationTemplateCode = "GeneralAndApplicationConfirmation";
    public const string GeneralAndApplicationConfirmationTemplateHtmlCode = "GeneralAndApplicationConfirmation.Email.Html";

    public const string PartnerConfirmationTemplateCode = "PartnerConfirmation";
    public const string PartnerConfirmationTemplateHtmlCode = "PartnerConfirmation.Email.Html";

    public const string SupportTemplateCode = "Support";
    public const string SupportTemplateHtmlCode = "Support.Email.Html";

    public const string SubscriptionExpiresReminderTemplateCode = "SubscriptionExpiresReminder";
    public const string SubscriptionExpiresReminderTemplateHtmlCode = "SubscriptionExpiresReminder.Email.Html";
}
