namespace ASOL.PlatformStore.Store.Domain.Consts;

public static class StorePackageCodes
{
    public const string Portal = "Portal";
}
