namespace ASOL.PlatformStore.Store.Domain.Consts;

public static class TenantIds
{
    public const string ASOLEU = "ASOLEU";
}
