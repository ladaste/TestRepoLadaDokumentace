namespace ASOL.PlatformStore.Store.Domain;

public class DescriptionDataItem
{
    public string Text { get; set; }
}
