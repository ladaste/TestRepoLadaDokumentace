namespace ASOL.PlatformStore.Store.Domain;

public class DescriptionFeatureItem
{
    public DescriptionDataItem Subject { get; set; }

    public DescriptionDataItem Description { get; set; }

    public FileReference ContentImage { get; set; }

    public string ImageRedirectUrl { get; set; }
}
