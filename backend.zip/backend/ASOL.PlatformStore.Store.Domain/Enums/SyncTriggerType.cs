

namespace ASOL.PlatformStore.Store.Domain;

/// <summary>
/// SyncTriggerType
/// </summary>
public enum SyncTriggerType
{
    Global = 1,
    ApplicationLicenseChanged,
    LicenseRoleMemberChanged,
    OrganizationRelationshipChanged,
    OrganizationRelationshipDeleted,
    TenantReleased,
    ProductCatalogChanged,
    OrganizationRelationshipCreated
}
