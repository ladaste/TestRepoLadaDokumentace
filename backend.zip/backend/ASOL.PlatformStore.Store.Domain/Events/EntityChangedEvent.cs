namespace ASOL.PlatformStore.Store.Domain.Events;

public sealed record EntityChangedEvent<TEntity>(TEntity Entity);
