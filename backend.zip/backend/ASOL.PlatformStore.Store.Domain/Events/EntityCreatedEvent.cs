namespace ASOL.PlatformStore.Store.Domain.Events;

public sealed record EntityCreatedEvent<TEntity>(TEntity Entity);
