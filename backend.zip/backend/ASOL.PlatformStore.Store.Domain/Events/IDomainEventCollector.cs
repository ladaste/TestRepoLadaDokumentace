#nullable enable

namespace ASOL.PlatformStore.Store.Domain.Events;

public interface IDomainEventCollector
{
    public void AddEvent(object @event);
}
