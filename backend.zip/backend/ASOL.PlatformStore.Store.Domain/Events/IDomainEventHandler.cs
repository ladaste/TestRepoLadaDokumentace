using System.Threading;
using System.Threading.Tasks;

namespace ASOL.PlatformStore.Store.Domain.Events;

public interface IDomainEventHandler<TEvent>
{
    public Task HandleAsync(TEvent @event, CancellationToken cancellationToken);
}
