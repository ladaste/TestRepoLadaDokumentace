using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace ASOL.PlatformStore.Store.Domain.Events;

public interface IDomainEventsHandler<TEvent>
{
    public Task HandleAsync(IReadOnlyList<TEvent> events, CancellationToken cancellationToken);
}
