using System;
using System.Linq;
using ASOL.PlatformStore.Store.Contracts.Enums;

namespace ASOL.PlatformStore.Store.Domain.Extensions;

internal static class AllPurchasedAggregatedItemQueryableExtensions
{
    public static IQueryable<AllPurchasedAggregatedItem> ForTenant(
        this IQueryable<AllPurchasedAggregatedItem> allPurchasedAggregatedItems,
        string tenantId)
    {
        return allPurchasedAggregatedItems
            .Where(_ => _.TenantId == tenantId);
    }

    public static IQueryable<AllPurchasedAggregatedItem> ActiveOnly(
        this IQueryable<AllPurchasedAggregatedItem> allPurchasedAggregatedItems)
    {
        return allPurchasedAggregatedItems
            .Where(_ => _.Status != AllPurchasedStates.Failed.ToString()
                && _.Status != AllPurchasedStates.Ended.ToString());
    }

    public static IQueryable<AllPurchasedAggregatedItem> AreDone(
        this IQueryable<AllPurchasedAggregatedItem> allPurchasedAggregatedItems)
    {
        return allPurchasedAggregatedItems
            .Where(_ => _.Status == AllPurchasedStates.Done.ToString());
    }

    public static IQueryable<AllPurchasedAggregatedItem> HaveLinks(
        this IQueryable<AllPurchasedAggregatedItem> allPurchasedAggregatedItems)
    {
        return allPurchasedAggregatedItems
            .Where(_ => _.FrontendUrl != null);
    }

    public static IQueryable<AllPurchasedAggregatedItem> HasAccesibleByRole(
    this IQueryable<AllPurchasedAggregatedItem> allPurchasedAggregatedItems)
    {
        return allPurchasedAggregatedItems
            .Where(_ => _.HasAccesibleByRole);
    }

    public static IQueryable<AllPurchasedAggregatedItem> WithValidLicenseAt(
        this IQueryable<AllPurchasedAggregatedItem> allPurchasedAggregatedItems,
        DateTime at)
    {
        return allPurchasedAggregatedItems
            .Where(item => item.Licenses
                .Any(_ => (_.ValidFrom == null || _.ValidFrom <= at)
                    && (_.ValidTo == null || _.ValidTo >= at)));
    }
}
