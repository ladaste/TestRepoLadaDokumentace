using System;
using System.Collections.Generic;
using System.Linq;
using ASOL.SubjectManager.Contracts.Model;

namespace ASOL.PlatformStore.Store.Domain.Extensions;

/// <summary>
/// Extension methods for querying <see cref="ContactEntryModel"/> collections.
/// </summary>
public static class ContactEntryModelExtensions
{
    /// <summary>
    /// Returns valid contact values for specified groupCode and typeCode at given timestamp.
    /// </summary>
    public static ICollection<string> GetValidValues(
        this IEnumerable<ContactEntryModel> source,
        string groupCode,
        string typeCode,
        DateTime? compareWith = null)
    {
        if (source == null || string.IsNullOrWhiteSpace(groupCode) || string.IsNullOrWhiteSpace(typeCode))
        {
            return [];
        }

        var timestamp = compareWith ?? DateTime.UtcNow;

        source = source
            .Where(r =>
                r.GroupCode == groupCode
                && r.ValidFrom <= timestamp && (r.ValidTo == null || r.ValidTo > timestamp)
                && (r.ValidTo == null || r.ValidTo >= timestamp) && r.ValidFrom <= timestamp)
            .OrderByDescending(c => c.ValidFrom ?? DateTime.MinValue);

        var values = source
            .SelectMany(c => c.Values)
            .Where(v => v.TypeCode == typeCode)
            .Select(v => v.Value)
            .ToArray();

        return values;
    }
}
