using System;

#nullable enable

namespace ASOL.PlatformStore.Store.Domain.Extensions;

internal static class IntervalExtensions
{
    public static bool InContainedInClosedInterval<T>(this T value, T? from, T? to)
        where T : struct, IComparable
    {
        return (from, to) switch
        {
            (T, T) => value.CompareTo(from) >= 0 && value.CompareTo(to) <= 0,
            (null, T) => value.CompareTo(to) <= 0,
            (T, null) => value.CompareTo(from) >= 0,
            (null, null) => true,
        };
    }
}
