using System;
using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.Domain.Extensions;

internal static class ListExtensions
{
    public static void Move<T>(this IList<T> source,
        int initialPosition,
        int targetPosition)
    {
        ArgumentNullException.ThrowIfNull(source);
        if (initialPosition < 0 || initialPosition >= source.Count)
        {
            throw new ArgumentOutOfRangeException(nameof(initialPosition));
        }
        if (targetPosition < 0 || targetPosition >= source.Count)
        {
            throw new ArgumentOutOfRangeException(nameof(initialPosition));
        }

        if (initialPosition == targetPosition)
        {
            return;
        }

        Func<int, int> moveIndex = targetPosition - initialPosition > 0
            ? index => index + 1
            : index => index - 1;

        var movedItem = source[initialPosition];

        var index = initialPosition;
        while (index != targetPosition)
        {
            source[index] = source[moveIndex(index)];
            index = moveIndex(index);
        }

        source[targetPosition] = movedItem;
    }
}
