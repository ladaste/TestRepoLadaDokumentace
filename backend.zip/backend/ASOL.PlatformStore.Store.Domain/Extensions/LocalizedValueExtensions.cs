using System.Collections.Generic;
using System.Linq;
using ASOL.Core.Localization;

namespace ASOL.PlatformStore.Store.Domain.Extensions;

public static class LocalizedValueExtensions
{
    public static bool IsEquivalentTo<T>(this LocalizedValue<T> a, LocalizedValue<T> b)
    {
        if (ReferenceEquals(a, b))
        {
            return true;
        }

        if (a is null || b is null)
        {
            return false;
        }

        var aVals = a.Values ?? [];
        var bVals = b.Values ?? [];

        if (aVals.Count != bVals.Count)
        {
            return false;
        }

        return aVals.OrderBy(x => x.Locale).Zip(bVals.OrderBy(x => x.Locale))
            .All(pair => pair.First.Locale == pair.Second.Locale &&
                         EqualityComparer<T>.Default.Equals(pair.First.Value, pair.Second.Value));
    }
}
