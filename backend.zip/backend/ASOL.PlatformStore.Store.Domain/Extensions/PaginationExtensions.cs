using System;
using System.Collections.Generic;
using System.Linq;
using ASOL.Core.Paging.Contracts.Filters;

#nullable enable

namespace ASOL.PlatformStore.Store.Domain.Extensions;

internal static class PaginationExtensions
{
    public static IEnumerable<T> ApplyPagingFilter<T>(this IEnumerable<T> items,
        PagingFilter? pagination)
    {
        ArgumentNullException.ThrowIfNull(items);
        return pagination is { }
            ? items
                .Skip(pagination.Offset)
                .Take(pagination.Limit)
            : items;
    }

    public static IQueryable<T> ApplyPagingFilter<T>(this IQueryable<T> items,
        PagingFilter? pagination)
    {
        ArgumentNullException.ThrowIfNull(items);
        return pagination is { }
            ? items
                .Skip(pagination.Offset)
                .Take(pagination.Limit)
            : items;
    }
}
