using System;
using ASOL.Core.CustomAttributes.Contracts.Utils;
using ASOL.Core.CustomAttributes.Domain.Extensions;
using ASOL.Core.Identity.Contexts;
using ASOL.Core.Localization;
using ASOL.PlatformStore.Store.Domain.Consts;

namespace ASOL.PlatformStore.Store.Domain.Extensions;

public static class ProductCatalogExtensions
{
    public static LocalizedValue<string> GetLocalizedName(this ProductCatalog product, string groupCode = nameof(PdmAttributeGroups.PDM_STOREITEM))
    {
        ArgumentNullException.ThrowIfNull(product);

        var attributeCode = groupCode switch
        {
            _ => PdmAttributeGroups.PDM_STOREITEM.Name
        };

        return product.GetCustomAttributeValue<LocalizedValue<string>>(groupCode, attributeCode)
               ?? new LocalizedValue<string>((LocalizationContext.DefaultLanguageCode, product.Name));
    }

    public static LocalizedValue<string> GetLocalizedShortDescription(this ProductCatalog product, string groupCode = nameof(PdmAttributeGroups.PDM_STOREITEM))
    {
        ArgumentNullException.ThrowIfNull(product);

        var attributeCode = groupCode switch
        {
            _ => PdmAttributeGroups.PDM_STOREITEM.ShortDescription
        };

        return product.GetCustomAttributeValue<LocalizedValue<string>>(groupCode, attributeCode);
    }

    public static LocalizedValue<string> GetLocalizedDescription(this ProductCatalog product, string groupCode = nameof(PdmAttributeGroups.PDM_STOREITEM))
    {
        ArgumentNullException.ThrowIfNull(product);

        var attributeCode = groupCode switch
        {
            _ => PdmAttributeGroups.PDM_STOREITEM.Description
        };

        return product.GetCustomAttributeValue<LocalizedValue<string>>(groupCode, attributeCode);
    }

    public static string GetPackageCardImageId(this ProductCatalog product)
    {
        ArgumentNullException.ThrowIfNull(product);

        return product.GetCustomAttributeValue<FileRef>(nameof(PdmAttributeGroups.PDM_STOREITEM), PdmAttributeGroups.PDM_STOREITEM.CardImage)?.FileId;
    }

    public static string GetFrontendUrl(this ProductCatalog product)
    {
        ArgumentNullException.ThrowIfNull(product);

        return product.GetCustomAttributeValue<string>(nameof(PdmAttributeGroups.PDM_PRODUCT), PdmAttributeGroups.PDM_PRODUCT.Url);
    }

    public static string GetBackendUrl(this ProductCatalog product)
    {
        ArgumentNullException.ThrowIfNull(product);

        return product.GetCustomAttributeValue<string>(nameof(PdmAttributeGroups.PDM_PRODUCT), PdmAttributeGroups.PDM_PRODUCT.BackendUrl);
    }

    public static bool IsVirtual(this ProductCatalog product)
    {
        ArgumentNullException.ThrowIfNull(product);
        return product.GetCustomAttributeValue<bool>(nameof(PdmAttributeGroups.PDM_PRODUCT), PdmAttributeGroups.PDM_PRODUCT.IsVirtual);
    }

    public static bool IsNative(this ProductCatalog product)
    {
        ArgumentNullException.ThrowIfNull(product);
        return product.GetCustomAttributeValue<bool>(nameof(PdmAttributeGroups.PDM_PRODUCT), PdmAttributeGroups.PDM_PRODUCT.IsNative);
    }

    public static bool IsHidden(this ProductCatalog product)
    {
        ArgumentNullException.ThrowIfNull(product);
        return product.GetCustomAttributeValue<bool>(nameof(PdmAttributeGroups.PDM_STOREITEM), PdmAttributeGroups.PDM_STOREITEM.IsHidden);
    }
}
