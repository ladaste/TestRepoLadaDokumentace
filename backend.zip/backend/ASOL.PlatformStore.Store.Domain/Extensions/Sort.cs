using System;
using System.Buffers;

namespace ASOL.PlatformStore.Store.Domain.Extensions;

internal static class Sort
{
    public static void Make<T, TKey>(Span<T> s1, Span<T> s2, Func<T, TKey> keySelector)
        where TKey : IComparable<TKey>
    {
        if (s1.Length == 0 || s2.Length == 0)
        {
            return;
        }

        s1.Sort((x, y) => keySelector(x).CompareTo(keySelector(y)));
        s2.Sort((x, y) => keySelector(x).CompareTo(keySelector(y)));

        if (keySelector(s1[^1]).CompareTo(keySelector(s2[0])) <= 0)
        {
            return;
        }

        var buffer = ArrayPool<T>.Shared.Rent(s1.Length + s2.Length);
        var mergedSpan = new Span<T>(buffer, 0, s1.Length + s2.Length);

        try
        {
            s1.CopyTo(mergedSpan[..s1.Length]);
            s2.CopyTo(mergedSpan[s1.Length..]);

            mergedSpan.Sort((x, y) => keySelector(x).CompareTo(keySelector(y)));

            mergedSpan[..s1.Length].CopyTo(s1);
            mergedSpan[s1.Length..].CopyTo(s2);
        }
        finally
        {
            ArrayPool<T>.Shared.Return(buffer);
        }
    }
}
