using System;
using System.Text;

namespace ASOL.PlatformStore.Store.Domain.Extensions;

internal static class StringExtensions
{
    public static string GetInitials(this string value, int maxCount = 2)
    {
        ArgumentNullException.ThrowIfNull(value);

        StringBuilder initials = new(maxCount);
        foreach (var c in value)
        {
            if (!char.IsUpper(c))
            {
                continue;
            }

            initials.Append(c);

            if (initials.Length == maxCount)
            {
                break;
            }
        }

        return initials.ToString();
    }
}
