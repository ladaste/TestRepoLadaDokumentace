namespace ASOL.PlatformStore.Store.Domain;

public class FileReference
{
    public string FileId { get; set; }
}
