using System.Collections.Generic;
using System.Dynamic;
using System.Security.Claims;
using ASOL.Core.CustomAttributes.Domain;
using ASOL.Core.CustomAttributes.Domain.Entities.Definition;
using ASOL.Core.Domain;

namespace ASOL.PlatformStore.Store.Domain;

/// <summary>
/// Entity for the product catalog node type ProductCatalogNode - base class for other types
/// </summary>    

public class FulltextSearch : BaseEntity<string>, IExpandableEntity
{
    /// <inheritdoc/>
    public FulltextSearch()
    {
    }

    /// <inheritdoc/>
    public FulltextSearch(string id, ClaimsPrincipal user, string productId)
        : base(id, user)
    {
        ProductId = productId;
    }

    /// <summary>
    /// Id of of the product
    /// </summary>
    public string ProductId { get; set; }

    /// <summary>
    /// Language Code
    /// </summary>
    public string LanguageCode { get; set; }

    /// <summary>
    /// Fulltext Data
    /// </summary>
    public IEnumerable<string> FulltextData { get; set; }

    /// <summary>
    /// List of custom attributes
    /// </summary>
    public ExpandoObject CustomAttributes { get; set; }

    /// <summary>
    /// List of assigned categories
    /// </summary>
    public ICollection<CategoryReference> Categories { get; set; }
}
