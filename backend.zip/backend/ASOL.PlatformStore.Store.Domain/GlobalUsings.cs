// Temporary alias for LicenseModel from IdentityManager (IDM). 
// Used in places (e.g., SyncAllPurchasedDataService) that still need to call IDM directly.
// This should be removed once all usages are migrated to the Store's own LicenseModel.
global using IdmLicenseModel = ASOL.IdentityManager.Contracts.LicenseModel;
