using ASOL.Core.Identity;

namespace ASOL.PlatformStore.Store.Domain.Helpers;

public static class AccountHelper
{
    public static string GenerateAccountId(IRuntimeContext runtimeContext)
    {
        if (runtimeContext.Security.HasUserContext)
        {
            return $"{runtimeContext.Security.User.GetName().ToUpper()}|UserName";
        }
        else
        {
            return $"{runtimeContext.Security.User.GetClientId().ToUpper()}|ServiceId";
        }
    }
}
