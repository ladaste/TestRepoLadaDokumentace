using Microsoft.Extensions.Caching.Memory;

namespace ASOL.PlatformStore.Store.Domain.Helpers;

public static class CacheHelper
{
    public static void ClearCache(this IMemoryCache memoryCache)
    {
        if (memoryCache is MemoryCache cache)
        {
            cache.Compact(1.0);
        }
    }
}
