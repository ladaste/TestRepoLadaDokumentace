using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace ASOL.PlatformStore.Store.Domain.Helpers;

public static class InterfacePropertyHelper
{
    public static PropertyInfo[] GetAllInterfaceProperties(Type interfaceType)
    {
        var allInterfaces = new List<Type>();
        CollectInterfaces(interfaceType, allInterfaces);

        return allInterfaces
            .SelectMany(i => i.GetProperties(BindingFlags.Public | BindingFlags.Instance))
            .GroupBy(p => p.Name)
            .Select(g => g.First())
            .ToArray();
    }

    private static void CollectInterfaces(Type type, List<Type> results)
    {
        if (!type.IsInterface || results.Contains(type))
        {
            return;
        }

        results.Add(type);
        foreach (var i in type.GetInterfaces())
        {
            CollectInterfaces(i, results);
        }
    }
}
