using System;
using System.Linq.Expressions;
using System.Reflection;
using ASOL.PlatformStore.Store.Domain.Extensions;

namespace ASOL.PlatformStore.Store.Domain.Helpers;

public class PropertyValueComparer<TValue> where TValue : class
{
    private static readonly Func<TValue, TValue, bool> _comparer = GenerateComparer();

    public static bool AreEquivalent(TValue x, TValue y)
    {
        if (ReferenceEquals(x, y))
        {
            return true;
        }

        if (x is null || y is null)
        {
            return false;
        }

        return _comparer(x, y);
    }

    private static Func<TValue, TValue, bool> GenerateComparer()
    {
        var type = typeof(TValue);
        var xParam = Expression.Parameter(type, "x");
        var yParam = Expression.Parameter(type, "y");

        var properties = type.IsInterface
            ? InterfacePropertyHelper.GetAllInterfaceProperties(type)
            : type.GetProperties(BindingFlags.Public | BindingFlags.Instance);

        Expression body = null;

        foreach (var prop in properties)
        {
            var xProp = Expression.Property(xParam, prop);
            var yProp = Expression.Property(yParam, prop);

            Expression equalsExpr;

            // TODO: Implement proper value equality in LocalizedValue<T> 
            if (prop.PropertyType.IsGenericType &&
                prop.PropertyType.GetGenericTypeDefinition() == typeof(Core.Localization.LocalizedValue<>))
            {
                var genericArg = prop.PropertyType.GetGenericArguments()[0];

                var isEquivalentTo = (typeof(LocalizedValueExtensions)
                    .GetMethod(nameof(LocalizedValueExtensions.IsEquivalentTo),
                        BindingFlags.Public | BindingFlags.Static)
                    ?.MakeGenericMethod(genericArg)) ?? throw new InvalidOperationException("Could not find IsEquivalentTo<T>() method.");

                equalsExpr = Expression.Call(isEquivalentTo, xProp, yProp);
            }
            else
            {
                equalsExpr = Expression.Call(
                    typeof(object).GetMethod(nameof(Equals), [typeof(object), typeof(object)])!,
                    Expression.Convert(xProp, typeof(object)),
                    Expression.Convert(yProp, typeof(object)));
            }

            body = body == null ? equalsExpr : Expression.AndAlso(body, equalsExpr);
        }

        if (body == null)
        {
            return (_, _) => true;
        }

        return Expression.Lambda<Func<TValue, TValue, bool>>(body, xParam, yParam).Compile();
    }
}
