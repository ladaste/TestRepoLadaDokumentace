using System;
using ASOL.PlatformStore.Store.Domain.Options;

namespace ASOL.PlatformStore.Store.Domain.Helpers;

/// <summary>
/// A helper class for URL manipulations.
/// </summary>
public static class UrlHelper
{
    /// <summary>
    /// Tries to make the given URL absolute based on the hosting environment URL in the options.
    /// </summary>
    /// <param name="options"></param>
    /// <param name="url"></param>
    /// <returns></returns>
    public static string MakeAbsoluteUrlIfPossible(NavigationServiceOptions options, string url)
    {
        if (url == null)
        {
            return url;
        }
        if (url == string.Empty || url == "/")
        {
            return options.HostingEnvironmentUrl;
        }

        var baseUri = options
            .HostingEnvironmentUrl?
            .TrimEnd('/');

        var uri = new Uri(url, UriKind.RelativeOrAbsolute);
        if (uri.IsAbsoluteUri)
        {
            // url value already absolute path;
            return url;
        }
        if (url.StartsWith("/", StringComparison.OrdinalIgnoreCase))
        {
            return $"{baseUri}{url}";
        }
        else
        {
            return $"{baseUri}/{url}";
        }
    }
}
