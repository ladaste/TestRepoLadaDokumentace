using System;
using System.Collections.Generic;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Domain.Options;
using ASOL.PlatformStore.Store.Domain.Resources;
using Microsoft.Extensions.Options;

namespace ASOL.PlatformStore.Store.Domain.Helpers;

/// <summary>
/// Common validation helper for the Platform Store Order domain.
/// </summary>
/// <param name="options">Active appsettings configuration (AppUrl__BaseUrl)</param>
public class ValidationHelper(IOptions<AppUrlOptions> options)
{
    /// <summary>
    /// Validate the deeplink base URL against the current stage URL. Add an error to <paramref name="errors"/> if the deeplink URL is not whitelisted or has an incorrect format.
    /// Usefull for validating deeplink URLs before processing them in the system.
    /// </summary>
    /// <param name="errors"></param>
    /// <param name="deeplinkUrl"></param>
    /// <remarks>No exceptions. Only append errors.</remarks>
    public bool ValidateDeeplinkBaseUrl(List<ValidationError> errors, string deeplinkBaseUrl)
    {
        if (string.IsNullOrWhiteSpace(deeplinkBaseUrl))
        {
            errors.Add(new ValidationError(string.Format(ValidationResultMessages.UndefinedDeeplinkBaseUrl), [nameof(deeplinkBaseUrl)]));
            return false;
        }

        if (Uri.TryCreate(deeplinkBaseUrl, UriKind.Absolute, out var deeplinkUrlParsed))
        {
            var whitelistedUrlParsed = new Uri(options.Value.BaseUrl);
            if (deeplinkUrlParsed.Host != whitelistedUrlParsed.Host)
            {
                errors.Add(new ValidationError(string.Format(ValidationResultMessages.NotWhitelistedDeeplinkBaseUrl, deeplinkBaseUrl), [nameof(deeplinkBaseUrl)]));
                return false;
            }
            return true;
        }
        else
        {
            errors.Add(new ValidationError(string.Format(ValidationResultMessages.NotWhitelistedDeeplinkBaseUrl, deeplinkBaseUrl), [nameof(deeplinkBaseUrl)]));
            return false;
        }
    }
}
