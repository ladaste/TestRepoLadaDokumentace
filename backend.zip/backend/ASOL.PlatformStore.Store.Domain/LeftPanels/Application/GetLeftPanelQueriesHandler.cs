using System;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Identity;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Contracts.LeftPanels;
using ASOL.PlatformStore.Store.Domain.Extensions;
using ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

#nullable enable

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Application;

public sealed class GetLeftPanelQueriesHandler(
    ILeftPanelProvider leftPanelProvider,
    IRuntimeContext runtimeContext) :
    IQueryHandler<GetLeftPanelQuery, LeftPanelModel>,
    IQueryHandler<GetLeftPanelQuickAccessQuery, CollectionResult<PanelItemModel>>,
    IQueryHandler<GetLeftPanelAllApplicationsQuery, CollectionResult<PanelItemModel>>
{
    private readonly ILeftPanelProvider _leftPanelProvider = leftPanelProvider
            ?? throw new ArgumentNullException(nameof(leftPanelProvider));
    private readonly IRuntimeContext _runtimeContext = runtimeContext
            ?? throw new ArgumentNullException(nameof(runtimeContext));

    public async Task<QueryResult<LeftPanelModel>> HandleAsync(
        GetLeftPanelQuery query,
        CancellationToken ct)
    {
        ArgumentNullException.ThrowIfNull(query);

        var leftPanel = await GetLeftPanel(ct);
        var leftPanelModel = leftPanel.ToModel(
            query.QuickAccessPagination,
            query.AllAppsPagination);

        return new QueryResult<LeftPanelModel>(leftPanelModel);
    }

    public async Task<QueryResult<CollectionResult<PanelItemModel>>> HandleAsync(
        GetLeftPanelQuickAccessQuery query,
        CancellationToken ct)
    {
        ArgumentNullException.ThrowIfNull(query);

        var leftPanel = await GetLeftPanel(ct);
        return new(new CollectionResult<PanelItemModel>()
        {
            Items = [.. leftPanel.QuickAccess
                .ApplyPagingFilter(query.PagingFilter)
                .ToModel()],
            TotalCount = leftPanel.QuickAccess.Count,
        });
    }

    public async Task<QueryResult<CollectionResult<PanelItemModel>>> HandleAsync(
        GetLeftPanelAllApplicationsQuery query,
        CancellationToken ct)
    {
        ArgumentNullException.ThrowIfNull(query);

        var leftPanel = await GetLeftPanel(ct);
        return new(new CollectionResult<PanelItemModel>()
        {
            Items = [.. leftPanel.AllApplications
                .ApplyPagingFilter(query.PagingFilter)
                .ToModel()],
            TotalCount = leftPanel.AllApplications.Count,
        });
    }


    public Task<ValidationResult> ValidateAsync(
        GetLeftPanelQuery query,
        CancellationToken ct)
    {
        return ValidationResult.SuccessfulResultTask;
    }

    public Task<ValidationResult> ValidateAsync(
        GetLeftPanelQuickAccessQuery query,
        CancellationToken ct)
    {
        return ValidationResult.SuccessfulResultTask;
    }

    public Task<ValidationResult> ValidateAsync(
        GetLeftPanelAllApplicationsQuery query,
        CancellationToken ct)
    {
        return ValidationResult.SuccessfulResultTask;
    }

    private async Task<LeftPanel> GetLeftPanel(CancellationToken cancellationToken)
    {
        var userId = _runtimeContext.Security.UserId;
        var tenantId = _runtimeContext.Security.TenantId;

        try
        {
            return await _leftPanelProvider.GetOrCreateForUserAsync(userId, tenantId,
                cancellationToken);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(
                $"An error occured when retrieving an left panel of user '{userId}|{tenantId}'", ex);
        }
    }
}
