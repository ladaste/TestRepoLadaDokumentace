using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Contracts.LeftPanels;

#nullable enable

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Application;

public sealed record GetLeftPanelQuickAccessQuery(PagingFilter? PagingFilter)
    : IQuery<CollectionResult<PanelItemModel>>;
