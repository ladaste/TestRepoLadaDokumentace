using System;
using System.Collections.Generic;
using System.Linq;
using ASOL.PlatformStore.Store.Contracts.LeftPanels;
using ASOL.PlatformStore.Store.Contracts.LeftPanels.Updates;
using ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;
using ASOL.PlatformStore.Store.Domain.LeftPanels.Domain.Updates;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Application;

public static class ToDomainMapping
{
    public static IEnumerable<IPanelUpdate> ToDomain(this IEnumerable<PanelUpdateModel> models)
    {
        return models is { }
            ? models.Select(ToDomain)
            : throw new ArgumentNullException(nameof(models));
    }

    public static IPanelUpdate ToDomain(this PanelUpdateModel model) => model switch
    {
        CreateCustomItemModel createCustomItemModel => createCustomItemModel.ToDomain(),
        MoveItemModel moveItemModel => moveItemModel.ToDomain(),
        ChangeItemLabelModel changeItemLabelModel => changeItemLabelModel.ToDomain(),
        ChangeCustomItemUrlModel changeCustomItemUrlModel => changeCustomItemUrlModel.ToDomain(),
        ChangeItemIconModel changeItemIconModel => changeItemIconModel.ToDomain(),
        ChangeApplicationItemPinnedStateModel changeApplicationItemPinnedStateModel =>
            changeApplicationItemPinnedStateModel.ToDomain(),
        ChangeItemOpenInSeparateWindowStateModel changeItemOpenInSeparateWindowStateModel =>
            changeItemOpenInSeparateWindowStateModel.ToDomain(),
        RemoveItemModel removeItemModel => removeItemModel.ToDomain(),
        null => throw new ArgumentNullException(nameof(model)),
        _ => throw new NotImplementedException()
    };

    public static PanelPart ToDomain(this PanelPartModel model)
    {
        return model switch
        {
            PanelPartModel.QuickAccess => PanelPart.QuickAccess,
            PanelPartModel.AllApplications => PanelPart.AllApplications,
            _ => throw new ArgumentOutOfRangeException(nameof(model), model, null)
        };
    }

    public static PanelItemPosition ToDomain(this PanelItemPositionModel model)
    {
        ArgumentNullException.ThrowIfNull(model);

        return new PanelItemPosition(
            model.Part.ToDomain(),
            model.Index
        );
    }


    public static Icon ToDomain(this IconModel model)
    {
        ArgumentNullException.ThrowIfNull(model);

        return new Icon(
            model.Value,
            model.Type.ToDomain()
        );
    }

    public static IconType ToDomain(this IconTypeModel model)
    {
        return model switch
        {
            IconTypeModel.Url => IconType.Url,
            IconTypeModel.GoogleName => IconType.GoogleName,
            IconTypeModel.Svg => IconType.Svg,
            IconTypeModel.Initials => IconType.Initials,
            _ => throw new ArgumentOutOfRangeException(nameof(model))
        };
    }
    public static MoveItem ToDomain(this MoveItemModel model)
    {
        ArgumentNullException.ThrowIfNull(model);

        return new MoveItem(
            model.Position.ToDomain(),
            model.TargetPosition.ToDomain()
        );
    }

    public static CreateCustomItem ToDomain(this CreateCustomItemModel model)
    {
        ArgumentNullException.ThrowIfNull(model);

        return new CreateCustomItem(
            model.Position.ToDomain(),
            model.Label,
            model.Url
        );
    }

    public static ChangeItemLabel ToDomain(this ChangeItemLabelModel model)
    {
        ArgumentNullException.ThrowIfNull(model);

        return new ChangeItemLabel(
            model.Position.ToDomain(),
            model.Label
        );
    }

    public static ChangeCustomItemUrl ToDomain(this ChangeCustomItemUrlModel model)
    {
        ArgumentNullException.ThrowIfNull(model);

        return new ChangeCustomItemUrl(
            model.Position.ToDomain(),
            model.Url
        );
    }

    public static ChangeItemIcon ToDomain(this ChangeItemIconModel model)
    {
        ArgumentNullException.ThrowIfNull(model);

        return new ChangeItemIcon(
            model.Position.ToDomain(),
            model.Icon.ToDomain()
        );
    }

    public static ChangeApplicationItemPinnedState ToDomain(this ChangeApplicationItemPinnedStateModel model)
    {
        ArgumentNullException.ThrowIfNull(model);

        return new ChangeApplicationItemPinnedState(
            model.Position.ToDomain(),
            model.IsPinned
        );
    }

    public static ChangeItemOpenInSeparateWindowState ToDomain(this ChangeItemOpenInSeparateWindowStateModel model)
    {
        ArgumentNullException.ThrowIfNull(model);

        return new ChangeItemOpenInSeparateWindowState(
            model.Position.ToDomain(),
            model.OpenInSeparateWindow
        );
    }

    public static RemoveItem ToDomain(this RemoveItemModel model)
    {
        ArgumentNullException.ThrowIfNull(model);

        return new RemoveItem(
            model.Position.ToDomain()
        );
    }
}
