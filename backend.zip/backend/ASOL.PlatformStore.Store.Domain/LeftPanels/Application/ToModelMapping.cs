using System;
using System.Collections.Generic;
using System.Linq;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.PlatformStore.Store.Contracts.LeftPanels;
using ASOL.PlatformStore.Store.Domain.Extensions;
using ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

#nullable enable

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Application;

public static class ToModelMapping
{
    public static LeftPanelModel ToModel(
        this LeftPanel leftPanel,
        PagingFilter? quickAccessPagination,
        PagingFilter? allAppsPagination)
    {
        ArgumentNullException.ThrowIfNull(leftPanel);

        return new LeftPanelModel
        {
            QuickAccess = new()
            {
                TotalCount = leftPanel.QuickAccess.Count,
                Items = [.. leftPanel.QuickAccess
                    .ApplyPagingFilter(quickAccessPagination)
                    .ToModel()]
            },
            AllApplications = new()
            {
                TotalCount = leftPanel.AllApplications.Count,
                Items = [.. leftPanel.AllApplications
                    .ApplyPagingFilter(allAppsPagination)
                    .ToModel()]
            },
            Version = leftPanel.Version
        };
    }

    public static IEnumerable<PanelItemModel> ToModel(this IEnumerable<PanelItem> panelItems)
    {
        ArgumentNullException.ThrowIfNull(panelItems);

        return panelItems
            .Select(ToModel);
    }

    public static PanelItemModel ToModel(this PanelItem panelItem)
    {
        ArgumentNullException.ThrowIfNull(panelItem);

        var panelItemModel = panelItem switch
        {
            ApplicationPanelItem appPanelItem => new ApplicationPanelItemModel
            {
                ApplicationCode = appPanelItem.ApplicationCode,
                IsPinned = appPanelItem.IsPinned,
            },
            _ => new PanelItemModel()
        };

        return panelItem.OnModel(panelItemModel);
    }

    private static PanelItemModel OnModel(
        this PanelItem panelItem,
        PanelItemModel panelItemModel)
    {
        panelItemModel.Id = panelItem.Id;
        panelItemModel.Label = panelItem.Label;
        panelItemModel.Url = panelItem.Url.ToString();
        panelItemModel.Icon = panelItem.Icon.ToModel();
        panelItemModel.OpenInSeparateWindow = panelItem.OpenInSeparateWindow;
        panelItemModel.Type = panelItem.GetType().Name;

        return panelItemModel;
    }

    public static IconModel ToModel(this Icon icon)
    {
        ArgumentNullException.ThrowIfNull(icon);

        return new IconModel
        {
            Value = icon.Value,
            Type = (IconTypeModel)icon.Type
        };
    }
}
