using System;
using System.Collections.Generic;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Contracts.LeftPanels.Updates;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Application;

public sealed class UpdateLeftPanelCommand(int panelVersion, IEnumerable<PanelUpdateModel> updates) : ICommand<bool>
{
    public int PanelVersion { get; } = panelVersion;
    public IEnumerable<PanelUpdateModel> Updates { get; } = updates ?? throw new ArgumentNullException(nameof(updates));
}
