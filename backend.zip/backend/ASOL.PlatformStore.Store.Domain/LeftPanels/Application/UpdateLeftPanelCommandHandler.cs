using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Identity;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;
using ASOL.PlatformStore.Store.Domain.Repositories;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Application;

public sealed class UpdateLeftPanelCommandHandler(
    ILeftPanelRepository panelRepository,
    IRuntimeContext runtimeContext,
    ILogger<UpdateLeftPanelCommandHandler> logger) : ICommandHandler<UpdateLeftPanelCommand, bool>
{
    private readonly ILeftPanelRepository _panelRepository = panelRepository
            ?? throw new ArgumentNullException(nameof(panelRepository));
    private readonly IRuntimeContext _runtimeContext = runtimeContext
            ?? throw new ArgumentNullException(nameof(runtimeContext));
    private readonly ILogger _logger = logger ?? throw new ArgumentNullException(nameof(logger));

    public Task<ValidationResult> ValidateAsync(UpdateLeftPanelCommand command, CancellationToken ct)
    {
        return ValidationResult.SuccessfulResultTask;
    }

    public async Task<ExecutionResult<bool>> HandleAsync(UpdateLeftPanelCommand command,
        CancellationToken ct)
    {
        _logger.LogDebug("Handling UpdateLeftPanelCommand command.");

        ArgumentNullException.ThrowIfNull(command);

        try
        {
            await UpdatePanelAsync(command, ct);
            return new ExecutionResult<bool>(true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An exception occurred when processing UpdateLeftPanelCommand command.");
            throw;
        }
    }

    private async Task UpdatePanelAsync(UpdateLeftPanelCommand command,
        CancellationToken cancellationToken)
    {
        var userId = _runtimeContext.Security.UserId;
        var tenantId = _runtimeContext.Security.TenantId;

        _logger.LogDebug("Updating left panel for user = '{userId}|{tenantId}'",
            userId, tenantId);

        var panel = _panelRepository.GetAll()
            .ForUser(userId, tenantId)
            .FirstOrDefault();
        if (panel is null)
        {
            _logger.LogDebug("Updating left panel for user = '{userId}|{tenantId}' skipped - no left panel to found.",
                userId, tenantId);
            throw new KeyNotFoundException("Left panel not found.");
        }

        if (panel.Version != command.PanelVersion)
        {
            _logger.LogDebug("Updating left panel for user = '{userId}|{tenantId}' denied due to outdated version.",
                userId, tenantId);

            throw new UpdatingOutdatedDataException("Outdated left panel version.");
        }

        var updates = command.Updates.ToDomain();
        panel.Accept(updates);
        await _panelRepository.UpdateAsync(panel, cancellationToken);

        _logger.LogDebug("Left panel for user = '{userId}|{tenantId}' updated.",
            userId, tenantId);
    }
}
