using System;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Application;

public sealed class UpdatingOutdatedDataException : InvalidOperationException
{
    public UpdatingOutdatedDataException(string message) : base(message)
    {
    }
    public UpdatingOutdatedDataException(string message, Exception innerException)
        : base(message, innerException)
    {
    }
    public UpdatingOutdatedDataException() : this("Updating outdated data.")
    {
    }
}
