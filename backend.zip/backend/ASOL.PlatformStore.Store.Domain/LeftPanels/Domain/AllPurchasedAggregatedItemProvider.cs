using System;
using System.Collections.Frozen;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ASOL.Core.Domain;
using ASOL.Core.Domain.Contracts;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.IdentityManager.Connector;
using ASOL.PlatformStore.Store.Domain.Consts;
using ASOL.PlatformStore.Store.Domain.Extensions;
using ASOL.PlatformStore.Store.Domain.Repositories;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

internal sealed class AllPurchasedAggregatedItemProvider(
    IDbScopeSelector<IAllPurchasedAggregatedItemRepository> allPurchasedItemRepositorySelector,
    IIdentityManagerClient identityManagerClient,
    TimeProvider timeProvider) : IAllPurchasedAggregatedItemProvider
{
    private static readonly FrozenSet<string> s_alwaysLicensedApplicationCodes = new[]
    {
        AllPurchasedConstants.PlatformApplicationCode,
        AllPurchasedConstants.PortalApplicationCode,
        AllPurchasedConstants.PublicPortalApplicationCode
    }
    .ToFrozenSet(StringComparer.OrdinalIgnoreCase);

    private readonly IAllPurchasedAggregatedItemRepository _allPurchasedItems = allPurchasedItemRepositorySelector.GetRepository(DataAccessLevel.Public);
    private readonly IIdentityManagerClient _identityManagerClient = identityManagerClient;
    private readonly TimeProvider _timeProvider = timeProvider;

    public async Task<IEnumerable<AllPurchasedAggregatedItem>> GetRelevantForTenant(
        string tenantId)
    {
        ArgumentNullException.ThrowIfNull(tenantId);

        var userRolesResponse = await _identityManagerClient.Authorization.GetRoles();
        var userRoles = userRolesResponse?.Items.ToHashSet();

        var items = _allPurchasedItems
            .GetAll()
            .ApplyBaseEntityFilter(BaseEntityFilter.Default)
            .ForTenant(tenantId)
            .AreDone()
            .HaveLinks()
            .HasAccesibleByRole()
            .WithValidLicenseAt(_timeProvider.GetLocalNow().DateTime)
            .ToList();

        return Filter(items, userRoles);
    }

    public static IEnumerable<AllPurchasedAggregatedItem> Filter(
        IEnumerable<AllPurchasedAggregatedItem> items,
        IReadOnlySet<string> userRoles)
    {
        return items
            .Where(item => item.Licenses.Any(license =>
            {
                return s_alwaysLicensedApplicationCodes.Contains(item.ApplicationCode)
                    || userRoles.Contains(license.Role?.RoleCode);
            }));
    }
}
