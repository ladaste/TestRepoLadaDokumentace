using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.PlatformStore.Store.Domain.Events;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

internal class AllPurchasedDataEventsHandler(
    IImpersonateService impersonateService,
    ILogger<AllPurchasedDataEventsHandler> logger) :
    IDomainEventsHandler<EntityCreatedEvent<AllPurchasedAggregatedItem>>,
    IDomainEventsHandler<EntityChangedEvent<AllPurchasedAggregatedItem>>
{
    private readonly IImpersonateService _impersonateService = impersonateService;
    private readonly ILogger _logger = logger;

    public Task HandleAsync(IReadOnlyList<EntityCreatedEvent<AllPurchasedAggregatedItem>> events,
        CancellationToken cancellationToken)
    {
        _logger.LogDebug("Handling AllPurchasedAggregatedItem created events.");

        ArgumentNullException.ThrowIfNull(events);

        var tenantIds = events
            .Select(_ => _.Entity.TenantId)
            .Distinct();

        return MarkPanelForSynchronization(tenantIds, cancellationToken);
    }

    public Task HandleAsync(IReadOnlyList<EntityChangedEvent<AllPurchasedAggregatedItem>> events,
        CancellationToken cancellationToken)
    {
        _logger.LogDebug("Handling AllPurchasedAggregatedItem changed events.");

        ArgumentNullException.ThrowIfNull(events);

        var tenantIds = events
            .Select(_ => _.Entity.TenantId)
            .Distinct();

        return MarkPanelForSynchronization(tenantIds, cancellationToken);
    }

    private Task MarkPanelForSynchronization(IEnumerable<string> tenantIds,
        CancellationToken cancellationToken)
    {
        return Parallel.ForEachAsync(tenantIds, cancellationToken,
            MarkPanelForSynchronization);
    }

    private async ValueTask MarkPanelForSynchronization(string tenantId,
        CancellationToken cancellationToken)
    {
        try
        {
            using var tenantScope = _impersonateService.GetTenantContext(tenantId);
            var _panelRepository = tenantScope.ScopeProvider
                .GetRequiredService<ILeftPanelRepository>();

            var panels = _panelRepository
                .Get(_ => _.TenantId == tenantId)
                .ToList();

            foreach (var panel in panels)
            {
                panel.SetIsSynchronized(false);
                await _panelRepository.UpdateAsync(panel, cancellationToken);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An error occurred when marking panels for tenant '{tenantId}' for synchronization.",
                tenantId);
            throw;
        }
    }
}
