using System;
using ASOL.Core.Localization;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

public sealed class ApplicationPanelItem(
    string id,
    LocalizedValue<string> label,
    string url,
    Icon icon,
    bool isPinned,
    bool openInSeparateWindow,
    string applicationCode,
    DateTime? defaultOrder) : PanelItem(
            id,
            label,
            url,
            icon,
            openInSeparateWindow)
{
    public bool IsPinned { get; private set; } = isPinned;

    public string ApplicationCode { get; } = applicationCode
            ?? throw new ArgumentNullException(nameof(applicationCode));

    public DateTime? DefaultOrder { get; } = defaultOrder;

    internal override Updater GetUpdater(LeftPanel.Updater panelUpdater) =>
        new ApplicationItemUpdater(this, panelUpdater);

    public class ApplicationItemUpdater : Updater
    {
        public new ApplicationPanelItem Item { get; }

        public bool IsPinned { get; protected set; }
        public DateTime? DefaultOrder { get; protected set; }

        internal ApplicationItemUpdater(ApplicationPanelItem panelItem,
            LeftPanel.Updater panelUpdater)
            : base(panelItem, panelUpdater)
        {
            Item = panelItem
                ?? throw new ArgumentNullException(nameof(panelItem));
            IsPinned = panelItem.IsPinned;
            DefaultOrder = panelItem.DefaultOrder;
        }

        public void SetIsPinned(bool value)
        {
            IsPinned = value;
            ReportChange();
        }

        public override void SetUrl(string url) => throw new BusinessException(
            "Url of an application item cannot be changed.");

        protected override void WriteChanges()
        {
            base.WriteChanges();
            Item.IsPinned = IsPinned;
        }
    }
}
