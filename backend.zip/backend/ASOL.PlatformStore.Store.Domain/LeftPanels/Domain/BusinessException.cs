using System;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

public sealed class BusinessException(string message) : InvalidOperationException(message)
{
}
