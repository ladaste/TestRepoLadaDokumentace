using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

internal sealed class DefaultLeftPanelCreator(
    IAllPurchasedAggregatedItemProvider allPurchasedItemProvider,
    ILogger<DefaultLeftPanelCreator> logger) : IDefaultLeftPanelCreator
{
    private readonly IAllPurchasedAggregatedItemProvider _allPurchasedItemProvider = allPurchasedItemProvider
            ?? throw new ArgumentNullException(nameof(allPurchasedItemProvider));
    private readonly ILogger _logger = logger ?? throw new ArgumentNullException(nameof(logger));

    public async Task<LeftPanel> CreateForUserIdAsync(
        string userId,
        string tenantId,
        CancellationToken _)
    {
        _logger.LogDebug("Creating default left panel for user = '{userId}|{tenantId}'",
            userId, tenantId);

        var allPurchasedItems = (await _allPurchasedItemProvider.GetRelevantForTenant(tenantId))
            .OrderBy(_ => _.DateOfStatus)
            .ToList();

        IEnumerable<PanelItem> quickAccess = allPurchasedItems
            .Take(LeftPanel.MinQuickAccessLength)
            .ToPanelItems()
            .ToList();

        IEnumerable<PanelItem> allApplications = allPurchasedItems
            .Skip(LeftPanel.MinQuickAccessLength)
            .ToPanelItems()
            .ToList();

        var leftPanel = new LeftPanel(Guid.NewGuid().ToString(), userId, tenantId, quickAccess, allApplications);

        _logger.LogDebug("Default left panel for user = '{userId}|{tenantId}' created.",
            userId, tenantId);

        return leftPanel;
    }
}
