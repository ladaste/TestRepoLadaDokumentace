using System.Collections.Generic;
using System.Threading.Tasks;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

internal interface IAllPurchasedAggregatedItemProvider
{
    Task<IEnumerable<AllPurchasedAggregatedItem>> GetRelevantForTenant(string tenantId);
}
