using System.Threading;
using System.Threading.Tasks;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

public interface IDefaultLeftPanelCreator
{
    Task<LeftPanel> CreateForUserIdAsync(
        string userId,
        string tenantId,
        CancellationToken cancellationToken);
}
