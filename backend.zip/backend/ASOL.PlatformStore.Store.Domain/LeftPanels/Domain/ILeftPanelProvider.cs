using System.Threading;
using System.Threading.Tasks;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

public interface ILeftPanelProvider
{
    Task<LeftPanel> GetOrCreateForUserAsync(
        string userId,
        string tenantId,
        CancellationToken cancellationToken);
}
