using System.Threading;
using System.Threading.Tasks;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

internal interface ILeftPanelSynchronizer
{
    public Task Synchronize(LeftPanel panel, CancellationToken cancellationToken);
}
