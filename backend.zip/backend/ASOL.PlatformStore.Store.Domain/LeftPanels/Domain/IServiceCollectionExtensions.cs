using ASOL.PlatformStore.Store.Domain.Events;
using Microsoft.Extensions.DependencyInjection;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

public static class IServiceCollectionExtensions
{
    public static IServiceCollection AddLeftPanel(this IServiceCollection services) => services
        .AddTransient<IDefaultLeftPanelCreator, DefaultLeftPanelCreator>()
        .AddTransient<ILeftPanelProvider, LeftPanelProvider>()
        .AddTransient<ILeftPanelSynchronizer, LeftPanelSynchronizer>()
        .AddTransient<IAllPurchasedAggregatedItemProvider, AllPurchasedAggregatedItemProvider>()
        .AddScoped<IDomainEventsHandler<EntityCreatedEvent<AllPurchasedAggregatedItem>>, AllPurchasedDataEventsHandler>()
        .AddScoped<IDomainEventsHandler<EntityChangedEvent<AllPurchasedAggregatedItem>>, AllPurchasedDataEventsHandler>();
}
