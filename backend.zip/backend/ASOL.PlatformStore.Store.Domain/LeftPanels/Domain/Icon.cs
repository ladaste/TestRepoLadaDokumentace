using System.Collections.Generic;
using ASOL.Core.Domain;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

public sealed class Icon(string value, IconType type) : ValueObject
{
    public string Value { get; } = value;

    public IconType Type { get; } = type;

    protected override IEnumerable<object> GetAtomicValues()
    {
        yield return Value;
        yield return Type;
    }
}
