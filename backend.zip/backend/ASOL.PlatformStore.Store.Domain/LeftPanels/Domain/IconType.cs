namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

public enum IconType
{
    Url = 1,
    GoogleName = 2,
    Svg = 3,
    Initials = 4,
}
