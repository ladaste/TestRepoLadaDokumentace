using System;
using System.Collections.Generic;
using ASOL.Core.Domain;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

public sealed partial class LeftPanel : Entity<string>
{
    public const int MinQuickAccessLength = 5;

#pragma warning disable IDE0044 // Add readonly modifier
    private List<PanelItem> _quickAccess = [];
    private List<PanelItem> _allApplications = [];
#pragma warning restore IDE0044 // Add readonly modifier

    /// <summary>
    /// Default constructor for serialization. Do not use it explicitly!!!
    /// </summary>
    public LeftPanel()
    {
    }

    public LeftPanel(
        string id,
        string userId,
        string tenantId,
        IEnumerable<PanelItem> quickAccessItems,
        IEnumerable<PanelItem> allApplicationItems)
            : base(id)
    {
        UserId = userId ?? throw new ArgumentNullException(nameof(userId));
        TenantId = tenantId ?? throw new ArgumentNullException(nameof(tenantId));

        var updater = GetUpdater();
        updater.AddQuickAccessItems(quickAccessItems);
        updater.AddAllApplicationsItems(allApplicationItems);
        updater.Complete();

        Version = 0;
    }

    public string UserId { get; private set; }

    public string TenantId { get; private set; }

    /// <summary>
    /// Indicates whether the panel is synchronized with the purchased items.
    /// </summary>
    public bool IsSynchronized { get; private set; }

    public IReadOnlyList<PanelItem> QuickAccess => _quickAccess.AsReadOnly();
    public IReadOnlyList<PanelItem> AllApplications => _allApplications.AsReadOnly();

    public int Version { get; private set; }

    internal Updater GetUpdater() => new(this);

    /// <summary>
    /// Sets indication whether the panel is synchronized with the purchased items or not.
    /// </summary>
    /// <remarks>
    /// See <see cref="AllPurchasedDataEventsHandler"/> and <see cref="LeftPanelSynchronizer"/> resp. <see cref="LeftPanelProvider"/> for details.
    /// <param name="value"></param>
    public void SetIsSynchronized(bool value)
    {
        IsSynchronized = value;
        MarkAsChanged();
    }

    private void MarkAsChanged() => Version++;
}
