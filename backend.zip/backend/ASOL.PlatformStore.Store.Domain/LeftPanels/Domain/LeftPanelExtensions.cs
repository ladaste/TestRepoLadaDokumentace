using System;
using System.Collections.Generic;
using System.Linq;
using ASOL.PlatformStore.Store.Domain.LeftPanels.Domain.Updates;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

public static class LeftPanelExtensions
{
    public static IEnumerable<ApplicationPanelItem> GetApplicationItems(
        this LeftPanel panel)
    {
        ArgumentNullException.ThrowIfNull(panel);

        var quickAccessItems = panel.QuickAccess
            .OfType<ApplicationPanelItem>();
        var allApplicationItems = panel.AllApplications
            .OfType<ApplicationPanelItem>();

        return quickAccessItems.Concat(allApplicationItems);
    }

    public static void Accept(this LeftPanel panel, IEnumerable<IPanelUpdate> updates)
    {
        ArgumentNullException.ThrowIfNull(panel);
        ArgumentNullException.ThrowIfNull(updates);

        using var panelUpdater = panel.GetUpdater();

        foreach (var update in updates)
        {
            update.Apply(panelUpdater);
        }
    }

    public static void AddQuickAccessItems(this LeftPanel.Updater updater,
                IEnumerable<PanelItem> items)
    {
        ArgumentNullException.ThrowIfNull(updater);
        ArgumentNullException.ThrowIfNull(items);

        foreach (var item in items)
        {
            updater.AddQuickAccessItem(item);
        }
    }

    public static void AddAllApplicationsItems(this LeftPanel.Updater updater,
        IEnumerable<PanelItem> items)
    {
        ArgumentNullException.ThrowIfNull(updater);
        ArgumentNullException.ThrowIfNull(items);

        foreach (var item in items)
        {
            updater.AddAllApplicationsItem(item);
        }
    }
}
