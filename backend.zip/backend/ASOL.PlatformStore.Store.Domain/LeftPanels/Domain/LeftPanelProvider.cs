using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.PlatformStore.Store.Domain.Repositories;
using Microsoft.Extensions.Logging;

#nullable enable

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

internal sealed class LeftPanelProvider(
    ILeftPanelRepository panelRepository,
    IDefaultLeftPanelCreator defaultLeftPanelCreator,
    ILeftPanelSynchronizer leftPanelSynchronizer,
    ILogger<LeftPanelProvider> logger) : ILeftPanelProvider
{
    private readonly ILeftPanelRepository _panelRepository = panelRepository;
    private readonly IDefaultLeftPanelCreator _defaultLeftPanelCreator = defaultLeftPanelCreator;
    private readonly ILeftPanelSynchronizer _leftPanelSynchronizer = leftPanelSynchronizer;
    private readonly ILogger _logger = logger;

    public async Task<LeftPanel> GetOrCreateForUserAsync(
        string userId,
        string tenantId,
        CancellationToken cancellationToken)
    {
        _logger.LogDebug("Providing left panel for user = '{userId}|{tenantId}'.",
            userId, tenantId);

        var leftPanel = _panelRepository.GetAll()
            .ForUser(userId, tenantId)
            .FirstOrDefault();
        if (leftPanel is { })
        {
            _logger.LogDebug("Left panel for user = '{userId}|{tenantId}' found.",
                userId, tenantId);

            if (!leftPanel.IsSynchronized)
            {
                await _leftPanelSynchronizer.Synchronize(leftPanel, cancellationToken);
            }

            return leftPanel;
        }

        _logger.LogDebug("Left panel for user = '{userId}|{tenantId}' was not found.",
            userId, tenantId);

        var defaultLeftPanel = await _defaultLeftPanelCreator.CreateForUserIdAsync(
            userId,
            tenantId,
            cancellationToken);

        _panelRepository.Add(defaultLeftPanel);
        await (_panelRepository.UnitOfWork?.CompleteAsync(cancellationToken)
            ?? Task.CompletedTask);

        _logger.LogDebug("Default left panel for user = '{userId}|{tenantId}' was created.",
            userId, tenantId);

        return defaultLeftPanel;
    }
}
