using System.Linq;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

public static class LeftPanelQueryableExtensions
{
    public static IQueryable<LeftPanel> ForUser(this IQueryable<LeftPanel> leftPanel,
        string userId,
        string tenantId)
    {
        return leftPanel
            .Where(_ => _.UserId == userId
                && _.TenantId == tenantId);
    }
}
