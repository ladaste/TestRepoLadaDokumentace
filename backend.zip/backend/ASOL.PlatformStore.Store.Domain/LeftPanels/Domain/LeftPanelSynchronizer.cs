using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.PlatformStore.Store.Domain.Repositories;
using Microsoft.Extensions.Logging;

#nullable enable

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

internal sealed class LeftPanelSynchronizer(
    ILeftPanelRepository panelRepository,
    IAllPurchasedAggregatedItemProvider allPurchasedItemProvider,
    ILogger<LeftPanelSynchronizer> logger) : ILeftPanelSynchronizer
{
    private readonly ILeftPanelRepository _panelRepository = panelRepository
            ?? throw new ArgumentNullException(nameof(panelRepository));
    private readonly IAllPurchasedAggregatedItemProvider _allPurchasedItemProvider = allPurchasedItemProvider
            ?? throw new ArgumentNullException(nameof(allPurchasedItemProvider));
    private readonly ILogger _logger = logger;

    public async Task Synchronize(LeftPanel panel,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(panel);

        _logger.LogInformation(
            "Synchronizing left panel of user '{userId}|{tenantId}'.", panel.UserId, panel.TenantId);

        var allPurchasedItems = (await _allPurchasedItemProvider.GetRelevantForTenant(panel.TenantId))
            .ToDictionary(_ => _.ApplicationCode);

        SynchronizePanel(panel, new(allPurchasedItems));
        await _panelRepository.UpdateAsync(panel, cancellationToken);
    }

    private static void SynchronizePanel(LeftPanel panel,
        Dictionary<string, AllPurchasedAggregatedItem> purchasedItems)
    {
        using var panelUpdater = panel.GetUpdater();

        foreach (var item in panel.GetApplicationItems())
        {
            if (purchasedItems.Remove(item.ApplicationCode))
            {
                continue;
            }

            panelUpdater.RemoveItem(item);
        }

        var missingPanelItems = purchasedItems.Values
            .OrderBy(_ => _.DateOfStatus)
            .ToPanelItems();

        foreach (var item in missingPanelItems)
        {
            panelUpdater.AddAllApplicationsItem(item);
        }

        panelUpdater.SetSynchronized(true);
    }
}
