using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using ASOL.PlatformStore.Store.Domain.Extensions;
using ApplicationPanelItemUpdater = ASOL.PlatformStore.Store.Domain.LeftPanels.Domain.ApplicationPanelItem.ApplicationItemUpdater;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

public sealed partial class LeftPanel
{
    public sealed class Updater : IDisposable
    {
        private readonly List<PanelItem.Updater> _quickAccess;
        private readonly List<PanelItem.Updater> _allApplications;
        private readonly Dictionary<PanelItem, PanelItem.Updater> _itemUpdaters;

        private bool _isSynchronized;

        private bool _changeOccurred;
        private Action _writingChanges;

        public LeftPanel Panel { get; }

        public IReadOnlyList<PanelItem.Updater> QuickAccess => _quickAccess;
        public IReadOnlyList<PanelItem.Updater> AllApplications => _allApplications;

        public Action WritingChanges
        {
            get => _writingChanges;
            set => _writingChanges = value ?? throw new ArgumentNullException(nameof(WritingChanges));
        }

        internal Updater(LeftPanel panel)
        {
            Panel = panel ?? throw new ArgumentNullException(nameof(panel));

            _quickAccess = [.. panel._quickAccess.Select(_ => _.GetUpdater(this))];
            _allApplications = [.. panel._allApplications.Select(_ => _.GetUpdater(this))];
            _isSynchronized = panel.IsSynchronized;

            _itemUpdaters = _quickAccess.Concat(_allApplications)
                .ToDictionary(_ => _.Item);
        }

        public void ReportItemChange(PanelItem.Updater itemUpdater)
        {
            if (!_itemUpdaters.TryGetValue(itemUpdater.Item, out var registeredItemUpdater)
                || registeredItemUpdater != itemUpdater)
            {
                throw new Exception("Unknown item updater is reporting a change.");
            }

            _changeOccurred = true;
        }

        public void AddItemAt(PanelItem item, PanelItemPosition position)
        {
            ArgumentNullException.ThrowIfNull(item);
            ArgumentNullException.ThrowIfNull(position);

            var updater = item.GetUpdater(this);
            _itemUpdaters.Add(item, updater);
            var part = position.Part == PanelPart.QuickAccess
                ? _quickAccess
                : _allApplications;
            part.Insert((int)position.Index, updater);

            _changeOccurred = true;
        }

        public void AddAllApplicationsItem(PanelItem item)
        {
            ArgumentNullException.ThrowIfNull(item);

            var updater = item.GetUpdater(this);
            _itemUpdaters.Add(item, updater);
            _allApplications.Add(updater);

            _changeOccurred = true;
        }

        public void AddQuickAccessItem(PanelItem item)
        {
            ArgumentNullException.ThrowIfNull(item);

            var updater = item.GetUpdater(this);
            _itemUpdaters.Add(item, updater);
            _quickAccess.Add(updater);

            _changeOccurred = true;
        }

        public void RemoveItem(PanelItemPosition position)
        {
            var updater = GetItemUpdater(position, out var part);

            _itemUpdaters.Remove(updater.Item);
            part.RemoveAt((int)position.Index);

            _changeOccurred = true;
        }

        public void RemoveItem(PanelItem item)
        {
            ArgumentNullException.ThrowIfNull(item);

            if (!_itemUpdaters.TryGetValue(item, out var updater))
            {
                throw Error.ItemNotFound();
            }

            _itemUpdaters.Remove(updater.Item);
            var _ = _quickAccess.Remove(updater) || _allApplications.Remove(updater);
            _changeOccurred = true;
        }

        public void MoveItem(PanelItemPosition position, PanelItemPosition targetPosition)
        {
            ArgumentNullException.ThrowIfNull(position);
            ArgumentNullException.ThrowIfNull(targetPosition);

            if (position == targetPosition)
            {
                return;
            }

            if (position.Part == targetPosition.Part)
            {
                var part = position.Part == PanelPart.QuickAccess
                   ? _quickAccess
                   : _allApplications;

                part.Move((int)position.Index, (int)targetPosition.Index);
            }
            else
            {
                var (sourcePart, targetPart) = position.Part == PanelPart.QuickAccess
                    ? (_quickAccess, _allApplications)
                    : (_allApplications, _quickAccess);

                var movedUpdater = sourcePart[(int)position.Index];

                sourcePart.RemoveAt((int)position.Index);
                targetPart.Insert((int)targetPosition.Index, movedUpdater);
            }

            _changeOccurred = true;
        }

        public PanelItem.Updater GetItemUpdater(PanelItemPosition position) => GetItemUpdater(
            position, out _);

        public void SetSynchronized(bool isSynchronized)
        {
            _isSynchronized = isSynchronized;
            _changeOccurred = true;
        }

        public void Complete()
        {
            if (!_changeOccurred)
            {
                return;
            }

            AssertNoDuplicateApplicationItems();
            Normalize();

            _writingChanges?.Invoke();

            Panel._quickAccess.Clear();
            Panel._quickAccess.AddRange(_quickAccess.Select(_ => _.Item));

            Panel._allApplications.Clear();
            Panel._allApplications.AddRange(_allApplications.Select(_ => _.Item));

            Panel.IsSynchronized = _isSynchronized;

            Panel.MarkAsChanged();
        }

        private PanelItem.Updater GetItemUpdater(PanelItemPosition position,
            out List<PanelItem.Updater> part)
        {
            ArgumentNullException.ThrowIfNull(position);

            part = position.Part == PanelPart.QuickAccess
                ? _quickAccess
                : _allApplications;

            return position.Index < part.Count
                ? part[(int)position.Index]
                : throw Error.PositionOutOfRange();
        }

        private void Normalize()
        {
            static void MakePinnedItemsContinuous(IReadOnlyList<PanelItem.Updater> updaters,
                out int unpinnedIndex)
            {
                var index = updaters.Count;
                while (--index >= 0)
                {
                    var updater = updaters[index];
                    if (updater is not ApplicationPanelItemUpdater applicationItemUpdater
                        || applicationItemUpdater.IsPinned)
                    {
                        break;
                    }
                }
                unpinnedIndex = index + 1;
                while (--index >= 0)
                {
                    var updater = updaters[index];
                    if (updater is ApplicationPanelItemUpdater applicationItemUpdater
                        && !applicationItemUpdater.IsPinned)
                    {
                        applicationItemUpdater.SetIsPinned(true);
                    }
                }
            }

            MakePinnedItemsContinuous(_quickAccess, out var quickAccessUnpinnedIndex);
            MakePinnedItemsContinuous(_allApplications, out var allApplicationsUnpinnedIndex);

            // Balance QuickAccess 
            while (_quickAccess.Count < MinQuickAccessLength
                && allApplicationsUnpinnedIndex < _allApplications.Count)
            {
                var updater = _allApplications[allApplicationsUnpinnedIndex];
                _allApplications.RemoveAt(allApplicationsUnpinnedIndex);
                _quickAccess.Add(updater);
            }
            while (_quickAccess.Count > MinQuickAccessLength
                && quickAccessUnpinnedIndex < _quickAccess.Count)
            {
                var updater = _quickAccess[^1];
                _quickAccess.RemoveAt(_quickAccess.Count - 1);
                _allApplications.Insert(allApplicationsUnpinnedIndex, updater);
            }

            // Sort Unpinned items
            var quickAccessUnpinnedItems = CollectionsMarshal
                .AsSpan(_quickAccess)[quickAccessUnpinnedIndex..];
            var allApplicationsUnpinnedItems = CollectionsMarshal
                .AsSpan(_allApplications)[allApplicationsUnpinnedIndex..];

            Sort.Make(quickAccessUnpinnedItems, allApplicationsUnpinnedItems,
                updater => ((ApplicationPanelItemUpdater)updater).DefaultOrder ?? DateTime.MinValue);
        }

        private void AssertNoDuplicateApplicationItems()
        {
            var allAppsApplicationCodes = _allApplications
                .Select(_ => _.Item);
            var quickAccessApplicationCodes = _quickAccess
                .Select(_ => _.Item);

            var allItems = allAppsApplicationCodes
                .Concat(quickAccessApplicationCodes);

            Assert.NoDuplicateApplicationItems(allItems);
        }

        public void Dispose()
        {
            Complete();
        }
    }

    private static class Assert
    {
        public static void NoDuplicateApplicationItems(IEnumerable<PanelItem> items)
        {
            var duplicitApplicationItems = items
                .OfType<ApplicationPanelItem>()
                .GroupBy(_ => _.ApplicationCode)
                .Where(_ => _.Count() > 1)
                .Select(group => group.First())
                .ToList();

            if (duplicitApplicationItems.Count > 0)
            {
                throw Error.DuplicateApplicationItems(duplicitApplicationItems);
            }
        }
    }

    private static class Error
    {
        public static BusinessException DuplicateApplicationItems(
            IEnumerable<ApplicationPanelItem> duplicateApplicationItems)
        {
            var appCodes = duplicateApplicationItems
                .Select(_ => _.ApplicationCode);
            throw new BusinessException(
                $"Duplicate application items '{string.Join("', '", appCodes)}'.");
        }

        public static BusinessException ItemNotFound() =>
            new("Item is neither part or quick access nor all applications.");

        public static BusinessException PositionOutOfRange() =>
            new("There is no item at specified position.");
    }
}
