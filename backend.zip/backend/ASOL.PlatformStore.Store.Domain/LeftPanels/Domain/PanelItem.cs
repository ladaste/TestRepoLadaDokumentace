using System;
using ASOL.Core.Domain;
using ASOL.Core.Localization;

#nullable enable

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

public partial class PanelItem(
    string id,
    LocalizedValue<string> label,
    string url,
    Icon icon,
    bool openInSeparateWindow) : Entity<string>(id)
{
    public LocalizedValue<string> Label { get; private set; } = label ?? throw new ArgumentNullException(nameof(label));

    public string Url { get; private set; } = url ?? throw new ArgumentNullException(nameof(url));

    public Icon Icon { get; private set; } = icon ?? throw new ArgumentNullException(nameof(icon));

    public bool OpenInSeparateWindow { get; private set; } = openInSeparateWindow;

    internal virtual Updater GetUpdater(LeftPanel.Updater panelUpdater) =>
        new(this, panelUpdater);
}
