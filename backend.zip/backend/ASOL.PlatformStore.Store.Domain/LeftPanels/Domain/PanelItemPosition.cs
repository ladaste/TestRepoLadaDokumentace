namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

public sealed record PanelItemPosition(PanelPart Part, uint Index);
