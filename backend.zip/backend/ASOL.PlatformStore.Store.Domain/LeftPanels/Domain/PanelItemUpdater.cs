using System;
using ASOL.Core.Localization;

#nullable enable

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

public partial class PanelItem
{
    public class Updater
    {
        protected readonly LeftPanel.Updater _panelUpdater;

        public PanelItem Item { get; }

        public LocalizedValue<string> Label { get; protected set; }
        public string Url { get; protected set; }
        public Icon Icon { get; protected set; }
        public bool OpenInSeparateWindow { get; protected set; }

        internal Updater(PanelItem panelItem, LeftPanel.Updater panelUpdater)
        {
            Item = panelItem ?? throw new ArgumentNullException(nameof(panelItem));
            _panelUpdater = panelUpdater ?? throw new ArgumentNullException(nameof(panelUpdater));
            _panelUpdater.WritingChanges += WriteChanges;

            Label = panelItem.Label;
            Url = panelItem.Url;
            Icon = panelItem.Icon;
            OpenInSeparateWindow = panelItem.OpenInSeparateWindow;
        }

        public void SetLabel(LocalizedValue<string> label)
        {
            Label = label ?? throw new ArgumentNullException(nameof(label));
            ReportChange();
        }

        public virtual void SetUrl(string url)
        {
            Url = url ?? throw new ArgumentNullException(nameof(url));
            ReportChange();
        }

        public void SetIcon(Icon icon)
        {
            Icon = icon ?? throw new ArgumentNullException(nameof(icon));
            ReportChange();
        }

        public void SetOpenInSeparateWindow(bool value)
        {
            OpenInSeparateWindow = value;
            ReportChange();
        }

        protected void ReportChange() => _panelUpdater.ReportItemChange(this);

        protected virtual void WriteChanges()
        {
            Item.Label = Label;
            Item.Url = Url;
            Item.Icon = Icon;
            Item.OpenInSeparateWindow = OpenInSeparateWindow;
        }
    }
}
