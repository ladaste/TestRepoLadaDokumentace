namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

public enum PanelPart
{
    QuickAccess = 1,
    AllApplications = 2
}
