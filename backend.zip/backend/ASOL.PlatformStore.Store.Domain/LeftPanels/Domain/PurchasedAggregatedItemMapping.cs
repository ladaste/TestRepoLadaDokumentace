using System;
using System.Collections.Generic;
using System.Linq;
using ASOL.Core.Localization;
using ASOL.PlatformStore.Store.Domain.Extensions;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

internal static class PurchasedAggregatedItemMapping
{
    public static ApplicationPanelItem ToPanelItem(this AllPurchasedAggregatedItem item)
    {
        const string defaultLangugage = "en";

        ArgumentNullException.ThrowIfNull(item);

        var initials = item.Name.Translate(defaultLangugage, default).GetInitials();

        return new ApplicationPanelItem(
            id: Guid.NewGuid().ToString(),
            label: item.Name,
            url: item.FrontendUrl,
            icon: new Icon(initials, IconType.Initials),
            isPinned: false,
            openInSeparateWindow: false,
            applicationCode: item.ApplicationCode,
            defaultOrder: item.DateOfStatus
                ?? item.OrderDate);
    }

    public static IEnumerable<ApplicationPanelItem> ToPanelItems(
        this IEnumerable<AllPurchasedAggregatedItem> items)
    {
        ArgumentNullException.ThrowIfNull(items);

        return items
            .Select(ToPanelItem);
    }
}
