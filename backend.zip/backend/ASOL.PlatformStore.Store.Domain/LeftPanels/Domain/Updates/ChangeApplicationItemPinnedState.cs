using System;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain.Updates;

public sealed record ChangeApplicationItemPinnedState
(
    PanelItemPosition Position,
    bool IsPinned
)
    : IPanelUpdate
{
    public void Apply(LeftPanel.Updater panelUpdater)
    {
        ArgumentNullException.ThrowIfNull(panelUpdater);

        var updater = panelUpdater.GetItemUpdater(Position);
        if (updater is not ApplicationPanelItem.ApplicationItemUpdater applicationItemUpdater)
        {
            throw new BusinessException("Custom panel item cannot be pinned or unpinned.");
        }

        applicationItemUpdater.SetIsPinned(IsPinned);
    }
}
