using System;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain.Updates;

public sealed record ChangeCustomItemUrl
(
    PanelItemPosition Position,
    string Url
)
    : IPanelUpdate
{
    public void Apply(LeftPanel.Updater panelUpdater)
    {
        ArgumentNullException.ThrowIfNull(panelUpdater);

        panelUpdater.GetItemUpdater(Position).SetUrl(Url);
    }
}
