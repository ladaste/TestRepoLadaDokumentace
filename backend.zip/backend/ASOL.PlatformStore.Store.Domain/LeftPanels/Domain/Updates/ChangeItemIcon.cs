using System;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain.Updates;

public sealed record ChangeItemIcon
(
    PanelItemPosition Position,
    Icon Icon
)
    : IPanelUpdate
{
    public void Apply(LeftPanel.Updater panelUpdater)
    {
        ArgumentNullException.ThrowIfNull(panelUpdater);

        panelUpdater.GetItemUpdater(Position).SetIcon(Icon);
    }
}
