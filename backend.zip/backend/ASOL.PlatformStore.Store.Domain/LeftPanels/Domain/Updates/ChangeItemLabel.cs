using System;
using ASOL.Core.Localization;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain.Updates;

public sealed record ChangeItemLabel
(
    PanelItemPosition Position,
    LocalizedValue<string> Label
)
    : IPanelUpdate
{
    public void Apply(LeftPanel.Updater panelUpdater)
    {
        ArgumentNullException.ThrowIfNull(panelUpdater);

        panelUpdater.GetItemUpdater(Position).SetLabel(Label);
    }
}
