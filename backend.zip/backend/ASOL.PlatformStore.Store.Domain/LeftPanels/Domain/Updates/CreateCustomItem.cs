using System;
using System.Linq;
using ASOL.Core.Localization;
using ASOL.PlatformStore.Store.Domain.Extensions;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain.Updates;

public sealed record CreateCustomItem
(
    PanelItemPosition Position,
    LocalizedValue<string> Label,
    string Url
)
    : IPanelUpdate
{
    public void Apply(LeftPanel.Updater panelUpdater)
    {
        ArgumentNullException.ThrowIfNull(panelUpdater);

        var initialsSource = Label.Translate(string.Empty, Label.Values.FirstOrDefault().Value);

        var item = new PanelItem(
            id: Guid.NewGuid().ToString(),
            label: Label,
            url: Url,
            icon: new(initialsSource.GetInitials(), IconType.Initials),
            openInSeparateWindow: false);

        panelUpdater.AddItemAt(item, Position);
    }
}
