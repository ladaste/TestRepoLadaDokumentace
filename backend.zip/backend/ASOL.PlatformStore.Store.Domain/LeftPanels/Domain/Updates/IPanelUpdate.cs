namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain.Updates;

public interface IPanelUpdate
{
    public void Apply(LeftPanel.Updater panelUpdater);
}
