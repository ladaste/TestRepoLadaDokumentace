using System;

namespace ASOL.PlatformStore.Store.Domain.LeftPanels.Domain.Updates;

public sealed record MoveItem
(
    PanelItemPosition Position,
    PanelItemPosition TargetPosition
)
    : IPanelUpdate
{
    public void Apply(LeftPanel.Updater panelUpdater)
    {
        ArgumentNullException.ThrowIfNull(panelUpdater);

        panelUpdater.MoveItem(Position, TargetPosition);
    }
}
