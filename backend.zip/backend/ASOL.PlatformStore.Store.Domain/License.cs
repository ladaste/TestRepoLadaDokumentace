using System;
using System.Collections.Generic;
using ASOL.Core.Domain;
using ASOL.Core.Localization;
using ASOL.IdentityManager.Contracts;

namespace ASOL.PlatformStore.Store.Domain;

/// <summary>
/// Represents a lightweight, value-object model of a license, primarily used for aggregation and data transfer
/// within <see cref="AllPurchasedAggregatedItem"/>. This class is not a full domain entity and is not intended
/// for direct manipulation of subscription-bound licenses.
/// <para>
/// <b>This entity exists outside of event sourcing and the Subscription aggregate.</b>
/// It serves only as a technical and temporary structure for listing or aggregating purchased licenses,
/// and is not part of the event-sourced domain model.
/// </para>
/// <para>
/// For full domain logic and management of licenses bound to subscriptions, see
/// <see cref="ASOL.PlatformStore.Store.Domain.SubscriptionRoot.SubscriptionLicense"/>.
/// </para>
/// </summary>
public class License : ValueObject
{
    /// <summary>
    /// Constructor for serialize/deserialize. Don't use it directly.
    /// </summary>
    public License()
    {
    }

    public string LicenseId { get; set; }

    /// <summary>
    /// License code.
    /// </summary>
    public string Code { get; set; }

    /// <summary>
    /// License name.
    /// </summary>
    public LocalizedValue<string> Name { get; set; }

    /// <summary>
    /// Order (number) which created this license.
    /// </summary>
    public string OrderNumber { get; set; }

    /// <summary>
    /// Order line which created this license. Identification within <see cref="P:ASOL.IdentityManager.Contracts.LicenseModel.OrderNumber" />
    /// </summary>
    public string OrderLineId { get; set; }

    /// <summary>
    /// Billing period code.
    /// </summary>
    public string BillingPeriodCode { get; set; }

    /// <summary>
    /// Accrual date from of latest invoice.
    /// </summary>
    public DateTime? LatestInvoiceAccrualDateFrom { get; set; }

    /// <summary>
    /// Accrual date to of latest invoice.
    /// </summary>
    public DateTime? LatestInvoiceAccrualDateTo { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether the item is free of charge.
    /// </summary>
    public bool? IsFree { get; set; }

    /// <summary>
    /// Data format version of this license.
    /// </summary>
    public int FormatVersion { get; set; }

    /// <summary>
    /// Gets License role. (Only valid when FormatVersion is 1 or greater). For FormatVersion 0 you must read Feature.Roles array.
    /// </summary>
    public LicenseRole Role { get; set; }

    /// <summary>
    /// Current license system status <see cref="T:ASOL.IdentityManager.Contracts.LicenseSystemStatus" />.
    /// </summary>
    public LicenseSystemStatus? Status { get; set; }

    public DateTime? ValidFrom { get; set; }

    public DateTime? ValidTo { get; set; }

    protected override IEnumerable<object> GetAtomicValues()
    {
        yield return LicenseId;
        yield return Code;
        yield return OrderNumber;
        yield return OrderLineId;
        yield return FormatVersion;
        yield return Role;
        yield return Status;
    }
}
