using System.Collections.Generic;
using ASOL.Core.Domain;
using ASOL.Core.Localization;

namespace ASOL.PlatformStore.Store.Domain;

/// <summary>
/// Root entity for this domain.
/// </summary>
public class LicenseRole : ValueObject
{
    /// <summary>
    /// Constructor for serialize/deserialize. Don't use it directly.
    /// </summary>
    public LicenseRole()
    {
    }

    public string RoleCode { get; set; }

    /// <summary>
    /// Only for GET actions. PATCH, POST and PUT actions always ignore it.
    /// </summary>
    public LocalizedValue<string> RoleName { get; set; }

    public bool IsTrial { get; set; }

    /// <summary>
    /// Maximum users allowed in license for this role.
    /// </summary>
    public int? UserMaxCount { get; set; }

    /// <summary>
    /// Current users count in license for this role.
    /// </summary>
    public int? UserCount { get; set; }

    protected override IEnumerable<object> GetAtomicValues()
    {
        yield return RoleCode;
        yield return RoleName;
        yield return IsTrial;
        yield return UserMaxCount;
        yield return UserCount;
    }
}
