namespace ASOL.PlatformStore.Store.Domain;

public class MediaFile
{
    public string Type { get; set; }

    public FileReference ContentFile { get; set; }

    public FileReference PosterFile { get; set; }
}
