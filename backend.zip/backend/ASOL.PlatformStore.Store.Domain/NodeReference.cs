using System;
using System.Collections.Generic;
using ASOL.Core.Domain;
using ASOL.PlatformStore.Store.Contracts;

namespace ASOL.PlatformStore.Store.Domain;

/// <summary>
/// Class for referencing the child nodes in the product catalog tree
/// </summary>
/// <remarks>
/// Initializes the instance
/// </remarks>
/// <param name="id">Id of the reference node</param>
/// <param name="partCode">Part code of the referenced node</param>
/// <param name="code">Code of the referenced node</param>
/// <param name="referencedNodeType">Type of the referenced node</param>
public class NodeReference(string id, string partCode, string code, NodeTypeModel referencedNodeType) : ValueObject
{
    /// <summary>
    /// Id of the referenced node
    /// </summary>
    public string Id { get; set; } = id;

    /// <summary>
    /// Part code of the referenced node
    /// </summary>
    public string PartCode { get; set; } = partCode;

    /// <summary>
    /// Part code of the referenced node
    /// </summary>
    public string Code { get; set; } = code;

    /// <summary>
    /// Name of the referenced node
    /// </summary>
    public string Name { get; set; }

    /// <summary>
    /// Flag is reference is mandatory
    /// </summary>
    public bool IsMandatory { get; set; }

    /// <summary>
    /// Option group code for defining groups of references
    /// </summary>
    public string OptionGroupCode { get; set; }

    /// <summary>
    /// Type of referenced node
    /// </summary>
    public NodeTypeModel ReferencedNodeType { get; set; } = referencedNodeType;

    /// <summary>
    /// Sequence number
    /// </summary>
    public int? SequenceNumber { get; set; }

    /// <summary>
    /// OwnershipType
    /// </summary>
    public OwnershipType? OwnershipType { get; set; }

    /// <summary>
    /// Code from BillingPeriod codebook
    /// </summary>
    public string BillingPeriodCode { get; set; }

    /// <summary>
    /// Valid from
    /// </summary>
    public DateTime? ValidFrom { get; set; }

    /// <summary>
    /// Valid to
    /// </summary>
    public DateTime? ValidTo { get; set; }

    /// <summary>
    /// Upgrade type
    /// </summary>
    public UpgradeType? UpgradeType { get; set; }

    /// <summary>
    /// can be canceled / cannot be canceled
    /// </summary>
    public bool? CanCancel { get; set; }

    /// <summary>
    /// Sales item
    /// </summary>
    public SalesItemReference SalesItem { get; set; }

    /// <inheritdoc/>
    protected override IEnumerable<object> GetAtomicValues()
    {
        return [Id];
    }
}
