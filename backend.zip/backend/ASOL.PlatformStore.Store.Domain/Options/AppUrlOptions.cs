namespace ASOL.PlatformStore.Domain.Options;

public class AppUrlOptions
{
    public static readonly string DefaultSectionName = "AppUrl";

    public string BaseUrl { get; set; }
}
