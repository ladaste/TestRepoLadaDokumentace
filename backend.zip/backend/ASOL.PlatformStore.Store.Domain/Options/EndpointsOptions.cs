namespace ASOL.PlatformStore.Order.Domain.Options;

public class EndpointsOptions
{
    /// <summary>
    /// Endpoint settings.
    /// </summary>
    public HttpsOptions Https { get; set; }
}
