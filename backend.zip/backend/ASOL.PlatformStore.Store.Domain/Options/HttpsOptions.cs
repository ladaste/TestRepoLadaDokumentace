namespace ASOL.PlatformStore.Order.Domain.Options;

public class HttpsOptions
{
    /// <summary>
    /// Url of kestrel.
    /// </summary>
    public string Url { get; set; }
}
