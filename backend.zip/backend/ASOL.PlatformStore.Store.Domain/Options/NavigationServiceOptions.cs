namespace ASOL.PlatformStore.Store.Domain.Options;

public class NavigationServiceOptions
{
    public string HostingEnvironmentUrl { get; set; }

    // TODO: this collection will be returns from IDP service master data....
    public string[] KnownHostNames { get; set; }
}

