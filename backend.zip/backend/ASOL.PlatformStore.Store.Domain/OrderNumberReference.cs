namespace ASOL.PlatformStore.Store.Domain;

public sealed record OrderNumberReference(string OrderNumber, bool IsSystem)
{
    public static OrderNumberReference System(string orderNumber)
    {
        return new(orderNumber, true);
    }

    public static OrderNumberReference NonSystem(string orderNumber)
    {
        return new(orderNumber, false);
    }

    public override string ToString()
    {
        return OrderNumber;
    }
}
