namespace ASOL.PlatformStore.Store.Domain;

/// <summary>
/// Ownership type
/// </summary>
public enum OwnershipType
{
    /// <summary>
    /// Own
    /// </summary>
    Own = 1,

    /// <summary>
    /// Rent
    /// </summary>
    Rent = 2
}
