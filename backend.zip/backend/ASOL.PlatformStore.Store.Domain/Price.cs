using System;
using System.Collections.Generic;
using ASOL.Core.Domain;

namespace ASOL.PlatformStore.Store.Domain;

public class Price : ValueObject
{
    public DateTime? ValidFrom { get; set; }
    public DateTime? ValidTo { get; set; }
    public decimal BasePrice { get; set; }

    protected override IEnumerable<object> GetAtomicValues()
    {
        return [ValidFrom, ValidTo, BasePrice];
    }
}
