using System.Collections.Generic;
using ASOL.Core.Domain;

namespace ASOL.PlatformStore.Store.Domain;

public class PriceScale : ValueObject
{
    public int? MinLicences { get; set; }
    public int? MaxLicences { get; set; }
    public decimal BasePricePercentage { get; set; }

    protected override IEnumerable<object> GetAtomicValues()
    {
        return [MinLicences, MaxLicences, BasePricePercentage];
    }
}
