using System.Collections.Generic;
using System.Dynamic;
using System.Security.Claims;
using ASOL.Core.CustomAttributes.Domain;
using ASOL.Core.CustomAttributes.Domain.Entities.Definition;
using ASOL.Core.Domain;
using ASOL.PlatformStore.Store.Contracts;

namespace ASOL.PlatformStore.Store.Domain;

/// <summary>
/// Entity for the product catalog node type ProductCatalogNode - base class for other types
/// </summary>    

public class ProductCatalog : BaseEntity<string>, IExpandableEntity
{
    /// <inheritdoc/>
    public ProductCatalog()
    {
    }

    /// <inheritdoc/>
    public ProductCatalog(string id, ClaimsPrincipal user, string code)
        : base(id, user)
    {
        Code = code;
    }

    /// <summary>
    /// Type of the node
    /// </summary>
    public virtual NodeTypeModel NodeType { get; set; }

    /// <summary>
    /// Code of the item
    /// </summary>
    public string Code { get; set; }

    /// <summary>
    /// Part code of the item
    /// </summary>
    public string PartCode { get; set; }

    /// <summary>
    /// Name of the item
    /// </summary>
    public string Name { get; set; }

    /// <summary>
    /// Description
    /// </summary>
    public string Description { get; set; }

    /// <summary>
    /// Code from ItemType codebook
    /// </summary>
    public string ItemTypeCode { get; set; }

    /// <summary>
    /// OwnershipType
    /// </summary>
    public OwnershipType? OwnershipType { get; set; }

    /// <summary>
    /// Code from BillingPeriod codebook
    /// </summary>
    public string BillingPeriodCode { get; set; }

    /// <summary>
    /// Unit Of Sale - code
    /// </summary>
    public string UnitOfSaleCode { get; set; }

    /// <summary>
    /// Unit Of Measure - code
    /// </summary>
    public string UnitOfMeasureCode { get; set; }

    /// <summary>
    /// Sequence id
    /// </summary>
    public object SequenceId { get; set; }

    /// <summary>
    /// List of the child items
    /// </summary>
    public List<NodeReference> Children { get; set; }

    /// <summary>
    /// Revision
    /// </summary>
    public string Revision { get; set; }

    /// <summary>
    /// Version
    /// </summary>
    public string Version { get; set; }

    /// <summary>
    /// List of custom attributes
    /// </summary>
    public ExpandoObject CustomAttributes { get; set; }

    /// <summary>
    /// List of assigned categories
    /// </summary>
    public ICollection<CategoryReference> Categories { get; set; }

    /// <summary>
    /// Id of the tenant of the product vendor
    /// </summary>
    public string VendorTenantId { get; set; }

    /// <summary>
    /// Flag indicating if the record is published
    /// </summary>
    public bool Published { get; set; }

    /// <summary>
    /// Inherits billing period
    /// </summary>
    public bool InheritsBillingPeriod { get; set; }

    /// <summary>
    /// Inherits amount of units
    /// </summary>
    public bool InheritsAmountOfUnits { get; set; }
}
