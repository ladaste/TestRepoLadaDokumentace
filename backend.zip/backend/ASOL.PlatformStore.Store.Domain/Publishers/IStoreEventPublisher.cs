using System;
using System.Threading;
using System.Threading.Tasks;

namespace ASOL.PlatformStore.Store.Domain.Publishers;

/// <summary>
/// Service for raising notifications about <see cref="Store"/> events.
/// </summary>
public interface IStoreEventPublisher
{
    /// <summary>
    /// Publish <see cref="TriggerHelpDeskTickets"/> event.
    /// </summary>
    /// <param name="subject"></param>
    /// <param name="message"></param>
    /// <param name="applicationCode"></param>
    /// <param name="currentUrl"></param>
    /// <param name="ct"></param>
    /// <returns></returns>
    Task PublishHelpdeskRequestAsync(string subject, string message, string applicationCode, string currentUrl, CancellationToken ct = default);

    /// <summary>
    /// Publish <see cref="TriggerAggregateAllPurchasedDataSync"/> event.
    /// </summary>
    /// <param name="requestId"></param>
    /// <param name="ct"></param>
    /// <returns></returns>
    Task PublishAggregateAllPurchasedDataSyncRequestAsync(Guid requestId, CancellationToken ct = default);

}
