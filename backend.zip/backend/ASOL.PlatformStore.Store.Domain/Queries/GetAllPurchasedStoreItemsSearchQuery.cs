using ASOL.Core.Domain.Contracts;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Contracts;

namespace ASOL.PlatformStore.Store.Domain.Queries;

public class GetAllPurchasedStoreItemsSearchQuery(
    SearchParametersModel searchParameters,
    BaseEntityFilter baseEntityFilter,
    PagingFilter pagingFilter) : GetStoreItemsSearchQueryBase(searchParameters, baseEntityFilter, pagingFilter), IQuery<CollectionResult<StoreItemWithLicenceInformationModel>>
{
}
