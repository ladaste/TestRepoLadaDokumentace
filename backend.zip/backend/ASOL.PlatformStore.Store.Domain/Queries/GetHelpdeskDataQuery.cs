using ASOL.Core.Paging.Contracts;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Contracts;

namespace ASOL.PlatformStore.Store.Domain.Queries;

public class GetHelpdeskDataQuery : IQuery<CollectionResult<HelpdeskDataModel>>
{
    public GetHelpdeskDataQuery()
    {
    }
}
