using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Contracts;

namespace ASOL.PlatformStore.Store.Domain.Queries;

public class GetOrderLicenceInformationQuery(string productCatalogId) : IQuery<OrderLicenceInformation>
{
    public string ProductCatalogId { get; set; } = productCatalogId;
}
