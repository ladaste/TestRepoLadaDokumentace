using ASOL.Core.Domain.Contracts;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Contracts;

namespace ASOL.PlatformStore.Store.Domain.Queries;

public class GetStoreItemDetailByIdQuery(string storeItemId, BaseEntityFilter baseEntityFilter) : IQuery<StoreItemDetailModel>
{
    public string StoreItemId { get; set; } = storeItemId;

    public BaseEntityFilter BaseEntityFilter { get; } = baseEntityFilter;
}
