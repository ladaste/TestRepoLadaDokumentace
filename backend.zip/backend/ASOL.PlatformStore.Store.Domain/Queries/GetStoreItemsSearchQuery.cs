using ASOL.Core.Domain.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Contracts;

namespace ASOL.PlatformStore.Store.Domain.Queries;

public class GetStoreItemsSearchQuery(
    SearchParametersModel searchParameters,
    BaseEntityFilter baseEntityFilter,
    PagingFilter pagingFilter) : GetStoreItemsSearchQueryBase(searchParameters, baseEntityFilter, pagingFilter), IQuery<SearchResultModel>
{
}
