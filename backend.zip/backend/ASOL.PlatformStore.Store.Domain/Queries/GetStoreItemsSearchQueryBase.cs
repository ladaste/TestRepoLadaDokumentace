using ASOL.Core.Domain.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.PlatformStore.Store.Contracts;

namespace ASOL.PlatformStore.Store.Domain.Queries;

public abstract class GetStoreItemsSearchQueryBase(SearchParametersModel searchParameters, BaseEntityFilter baseEntityFilter, PagingFilter pagingFilter)
{
    public SearchParametersModel SearchParameters { get; set; } = searchParameters;

    public BaseEntityFilter BaseEntityFilter { get; } = baseEntityFilter;

    public PagingFilter PagingFilter { get; } = pagingFilter;
}
