using ASOL.Core.Domain.Contracts;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Contracts;

namespace ASOL.PlatformStore.Store.Domain.Queries;

public class GetStoreItemsSimilarQuery(string sourceItemId, BaseEntityFilter baseEntityFilter, PagingFilter pagingFilter) : IQuery<CollectionResult<StoreItemModel>>
{
    public string SourceItemId { get; set; } = sourceItemId;

    public BaseEntityFilter BaseEntityFilter { get; } = baseEntityFilter;

    public PagingFilter PagingFilter { get; } = pagingFilter;
}
