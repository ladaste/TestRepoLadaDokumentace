using ASOL.Core.Domain.Contracts;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Contracts;

namespace ASOL.PlatformStore.Store.Domain.Queries;

public class GetSubscriptionsQuery(
    SearchSubscriptionsModel searchParameters,
    BaseEntityFilter baseEntityFilter,
    PagingFilter pagingFilter) : IQuery<
    CollectionResult<SubscriptionsSummaryModel>>
{
    public SearchSubscriptionsModel SearchParameters { get; set; } = searchParameters;

    public BaseEntityFilter BaseEntityFilter { get; } = baseEntityFilter;

    public PagingFilter PagingFilter { get; } = pagingFilter;
}
