using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.CustomAttributes.Domain.Repositories;
using ASOL.Core.Domain;
using ASOL.Core.Domain.Contracts;
using ASOL.Core.Identity;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Processing;
using ASOL.IdentityManager.Connector;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Domain.Consts;
using ASOL.PlatformStore.Store.Domain.Extensions;
using ASOL.PlatformStore.Store.Domain.Options;
using ASOL.PlatformStore.Store.Domain.Queries;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Services.AllPurchased;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using LicenseSystemStatus = ASOL.IdentityManager.Contracts.LicenseSystemStatus;

namespace ASOL.PlatformStore.Store.Domain.QueryHandlers;

public class GetAllPurchasedAggregatedItemsQueryHandler(
    ILogger<GetAllPurchasedAggregatedItemsQueryHandler> logger,
    IRuntimeContext context,
    IIdentityManagerClient identityManagerClient,
    IDbScopeSelector<IFulltextSearchRepository> fulltextSearches,
    IDbScopeSelector<IAllPurchasedAggregatedItemRepository> allPurchasedAggregatedItems,
    IDbScopeSelector<ICategoryRepository> categories,
    IRightsObjectGroupService rightsObjectGroupService,
    IOptions<NavigationServiceOptions> options) : IQueryHandler<GetAllPurchasedDataQuery, CollectionResult<AllPurchasedDataSummaryModel>>
{
    protected ILogger<GetAllPurchasedAggregatedItemsQueryHandler> Logger { get; } = logger;
    protected IRuntimeContext Context { get; } = context;
    protected IIdentityManagerClient IdentityManagerClient { get; } = identityManagerClient;

    protected IFulltextSearchRepository FulltextSearches { get; } = fulltextSearches.GetRepository(DataAccessLevel.Public);
    protected IAllPurchasedAggregatedItemRepository AllPurchasedAggregatedItems { get; } = allPurchasedAggregatedItems.GetRepository(DataAccessLevel.Public);
    protected IRightsObjectGroupService RightsObjectGroupService { get; } = rightsObjectGroupService;
    protected ICategoryRepository Categories { get; } = categories.GetRepository(DataAccessLevel.Public);

    protected NavigationServiceOptions Options { get; } = options.Value;

    public async Task<QueryResult<CollectionResult<AllPurchasedDataSummaryModel>>> HandleAsync(GetAllPurchasedDataQuery query, CancellationToken ct = default)
    {
        var dataQuery = AllPurchasedAggregatedItems.GetAll()
            .ApplyBaseEntityFilter(BaseEntityFilter.Default)
            .ForTenant(Context.Security.TenantId)
            .ActiveOnly()
            .WithValidLicenseAt(DateTime.UtcNow);

        if (query.SearchParameters != null && query.SearchParameters.ExcludeDefaultApps)
        {
            dataQuery = dataQuery.Where(x => x.OrderNumber != null);
        }

        List<AllPurchasedAggregatedItem> allP;

        if (query.SearchParameters?.CategoryCodes != null &&
            query.SearchParameters.CategoryCodes.Count != 0)
        {
            var codes = query.SearchParameters.CategoryCodes;

            dataQuery = dataQuery
                .Where(x => x.Category != null && codes.Contains(x.Category.Code));
        }

        if (query.SearchParameters?.ExcludeCategoryCodes != null &&
            query.SearchParameters.ExcludeCategoryCodes.Count != 0)
        {
            var excludeCodes = query.SearchParameters.ExcludeCategoryCodes;

            dataQuery = dataQuery
                .Where(x => x.Category == null || (x.Category != null && !excludeCodes.Contains(x.Category.Code)));
        }

        if (query.SearchParameters != null && !string.IsNullOrEmpty(query.SearchParameters?.SearchText))
        {
            var searchedString = query.SearchParameters?.SearchText.ToUpperInvariant();
            var fulltextResponses = FulltextSearches
                .Get(x => x.LanguageCode == Context.Localization.LanguageCode &&
                    x.FulltextData.Any(x => x.ToUpperInvariant().Contains(searchedString)));

            allP = [.. dataQuery
                .ToList()
                .Where(allP => fulltextResponses
                    .Any(x => x.ProductId == allP.ProductCatalogId))
                .OrderBy(item => item.Name)];
        }
        else
        {
            allP = [.. dataQuery.OrderBy(item => item.Name)];
        }

        List<string> userRoles = null;

        if (allP != null && allP.Count != 0)
        {
            var userRolesResponse = await IdentityManagerClient.Authorization.GetRoles(ct);
            userRoles = [.. userRolesResponse?.Items];
        }

        var responseItems = new List<AllPurchasedDataSummaryModel>();

        foreach (var item in allP)
        {
            var hasUserContext = Context.Security.HasUserContext;
            var hasAccesibleByRole = item.HasAccesibleByRole;

            var licenses = new List<License>();

            if (hasAccesibleByRole)
            {
                hasAccesibleByRole = false;

                foreach (var license in item.Licenses)
                {
                    if (license.Role != null)
                    {
                        licenses.Add(license);
                    }

                    if (!(IsTimeValid(license.ValidFrom, license.ValidTo) && license.Status == LicenseSystemStatus.Done))
                    {// license is not ready to use, remove response FE and BE URIs.
                        item.FrontendUrl = null;
                        item.BackendUrl = null;
                        hasAccesibleByRole = true; // not ready license is OK for response without role check.
                    }
                    else if (!hasAccesibleByRole && hasUserContext)
                    {// license is ready to use, but user doesn't member of license role.
                        hasAccesibleByRole = IsApplicationCodeLicensed(userRoles, item.ApplicationCode, license.Role?.RoleCode);
                    }
                }

                item.Licenses = licenses;
            }

            var isVisible = hasAccesibleByRole;
            if (!isVisible || item.Licenses.Count == 0)
            {
                continue;
            }

            responseItems.Add(MapToSubscriptionSummaryModel(item));
        }

        var result = new CollectionResult<AllPurchasedDataSummaryModel>
        {
            TotalCount = responseItems.Count,
            Items = responseItems.Skip(query.PagingFilter.Offset).Take(query.PagingFilter.Limit).ToList()
        };

        return new QueryResult<CollectionResult<AllPurchasedDataSummaryModel>>(result);
    }

    public Task<ValidationResult> ValidateAsync(GetAllPurchasedDataQuery query, CancellationToken ct = default)
    {
        return ValidationResult.SuccessfulResultTask;
    }

    private AllPurchasedDataSummaryModel MapToSubscriptionSummaryModel(AllPurchasedAggregatedItem item)
    {
        var allPurchasedDataSummaryModel = new AllPurchasedDataSummaryModel
        {
            Id = item.Id,
            TenantId = item.TenantId,
            ProductCatalogId = item.ProductCatalogId,
            SolutionPackageName = item.ProductCatalogId,
            SolutionPackageCode = item.SolutionPackageCode,
            EditionCode = item.EditionCode,
            EditionName = item.EditionName,
            ApplicationCode = item.ApplicationCode,
            Name = item.Name?.Values?.FirstOrDefault(x => x.Locale == Context.Localization.LanguageCode)?.Value,
            OrderNumber = item.OrderNumber,
            ApprovedByCustomerOn = item.ApprovedByCustomerOn,
            ShortDescription = item.ShortDescription?.Values?.FirstOrDefault(x => x.Locale == Context.Localization.LanguageCode)?.Value,
            CardImageId = item.CardImageId,
            FrontendUrl = item.FrontendUrl,
            BackendUrl = item.BackendUrl,
            OranizationRelationshipId = item.OranizationRelationshipId,
            OrganizationRelationshipDataId = item.OrganizationRelationshipDataId,
            TenantSolutionPartnerId = item.TenantSolutionPartnerId,
            TenantSolutionPartnerName = item.TenantSolutionPartnerName,
            ApplicationSolutionPartnerId = item.ApplicationSolutionPartnerId,
            ApplicationSolutionPartnerName = item.ApplicationSolutionPartnerName,
            DevelopmentPartnerId = item.DevelopmentPartnerId,
            DevelopmentPartnerName = item.DevelopmentPartnerName,
            CustomerId = item.CustomerId,
            CustomerName = item.CustomerName,
            DateOfStatus = item.DateOfStatus,
            LicenseModifiedOn = item.LicenseModifiedOn,
            OrderDate = item.OrderDate,
            DateOfEndedLicense = item.DateOfEndedLicense,
            BillingPeriod = item.BillingPeriod,
            Status = item.Status,
            StatusDescription = item.StatusDescription,
            AllowedOperation = item.AllowedOperation,
            Category = item.Category != null
                ? new CategoryModel
                {
                    Id = item.Category?.Id,
                    Code = item.Category?.Code,
                    Name = item.Category?.Name?.Values?.FirstOrDefault(x => x.Locale == Context.Localization.LanguageCode)?.Value
                }
                : null,
            IntegrationCategories = item.IntegrationCategories?.Select(x => new CategoryModel { Id = x.Id, Code = x.Code, Name = x.Name?.Values?.FirstOrDefault(x => x.Locale == Context.Localization.LanguageCode)?.Value }).ToList()
        };

        return allPurchasedDataSummaryModel;
    }

    private bool IsApplicationCodeLicensed(
        ICollection<string> userRoles,
        string applicationCode,
        string licenseRoleCode)
    {
        if (TestAlwaysLicensedApplicationCode(applicationCode))
        {
            return true;
        }
        var isLicenceRoleValid = false;
        if (userRoles.Contains(licenseRoleCode))
        {
            isLicenceRoleValid = true;
        }
        return isLicenceRoleValid;
    }

    private static bool TestAlwaysLicensedApplicationCode(string applicationCode)
    {
        return AlwaysLicensedApplicationCodes.Contains(applicationCode);
    }

    private static readonly HashSet<string> AlwaysLicensedApplicationCodes = new(
        [
            AllPurchasedConstants.PlatformApplicationCode,
            AllPurchasedConstants.PortalApplicationCode,
            AllPurchasedConstants.PublicPortalApplicationCode,
        ], StringComparer.OrdinalIgnoreCase);

    private static bool IsTimeValid(DateTime? validFrom, DateTime? validTo)
    {
        if (validFrom == null && validTo == null)
        {
            return true;
        }

        var timestampToCheck = DateTime.UtcNow;

        if (validFrom != null && validTo != null)
        {
            return validFrom.Value <= timestampToCheck && validTo.Value >= timestampToCheck;
        }
        if (validFrom != null)
        {
            return validFrom.Value <= timestampToCheck;
        }
        return validTo.Value >= timestampToCheck;
    }
}
