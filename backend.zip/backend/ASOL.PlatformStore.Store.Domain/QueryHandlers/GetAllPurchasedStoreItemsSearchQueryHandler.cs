using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.CustomAttributes.Domain.Repositories;
using ASOL.Core.Identity;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.Core.Processing;
using ASOL.IdentityManager.Connector;
using ASOL.IdentityManager.Contracts;
using ASOL.IdentityManager.Contracts.Filters;
using ASOL.IdentityManager.Contracts.Licenses;
using ASOL.PlatformStore.Order.Connector;
using ASOL.PlatformStore.PDM.Connector;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Domain.Consts;
using ASOL.PlatformStore.Store.Domain.Helpers;
using ASOL.PlatformStore.Store.Domain.Queries;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Services;
using ASOL.SubjectManager.Connector;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;

namespace ASOL.PlatformStore.Store.Domain.QueryHandlers;

public class GetAllPurchasedStoreItemsSearchQueryHandler(
    ILogger<GetAllPurchasedStoreItemsSearchQueryHandler> logger,
    IRuntimeContext context,
    IDbScopeSelector<IProductCatalogRepository> productCatalogs,
    IDbScopeSelector<ICategoryRepository> categories,
    IDbScopeSelector<IFulltextSearchRepository> fulltextSearches,
    IMappingService mappingService,
    IIdentityManagerClient identityManagerClient,
    ISubjectManagerClient subjectManagerClient,
    IMemoryCache cache,
    IPlatformStoreOrderClient platformStoreOrderClient,
    IPlatformStorePdmClient platformStorePdmClient) : GetStoreItemsSearchQueryHandlerBase(logger, context, productCatalogs, categories, fulltextSearches, mappingService, platformStoreOrderClient, identityManagerClient, subjectManagerClient, platformStorePdmClient), IQueryHandler<GetAllPurchasedStoreItemsSearchQuery, CollectionResult<StoreItemWithLicenceInformationModel>>
{
    protected IMemoryCache Cache { get; } = cache;

    public async Task<QueryResult<CollectionResult<StoreItemWithLicenceInformationModel>>> HandleAsync(GetAllPurchasedStoreItemsSearchQuery query, CancellationToken ct = default)
    {
        var isDefaultRequestCondition = query.PagingFilter.Limit == 100 &&
            query.PagingFilter.Offset == 0 &&
            string.IsNullOrWhiteSpace(query.SearchParameters?.SearchText) &&
            query.SearchParameters?.AdditionalFilter == null &&
            query.SearchParameters?.CategoryCodes == null &&
!query.SearchParameters.ExcludeDefaultApps &&
!query.SearchParameters.ShowSolutionPartners &&
!query.SearchParameters.IsSourceLicenses;

        var isDefaultRequestForSubscriptions = query.PagingFilter.Limit == 100 &&
            query.PagingFilter.Offset == 0 &&
            string.IsNullOrWhiteSpace(query.SearchParameters?.SearchText) &&
            query.SearchParameters?.AdditionalFilter == null &&
            query.SearchParameters?.CategoryCodes == null &&
!query.SearchParameters.ExcludeDefaultApps &&
            query.SearchParameters.ShowSolutionPartners &&
            query.SearchParameters.IsSourceLicenses;

        var tenantCancelationTokenSource = Cache.GetOrCreate($"{CacheKeys.GetStoreItemsToken}-{Context.Security.TenantId}", entry =>
        {
            entry.SetPriority(CacheItemPriority.NeverRemove);
            return new CancellationTokenSource();
        });
        var localizationCancelationTokenSource = Cache.GetOrCreate($"{CacheKeys.GetStoreItemsToken}-{CacheKeys.AllPurchased}-{Context.Security.TenantId}-{AccountHelper.GenerateAccountId(Context)}", entry =>
        {
            entry.SetPriority(CacheItemPriority.NeverRemove);
            return new CancellationTokenSource();
        });

        if (isDefaultRequestCondition)
        {
            return await Cache.GetOrCreateAsync($"{CacheKeys.AllPurchased}-{Context.Localization.LanguageCode}-{Context.Security.TenantId}-{AccountHelper.GenerateAccountId(Context)}", async entry =>
            {
                var expirationTokens = new CompositeChangeToken(new List<IChangeToken>
                    {
                        new CancellationChangeToken(tenantCancelationTokenSource.Token),
                        new CancellationChangeToken(localizationCancelationTokenSource.Token)
                    });

                entry.AddExpirationToken(expirationTokens);
                entry.SlidingExpiration = TimeSpan.FromDays(1);
                return await TriggerStoreItemsSearch(query, ct);
            });
        }
        else if (isDefaultRequestForSubscriptions)
        {
            return await Cache.GetOrCreateAsync($"{CacheKeys.AllPurchased}-{CacheKeys.IsDefaultSubscriptionSearch}-{Context.Localization.LanguageCode}-{Context.Security.TenantId}-{AccountHelper.GenerateAccountId(Context)}", async entry =>
            {
                var expirationTokens = new CompositeChangeToken(new List<IChangeToken>
                    {
                        new CancellationChangeToken(tenantCancelationTokenSource.Token),
                        new CancellationChangeToken(localizationCancelationTokenSource.Token)
                    });

                entry.AddExpirationToken(expirationTokens);
                entry.SlidingExpiration = TimeSpan.FromDays(1);
                return await TriggerStoreItemsSearch(query, ct);
            });
        }

        return await TriggerStoreItemsSearch(query, ct);
    }

    public Task<ValidationResult> ValidateAsync(GetAllPurchasedStoreItemsSearchQuery query, CancellationToken ct = default)
    {
        return ValidationResult.SuccessfulResultTask;
    }

    private async Task<QueryResult<CollectionResult<StoreItemWithLicenceInformationModel>>> TriggerStoreItemsSearch(GetAllPurchasedStoreItemsSearchQuery query,
        CancellationToken ct)
    {
        var categoryStoreItem = Categories.Single(item => item.Code == StoreCategoryCodes.StoreItem);

        var allPurchasedAppsItems = new List<ApplicationLicenseModelAggregatedByPackageCode>();
        var allPurchasedLicensesItems = new List<LicenseModelAggregatedByPackageCode>();

        Dictionary<string, string> allPurchasedDictionary = null;

        var dataQuery = ProductCatalogs.Get(
            item => item.NodeType == NodeTypeModel.Package &&
                    item.Categories.Any(c => c.CategoryId == categoryStoreItem.Id));

        dataQuery = ProductCatalogs.AddHasAttributeGroupFilter(dataQuery, StoreAttributeGroupCodes.StoreItem);

        var isSourceLicenses = query.SearchParameters.IsSourceLicenses;

        if (isSourceLicenses)
        {
            await FetchLicenseModelAggregatedByPackageCode(query, allPurchasedLicensesItems, dataQuery, ct);
        }
        else
        {
            allPurchasedDictionary = await FetchApplicationLicenseModelAggregatedByPackageCode(query, allPurchasedAppsItems, dataQuery);
        }

        var storeItems = await StoreItemsWithLicenseSearchAsync(query,
            dataQuery,
            allPurchasedAppsItems,
            allPurchasedLicensesItems,
            isSourceLicenses,
            allPurchasedDictionary,
            ct);

        return new QueryResult<CollectionResult<StoreItemWithLicenceInformationModel>>(storeItems);
    }

    private async Task FetchLicenseModelAggregatedByPackageCode(GetAllPurchasedStoreItemsSearchQuery query,
        List<LicenseModelAggregatedByPackageCode> allPurchasedLicensesItems,
        IQueryable<ProductCatalog> dataQuery,
        CancellationToken ct)
    {
        CollectionResult<LicenseModelAggregatedByPackageCode> licensesResult;

        var licenseFilter = new LicenseFilter()
        {
            ForceApplyFilterIsVisibleApplication = true
        };

        if (query.SearchParameters.ExcludeDefaultApps)
        {
            licenseFilter.ExcludeWithoutOrderNumber = true;
        }

        var pagingFilter = new PagingFilter { Limit = 100, Offset = 0 };

        do
        {
            licensesResult = await IdentityManagerClient.Licenses
                .GetLicenseAggregatedByPackageCodeAsync(licenseFilter, pagingFilter, ct);

            if (licensesResult is null || licensesResult.Items is null || licensesResult.Items.Count == 0)
            {
                break;
            }

            allPurchasedLicensesItems.AddRange(licensesResult.Items);
            pagingFilter.Offset += pagingFilter.Limit;

        }
        while (licensesResult != null && licensesResult.Items != null && licensesResult.Items.Count > 0);

        var allPurchasedFiltered = allPurchasedLicensesItems
            .Select(item => item.SolutionPackageCode)
            .Distinct();

        dataQuery = dataQuery.Where(item => allPurchasedFiltered.Contains(item.PartCode));
    }

    private async Task<Dictionary<string, string>> FetchApplicationLicenseModelAggregatedByPackageCode(GetAllPurchasedStoreItemsSearchQuery query,
        List<ApplicationLicenseModelAggregatedByPackageCode> allPurchasedAppsItems,
        IQueryable<ProductCatalog> dataQuery)
    {
        var applicationLicenseFilter = new ApplicationLicenseFilter();

        if (query.SearchParameters.ExcludeDefaultApps)
        {
            applicationLicenseFilter.IncludeOnlyWithOrderNumber = true;
        }

        CollectionResult<ApplicationLicenseModelAggregatedByPackageCode> applicationResult;
        var pagingFilter = new PagingFilter { Limit = 100, Offset = 0 };

        do
        {
            applicationResult = await IdentityManagerClient.Applications
                .GetApplicationsAggregatedByPackageCodeAsync(pagingFilter, applicationLicenseFilter);

            if (applicationResult is null || applicationResult.Items is null || applicationResult.Items.Count == 0)
            {
                break;
            }

            allPurchasedAppsItems.AddRange(applicationResult.Items);
            pagingFilter.Offset += pagingFilter.Limit;

        }
        while (applicationResult != null && applicationResult.Items != null && applicationResult.Items.Count > 0);

        var allPurchasedDictionary = allPurchasedAppsItems
            .Select(item => new { item.SolutionPackageCode, item.FrontendUrl })
            .Distinct()
            .ToDictionary(item => item.SolutionPackageCode, item => item.FrontendUrl);

        dataQuery = dataQuery.Where(item => allPurchasedDictionary.Keys.Contains(item.PartCode));

        return allPurchasedDictionary;
    }
}
