using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.CustomAttributes.Domain.Extensions;
using ASOL.Core.Domain;
using ASOL.Core.Domain.Contracts;
using ASOL.Core.Identity;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.Core.Processing;
using ASOL.IdentityManager.Connector;
using ASOL.IdentityManager.Contracts.Filters;
using ASOL.IdentityManager.Contracts.Licenses;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Domain.Consts;
using ASOL.PlatformStore.Store.Domain.Queries;
using ASOL.PlatformStore.Store.Domain.Repositories;
using AutoMapper;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.Domain.QueryHandlers;

public class GetHelpdeskDataQueryHandler(
    IRuntimeContext context,
    ILogger<GetHelpdeskDataQueryHandler> logger,
    IMapper mapper,
    IIdentityManagerClient identityManagerClient,
    IDbScopeSelector<IProductCatalogRepository> productCatalogs) : IQueryHandler<GetHelpdeskDataQuery, CollectionResult<HelpdeskDataModel>>
{
    private readonly IRuntimeContext _context = context;
    private readonly ILogger<GetHelpdeskDataQueryHandler> _logger = logger;
    private readonly IMapper _mapper = mapper;
    private readonly IIdentityManagerClient _identityManagerClient = identityManagerClient;
    private readonly IProductCatalogRepository _productCatalogRepository = productCatalogs.GetRepository(DataAccessLevel.Public);

    public async Task<QueryResult<CollectionResult<HelpdeskDataModel>>> HandleAsync(GetHelpdeskDataQuery query, CancellationToken ct = default)
    {
        var filter = new PagingFilter { Limit = 100, Offset = 0 };
        var applicationLicenseFilter = new ApplicationLicenseFilter
        {
            IncludeOnlyWithOrderNumber = false
        };

        var allPurchasedItems = new List<ApplicationLicenseModelAggregatedByPackageCode>();
        CollectionResult<ApplicationLicenseModelAggregatedByPackageCode> allPurchasedResult;
        do
        {
            allPurchasedResult = await _identityManagerClient.Applications
                .GetApplicationsAggregatedByPackageCodeAsync(filter, applicationLicenseFilter, ct);

            if (allPurchasedResult is null || allPurchasedResult.Items is null || allPurchasedResult.Items.Count == 0)
            {
                break;
            }
            allPurchasedItems.AddRange(allPurchasedResult.Items);

            filter.Offset += filter.Limit;
        }
        while (allPurchasedResult != null && allPurchasedResult.Items != null && allPurchasedResult.Items.Count > 0);

        var helpdeskDataModels = _mapper.Map<List<HelpdeskDataModel>>(allPurchasedItems);

        var platformAppResponse = _productCatalogRepository
            .Get(x => x.PartCode == "ASOLEU-Portal-PA")
            .ApplyBaseEntityFilter(BaseEntityFilter.Default)
            .FirstOrDefault();

        var languageCode = _context.Localization.LanguageCode;

        var platformApp = new HelpdeskDataModel
        {
            Id = platformAppResponse.Id,
            ApplicationCode = platformAppResponse
                .GetCustomAttributeValue<string>(StoreAttributeGroupCodes.Product, StoreAttributeCodes.GlobalApplicationCode),
            SolutionPackageName = platformAppResponse
                .GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.Product, StoreAttributeCodes.ApplicationName, languageCode),
            FrontendUrl = platformAppResponse
                .GetCustomAttributeValue<string>(StoreAttributeGroupCodes.Product, StoreAttributeCodes.Url)
        };

        helpdeskDataModels.Add(platformApp);

        var result = new CollectionResult<HelpdeskDataModel>
        {
            TotalCount = helpdeskDataModels.Count,
            Items = helpdeskDataModels
        };

        return new QueryResult<CollectionResult<HelpdeskDataModel>>(result);
    }

    public async Task<ValidationResult> ValidateAsync(GetHelpdeskDataQuery query, CancellationToken ct = default)
    {
        var errors = new List<ValidationError>();

        return errors.Count != 0
            ? new ValidationResult(errors)
            : await ValidationResult.SuccessfulResultTask;
    }
}
