using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.CustomAttributes.Domain.Extensions;
using ASOL.Core.Domain;
using ASOL.Core.Domain.Contracts;
using ASOL.Core.Identity;
using ASOL.Core.Localization;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.Core.Processing;
using ASOL.IdentityManager.Connector;
using ASOL.IdentityManager.Contracts;
using ASOL.IdentityManager.Contracts.Filters;
using ASOL.PlatformStore.PDM.Connector;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Domain.Consts;
using ASOL.PlatformStore.Store.Domain.Queries;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Resources;
using ASOL.PlatformStore.Store.Domain.Services;
using LicenseSystemStatus = ASOL.IdentityManager.Contracts.LicenseSystemStatus;

namespace ASOL.PlatformStore.Store.Domain.QueryHandlers;

/// <summary>
/// Initialize.
/// </summary>
/// <param name="productCatalogs"></param>
/// <param name="identityManagerClient"></param>
/// <param name="platformStoreOrderClient"></param>
/// <param name="platformStorePdmClient"></param>
public class GetOrderLicenseInformationQueryHandler
(
    IRuntimeContext context,
    IDbScopeSelector<IProductCatalogRepository> productCatalogs,
    IIdentityManagerClient identityManagerClient,
    IPlatformStorePdmClient platformStorePdmClient,
    IMappingService mappingService
)
    : IQueryHandler<GetOrderLicenceInformationQuery, OrderLicenceInformation>
{
    /// <inheritdoc cref="IRuntimeContext"/>
    protected IRuntimeContext Context { get; } = context;

    /// <inheritdoc cref="IProductCatalogRepository"/>
    protected IProductCatalogRepository ProductCatalogs { get; } = productCatalogs.GetRepository(DataAccessLevel.Public);

    /// <inheritdoc cref="IIdentityManagerClient"/>
    protected IIdentityManagerClient IdentityManagerClient { get; } = identityManagerClient;

    /// <inheritdoc cref="IPlatformStorePdmClient"/>
    protected IPlatformStorePdmClient PlatformStorePdmClient { get; } = platformStorePdmClient;

    /// <inheritdoc cref="IMappingService"/>
    protected IMappingService MappingService { get; } = mappingService;

    public async Task<QueryResult<OrderLicenceInformation>> HandleAsync(GetOrderLicenceInformationQuery query, CancellationToken ct = default)
    {
        var product = ProductCatalogs
            .Get(x => x.Id == query.ProductCatalogId)
            .ApplyBaseEntityFilter(BaseEntityFilter.Default)
            .FirstOrDefault();

        if (product is null)
        {
            ThrowNotFoundException(query.ProductCatalogId);
        }

        var storeItem = MappingService.MapProductCatalogToStoreItem(product);

        var productAppCode = product.GetCustomAttributeValue<string>(StoreAttributeGroupCodes.Product, StoreAttributeCodes.GlobalApplicationCode);

        CollectionResult<LicenseModelAggregatedByPackageCode> licensesResult;

        var licenseFilter = new LicenseFilter
        {
            IncludeInvalid = true,
            ForceApplyFilterIsVisibleApplication = true,
            ApplicationCode = productAppCode
        };

        var pagingFilter = new PagingFilter
        {
            Limit = 100,
            Offset = 0
        };

        var allPurchasedLicensesItems = new List<LicenseModelAggregatedByPackageCode>();

        do
        {
            licensesResult = await IdentityManagerClient.Licenses
                .GetLicenseAggregatedByPackageCodeAsync(licenseFilter, pagingFilter, ct);

            if (licensesResult is null || licensesResult.Items is null || licensesResult.Items.Count == 0)
            {
                break;
            }

            allPurchasedLicensesItems.AddRange(licensesResult.Items);
            pagingFilter.Offset += pagingFilter.Limit;
        } while (licensesResult != null && licensesResult.Items != null && licensesResult.Items.Count > 0);

        var applicationLicense = allPurchasedLicensesItems
            .Select(item => new
            {
                Item = item,
                FilteredLicenses = item.Licenses
                    .Where(r =>
                        (r.ValidFrom == null || r.ValidFrom.Value <= DateTime.UtcNow) &&
                        (r.ValidTo == null || r.ValidTo > DateTime.UtcNow))
                    .ToList()
            })
            .Where(x => x.FilteredLicenses.Count != 0)
            .Select(x =>
            {
                x.Item.Licenses = x.FilteredLicenses;
                return x.Item;
            })
            .Distinct()
            .FirstOrDefault();

        //string billingPeriod = null;

        var orderNumber = applicationLicense?.Licenses.FirstOrDefault().OrderNumber;
        var subscriptionValidTo = applicationLicense?.Licenses.FirstOrDefault()?.ValidTo;

        // An unhandled exception occurs when calling Order (returns 403); ApiClientHelper usage is missing. However, billingPeriod is not used → commented out.
        /*if (!string.IsNullOrEmpty(orderNumber))
        {
            var order = await PlatformStoreOrderClient.GetOrderByNumberOptionalAsync(orderNumber,
                OrderAccessType.Customer, true, ct);
            if (order != null)
            {
                if (order.OrderLines.Any(a => a.OrderLineType == PDM.Contracts.NodeType.Edition.ToString()))
                {
                    var orderLineEdition = order.OrderLines.Single(l => l.OrderLineType == PDM.Contracts.NodeType.Edition.ToString());
                    var editionSubscriptions = order.OrderLines.FirstOrDefault(w => w.OrderLineType == PDM.Contracts.NodeType.Subscription.ToString() && w.ParentOrderLineId == orderLineEdition.Id);
                    if (editionSubscriptions != null)
                    {
                        var billingPeriodElement = await PlatformStorePdmClient.GetBillingPeriodByCode(editionSubscriptions.BillingPeriodCode, ct);
                        billingPeriod = billingPeriodElement.PeriodUnit switch
                        {
                            PDM.Contracts.PeriodUnitModel.Month => PeriodTypes.Monthly,
                            PDM.Contracts.PeriodUnitModel.Year => PeriodTypes.Yearly,
                            _ => null
                        };
                    }
                }
                else if (order.OrderLines.Any(a => a.OrderLineType == PDM.Contracts.NodeType.Licence.ToString()))
                {
                    var orderLicence = order.OrderLines.First(l => l.OrderLineType == PDM.Contracts.NodeType.Licence.ToString());
                    billingPeriod = orderLicence.BillingPeriodV2 == null ? orderLicence.BillingPeriod :
                        orderLicence.BillingPeriodV2.PeriodUnit == PeriodUnitModel.Month.ToString() &&
                        orderLicence.BillingPeriodV2.Period == 1 ? PeriodTypes.Monthly :
                        orderLicence.BillingPeriodV2.PeriodUnit == PeriodUnitModel.Year.ToString() &&
                        orderLicence.BillingPeriodV2.Period == 1 ? PeriodTypes.Yearly : null;
                }
            }
        }*/


        var userIsSalesRep = await IsSalesRep(ct);

        if (applicationLicense is null || userIsSalesRep || IsCustomerProductOwner(product.VendorTenantId))
        {
            if (allPurchasedLicensesItems.Count != 0)
            {
                var license = allPurchasedLicensesItems
                    .Distinct()
                    .FirstOrDefault()
                    ?.Licenses
                    .OrderBy(l => l.ValidTo == null)
                    .ThenByDescending(l => l.ValidTo)
                    .FirstOrDefault();

                orderNumber = license?.OrderNumber;
                subscriptionValidTo = license?.ValidTo;
            }

            var response = new OrderLicenceInformation
            {
                OrderNumber = orderNumber,
                IsSubscriptionCanceled = subscriptionValidTo != null,
                SubscriptionValidTo = subscriptionValidTo,
                LicenceInformationModels = new List<LicenceInformationModel>
                {
                    new()
                    {
                        AllowedOperation = StoreItemAllowedOperation.Create
                    }
                }
            };

            return new QueryResult<OrderLicenceInformation>(response);
        }

        var licenceInformationModels = new List<LicenceInformationModel>();

        var edition = ProductCatalogs
            .Get(item => item.PartCode == applicationLicense.EditionCode)
            .ApplyBaseEntityFilter(BaseEntityFilter.Default)
            .FirstOrDefault();

        foreach (var item in applicationLicense.Licenses)
        {
            var licenceInformationModel = new LicenceInformationModel
            {
                EditionName = edition.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.Edition, "name", Context.Localization.LanguageCode),
                LicenceCode = item.Code,
                OrderLineId = item.OrderLineId,
                Role = item.Feature.Role != null
                    ? new Contracts.LicenseRoleModel
                    {
                        RoleCode = item.Feature.Role.RoleCode,
                        RoleName = item.Feature.Role.RoleName?.Translate(Context.Localization.LanguageCode, item.Feature.Role.RoleName.Values?.FirstOrDefault()?.Value),
                        UserCount = item.Feature.Role.UserCount,
                        UserMaxCount = item.Feature.Role.UserMaxCount
                    }
                    : null,
                IsTrial = item.Role != null && item.Role.IsTrial,
                StatusDescription = MapLicenseSystemStatusToDescription(item.Status),
                ValidFrom = item.ValidFrom,
                ValidTo = item.ValidTo,

                //If license exists, create or modify is not allowed.
                AllowedOperation = StoreItemAllowedOperation.None
            };
            //if (item.ValidFrom.HasValue)
            //{
            //    int durationInMonths = ((DateTime.UtcNow.Year - item.ValidFrom.Value.Year) * 12) + (DateTime.UtcNow.Month - item.ValidFrom.Value.Month);
            //    if (durationInMonths >= 1)
            //    {

            //        if (billingPeriod == PeriodTypes.Yearly)
            //        {
            //            if (durationInMonths >= 11)
            //            {
            //                licenceInformationModel.AllowedOperation = StoreItemAllowedOperation.Create;
            //            }
            //            else
            //            {
            //                licenceInformationModel.AllowedOperation = StoreItemAllowedOperation.Modify;
            //            }
            //        }
            //        else
            //        {
            //            licenceInformationModel.AllowedOperation = StoreItemAllowedOperation.Create;
            //        }
            //    }
            //    else
            //    {
            //        licenceInformationModel.AllowedOperation = StoreItemAllowedOperation.None;
            //    }
            //}
            //else
            //{
            //    licenceInformationModel.AllowedOperation = StoreItemAllowedOperation.None;
            //}

            licenceInformationModels.Add(licenceInformationModel);
        }

        return new QueryResult<OrderLicenceInformation>(new OrderLicenceInformation
        {
            Id = storeItem.Id,
            OrderNumber = orderNumber,
            ApplicationCode = productAppCode,
            CardImageId = storeItem.CardImageId,
            CategoryName = storeItem.Category.Name,
            Name = storeItem.Name,
            ShortDescription = storeItem.ShortDescription,
            LicenceInformationModels = licenceInformationModels,
            IsSubscriptionCanceled = subscriptionValidTo != null,
            SubscriptionValidTo = subscriptionValidTo
        });
    }

    public Task<ValidationResult> ValidateAsync(GetOrderLicenceInformationQuery query, CancellationToken ct = default)
    {
        return ValidationResult.SuccessfulResultTask;
    }

    private bool IsCustomerProductOwner(string vendorTenantId)
    {
        return Context.Security.User.GetTenantId() == vendorTenantId;
    }

    private async Task<bool> IsSalesRep(CancellationToken ct = default)
    {
        var isInSalesRepRole = await IdentityManagerClient.Authorization.IsInRole(RightObjects.SalesRep, ct);
        return isInSalesRepRole.AccessGranted;
    }

    private static void ThrowNotFoundException(string productCatalogId)
    {
        throw new KeyNotFoundException(string.Format(ValidationResultMessages.InvalidOrMissingId, nameof(productCatalogId)));
    }

    private static string MapLicenseSystemStatusToDescription(LicenseSystemStatus? licenseSystemStatus)
    {
        return licenseSystemStatus switch
        {
            null => Labels.StoreAppStatusOrdered,
            LicenseSystemStatus.Validation => Labels.StoreAppStatusOrdered,
            LicenseSystemStatus.Fail => Labels.StoreAppStatusOrdered,
            LicenseSystemStatus.Confirmed => Labels.StoreAppStatusPreparing,
            LicenseSystemStatus.Done => null,
            _ => null
        };
    }
}
