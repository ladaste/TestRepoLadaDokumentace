using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Processing;
using ASOL.PlatformStore.PDM.Connector;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Domain.Queries;
using AutoMapper;

namespace ASOL.PlatformStore.Store.Domain.QueryHandlers;

public class GetProductCatalogCodebooksQueryHandler(IPlatformStorePdmClient platformStorePdmClient, IMapper mapper) : IQueryHandler<GetProductCatalogCodebooksQuery, ProductCatalogCodebooksModel>
{
    protected IPlatformStorePdmClient PlatformStorePdmClient { get; } = platformStorePdmClient;
    protected IMapper Mapper { get; } = mapper;

    public Task<ValidationResult> ValidateAsync(GetProductCatalogCodebooksQuery query, CancellationToken ct = default)
    {
        return ValidationResult.SuccessfulResultTask;
    }

    public async Task<QueryResult<ProductCatalogCodebooksModel>> HandleAsync(GetProductCatalogCodebooksQuery query, CancellationToken ct = default)
    {
        var billingPeriods = await PlatformStorePdmClient.GetBillingPeriods(ct);
        var unitsOfMeasures = await PlatformStorePdmClient.GetUnitsOfMeasures(ct);
        var unitOfSales = await PlatformStorePdmClient.GetUnitsOfSales(ct);

        var result = new ProductCatalogCodebooksModel
        {
            BillingPeriods = Mapper.Map<IList<BillingPeriodModel>>(billingPeriods),
            UnitsOfMeasures = Mapper.Map<IList<UnitOfMeasureModel>>(unitsOfMeasures),
            UnitsOfSales = Mapper.Map<IList<UnitOfSaleModel>>(unitOfSales),
        };
        return new QueryResult<ProductCatalogCodebooksModel>(result);

    }
}
