using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.CustomAttributes.Domain.Repositories;
using ASOL.Core.Domain.Contracts;
using ASOL.Core.Identity;
using ASOL.Core.Identity.Authorization;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Domain.Consts;
using ASOL.PlatformStore.Store.Domain.Queries;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Resources;
using ASOL.PlatformStore.Store.Domain.Services;

namespace ASOL.PlatformStore.Store.Domain.QueryHandlers;

public class GetStoreItemDetailByIdQueryHandler(
    IRuntimeContext runtimeContext,
    IPlatformAuthorizationService platformAuthorizationService,
    IDbScopeSelector<IProductCatalogRepository> productCatalogs,
    IDbScopeSelector<ICategoryRepository> categories,
    IMappingService mappingService,
    IStoreAccessControlService storeAccessControlService) : IQueryHandler<GetStoreItemDetailByIdQuery, StoreItemDetailModel>
{
    protected IRuntimeContext RuntimeContext { get; } = runtimeContext;

    protected IPlatformAuthorizationService PlatformAuthorizationService { get; } = platformAuthorizationService;

    protected ICategoryRepository Categories { get; } = categories.GetRepository(DataAccessLevel.Public);

    protected IProductCatalogRepository ProductCatalogs { get; } = productCatalogs.GetRepository(DataAccessLevel.Public);

    protected IMappingService MappingService { get; } = mappingService;

    protected IStoreAccessControlService StoreAccessControlService { get; } = storeAccessControlService;

    public async Task<QueryResult<StoreItemDetailModel>> HandleAsync(GetStoreItemDetailByIdQuery query, CancellationToken ct = default)
    {
        var categoryStoreItem = Categories.Single(item => item.Code == StoreCategoryCodes.StoreItem);

        ProductCatalog productCatalog = null;

        productCatalog = ProductCatalogs.Get(
            item => item.Id == query.StoreItemId &&
                    item.Categories.Any(c => c.CategoryId == categoryStoreItem.Id))
            .FirstOrDefault();

        if (productCatalog == null)
        {
            ThrowNotFoundException(query.StoreItemId);
        }

        if (!RuntimeContext.Security.IsAuthenticated)
        {
            if (!productCatalog.TryEntityFilter(query.BaseEntityFilter ?? BaseEntityFilter.Default) || !await StoreAccessControlService.TryAccessFilter(productCatalog))
            {
                ThrowNotFoundException(query.StoreItemId);
            }
        }
        else
        {
            var userRoles = (await RuntimeContext.Security.User.GetRolesAsync(PlatformAuthorizationService)).ToList();
            var isProductEditor = userRoles.Contains(RightObjects.EditorRoleAccess);

            if (!isProductEditor && (!productCatalog.TryEntityFilter(query.BaseEntityFilter ?? BaseEntityFilter.Default) || !await StoreAccessControlService.TryAccessFilter(productCatalog)))
            {
                ThrowNotFoundException(query.StoreItemId);
            }
            else if (isProductEditor && productCatalog.Deleted)
            {
                ThrowNotFoundException(query.StoreItemId);
            }
        }

        return new QueryResult<StoreItemDetailModel>(MappingService.MapProductCatalogToStoreItemDetail(productCatalog));
    }

    private static void ThrowNotFoundException(string storeItemId)
    {
        throw new KeyNotFoundException(string.Format(ValidationResultMessages.InvalidOrMissingId, nameof(storeItemId)));
    }

    public Task<ValidationResult> ValidateAsync(GetStoreItemDetailByIdQuery query, CancellationToken ct = default)
    {
        return ValidationResult.SuccessfulResultTask;
    }
}
