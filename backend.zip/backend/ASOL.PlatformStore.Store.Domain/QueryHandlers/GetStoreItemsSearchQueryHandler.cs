using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.CustomAttributes.Domain.Extensions;
using ASOL.Core.CustomAttributes.Domain.Repositories;
using ASOL.Core.Domain;
using ASOL.Core.Domain.Contracts;
using ASOL.Core.Identity;
using ASOL.Core.Identity.Contexts;
using ASOL.Core.Identity.Options;
using ASOL.Core.Localization;
using ASOL.Core.Multitenancy;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.Core.Processing;
using ASOL.CustomAttributes.Connector;
using ASOL.CustomAttributes.Contracts;
using ASOL.CustomAttributes.Contracts.Filters;
using ASOL.IdentityManager.Connector;
using ASOL.PlatformStore.Order.Connector;
using ASOL.PlatformStore.PDM.Connector;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Domain.Consts;
using ASOL.PlatformStore.Store.Domain.Queries;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Services;
using ASOL.SubjectManager.Connector;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace ASOL.PlatformStore.Store.Domain.QueryHandlers;

public class GetStoreItemsSearchQueryHandler(
    ILogger<GetStoreItemsSearchQueryHandler> logger,
    IRuntimeContext runtimeContext,
    IDbScopeSelector<IProductCatalogRepository> productCatalogs,
    IDbScopeSelector<ICategoryRepository> categories,
    IDbScopeSelector<IFulltextSearchRepository> fulltextSearches,
    IMappingService mappingService,
    IStoreAccessControlService storeAccessControlService,
    IPlatformStoreOrderClient platformStoreOrderClient,
    IIdentityManagerClient identityManagerClient,
    ISubjectManagerClient subjectManagerClient, IServiceProvider serviceProvider, IOptions<SsoAuthOptions> ssoAuthOptions, IPlatformStorePdmClient platformStorePdmClient) : GetStoreItemsSearchQueryHandlerBase(logger, runtimeContext, productCatalogs, categories, fulltextSearches, mappingService, platformStoreOrderClient, identityManagerClient, subjectManagerClient, platformStorePdmClient), IQueryHandler<GetStoreItemsSearchQuery, SearchResultModel>
{
    protected IStoreAccessControlService StoreAccessControlService { get; } = storeAccessControlService;
    protected IServiceProvider ServiceProvider { get; } = serviceProvider;
    protected IRuntimeContext RuntimeContext { get; } = runtimeContext;
    protected IOptions<SsoAuthOptions> SsoAuthOptions { get; } = ssoAuthOptions;

    public async Task<QueryResult<SearchResultModel>> HandleAsync(GetStoreItemsSearchQuery query, CancellationToken ct = default)
    {
        var categoryStoreItem = Categories.Single(item => item.Code == StoreCategoryCodes.StoreItem);

        var dataQuery = ProductCatalogs.Get(
            item => item.NodeType == NodeTypeModel.Package &&
                    item.Categories.Any(c => c.CategoryId == categoryStoreItem.Id));

        dataQuery = dataQuery
            .ApplyBaseEntityFilter(query.BaseEntityFilter ?? BaseEntityFilter.Default)
            .Where(p => p.Published);

        if (query.SearchParameters.IsCarouselView)
        {
            return await SearchWithoutSearchParametersAsync(query, dataQuery, ct);
        }

        var storeItems = await StoreItemsSearch(query, dataQuery, ct);

        var categoryResult = new CategoryResultModel
        {
            CategoryCode = StoreCategoryCodes.All,
            StoreItems = storeItems
        };

        var searchResult = new SearchResultModel
        {
            Categories = [categoryResult]
        };

        return new QueryResult<SearchResultModel>(searchResult);
    }

    public Task<ValidationResult> ValidateAsync(GetStoreItemsSearchQuery query, CancellationToken ct = default)
    {
        var errors = new List<ValidationError>();

        if (query.SearchParameters.IsCarouselView)
        {
            if (!string.IsNullOrEmpty(query.SearchParameters.SearchText)
                || query.SearchParameters.ExcludeDefaultApps
                || query.SearchParameters.CategoryCodes != null
                || query.SearchParameters.AdditionalFilter != null)
            {
                errors.Add(new ValidationError("It is not allowed to use aditional filters with Carousel View"));
            }
        }

        return errors.Count != 0
            ? Task.FromResult(new ValidationResult(errors))
            : ValidationResult.SuccessfulResultTask;
    }

    private async Task<QueryResult<SearchResultModel>> SearchWithoutSearchParametersAsync(GetStoreItemsSearchQuery searchQuery, IQueryable<ProductCatalog> dataQuery, CancellationToken ct)
    {
        var categoryStoreItem = Categories.Get(item => item.Code == StoreCategoryCodes.PublicLandingPages).SingleOrDefault();
        if (categoryStoreItem == null)
        {
            return await SearchWithoutSearchParametersDefault(searchQuery, dataQuery);
        }

        var productCatalogsQuery = ProductCatalogs.Get(item => item.NodeType == NodeTypeModel.Package && item.Categories.Any(c => c.CategoryId == categoryStoreItem.Id));
        productCatalogsQuery = ProductCatalogs.AddHasAttributeGroupFilter(productCatalogsQuery, StoreAttributeGroupCodes.PublicPortalLandingItem);
        var publicProductCatalog = productCatalogsQuery.ApplyBaseEntityFilter(BaseEntityFilter.Default).SingleOrDefault();
        if (publicProductCatalog == null)
        {
            return await SearchWithoutSearchParametersDefault(searchQuery, dataQuery);
        }

        var carouselCategoriesString = publicProductCatalog.GetCustomAttributeValue<string>(StoreAttributeGroupCodes.PublicPortalLandingItem, StoreAttributeCodes.CarouselCategories);
        if (string.IsNullOrEmpty(carouselCategoriesString))
        {
            return await SearchWithoutSearchParametersDefault(searchQuery, dataQuery);
        }

        var carouselCategories = JsonSerializer.Deserialize<IList<string>>(carouselCategoriesString);
        if (carouselCategories == null || !carouselCategories.Any())
        {
            return await SearchWithoutSearchParametersDefault(searchQuery, dataQuery);
        }

        var categoryResultModel = new List<CategoryResultModel>();

        // Impersonate to the ASOLEU tenant to get custom attributes associated to PublicPortalLandingItem
        using (var scope = ServiceProvider.GetRequiredService<IRuntimeContextScope>())
        {
            var tenantHolder = scope.ScopeProvider.GetRequiredService<ITenantContextHolder>();
            tenantHolder.TenantContext = new TenantContext { Tenant = new TenantInfo(TenantIds.ASOLEU, null) };
            scope.LocalizationContext = new LocalizationContext(RuntimeContext.Localization.LanguageCode);

            var serviceClient = ClaimsPrincipalBuilder.CreateClientPrincipal(SsoAuthOptions.Value.ClientId, TenantIds.ASOLEU)
                .AddAuthenticateType()
                .AddLocale(RuntimeContext.Localization.LanguageCode)
                .Build();

            scope.ImpersonateToIdentity(serviceClient, RuntimeContext.Trace);

            var customAttributesClient = scope.ScopeProvider.GetRequiredService<ICustomAttributesClient>();

            foreach (var carouselCategory in carouselCategories)
            {
                var category = await customAttributesClient.GetCategoryByCodeAsync(carouselCategory, ct);

                var attributeGroupItems = new List<AttributeGroupModelSummary>();

                long? totalCount = 0;
                var filter = new PagingFilter()
                {
                    Limit = 100,
                    Offset = 0
                };

                do
                {
                    var caResponse = await customAttributesClient
                        .GetAttributeGroups(new AttributeGroupFilter
                        { Categories = [category.Id] },
                            filter,
                            new BaseEntityFilter(), ct);

                    attributeGroupItems.AddRange(caResponse.Items.ToList());

                    totalCount = caResponse.TotalCount;
                    filter.Offset += filter.Limit;
                }
                while (totalCount > attributeGroupItems.Count);

                var attributeGroup = attributeGroupItems.FirstOrDefault(f => f.Attributes.Any(a => a.Code == StoreAttributeCodes.SortOrder));
                var carouselCategoryResult = GetByCategoryCode(searchQuery, dataQuery, carouselCategory, attributeGroup?.Code);
                categoryResultModel.Add(carouselCategoryResult);
            }

            var allItems = await StoreItemsSearch(searchQuery, dataQuery, ct);

            categoryResultModel.Add(new CategoryResultModel
            {
                CategoryCode = StoreCategoryCodes.All,
                StoreItems = allItems
            });
        }

        var searchResult = new SearchResultModel
        {
            Categories = categoryResultModel
        };

        return new QueryResult<SearchResultModel>(searchResult);
    }

    private Task<QueryResult<SearchResultModel>> SearchWithoutSearchParametersDefault(GetStoreItemsSearchQuery searchQuery, IQueryable<ProductCatalog> dataQuery)
    {
        var recommendedCategoryResult = GetByCategoryCode(searchQuery, dataQuery, StoreCategoryCodes.Recommended, StoreAttributeGroupCodes.Recommended);
        var comingSoonCategoryResult = GetByCategoryCode(searchQuery, dataQuery, StoreCategoryCodes.ComingSoon, null);

        var searchResult = new SearchResultModel
        {
            Categories =
            [
                recommendedCategoryResult,
                comingSoonCategoryResult
            ]
        };

        return Task.FromResult(new QueryResult<SearchResultModel>(searchResult));
    }

    private CategoryResultModel GetByCategoryCode(GetStoreItemsSearchQuery searchQuery, IQueryable<ProductCatalog> dataQuery, string categoryCode, string attributeGroupCodeWithSortOrder)
    {
        var filteringCategory = Categories.Single(item => item.Code == categoryCode);
        if (filteringCategory == null)
        {
            Logger.LogError($"There is no category with category code {categoryCode}");
            return null;
        }

        var result = dataQuery
            .Where(item => item.Categories
                .Any(category => category.CategoryId == filteringCategory.Id));

        var totalCount = result.Count();
        var items = result.ToList();

        List<StoreItemModel> storeItems;

        if (!string.IsNullOrEmpty(attributeGroupCodeWithSortOrder))
        {
            storeItems = items
                .OrderByDescending(o => o.GetCustomAttributeValue<int?>(attributeGroupCodeWithSortOrder, StoreAttributeCodes.SortOrder).HasValue)
                .ThenBy(o => o.GetCustomAttributeValue<int?>(attributeGroupCodeWithSortOrder, StoreAttributeCodes.SortOrder))
                .ThenBy(t => t.Name)
                .Select(item => MappingService.MapProductCatalogToStoreItem(item))
                .Skip(searchQuery.PagingFilter.Offset)
                .Take(searchQuery.PagingFilter.Limit)
                .ToList();
        }
        else
        {
            storeItems = items
                .Select(item => MappingService.MapProductCatalogToStoreItem(item))
                .OrderBy(t => t.Name)
                .Skip(searchQuery.PagingFilter.Offset)
                .Take(searchQuery.PagingFilter.Limit)
                .ToList();
        }

        var defaultCategoryName = filteringCategory.Name.Values.FirstOrDefault()?.Value;

        var categoryResult = new CategoryResultModel
        {
            CategoryName = filteringCategory.Name.Translate(Context.Localization.LanguageCode, defaultCategoryName),
            CategoryCode = filteringCategory.Code,
            StoreItems = new CollectionResult<StoreItemModel>
            {
                Items = storeItems,
                TotalCount = totalCount
            }
        };

        return categoryResult;
    }
}
