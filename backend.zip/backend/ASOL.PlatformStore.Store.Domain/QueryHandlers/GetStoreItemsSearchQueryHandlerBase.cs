using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.CustomAttributes.Domain.Extensions;
using ASOL.Core.CustomAttributes.Domain.Repositories;
using ASOL.Core.Identity;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.IdentityManager.Connector;
using ASOL.IdentityManager.Contracts;
using ASOL.IdentityManager.Contracts.Licenses;
using ASOL.PlatformStore.Order.Connector;
using ASOL.PlatformStore.Order.Contracts.Primitives;
using ASOL.PlatformStore.PDM.Connector;
using ASOL.PlatformStore.PDM.Contracts;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Domain.Consts;
using ASOL.PlatformStore.Store.Domain.Queries;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Services;
using ASOL.SubjectManager.Connector;
using ASOL.SubjectManager.Contracts.Filters;
using ASOL.SubjectManager.Contracts.Model;
using Microsoft.Extensions.Logging;
using PeriodUnitModel = ASOL.PlatformStore.Order.Contracts.PeriodUnitModel;

namespace ASOL.PlatformStore.Store.Domain.QueryHandlers;

public abstract class GetStoreItemsSearchQueryHandlerBase(
    ILogger<GetStoreItemsSearchQueryHandlerBase> logger,
    IRuntimeContext context,
    IDbScopeSelector<IProductCatalogRepository> productCatalogs,
    IDbScopeSelector<ICategoryRepository> categories,
    IDbScopeSelector<IFulltextSearchRepository> fulltextSearches,
    IMappingService mappingService,
    IPlatformStoreOrderClient platformStoreOrderClient,
    IIdentityManagerClient identityManagerClient,
    ISubjectManagerClient subjectManagerClient,
    IPlatformStorePdmClient platformStorePdmClient)
{
    protected ILogger<GetStoreItemsSearchQueryHandlerBase> Logger { get; } = logger;
    protected IRuntimeContext Context { get; } = context;
    protected ICategoryRepository Categories { get; } = categories.GetRepository(DataAccessLevel.Public);
    protected IProductCatalogRepository ProductCatalogs { get; } = productCatalogs.GetRepository(DataAccessLevel.Public);
    protected IFulltextSearchRepository FulltextSearches { get; } = fulltextSearches.GetRepository(DataAccessLevel.Public);
    protected IMappingService MappingService { get; } = mappingService;
    protected IPlatformStoreOrderClient PlatformStoreOrderClient { get; } = platformStoreOrderClient;
    protected IIdentityManagerClient IdentityManagerClient { get; } = identityManagerClient;
    protected ISubjectManagerClient SubjectManagerClient { get; } = subjectManagerClient;
    protected IPlatformStorePdmClient PlatformStorePdmClient { get; } = platformStorePdmClient;

    private const string SOLUTION_PARTNER_CODE = "SOLUTIONPARTNER";

    protected async Task<CollectionResult<StoreItemModel>> StoreItemsSearch(GetStoreItemsSearchQueryBase searchQuery,
        IQueryable<ProductCatalog> dataQuery,
        CancellationToken ct = default)
    {
        if (searchQuery.SearchParameters.CategoryCodes != null &&
            searchQuery.SearchParameters.CategoryCodes.Count != 0)
        {
            var categoriesIds = Categories
                .Get(item => searchQuery.SearchParameters.CategoryCodes.Contains(item.Code))
                .Select(category => category.Id)
                .ToList();

            if (categoriesIds != null && categoriesIds.Count != 0)
            {
                dataQuery = dataQuery
                    .Where(item => item.Categories
                    .Any(category => categoriesIds.Contains(category.CategoryId)));
            }
        }

        if (searchQuery.SearchParameters.SuitableForCategoryCodes != null &&
            searchQuery.SearchParameters.SuitableForCategoryCodes.Count != 0)
        {
            var categoriesIds = Categories
                .Get(item => searchQuery.SearchParameters.SuitableForCategoryCodes.Contains(item.Code))
                .Select(category => category.Id)
                .ToList();

            if (categoriesIds != null && categoriesIds.Count != 0)
            {
                dataQuery = dataQuery
                    .Where(item => item.Categories
                    .Any(category => categoriesIds.Contains(category.CategoryId)));
            }
        }

        if (searchQuery.SearchParameters.ExcludeCategoryCodes != null &&
            searchQuery.SearchParameters.ExcludeCategoryCodes.Count != 0)
        {
            foreach (var categoryCode in searchQuery.SearchParameters.ExcludeCategoryCodes)
            {
                var filteringCategory = Categories.Single(item => item.Code == categoryCode);
                if (filteringCategory == null)
                {
                    Logger.LogError($"There is no category with category code {categoryCode}");
                    continue;
                }

                dataQuery = dataQuery
                    .Where(x => !x.Categories.Any(c => c.CategoryId == filteringCategory.Id));
            }
        }

        var items = new List<ProductCatalog>();
        var storeItems = new List<StoreItemModel>();

        if (!string.IsNullOrEmpty(searchQuery.SearchParameters?.SearchText))
        {
            var searchedString = searchQuery.SearchParameters?.SearchText.ToUpperInvariant();
            var fulltextResponses = FulltextSearches
                .Get(x => x.LanguageCode == Context.Localization.LanguageCode &&
                    x.FulltextData.Any(x => x.ToUpperInvariant().Contains(searchedString)));

            var products = dataQuery
                .ToList()
                .Where(product => fulltextResponses
                    .Any(x => x.ProductId == product.Id));

            items = GetIsVisibleProductCatalogs(products);
        }
        else
        {
            items = GetIsVisibleProductCatalogs(dataQuery.ToList());
        }

        var totalCount = items.Count;
        items = items
            .OrderBy(item => item.Name)
            .Skip(searchQuery.PagingFilter.Offset)
            .Take(searchQuery.PagingFilter.Limit)
            .ToList();

        storeItems = items
            .Select(item => MappingService
                .MapProductCatalogToStoreItem(item, null))
            .ToList();
        if (searchQuery.SearchParameters.ShowSolutionPartners)
        {
            await SetSolutionPartnersDataForStoreItem(storeItems, ct);
        }

        return new CollectionResult<StoreItemModel>
        {
            Items = storeItems,
            TotalCount = totalCount
        };
    }

    protected async Task<CollectionResult<StoreItemWithLicenceInformationModel>> StoreItemsWithLicenseSearchAsync(GetStoreItemsSearchQueryBase searchQuery,
        IQueryable<ProductCatalog> dataQuery,
        List<ApplicationLicenseModelAggregatedByPackageCode> applicationLicensesModels,
        List<LicenseModelAggregatedByPackageCode> licensesModels,
        bool isSourceLicenses = false,
        Dictionary<string, string> allPurchasedDictionary = null,
        CancellationToken ct = default)
    {
        var items = new List<ProductCatalog>();
        var storeItemsWithLicence = new List<StoreItemWithLicenceInformationModel>();

        if (searchQuery.SearchParameters.CategoryCodes != null &&
            searchQuery.SearchParameters.CategoryCodes.Count != 0)
        {
            var categoryIds = Categories
                .Get(item => searchQuery.SearchParameters.CategoryCodes
                    .Contains(item.Code))
                .Select(category => category.Id)
                .ToList();

            dataQuery = dataQuery
                .Where(item => item.Categories
                    .Any(category => categoryIds
                        .Contains(category.CategoryId)));
        }

        if (!string.IsNullOrEmpty(searchQuery.SearchParameters?.SearchText))
        {
            var searchedString = searchQuery.SearchParameters?.SearchText.ToUpperInvariant();
            var fulltextResponses = FulltextSearches
                .Get(x => x.LanguageCode == Context.Localization.LanguageCode &&
                    x.FulltextData.Any(x => x.ToUpperInvariant().Contains(searchedString)));

            items = [.. dataQuery
                .ToList()
                .Where(product => fulltextResponses
                    .Any(x => x.ProductId == product.Id))
                .OrderBy(item => item.Name)];
        }
        else
        {
            items = [.. dataQuery.OrderBy(item => item.Name)];
        }

        var isRequestWithoutFilter = string.IsNullOrWhiteSpace(searchQuery.SearchParameters?.SearchText) &&
            searchQuery.SearchParameters?.AdditionalFilter == null &&
            searchQuery.SearchParameters?.CategoryCodes == null;

        if (isSourceLicenses)
        {
            foreach (var applicationLicense in licensesModels)
            {
                var activeProduct = items.FirstOrDefault(x => x.PartCode == applicationLicense.SolutionPackageCode && !x.Deleted);
                StoreItemModel storeItem = null;

                ProductCatalog product = null;

                if (activeProduct == null)
                {
                    //find latest deleted product if exist
                    product = items.OrderByDescending(x => x.ModifiedOn)
                        .FirstOrDefault(x => x.PartCode == applicationLicense.SolutionPackageCode && x.Deleted);
                }
                else
                {
                    product = activeProduct;
                }

                if (product.GetCustomAttributeValue<bool>(StoreAttributeGroupCodes.StoreItem, StoreAttributeCodes.IsHidden))
                {
                    continue;
                }

                if (isRequestWithoutFilter)
                {
                    storeItem = product != null ?
                        MappingService.MapProductCatalogToStoreItem(product, allPurchasedDictionary) :
                        new StoreItemModel
                        {
                            Name = applicationLicense.SolutionPackageCode,
                        };
                }
                else
                {
                    if (product == null)
                    {
                        continue;
                    }
                    storeItem = MappingService.MapProductCatalogToStoreItem(product, allPurchasedDictionary);
                }

                string billingPeriod = null;
                var orderExists = true;

                var orderNumber = applicationLicense.Licenses.FirstOrDefault().OrderNumber;

                if (!string.IsNullOrEmpty(orderNumber))
                {
                    var order = await PlatformStoreOrderClient.GetOrderByNumberOptionalAsync(orderNumber,
                        OrderAccessType.Customer, true, ct);
                    if (order != null)
                    {
                        if (order.OrderLines.Any(a => a.OrderLineType == NodeType.Edition.ToString()))
                        {
                            var orderLineEdition = order.OrderLines.Single(l => l.OrderLineType == NodeType.Edition.ToString());
                            var editionSubscriptions = order.OrderLines.FirstOrDefault(w => w.OrderLineType == NodeType.Subscription.ToString() && w.ParentOrderLineId == orderLineEdition.Id);
                            if (editionSubscriptions != null)
                            {
                                var billingPeriodElement = await PlatformStorePdmClient.GetBillingPeriodByCode(editionSubscriptions.BillingPeriodCode, ct);
                                billingPeriod = billingPeriodElement.PeriodUnit switch
                                {
                                    PDM.Contracts.PeriodUnitModel.Month => PeriodTypes.Monthly,
                                    PDM.Contracts.PeriodUnitModel.Year => PeriodTypes.Yearly,
                                    _ => null
                                };
                            }

                        }
                        else if (order.OrderLines.Any(a => a.OrderLineType == NodeType.Licence.ToString()))
                        {
                            var orderLicence = order.OrderLines.First(l => l.OrderLineType == NodeType.Licence.ToString());
                            billingPeriod = orderLicence.BillingPeriodV2 == null ? orderLicence.BillingPeriod :
                                orderLicence.BillingPeriodV2.PeriodUnit == PeriodUnitModel.Month.ToString() &&
                                orderLicence.BillingPeriodV2.Period == 1 ? PeriodTypes.Monthly :
                                orderLicence.BillingPeriodV2.PeriodUnit == PeriodUnitModel.Year.ToString() &&
                                orderLicence.BillingPeriodV2.Period == 1 ? PeriodTypes.Yearly : null;
                        }
                    }
                    else
                    {
                        orderExists = false;
                    }
                }

                var storeItemWithLicence = MappingService.MapStoreItemToStoreItemWithLicencesInformation(storeItem, applicationLicense);

                if (product == null || IsCustomerProductOwner(product.VendorTenantId))
                {
                    foreach (var item in storeItemWithLicence.LicenceInformationModels)
                    {
                        item.AllowedOperation = StoreItemAllowedOperation.Create;
                    }
                }
                else
                {
                    foreach (var item in storeItemWithLicence.LicenceInformationModels)
                    {
                        if (item.ValidFrom is null)
                        {
                            Logger.LogError($"Store licence with orderLinId '{item.OrderLineId}' and licenceCode '{item.LicenceCode}' has ValidFrom set to null");

                            item.AllowedOperation = StoreItemAllowedOperation.None;
                            continue;
                        }

                        var durationInMonths =
                            ((DateTime.UtcNow.Year - item.ValidFrom.Value.Year) * 12) +
                            DateTime.UtcNow.Month - item.ValidFrom.Value.Month;

                        if (durationInMonths >= 1)
                        {
                            if (billingPeriod == PeriodTypes.Yearly)
                            {
                                if (durationInMonths >= 11)
                                {
                                    item.AllowedOperation = StoreItemAllowedOperation.Create;
                                }
                                else
                                {
                                    item.AllowedOperation = StoreItemAllowedOperation.Modify;
                                }
                            }
                            else
                            {
                                item.AllowedOperation = StoreItemAllowedOperation.Create;
                            }
                        }
                        else
                        {
                            item.AllowedOperation = StoreItemAllowedOperation.None;
                        }
                    }
                }

                if (orderExists)
                {
                    storeItemsWithLicence.Add(storeItemWithLicence);
                }
            }
        }
        else
        {
            foreach (var applicationLicense in applicationLicensesModels)
            {
                var activeProduct = items.FirstOrDefault(x => x.PartCode == applicationLicense.SolutionPackageCode && !x.Deleted);
                StoreItemModel storeItem = null;

                ProductCatalog product = null;

                if (activeProduct == null)
                {
                    //find latest deleted product if exist
                    product = items.OrderByDescending(x => x.ModifiedOn)
                        .FirstOrDefault(x => x.PartCode == applicationLicense.SolutionPackageCode && x.Deleted);
                }
                else
                {
                    product = activeProduct;
                }

                if (product.GetCustomAttributeValue<bool>(StoreAttributeGroupCodes.StoreItem, StoreAttributeCodes.IsHidden))
                {
                    continue;
                }

                if (isRequestWithoutFilter)
                {
                    storeItem = product != null ?
                        MappingService.MapProductCatalogToStoreItem(product, allPurchasedDictionary) :
                        new StoreItemModel
                        {
                            Name = applicationLicense.SolutionPackageCode,
                            FrontendUrl = applicationLicense.FrontendUrl
                        };
                }
                else
                {
                    if (product == null)
                    {
                        continue;
                    }
                    storeItem = MappingService.MapProductCatalogToStoreItem(product, allPurchasedDictionary);
                }

                string billingPeriod = null;
                var orderExists = true;

                var orderNumber = applicationLicense.Licenses.FirstOrDefault().OrderNumber;

                if (!string.IsNullOrEmpty(orderNumber))
                {
                    var order = await PlatformStoreOrderClient.GetOrderByNumberOptionalAsync(orderNumber,
                        OrderAccessType.Customer, true, ct);
                    if (order != null)
                    {
                        if (order.OrderLines.Any(a => a.OrderLineType == NodeType.Edition.ToString()))
                        {
                            var orderLineEdition = order.OrderLines.Single(l => l.OrderLineType == NodeType.Edition.ToString());
                            var editionSubscriptions = order.OrderLines.FirstOrDefault(w => w.OrderLineType == NodeType.Subscription.ToString() && w.ParentOrderLineId == orderLineEdition.Id);
                            if (editionSubscriptions != null)
                            {
                                var billingPeriodElement = await PlatformStorePdmClient.GetBillingPeriodByCode(editionSubscriptions.BillingPeriodCode, ct);
                                billingPeriod = billingPeriodElement.PeriodUnit switch
                                {
                                    PDM.Contracts.PeriodUnitModel.Month => PeriodTypes.Monthly,
                                    PDM.Contracts.PeriodUnitModel.Year => PeriodTypes.Yearly,
                                    _ => null
                                };
                            }

                        }
                        else if (order.OrderLines.Any(a => a.OrderLineType == NodeType.Licence.ToString()))
                        {
                            var orderLicence = order.OrderLines.First(l => l.OrderLineType == NodeType.Licence.ToString());
                            billingPeriod = orderLicence.BillingPeriodV2 == null ? orderLicence.BillingPeriod :
                                orderLicence.BillingPeriodV2.PeriodUnit == PeriodUnitModel.Month.ToString() &&
                                orderLicence.BillingPeriodV2.Period == 1 ? PeriodTypes.Monthly :
                                orderLicence.BillingPeriodV2.PeriodUnit == PeriodUnitModel.Year.ToString() &&
                                orderLicence.BillingPeriodV2.Period == 1 ? PeriodTypes.Yearly : null;
                        }
                    }
                    else
                    {
                        orderExists = false;
                    }
                }

                var storeItemWithLicence = MappingService.MapStoreItemToStoreItemWithLicencesInformation(storeItem, applicationLicense);

                if (product == null || IsCustomerProductOwner(product.VendorTenantId))
                {
                    foreach (var item in storeItemWithLicence.LicenceInformationModels)
                    {
                        item.AllowedOperation = StoreItemAllowedOperation.Create;
                    }
                }
                else
                {
                    foreach (var item in storeItemWithLicence.LicenceInformationModels)
                    {
                        if (item.ValidFrom is null)
                        {
                            Logger.LogError($"Store licence with orderLinId '{item.OrderLineId}' and licenceCode '{item.LicenceCode}' has ValidFrom set to null");

                            item.AllowedOperation = StoreItemAllowedOperation.None;
                            continue;
                        }

                        var durationInMonths =
                            ((DateTime.UtcNow.Year - item.ValidFrom.Value.Year) * 12) +
                            DateTime.UtcNow.Month - item.ValidFrom.Value.Month;

                        if (durationInMonths >= 1)
                        {
                            if (billingPeriod == PeriodTypes.Yearly)
                            {
                                if (durationInMonths >= 11)
                                {
                                    item.AllowedOperation = StoreItemAllowedOperation.Create;
                                }
                                else
                                {
                                    item.AllowedOperation = StoreItemAllowedOperation.Modify;
                                }
                            }
                            else
                            {
                                item.AllowedOperation = StoreItemAllowedOperation.Create;
                            }
                        }
                        else
                        {
                            item.AllowedOperation = StoreItemAllowedOperation.None;
                        }
                    }
                }

                if (orderExists)
                {
                    storeItemsWithLicence.Add(storeItemWithLicence);
                }
            }
        }

        if (searchQuery.SearchParameters?.AdditionalFilter != null &&
            searchQuery.SearchParameters.AdditionalFilter.Any(x => x.ToUpperInvariant() == "TRIAL"))
        {
            storeItemsWithLicence = storeItemsWithLicence.Where(x => x.LicenceInformationModels.Any(x => x.IsTrial)).ToList();
        }

        var totalCount = storeItemsWithLicence.Count;

        storeItemsWithLicence = storeItemsWithLicence
            .OrderByDescending(x => x.LicenceInformationModels
                .OrderByDescending(y => y.ValidFrom)
                .FirstOrDefault().ValidFrom)
            .Skip(searchQuery.PagingFilter.Offset)
            .Take(searchQuery.PagingFilter.Limit)
            .ToList();

        if (searchQuery.SearchParameters.ShowSolutionPartners)
        {
            await SetSolutionPartnersDataForLicenceInformation(storeItemsWithLicence, ct);
        }

        return new CollectionResult<StoreItemWithLicenceInformationModel>
        {
            Items = storeItemsWithLicence,
            TotalCount = totalCount
        };
    }

    public bool IsCustomerProductOwner(string vendorTenantId)
    {
        return Context.Security.User.GetTenantId() == vendorTenantId;
    }

    private static List<ProductCatalog> GetIsVisibleProductCatalogs(IEnumerable<ProductCatalog> products)
    {
        var visibleProducts = new List<ProductCatalog>();

        foreach (var item in products)
        {
            var isHidden = item.GetCustomAttributeValue<bool>(StoreAttributeGroupCodes.StoreItem, "isHidden");

            if (isHidden)
            {
                continue;
            }

            visibleProducts.Add(item);
        }

        return visibleProducts;
    }

    private async Task SetSolutionPartnersDataForLicenceInformation(List<StoreItemWithLicenceInformationModel> storeItemsWithLicence, CancellationToken ct)
    {
        var allOrganizationRelationships = await GetOrganizationRelationshipModels(ct);

        var organizations = new List<SubjectManager.Contracts.Model.OrganizationModel>();
        foreach (var item in allOrganizationRelationships)
        {
            foreach (var data in item.Data)
            {
                if (data.GetType() == typeof(OrganizationRelationshipSolutionPartnerDataModel))
                {
                    var model = (OrganizationRelationshipSolutionPartnerDataModel)data;

                    var storeItem = storeItemsWithLicence.FirstOrDefault(x => x.ApplicationCode == model.ApplicationCode);

                    if (storeItem != null)
                    {
                        var organization = organizations.FirstOrDefault(x => x.Id == item.ParentOrganizationId);
                        if (organization == null)
                        {
                            organization = await SubjectManagerClient.GetOrganizationByIdAsync(item.ParentOrganizationId, false, DataAccessLevel.Public, false, ct);
                            organizations.Add(organization);
                        }

                        storeItem.SolutionPartnerId = organization.Id;
                        storeItem.SolutionPartnerName = organization.Name;
                    }
                }
            }
        }
    }

    private async Task SetSolutionPartnersDataForStoreItem(List<StoreItemModel> storeItemsWithLicence, CancellationToken ct)
    {
        var allOrganizationRelationships = await GetOrganizationRelationshipModels(ct);

        var organizations = new List<SubjectManager.Contracts.Model.OrganizationModel>();
        foreach (var item in allOrganizationRelationships)
        {
            foreach (var data in item.Data)
            {
                if (data.GetType() == typeof(OrganizationRelationshipSolutionPartnerDataModel))
                {
                    var model = (OrganizationRelationshipSolutionPartnerDataModel)data;

                    var storeItem = storeItemsWithLicence.FirstOrDefault(x => x.ApplicationCode == model.ApplicationCode);

                    if (storeItem != null)
                    {
                        var organization = organizations.FirstOrDefault(x => x.Id == item.ParentOrganizationId);
                        if (organization == null)
                        {
                            organization = await SubjectManagerClient.GetOrganizationByIdAsync(item.ParentOrganizationId, false, DataAccessLevel.Public, false, ct);
                            organizations.Add(organization);
                        }

                        storeItem.SolutionPartnerId = organization.Id;
                        storeItem.SolutionPartnerName = organization.Name;
                    }
                }
            }
        }
    }

    private async Task<List<OrganizationRelationshipModel>> GetOrganizationRelationshipModels(CancellationToken ct)
    {
        var organizationId = Context.Security.SelectedOrganizationId;

        var pagingFilter = new PagingFilter { Offset = 0, Limit = 100 };
        var filter = new OrganizationRelationshipFilter
        {
            ChildOrganizationId = organizationId,
            RelationTypeCode = SOLUTION_PARTNER_CODE,
            IncludeData = true,
            OnlyValid = true
        };

        var organizationRelationshipsResult = new List<OrganizationRelationshipModel>();
        var allOrganizationRelationships = new List<OrganizationRelationshipModel>();

        do
        {
            var result = await SubjectManagerClient.OrganizationRelationships
                .GetOrganizationRelationshipsIncludeDataAsync(DataAccessLevel.Public, pagingFilter, filter, ct);

            organizationRelationshipsResult = result?.Items.ToList();

            if (organizationRelationshipsResult is null || organizationRelationshipsResult.Count == 0)
            {
                break;
            }

            allOrganizationRelationships.AddRange(organizationRelationshipsResult);
            pagingFilter.Offset += pagingFilter.Limit;
        }
        while (organizationRelationshipsResult != null && organizationRelationshipsResult.Count > 0);

        return allOrganizationRelationships;
    }
}
