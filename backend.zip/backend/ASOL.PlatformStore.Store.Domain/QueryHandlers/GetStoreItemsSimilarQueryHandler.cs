using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.CustomAttributes.Domain.Repositories;
using ASOL.Core.Domain;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Processing;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Domain.Consts;
using ASOL.PlatformStore.Store.Domain.Queries;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Services;

namespace ASOL.PlatformStore.Store.Domain.QueryHandlers;

public class GetStoreItemsSimilarQueryHandler(
    IDbScopeSelector<IProductCatalogRepository> productCatalogs,
    IDbScopeSelector<ICategoryRepository> categories,
    IMappingService mappingService,
    IStoreAccessControlService storeAccessControlService) : IQueryHandler<GetStoreItemsSimilarQuery, CollectionResult<StoreItemModel>>
{
    protected ICategoryRepository Categories { get; } = categories.GetRepository(DataAccessLevel.Public);

    protected IProductCatalogRepository ProductCatalogs { get; } = productCatalogs.GetRepository(DataAccessLevel.Public);

    protected IMappingService MappingService { get; } = mappingService;

    protected IStoreAccessControlService StoreAccessControlService { get; } = storeAccessControlService;

    public async Task<QueryResult<CollectionResult<StoreItemModel>>> HandleAsync(GetStoreItemsSimilarQuery query, CancellationToken ct = default)
    {
        var sourceItem = ProductCatalogs.Single(item => item.Id == query.SourceItemId);
        if (sourceItem == null)
        {
            return QueryResult<CollectionResult<StoreItemModel>>.NoData;
        }

        var categoryStoreItemType = Categories.Single(item => item.Code == StoreCategoryCodes.StoreItem);
        var subCategoriesStoreItemType = Categories.Get(item => item.ParentIds.Contains(categoryStoreItemType.Id)).ToList();

        var categoryStoreItem = Categories.Single(item => item.Code == StoreCategoryCodes.StoreItem);

        var similarCategories = sourceItem.Categories.Where(c => subCategoriesStoreItemType.Any(cs => cs.Id == c.CategoryId)).Select(c => c.CategoryId).ToList();

        if (similarCategories.Count == 0)
        {
            return QueryResult<CollectionResult<StoreItemModel>>.NoData;
        }

        var dataQuery = ProductCatalogs.Get(
            item =>
            item.Id != query.SourceItemId &&
            item.Categories.Any(c => c.CategoryId == categoryStoreItem.Id));


        dataQuery = dataQuery.Where(item => item.Categories.Any(c => c.CategoryRootPath.Any(cr => similarCategories.Contains(cr))));
        dataQuery = dataQuery.ApplyBaseEntityFilter(query.BaseEntityFilter);
        dataQuery = await StoreAccessControlService.ApplyAccessFilter(dataQuery);

        var totalCount = dataQuery.Count();
        var items = dataQuery
            .OrderBy(r => r.Name)
            .Skip(query.PagingFilter.Offset)
            .Take(query.PagingFilter.Limit)
            .ToList();


        var storeItems = items.Select(i => MappingService.MapProductCatalogToStoreItem(i)).ToList();

        var result = new CollectionResult<StoreItemModel>()
        {
            Items = storeItems,
            TotalCount = totalCount
        };

        return new QueryResult<CollectionResult<StoreItemModel>>(result);
    }

    public Task<ValidationResult> ValidateAsync(GetStoreItemsSimilarQuery query, CancellationToken ct = default)
    {
        return ValidationResult.SuccessfulResultTask;
    }
}
