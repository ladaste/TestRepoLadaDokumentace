using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Domain;
using ASOL.Core.Domain.Contracts;
using ASOL.Core.Identity;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Processing;
using ASOL.IdentityManager.Connector;
using ASOL.IdentityProvider.Connector;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Contracts.Enums;
using ASOL.PlatformStore.Store.Domain.Queries;
using ASOL.PlatformStore.Store.Domain.Repositories;
using Microsoft.Extensions.Logging;

namespace ASOL.PlatformStore.Store.Domain.QueryHandlers;

public class GetSubscriptionsQueryHandler(
    ILogger<GetSubscriptionsQueryHandler> logger,
    IRuntimeContext context,
    IIdentityManagerClient identityManagerClient,
    IIdentityProviderClient iIdentityProviderClient,
    IDbScopeSelector<IFulltextSearchRepository> fulltextSearches,
    IDbScopeSelector<IAllPurchasedAggregatedItemRepository> allPurchasedAggregatedItems) : IQueryHandler<GetSubscriptionsQuery, CollectionResult<SubscriptionsSummaryModel>>
{
    protected ILogger<GetSubscriptionsQueryHandler> Logger { get; } = logger;
    protected IRuntimeContext Context { get; } = context;
    protected IIdentityManagerClient IdentityManagerClient { get; } = identityManagerClient;
    protected IIdentityProviderClient IdentityProviderClient { get; } = iIdentityProviderClient;

    protected IFulltextSearchRepository FulltextSearches { get; } = fulltextSearches.GetRepository(DataAccessLevel.Public);
    protected IAllPurchasedAggregatedItemRepository AllPurchasedAggregatedItems { get; } = allPurchasedAggregatedItems.GetRepository(DataAccessLevel.Public);

    public async Task<QueryResult<CollectionResult<SubscriptionsSummaryModel>>> HandleAsync(GetSubscriptionsQuery query, CancellationToken ct = default)
    {
        var dataQuery = AllPurchasedAggregatedItems
            .GetAll()
            .ApplyBaseEntityFilter(BaseEntityFilter.Default);

        var tenantResult = await IdentityProviderClient.Tenants.GetTenantByIdAsync(Context.Security.TenantId, ct);
        var organizationId = tenantResult.Organizations.FirstOrDefault(x => x.IsTenantOwner)?.Id;

        if (query.SearchParameters != null && query.SearchParameters.ExcludeDefaultApps)
        {
            dataQuery = dataQuery.Where(x => x.OrderNumber != null);
        }

        if (query.SearchParameters != null && query.SearchParameters.AccessTypeViews != null && query.SearchParameters.AccessTypeViews.Count != 0)
        {
            dataQuery = ApplyViewsCombinationsFilter(dataQuery, organizationId, query.SearchParameters.AccessTypeViews);
        }
        else
        {
            dataQuery = dataQuery.Where(x => x.TenantId == Context.Security.TenantId);
        }

        List<AllPurchasedAggregatedItem> allPurchasedAggregatedItems;

        var langSelected = Context.Localization.LanguageCode;
        if (query.SearchParameters != null && !string.IsNullOrEmpty(query.SearchParameters?.SearchText))
        {
            var searchedString = query.SearchParameters?.SearchText.ToUpperInvariant();
            var fulltextResponses = FulltextSearches
                .Get(x => x.LanguageCode == langSelected &&
                    x.FulltextData.Any(x => x.ToUpperInvariant().Contains(searchedString)));

            allPurchasedAggregatedItems = [.. dataQuery
                .ToList()
                .Where(allP => fulltextResponses
                    .Any(x => x.ProductId == allP.ProductCatalogId))
                .OrderBy(item => item.Name?.Values?.FirstOrDefault(v => v.Locale == langSelected)?.Value)];
        }
        else
        {
            allPurchasedAggregatedItems = [.. dataQuery
                .ToList()
                .OrderBy(item => item.Name?.Values?.FirstOrDefault(v => v.Locale == langSelected)?.Value)];
        }

        var totalCount = allPurchasedAggregatedItems.Count;

        var response = allPurchasedAggregatedItems
            .Skip(query.PagingFilter.Offset)
            .Take(query.PagingFilter.Limit)
            .ToList();

        var result = new CollectionResult<SubscriptionsSummaryModel>
        {
            Items = MapToSubscriptionSummaryModels(response),
            TotalCount = totalCount
        };

        return new QueryResult<CollectionResult<SubscriptionsSummaryModel>>(result);
    }

    public Task<ValidationResult> ValidateAsync(GetSubscriptionsQuery query, CancellationToken ct = default)
    {
        return ValidationResult.SuccessfulResultTask;
    }

    private IQueryable<AllPurchasedAggregatedItem> ApplyViewsCombinationsFilter(IQueryable<AllPurchasedAggregatedItem> dataQuery, string organizationId, List<AccessTypeView> views)
    {
        if (views.Count == 4)
        {
            dataQuery = dataQuery.Where(x => x.TenantId == Context.Security.TenantId
                || x.DevelopmentPartnerId == organizationId
                || x.ApplicationSolutionPartnerId == organizationId
                || x.TenantSolutionPartnerId == organizationId);
        }
        else if (views.Count == 3)
        {
            if (views.Any(x => x == AccessTypeView.Customer)
                && views.Any(x => x == AccessTypeView.DevelopmentPartner)
                && views.Any(x => x == AccessTypeView.ApplicationSolutionPartner))
            {
                dataQuery = dataQuery.Where(x => x.TenantId == Context.Security.TenantId
                    || x.DevelopmentPartnerId == organizationId
                    || x.TenantSolutionPartnerId == organizationId);
            }
            else if (views.Any(x => x == AccessTypeView.Customer)
                && views.Any(x => x == AccessTypeView.DevelopmentPartner)
                && views.Any(x => x == AccessTypeView.TenantSolutionPartner))
            {
                dataQuery = dataQuery.Where(x => x.TenantId == Context.Security.TenantId
                    || x.DevelopmentPartnerId == organizationId
                    || x.TenantSolutionPartnerId == organizationId);
            }
            else if (views.Any(x => x == AccessTypeView.Customer)
                && views.Any(x => x == AccessTypeView.ApplicationSolutionPartner)
                && views.Any(x => x == AccessTypeView.TenantSolutionPartner))
            {
                dataQuery = dataQuery.Where(x => x.TenantId == Context.Security.TenantId
                    || x.ApplicationSolutionPartnerId == organizationId
                    || x.TenantSolutionPartnerId == organizationId);
            }
            else if (views.Any(x => x == AccessTypeView.DevelopmentPartner)
                && views.Any(x => x == AccessTypeView.ApplicationSolutionPartner)
                && views.Any(x => x == AccessTypeView.TenantSolutionPartner))
            {
                dataQuery = dataQuery.Where(x => x.DevelopmentPartnerId == organizationId
                    || x.ApplicationSolutionPartnerId == organizationId
                    || x.TenantSolutionPartnerId == organizationId);
            }
        }
        else if (views.Count == 2)
        {
            if (views.Any(x => x == AccessTypeView.Customer)
                && views.Any(x => x == AccessTypeView.DevelopmentPartner))
            {
                dataQuery = dataQuery.Where(x => x.TenantId == Context.Security.TenantId
                    || x.DevelopmentPartnerId == organizationId);
            }
            else if (views.Any(x => x == AccessTypeView.Customer)
                && views.Any(x => x == AccessTypeView.ApplicationSolutionPartner))
            {
                dataQuery = dataQuery.Where(x => x.TenantId == Context.Security.TenantId
                || x.ApplicationSolutionPartnerId == organizationId);
            }
            else if (views.Any(x => x == AccessTypeView.Customer)
                && views.Any(x => x == AccessTypeView.TenantSolutionPartner))
            {
                dataQuery = dataQuery.Where(x => x.TenantId == Context.Security.TenantId
                || x.TenantSolutionPartnerId == organizationId);
            }
            else if (views.Any(x => x == AccessTypeView.DevelopmentPartner)
                && views.Any(x => x == AccessTypeView.ApplicationSolutionPartner))
            {
                dataQuery = dataQuery.Where(x => x.DevelopmentPartnerId == organizationId
                || x.ApplicationSolutionPartnerId == organizationId);
            }
            else if (views.Any(x => x == AccessTypeView.DevelopmentPartner)
                && views.Any(x => x == AccessTypeView.TenantSolutionPartner))
            {
                dataQuery = dataQuery.Where(x => x.DevelopmentPartnerId == organizationId
                || x.TenantSolutionPartnerId == organizationId);
            }
            else if (views.Any(x => x == AccessTypeView.ApplicationSolutionPartner)
                && views.Any(x => x == AccessTypeView.TenantSolutionPartner))
            {
                dataQuery = dataQuery.Where(x => x.ApplicationSolutionPartnerId == organizationId
                || x.TenantSolutionPartnerId == organizationId);
            }
        }
        else if (views.Count == 1)
        {
            if (views.Any(x => x == AccessTypeView.Customer))
            {
                dataQuery = dataQuery.Where(x => x.TenantId == Context.Security.TenantId);
            }
            else if (views.Any(x => x == AccessTypeView.DevelopmentPartner))
            {
                dataQuery = dataQuery.Where(x => x.DevelopmentPartnerId == organizationId);
            }
            else if (views.Any(x => x == AccessTypeView.ApplicationSolutionPartner))
            {
                dataQuery = dataQuery.Where(x => x.ApplicationSolutionPartnerId == organizationId);
            }
            else if (views.Any(x => x == AccessTypeView.TenantSolutionPartner))
            {
                dataQuery = dataQuery.Where(x => x.TenantSolutionPartnerId == organizationId);
            }
        }

        return dataQuery;
    }

    private List<SubscriptionsSummaryModel> MapToSubscriptionSummaryModels(List<AllPurchasedAggregatedItem> allPurchasedAggregatedItems)
    {
        var response = new List<SubscriptionsSummaryModel>();

        foreach (var item in allPurchasedAggregatedItems)
        {
            var subscriptionsSummaryModel = new SubscriptionsSummaryModel
            {
                Id = item.Id,
                ProductCatalogId = item.ProductCatalogId,
                Name = item.Name?.Values?.FirstOrDefault(x => x.Locale == Context.Localization.LanguageCode)?.Value,
                CustomerId = item.CustomerId,
                CustomerName = item.CustomerName,
                ApplicationCode = item.ApplicationCode,
                EditionName = item.EditionName,
                BillingPeriod = item.BillingPeriod,
                CardImageId = item.CardImageId,
                ApplicationSolutionPartnerId = item.ApplicationSolutionPartnerId,
                ApplicationSolutionPartnerName = item.ApplicationSolutionPartnerName,
                DevelopmentPartnerId = item.DevelopmentPartnerId,
                DevelopmentPartnerName = item.DevelopmentPartnerName,
                OrderNumber = item.OrderNumber,
                ShortDescription = item.ShortDescription?.Values?.FirstOrDefault(x => x.Locale == Context.Localization.LanguageCode)?.Value,
                TenantSolutionPartnerId = item.TenantSolutionPartnerId,
                TenantSolutionPartnerName = item.TenantSolutionPartnerName,
                DateOfStatus = item.DateOfStatus,
                OrderDate = item.OrderDate,
                LicenseModifiedOn = item.LicenseModifiedOn,
                DateOfEndedLicense = item.DateOfEndedLicense,
                ApprovedByCustomerOn = item.ApprovedByCustomerOn,
                ModifiedOn = item.ModifiedOn,
                Status = item.Status,
            };

            response.Add(subscriptionsSummaryModel);
        }

        return response;
    }
}
