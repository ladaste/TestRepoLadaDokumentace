using ASOL.Core.Persistence;

namespace ASOL.PlatformStore.Store.Domain.Repositories;

/// <inheritdoc/>
public interface IAllPurchasedAggregatedItemRepository : IRepository<AllPurchasedAggregatedItem, string>, IAllPurchasedAggregatedItemReadOnlyRepository
{
}

/// <inheritdoc/>
public interface IAllPurchasedAggregatedItemReadOnlyRepository : IReadOnlyRepository<AllPurchasedAggregatedItem, string>
{
}
