using System.Collections.Generic;
using ASOL.Core.Persistence;

namespace ASOL.PlatformStore.Store.Domain.Repositories;

/// <inheritdoc/>
public interface IFulltextSearchRepository : IRepository<FulltextSearch, string>, IFulltextSearchReadOnlyRepository
{
    IEnumerable<FulltextSearch> FulltextSearch(string searchedString, string languageCode);
}

/// <inheritdoc/>
public interface IFulltextSearchReadOnlyRepository : IReadOnlyRepository<FulltextSearch, string>
{
}
