using ASOL.Core.Persistence;
using ASOL.PlatformStore.Store.Domain.LeftPanels.Domain;

namespace ASOL.PlatformStore.Store.Domain.Repositories;

public interface ILeftPanelRepository : ILeftPanelReadOnlyRepository, IRepository<LeftPanel, string>
{
}
