using System.Linq;
using ASOL.Core.Persistence;

namespace ASOL.PlatformStore.Store.Domain.Repositories;

/// <inheritdoc/>
public interface IProductCatalogRepository : IRepository<ProductCatalog, string>, IProductCatalogReadOnlyRepository
{
}

/// <inheritdoc/>
public interface IProductCatalogReadOnlyRepository : IReadOnlyRepository<ProductCatalog, string>
{
    IQueryable<ProductCatalog> AddHasAttributeGroupFilter(IQueryable<ProductCatalog> query, string attributeGroupCode);
}
