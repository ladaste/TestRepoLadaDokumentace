using ASOL.Core.Persistence;

namespace ASOL.PlatformStore.Store.Domain.Repositories;

/// <inheritdoc/>
public interface ISyncDataLogRepository : IRepository<SyncDataLog, string>, ISyncDataLogReadOnlyRepository
{
}

/// <inheritdoc/>
public interface ISyncDataLogReadOnlyRepository : IReadOnlyRepository<SyncDataLog, string>
{
}
