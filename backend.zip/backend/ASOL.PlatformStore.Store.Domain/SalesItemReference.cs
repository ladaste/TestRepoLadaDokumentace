using System.Collections.Generic;
using ASOL.Core.Domain;

namespace ASOL.PlatformStore.Store.Domain;

public class SalesItemReference : ValueObject
{
    public IEnumerable<Price> PriceList { get; set; }
    public IEnumerable<PriceScale> PriceScales { get; set; }

    protected override IEnumerable<object> GetAtomicValues()
    {
        return [PriceList, PriceScales];
    }
}
