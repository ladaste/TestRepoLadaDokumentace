using System.Threading.Tasks;
using ASOL.Core.Domain.Contracts;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.IdentityManager.Contracts;

namespace ASOL.PlatformStore.Store.Domain.Services.AllPurchased;

public interface IRightsObjectGroupService
{
    Task<RightObjectGroupModel> GetGroupByCode(DataAccessLevel accessLevel, string groupCode, BaseEntityFilter baseEntityFilter = null);
}
