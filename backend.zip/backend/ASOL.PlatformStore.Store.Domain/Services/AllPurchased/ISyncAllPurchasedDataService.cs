using System.Threading;
using System.Threading.Tasks;

namespace ASOL.PlatformStore.Store.Domain.Services.AllPurchased;

public interface ISyncAllPurchasedDataService
{
    Task SyncAllPurchasedData(SyncTriggerType syncTriggerType,
        string requestId,
        string licenseId = null,
        string applicationCode = null,
        string editionCode = null,
        string roleId = null,
        string roleCode = null,
        string productCatalogId = null,
        CancellationToken ct = default);
}
