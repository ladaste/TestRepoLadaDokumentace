using System;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Domain.Contracts;
using ASOL.Core.Identity;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.IdentityManager.Connector;
using ASOL.IdentityManager.Contracts;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Primitives;

namespace ASOL.PlatformStore.Store.Domain.Services.AllPurchased;

public class RightsObjectGroupService(
    IRuntimeContext runtimeContext,
    IMemoryCache cache,
    IIdentityManagerClient idmClient) : IRightsObjectGroupService
{
    protected IRuntimeContext RuntimeContext { get; } = runtimeContext;

    protected IMemoryCache Cache { get; } = cache;

    protected IIdentityManagerClient IdmClient { get; } = idmClient;

    private readonly TimeSpan CacheEntryTimeout = TimeSpan.FromHours(1);

    public async Task<RightObjectGroupModel> GetGroupByCode(DataAccessLevel accessLevel, string groupCode, BaseEntityFilter baseEntityFilter = null)
    {
        if (string.IsNullOrEmpty(groupCode))
        {
            throw new ArgumentNullException(nameof(groupCode));
        }

        baseEntityFilter ??= BaseEntityFilter.Default;

        var cacheKey = CreateCacheKey(accessLevel, groupCode.ToLower(), baseEntityFilter);
        if (Cache.TryGetValue(cacheKey, out RightObjectGroupModel group))
        {
            return group;
        }

        if (accessLevel != DataAccessLevel.Private)
        {
            group = await IdmClient.RightsObjectGroups.GetByCodeAsync(groupCode, DataAccessLevel.Public, true, true);
        }

        if (group == null && RuntimeContext.Security.HasTenantContext && accessLevel != DataAccessLevel.Public)
        {
            group = await IdmClient.RightsObjectGroups.GetByCodeAsync(groupCode, DataAccessLevel.Private, true, true);
        }

        var entryOpt = new MemoryCacheEntryOptions()
             .AddExpirationToken(new CancellationChangeToken(GetOrAddGroupCodeResetToken(groupCode).Token))
             .SetSlidingExpiration(CacheEntryTimeout);
        Cache.Set(cacheKey, group, entryOpt);

        return group;
    }

    private string CreateCacheKey(DataAccessLevel accessLevel, string groupId, BaseEntityFilter baseEntityFilter)
    {
        var baseEntityFilterCacheKey = $"{(baseEntityFilter.Deleted ? "D" : string.Empty)}|{(baseEntityFilter.Undeleted ? "d" : string.Empty)}|{(baseEntityFilter.Released ? "R" : string.Empty)}|{(baseEntityFilter.Unreleased ? "r" : string.Empty)}|";
        var tenantCacheKeyPart = RuntimeContext.Security.HasTenantContext ? RuntimeContext.Security.TenantId : "Master";
        return $"{nameof(RightsObjectGroupService)}|{accessLevel}|{groupId}|{baseEntityFilterCacheKey}|{tenantCacheKeyPart}";
    }

    private CancellationTokenSource GetOrAddGroupCodeResetToken(string groupCode)
    {
        var cancellationKey = CreateCacheResetTokenKey(groupCode);
        if (!Cache.TryGetValue<CancellationTokenSource>(cancellationKey, out var cacheCts))
        {
            cacheCts = new CancellationTokenSource();
            Cache.Set(cancellationKey, cacheCts);
        }
        return cacheCts;
    }

    private string CreateCacheResetTokenKey(string groupCode)
    {
        var cancellationKey = $"{nameof(RightsObjectGroupService)}|CTS|{groupCode}";
        return cancellationKey;
    }
}

