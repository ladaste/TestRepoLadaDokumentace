using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.CustomAttributes.Contracts.Utils;
using ASOL.Core.CustomAttributes.Domain.Extensions;
using ASOL.Core.CustomAttributes.Domain.Repositories;
using ASOL.Core.Domain;
using ASOL.Core.Domain.Contracts;
using ASOL.Core.Identity;
using ASOL.Core.Localization;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.Core.Paging.Contracts;
using ASOL.Core.Paging.Contracts.Filters;
using ASOL.IdentityManager.Connector;
using ASOL.IdentityManager.Contracts;
using ASOL.IdentityManager.Contracts.Filters;
using ASOL.IdentityManager.Contracts.Licenses;
using ASOL.IdentityProvider.Connector;
using ASOL.IdentityProvider.Contracts.Tenant;
using ASOL.PlatformStore.Order.Connector;
using ASOL.PlatformStore.Order.Contracts;
using ASOL.PlatformStore.Order.Contracts.Primitives;
using ASOL.PlatformStore.PDM.Connector;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Contracts.Enums;
using ASOL.PlatformStore.Store.Domain.Consts;
using ASOL.PlatformStore.Store.Domain.Helpers;
using ASOL.PlatformStore.Store.Domain.Options;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Resources;
using ASOL.SubjectManager.Connector;
using ASOL.SubjectManager.Contracts.Filters;
using ASOL.SubjectManager.Contracts.Model;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Primitives;

using LicenseSystemStatus = ASOL.IdentityManager.Contracts.LicenseSystemStatus;

namespace ASOL.PlatformStore.Store.Domain.Services.AllPurchased;

/// <summary>
/// Initializes the instance.
/// </summary>
/// <param name="logger">Logger</param>
public class SyncAllPurchasedDataService(ILogger<SyncAllPurchasedDataService> logger,
    IOptions<NavigationServiceOptions> options,
    IRuntimeContext context,
    IServiceProvider serviceProvider,
    IImpersonateService impersonateService,
    IDbScopeSelector<IProductCatalogRepository> productCatalogs,
    IDbScopeSelector<ICategoryRepository> categories,
    IDbScopeSelector<IAllPurchasedAggregatedItemRepository> allPurchasedAggregatedItems,
    IIdentityManagerClient idmClient,
    ISubjectManagerClient idmsmClient,
    IPlatformStoreOrderClient orderClient,
    IPlatformStorePdmClient pdmClient,
    IMemoryCache cache) : ISyncAllPurchasedDataService
{
    protected ILogger<SyncAllPurchasedDataService> Logger { get; } = logger;
    protected NavigationServiceOptions Options { get; } = options.Value;
    protected IRuntimeContext Context { get; } = context;
    protected IServiceProvider ServiceProvider { get; } = serviceProvider;
    protected IImpersonateService ImpersonateService { get; } = impersonateService;

    protected ICategoryRepository Categories { get; } = categories.GetRepository(DataAccessLevel.Public);
    protected IProductCatalogRepository ProductCatalogs { get; } = productCatalogs.GetRepository(DataAccessLevel.Public);
    protected IAllPurchasedAggregatedItemRepository AllPurchasedAggregatedItems { get; } = allPurchasedAggregatedItems.GetRepository(DataAccessLevel.Public);

    protected IIdentityManagerClient IdmClient { get; } = idmClient;
    protected ISubjectManagerClient IdmsmClient { get; } = idmsmClient;
    protected IPlatformStoreOrderClient OrderClient { get; } = orderClient;
    protected IPlatformStorePdmClient PDMClient { get; } = pdmClient;

    protected string SpaceOwnerTenantId { get; set; }
    protected SubjectManager.Contracts.Model.OrganizationModel SpaceOwnerOrganizationModel { get; set; }

    private const string APP_SOLUTION_PARTNER_CODE = "SOLUTIONPARTNER";
    private const string TENANT_SOLUTION_PARTNER_CODE = "Platform";

    private string RequestId { get; set; }

    protected IMemoryCache Cache { get; } = cache;

    private readonly TimeSpan CacheEntryTimeout = TimeSpan.FromHours(1);

    private const string ORG_CACHE_KEY = "ORGANIZATIONS";
    private const string ORG_RELATIONSHIP_CACHE_KEY = "ORGANIZATION_RELATIONSHIPS";
    private const string BILLING_PERIODS_CACHE_KEY = "BILLING_PERIODS";

    private Dictionary<string, SubjectManager.Contracts.Model.OrganizationModel> Organizations { get; set; }
    private Dictionary<string, List<OrganizationRelationshipModel>> OrganizationRelationshipModels { get; set; }
    private List<PDM.Contracts.BillingPeriodModel> BillingPeriods { get; set; }

    public async Task SyncAllPurchasedData(SyncTriggerType syncTriggerType,
        string requestId,
        string licenseId = null,
        string applicationCode = null,
        string editionCode = null,
        string roleId = null,
        string roleCode = null,
        string productCatalogId = null,
        CancellationToken ct = default)
    {
        RequestId = requestId;
        var tenantId = Context.Security.TenantId;

        Logger.LogInformation($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. Started request type '{syncTriggerType}' for tenant '{tenantId}'");

        using (var scope = ImpersonateService.GetImpersonatedContext())
        {
            var idmsmClient = scope.ScopeProvider.GetRequiredService<ISubjectManagerClient>();

            CollectionResult<TenantModel2> tenantsResoult;
            var tenants = new List<TenantModel2>();

            var spaceOwnerOrg = await idmsmClient.GetSpaceOwnerOrganizationAsync(false, ct);
            SpaceOwnerTenantId = spaceOwnerOrg.SpaceOwnerTenantId;

            using (var spaceOwnerScope = ImpersonateService.GetTenantContext(SpaceOwnerTenantId))
            {
                var idmsmSpaceOwnerClient = spaceOwnerScope.ScopeProvider.GetRequiredService<ISubjectManagerClient>();
                var idpSpaceOwnerClient = spaceOwnerScope.ScopeProvider.GetRequiredService<IIdentityProviderClient>();

                SpaceOwnerOrganizationModel = await idmsmSpaceOwnerClient.GetOrganizationByIdentificationAsync(spaceOwnerOrg.Code, false, DataAccessLevel.Private, ct);

                if (SpaceOwnerOrganizationModel is null)
                {
                    throw new InvalidDataException($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. Unable to retrieve space owner tenant");
                }

                Logger.LogInformation($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. Starting sync process for all purchased data.");

                var tenant = await idpSpaceOwnerClient.Tenants.GetTenantByIdAsync(tenantId, ct);

                if (tenant == null)
                {
                    Logger.LogError($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. Provided tenant with Id: '{tenantId}' not found.");
                    return;
                }

                var errorLogs = new List<string>();
                try
                {
                    if (tenant.Id is null)
                    {
                        Logger.LogError($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. Skipping tenant because of missing data.");
                        return;
                    }

                    if (!string.IsNullOrWhiteSpace(licenseId))
                    {
                        //Check if Tenant has provided license
                        IdmLicenseModel license;
                        try
                        {
                            license = await IdmClient.Licenses.GetByIdAsync(licenseId, ct);
                        }
                        catch (Exception ex)
                        {
                            Logger.LogInformation($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. There were an error getting LicenseId: '{licenseId}' for tenant: '{tenant.Id}'. Exception: '{ex.Message}'");
                            return;
                        }
                        if (license is null)
                        {
                            Logger.LogInformation($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. LicenseId: '{licenseId}' for tenant: '{tenant.Id}' can not be found.");
                            return;
                        }

                        Logger.LogInformation($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. Syncing data for tenant: '{tenant.Id}' and LicenseId: '{licenseId}'.");

                        //check if ValidTo is set in past - if so allPurchasedItem will be updated just here and finish processing
                        if (license.ValidTo != null && license.ValidTo <= DateTime.UtcNow)
                        {
                            var recordsToUpdate = AllPurchasedAggregatedItems
                                .Get(x => x.TenantId == tenantId
                                    && x.Licenses.Any(x => x.LicenseId == license.Id)
                                    && !x.Deleted)
                                .ToList();

                            foreach (var item in recordsToUpdate)
                            {
                                var licensesToUpdate = item.Licenses.Where(x => x.LicenseId == license.Id);

                                foreach (var licenseToUpdate in licensesToUpdate)
                                {
                                    licenseToUpdate.ValidTo = license.ValidTo;
                                }

                                item.Status = AllPurchasedStates.Ended.ToString();
                                item.DateOfStatus = license.ValidTo;

                                item.LicenseModifiedOn = license.ModifiedOn;
                                item.DateOfEndedLicense = license.ValidTo;

                                item.Touched(Context.Security.User);
                                await AllPurchasedAggregatedItems.UpdateAsync(item, ct);
                            }

                            Logger.LogInformation($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. Finished processing tenant '{tenant.Id}' and LicenseId: '{licenseId}'.");
                            return;
                        }
                    }
                    else
                    {
                        Logger.LogInformation($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. Syncing data for tenant: '{tenant.Id}'.");
                    }

                    var allPurchasedAppsItems = new List<ApplicationLicenseModelAggregatedByPackageCode>();
                    var allPurchasedLicensesItems = new List<LicenseModelAggregatedByPackageCode>();

                    var categoryStoreItem = Categories.Single(item => item.Code == StoreCategoryCodes.StoreItem);

                    var dataQuery = ProductCatalogs.Get(
                        item => item.NodeType == NodeTypeModel.Package &&
                                item.Categories.Any(c => c.CategoryId == categoryStoreItem.Id));

                    dataQuery = ProductCatalogs
                        .AddHasAttributeGroupFilter(dataQuery, StoreAttributeGroupCodes.StoreItem);

                    var productCatalogs = dataQuery
                        .OrderBy(item => item.Name)
                        .ToList();

                    //Check if isTenantReleaseAction, if so, fetch license in 6 trys with delay 3sec if non is fetched
                    if (syncTriggerType == SyncTriggerType.TenantReleased)
                    {
                        for (var i = 0; i < 6; i++)
                        {
                            await Task.Delay(2000, ct);
                            await FetchLicenseModelAggregatedByPackageCodeAsync(allPurchasedLicensesItems, dataQuery, ct);

                            if (allPurchasedLicensesItems != null && allPurchasedLicensesItems.Count != 0)
                            {
                                break;
                            }
                        }
                        if (allPurchasedLicensesItems is null || allPurchasedLicensesItems.Count == 0)
                        {
                            Logger.LogError($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. There are no default apps returned from services for released tenant: '{tenant.Id}'.");
                        }
                    }
                    else
                    {
                        await FetchLicenseModelAggregatedByPackageCodeAsync(allPurchasedLicensesItems, dataQuery, ct);
                    }

                    if (!string.IsNullOrWhiteSpace(licenseId))
                    {
                        allPurchasedLicensesItems = allPurchasedLicensesItems
                            .Where(x => x.Licenses.Any(y => y.Id == licenseId))
                            .ToList();
                    }
                    else if (!string.IsNullOrWhiteSpace(applicationCode) && !string.IsNullOrWhiteSpace(editionCode))
                    {
                        allPurchasedLicensesItems = allPurchasedLicensesItems
                            .Where(x => x.ApplicationCode == applicationCode && x.EditionCode == editionCode)
                            .ToList();
                    }

                    if (allPurchasedLicensesItems is null || allPurchasedLicensesItems.Count == 0)
                    {
                        Logger.LogInformation($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. There are no licenses for tenat '{tenant.Id}'.");
                        return;
                    }

                    if (syncTriggerType == SyncTriggerType.Global)
                    {
                        //clear old allPurchasedData
                        var aggregatedItemsToDelete = AllPurchasedAggregatedItems.Get(x => x.TenantId == tenantId && !x.Deleted);

                        foreach (var item in aggregatedItemsToDelete)
                        {
                            item.MarkAsDeleted(Context.Security.User);
                            await AllPurchasedAggregatedItems.UpdateAsync(item, ct);
                        }
                    }

                    await GetAggregatedDataAsync(idmsmSpaceOwnerClient,
                        productCatalogs,
                        tenant,
                        allPurchasedLicensesItems,
                        productCatalogId,
                        ct);

                    Logger.LogInformation($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. Finishing syncing data for tenant: '{tenant.Id}'.");
                }
                catch (Exception ex)
                {
                    Logger.LogInformation($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. There were an exception durring syncing tenant: '{tenant.Id}'. Exception: '{ex.Message}'");
                }

                Logger.LogInformation($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. Finished processing tenant '{tenant.Id}'.");
            }
        }
    }

    protected async Task GetAggregatedDataAsync(ISubjectManagerClient spaceOwnerSubjectManagerClient,
        List<ProductCatalog> productCatalogs,
        TenantModel2 tenant,
        List<LicenseModelAggregatedByPackageCode> licensesModels,
        string productCatalogId = null,
        CancellationToken ct = default)
    {
        var allPurchasedAggregatedItems = new List<AllPurchasedAggregatedItem>();

        if (Cache.TryGetValue<List<PDM.Contracts.BillingPeriodModel>>(CreateCacheKey(BILLING_PERIODS_CACHE_KEY), out var billingPeriods))
        {
            BillingPeriods = billingPeriods;
        }
        else
        {
            var periods = await PDMClient.GetBillingPeriods(ct);
            BillingPeriods = periods?.ToList();

            var entryOpt = GetCacheEntryOptions(BILLING_PERIODS_CACHE_KEY);
            Cache.Set(CreateCacheKey(BILLING_PERIODS_CACHE_KEY), BillingPeriods, entryOpt);
        }

        foreach (var licenseModel in licensesModels)
        {
            ProductCatalog product = null;

            if (productCatalogId != null)
            {
                product = productCatalogs
                    .FirstOrDefault(x => x.Id == productCatalogId && x.PartCode == licenseModel.SolutionPackageCode && !x.Deleted);
                if (product == null)
                {
                    //find latest deleted product if exist
                    product = productCatalogs
                        .OrderByDescending(x => x.ModifiedOn)
                        .FirstOrDefault(x => x.Id == productCatalogId && x.PartCode == licenseModel.SolutionPackageCode && x.Deleted);

                    if (product == null)
                    {
                        continue;
                    }
                }

                if (product.GetCustomAttributeValue<bool>(StoreAttributeGroupCodes.StoreItem, StoreAttributeCodes.IsHidden))
                {
                    continue;
                }

                await MapAggregatedAllPurchasedDataForLicenses(spaceOwnerSubjectManagerClient,
                    tenant,
                    product,
                    licenseModel,
                    ct);

                break;
            }
            else
            {
                var activeProduct = productCatalogs
                    .FirstOrDefault(x => x.PartCode == licenseModel.SolutionPackageCode && !x.Deleted);

                if (activeProduct == null)
                {
                    //find latest deleted product if exist
                    product = productCatalogs
                        .OrderByDescending(x => x.ModifiedOn)
                        .FirstOrDefault(x => x.PartCode == licenseModel.SolutionPackageCode && x.Deleted);
                }
                else
                {
                    product = activeProduct;
                }
            }

            if (product.GetCustomAttributeValue<bool>(StoreAttributeGroupCodes.StoreItem, StoreAttributeCodes.IsHidden))
            {
                continue;
            }

            await MapAggregatedAllPurchasedDataForLicenses(spaceOwnerSubjectManagerClient,
                tenant,
                product,
                licenseModel,
                ct);
        }
    }

    public async Task MapAggregatedAllPurchasedDataForLicenses(ISubjectManagerClient spaceOwnerSubjectManagerClient,
        TenantModel2 tenant,
        ProductCatalog productCatalog,
        LicenseModelAggregatedByPackageCode licenseModel,
        CancellationToken ct = default)
    {
        var allPurchasedAggregatedItem = new AllPurchasedAggregatedItem(Guid.NewGuid().ToString(), Context.Security.User)
        {
            SolutionPackageName = licenseModel.SolutionPackageName,
            SolutionPackageCode = licenseModel.SolutionPackageCode,
            EditionCode = licenseModel.EditionCode,
            ApplicationCode = licenseModel.ApplicationCode,
            TenantId = tenant.Id,
            StatusDescription = MapLicenceSystemStatusToDescription(licenseModel.Licenses.OrderByDescending(x => x.ValidFrom).FirstOrDefault().Status),
            IsSourceLicense = true,

            ProductCatalogId = productCatalog?.Id,

            Name = productCatalog != null
                ? productCatalog.GetCustomAttributeValue<LocalizedValue<string>>(StoreAttributeGroupCodes.StoreItem, "name")
                : new LocalizedValue<string>(("en-US", licenseModel.SolutionPackageCode), ("cs-CZ", licenseModel.SolutionPackageCode), ("sk-SK", licenseModel.SolutionPackageCode)),

            ShortDescription = productCatalog?.GetCustomAttributeValue<LocalizedValue<string>>(StoreAttributeGroupCodes.StoreItem, "shortDescription"),

            CardImageId = productCatalog?.GetCustomAttributeValue<FileRef>(StoreAttributeGroupCodes.StoreItem, "cardImage")?.FileId,

            Published = productCatalog != null && productCatalog.Published
        };

        allPurchasedAggregatedItem.MarkAsReleased(Context.Security.User);

        var edition = ProductCatalogs
            .Get(item => item.PartCode == licenseModel.EditionCode)
            .ApplyBaseEntityFilter(BaseEntityFilter.Default)
            .FirstOrDefault();

        allPurchasedAggregatedItem.EditionName = edition.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.Edition, "name", Context.Localization.LanguageCode);

        await SetOrganizationRelationshipData(tenant,
                spaceOwnerSubjectManagerClient,
                allPurchasedAggregatedItem,
                ct);

        if (licenseModel.Licenses == null || !licenseModel.Licenses.Any())
        {
            Logger.LogInformation($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. Aggregated item with application code {allPurchasedAggregatedItem.ApplicationCode} doesn't have any licences. Skipping.");
            return;
        }

        var relevantLicenses = new List<IdmLicenseModel>();

        if (licenseModel.Licenses.Any(x => !string.IsNullOrWhiteSpace(x.OrderNumber)))
        {
            relevantLicenses = licenseModel.Licenses
                .OrderByDescending(x => x.ValidFrom)
                .Where(x => !string.IsNullOrWhiteSpace(x.OrderNumber))
                .ToList();
        }
        else
        {
            relevantLicenses = [.. licenseModel.Licenses.OrderByDescending(x => x.ValidFrom)];
        }

        var relevantLicense = relevantLicenses
                .OrderByDescending(x => x.ValidFrom)
                .FirstOrDefault(x => x.ValidTo == null || x.ValidTo > DateTime.UtcNow);

        if (!relevantLicenses.All(x => x.Status == LicenseSystemStatus.Done)
            && !relevantLicenses.All(x => x.Status == LicenseSystemStatus.Confirmed)
            && !relevantLicenses.All(x => x.Status == LicenseSystemStatus.Fail)
            && !relevantLicenses.All(x => x.Status == LicenseSystemStatus.Validation))
        {
            allPurchasedAggregatedItem.Status = AllPurchasedStates.InPreparation.ToString();
            allPurchasedAggregatedItem.DateOfStatus = relevantLicense.ValidFrom;

            allPurchasedAggregatedItem.LicenseModifiedOn = relevantLicense.ModifiedOn;
            allPurchasedAggregatedItem.DateOfEndedLicense = relevantLicense.ValidTo;
        }
        else if (relevantLicenses.Where(x => x.ValidTo == null || x.ValidTo > DateTime.UtcNow).All(x => x.Status == LicenseSystemStatus.Done))
        {
            relevantLicense = relevantLicenses
                .OrderByDescending(x => x.ValidFrom)
                .FirstOrDefault(x => (x.ValidTo == null || x.ValidTo > DateTime.UtcNow) && x.Status == LicenseSystemStatus.Done);

            allPurchasedAggregatedItem.Status = AllPurchasedStates.Done.ToString();
            allPurchasedAggregatedItem.DateOfStatus = relevantLicense.ValidFrom;

            allPurchasedAggregatedItem.LicenseModifiedOn = relevantLicense.ModifiedOn;
            allPurchasedAggregatedItem.DateOfEndedLicense = relevantLicense.ValidTo;
        }
        else if (relevantLicenses.All(x => x.Status == LicenseSystemStatus.Fail))
        {
            allPurchasedAggregatedItem.Status = AllPurchasedStates.Failed.ToString();
            allPurchasedAggregatedItem.DateOfStatus = relevantLicense.ValidTo;

            allPurchasedAggregatedItem.LicenseModifiedOn = relevantLicense.ModifiedOn;
            allPurchasedAggregatedItem.DateOfEndedLicense = relevantLicense.ValidTo;
        }
        else if (relevantLicenses.All(x => x.ValidTo < DateTime.UtcNow))
        {
            relevantLicense = relevantLicenses
                .OrderByDescending(x => x.ValidFrom)
                .FirstOrDefault(x => x.ValidTo < DateTime.UtcNow);

            allPurchasedAggregatedItem.Status = AllPurchasedStates.Ended.ToString();
            allPurchasedAggregatedItem.DateOfStatus = relevantLicense.ValidTo;

            allPurchasedAggregatedItem.LicenseModifiedOn = relevantLicense.ModifiedOn;
            allPurchasedAggregatedItem.DateOfEndedLicense = relevantLicense.ValidTo;
        }

        OrderModel order = null;
        var orderNumber = relevantLicense?.OrderNumber;

        var orderExists = true;

        if (!string.IsNullOrEmpty(orderNumber))
        {
            order = await SetOrderData(spaceOwnerSubjectManagerClient,
                    allPurchasedAggregatedItem,
                    order,
                    orderNumber,
                    ct);

            if (order == null)
            {
                Logger.LogWarning($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. Missing order with number '{orderNumber}'. TenantId: '{tenant.Id}'");
                orderExists = false;
            }
            else
            {
                allPurchasedAggregatedItem.OrderDate = string.IsNullOrWhiteSpace(order?.OrderSummary?.ApprovedByCustomerOn)
                    ? null
                    : DateTime.Parse(order.OrderSummary.ApprovedByCustomerOn);
            }
        }

        if (!orderExists)
        {
            Logger.LogError($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. Skipping Application '{licenseModel.ApplicationCode}' because of not found order with number '{orderNumber}'. TenantId: '{tenant.Id}'");
            allPurchasedAggregatedItem = null;
            return;
        }

        var allowedOperations = new List<string>();
        allPurchasedAggregatedItem.Licenses = [];

        foreach (var licenseItem in licenseModel.Licenses)
        {
            var productCatalogPart = ProductCatalogs
             .Get(p => p.PartCode == licenseItem.Code)
             .ApplyBaseEntityFilter(BaseEntityFilter.Default)
             .FirstOrDefault();

            var billingPeriodCode = order?.OrderLines?.FirstOrDefault(l => l.Id == licenseItem.OrderLineId)?.BillingPeriodCode;

            var license = new License
            {
                LicenseId = licenseItem.Id,
                Code = licenseItem.Code,
                Name = productCatalogPart.GetCustomAttributeValue<LocalizedValue<string>>(StoreAttributeGroupCodes.SalesItem, StoreAttributeCodes.Name),
                BillingPeriodCode = billingPeriodCode,
                OrderNumber = licenseItem.OrderNumber,
                OrderLineId = licenseItem.OrderLineId,
                FormatVersion = licenseItem.FormatVersion,
                Role = licenseItem.Role == null
                    ? null
                    : new LicenseRole
                    {
                        RoleCode = licenseItem.Role.RoleCode,
                        RoleName = licenseItem.Role.RoleName,
                        IsTrial = licenseItem.Role.IsTrial,
                        UserMaxCount = licenseItem.Role.UserMaxCount,
                        UserCount = licenseItem.Role.UserCount,

                    },
                Status = licenseItem.Status,
                ValidFrom = licenseItem.ValidFrom,
                ValidTo = licenseItem.ValidTo
            };

            allPurchasedAggregatedItem.Licenses.Add(license);

            if (productCatalog == null || (order != null && order.Customer?.TenantId == productCatalog?.VendorTenantId))
            {
                allPurchasedAggregatedItem.AllowedOperation = StoreItemAllowedOperation.Create;
            }
            else
            {
                if (licenseItem.ValidFrom is null)
                {
                    continue;
                }

                var durationInMonths =
                    ((DateTime.UtcNow.Year - licenseItem.ValidFrom.Value.Year) * 12) +
                    DateTime.UtcNow.Month - licenseItem.ValidFrom.Value.Month;

                if (durationInMonths >= 1)
                {
                    if (allPurchasedAggregatedItem.BillingPeriod == PeriodTypes.Yearly)
                    {
                        if (durationInMonths >= 11)
                        {
                            allowedOperations.Add(StoreItemAllowedOperation.Create);
                        }
                        else
                        {
                            allowedOperations.Add(StoreItemAllowedOperation.Modify);
                        }
                    }
                    else
                    {
                        allowedOperations.Add(StoreItemAllowedOperation.Create);
                    }
                }


                if (allowedOperations.Any(x => x == StoreItemAllowedOperation.Create))
                {
                    allPurchasedAggregatedItem.AllowedOperation = StoreItemAllowedOperation.Create;
                }
                else if (allowedOperations.Any(x => x == StoreItemAllowedOperation.Modify))
                {
                    allPurchasedAggregatedItem.AllowedOperation = StoreItemAllowedOperation.Modify;
                }
                else
                {
                    allPurchasedAggregatedItem.AllowedOperation = StoreItemAllowedOperation.None;
                }
            }
        }

        if (productCatalog != null)
        {
            SetCategoryData(productCatalog, allPurchasedAggregatedItem);
        }

        await SetAgregatedItemUrls(allPurchasedAggregatedItem);
        await SyncAllPurchasedAggregatedItem(allPurchasedAggregatedItem);
    }

    private async Task FetchLicenseModelAggregatedByPackageCodeAsync(List<LicenseModelAggregatedByPackageCode> allPurchasedLicensesItems,
        IQueryable<ProductCatalog> dataQuery,
        CancellationToken ct)
    {
        CollectionResult<LicenseModelAggregatedByPackageCode> licensesResult;

        var licenseFilter = new LicenseFilter()
        {
            ForceApplyFilterIsVisibleApplication = true,
        };

        var pagingFilter = new PagingFilter { Limit = 500, Offset = 0 };

        do
        {
            licensesResult = await IdmClient.Licenses
                .GetLicenseAggregatedByPackageCodeAsync(licenseFilter, pagingFilter, ct);

            if (licensesResult is null || licensesResult.Items is null || licensesResult.Items.Count == 0)
            {
                break;
            }

            allPurchasedLicensesItems.AddRange(licensesResult.Items);
            pagingFilter.Offset += pagingFilter.Limit;

        }
        while (licensesResult != null && licensesResult.Items != null && licensesResult.Items.Count > 0);

        var allPurchasedFiltered = allPurchasedLicensesItems
            .Select(item => item.SolutionPackageCode)
            .Distinct();

        dataQuery = dataQuery.Where(item => allPurchasedFiltered.Contains(item.PartCode));
    }

    private static string MapLicenceSystemStatusToDescription(LicenseSystemStatus? licenseSystemStatus)
    {
        return licenseSystemStatus switch
        {
            null => Labels.StoreAppStatusOrdered,
            LicenseSystemStatus.Validation => Labels.StoreAppStatusOrdered,
            LicenseSystemStatus.Fail => Labels.StoreAppStatusOrdered,
            LicenseSystemStatus.Confirmed => Labels.StoreAppStatusPreparing,
            LicenseSystemStatus.Done => null,
            _ => null,
        };
    }

    private async Task SyncAllPurchasedAggregatedItem(AllPurchasedAggregatedItem allPurchasedAggregatedItem)
    {
        var isNewRecord = true;

        //select allPurchasedItems already bought before and delete them
        var recordToMarkAsDeleted = AllPurchasedAggregatedItems
            .Get(x => x.TenantId == allPurchasedAggregatedItem.TenantId
                && x.ApplicationCode == allPurchasedAggregatedItem.ApplicationCode
                && x.OrderNumber != allPurchasedAggregatedItem.OrderNumber
                && !x.Deleted)
            .ToList();

        foreach (var item in recordToMarkAsDeleted)
        {
            item.MarkAsDeleted(Context.Security.User);
            await AllPurchasedAggregatedItems.UpdateAsync(item);
        }

        var recordToUpdate = AllPurchasedAggregatedItems
            .Get(x => x.TenantId == allPurchasedAggregatedItem.TenantId
                && x.ApplicationCode == allPurchasedAggregatedItem.ApplicationCode
                && x.OrderNumber == allPurchasedAggregatedItem.OrderNumber
                && !x.Deleted)
            .FirstOrDefault();

        if (recordToUpdate != null)
        {
            isNewRecord = false;
        }

        if (isNewRecord)
        {
            await AllPurchasedAggregatedItems.AddAsync(allPurchasedAggregatedItem);
        }
        else
        {
            recordToUpdate.ProductCatalogId = allPurchasedAggregatedItem.ProductCatalogId;
            recordToUpdate.SolutionPackageName = allPurchasedAggregatedItem.SolutionPackageName;
            recordToUpdate.SolutionPackageCode = allPurchasedAggregatedItem.SolutionPackageCode;
            recordToUpdate.EditionCode = allPurchasedAggregatedItem.EditionCode;
            recordToUpdate.Name = allPurchasedAggregatedItem.Name;
            recordToUpdate.ApprovedByCustomerOn = allPurchasedAggregatedItem.ApprovedByCustomerOn;
            recordToUpdate.ShortDescription = allPurchasedAggregatedItem.ShortDescription;
            recordToUpdate.CardImageId = allPurchasedAggregatedItem.CardImageId;
            recordToUpdate.FrontendUrl = allPurchasedAggregatedItem.FrontendUrl;
            recordToUpdate.BackendUrl = allPurchasedAggregatedItem.BackendUrl;
            recordToUpdate.HasAccesibleByRole = allPurchasedAggregatedItem.HasAccesibleByRole;
            recordToUpdate.ApplicationCode = allPurchasedAggregatedItem.ApplicationCode;
            recordToUpdate.EditionName = allPurchasedAggregatedItem.EditionName;
            recordToUpdate.TenantSolutionPartnerId = allPurchasedAggregatedItem.TenantSolutionPartnerId;
            recordToUpdate.TenantSolutionPartnerName = allPurchasedAggregatedItem.TenantSolutionPartnerName;
            recordToUpdate.ApplicationSolutionPartnerId = allPurchasedAggregatedItem.ApplicationSolutionPartnerId;
            recordToUpdate.ApplicationSolutionPartnerName = allPurchasedAggregatedItem.ApplicationSolutionPartnerName;
            recordToUpdate.DevelopmentPartnerId = allPurchasedAggregatedItem.DevelopmentPartnerId;
            recordToUpdate.DevelopmentPartnerName = allPurchasedAggregatedItem.DevelopmentPartnerName;
            recordToUpdate.CustomerId = allPurchasedAggregatedItem.CustomerId;
            recordToUpdate.CustomerName = allPurchasedAggregatedItem.CustomerName;
            recordToUpdate.BillingPeriod = allPurchasedAggregatedItem.BillingPeriod;
            recordToUpdate.Status = allPurchasedAggregatedItem.Status;
            recordToUpdate.LicenseModifiedOn = allPurchasedAggregatedItem.LicenseModifiedOn;
            recordToUpdate.DateOfStatus = allPurchasedAggregatedItem.DateOfStatus;
            recordToUpdate.OrderDate = allPurchasedAggregatedItem.OrderDate;
            recordToUpdate.LicenseModifiedOn = allPurchasedAggregatedItem.LicenseModifiedOn;
            recordToUpdate.DateOfEndedLicense = allPurchasedAggregatedItem.DateOfEndedLicense;
            recordToUpdate.Category = allPurchasedAggregatedItem.Category;
            recordToUpdate.IntegrationCategories = allPurchasedAggregatedItem.IntegrationCategories;
            recordToUpdate.StatusDescription = allPurchasedAggregatedItem.StatusDescription;
            recordToUpdate.Licenses = allPurchasedAggregatedItem.Licenses;
            recordToUpdate.AllowedOperation = allPurchasedAggregatedItem.AllowedOperation;
            recordToUpdate.IsSourceLicense = allPurchasedAggregatedItem.IsSourceLicense;
            recordToUpdate.Published = allPurchasedAggregatedItem.Published;

            if (allPurchasedAggregatedItem.Released)
            {
                recordToUpdate.MarkAsReleased(Context.Security.User);
            }
            else
            {
                recordToUpdate.MarkAsUnreleased(Context.Security.User);
            }

            if (allPurchasedAggregatedItem.Deleted)
            {
                recordToUpdate.MarkAsDeleted(Context.Security.User);
            }
            else
            {
                recordToUpdate.MarkAsUndeleted(Context.Security.User);
            }

            recordToUpdate.Touched(Context.Security.User);

            await AllPurchasedAggregatedItems.UpdateAsync(recordToUpdate);
        }
    }

    private async Task SetOrganizationRelationshipData(TenantModel2 tenant,
        ISubjectManagerClient spaceOwnerSubjectManagerClient,
        AllPurchasedAggregatedItem allPurchasedAggregatedItem,
        CancellationToken ct)
    {
        var organizationId = tenant.Organizations.FirstOrDefault(x => x.IsTenantOwner)?.Id;

        if (Cache.TryGetValue<Dictionary<string, List<OrganizationRelationshipModel>>>(CreateCacheKey(ORG_RELATIONSHIP_CACHE_KEY), out var organizationRelationships))
        {
            OrganizationRelationshipModels = organizationRelationships;
        }
        else
        {
            OrganizationRelationshipModels = [];

            var entryOpt = GetCacheEntryOptions(ORG_RELATIONSHIP_CACHE_KEY);
            Cache.Set(CreateCacheKey(CreateCacheKey(ORG_RELATIONSHIP_CACHE_KEY)), OrganizationRelationshipModels, entryOpt);
        }


        if (!OrganizationRelationshipModels.TryGetValue(organizationId, out var allOrganizationRelationships))
        {
            // the key isn't in the dictionary.
            allOrganizationRelationships = await GetOrganizationRelationshipModels(organizationId, ct);
            if (allOrganizationRelationships == null)
            {
                Logger.LogError($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. Organization with Id '{organizationId}' does not have any GetOrganizationRelationshipModels.");
                return;
            }
            OrganizationRelationshipModels.Add(organizationId, allOrganizationRelationships);
            Cache.Set(CreateCacheKey(ORG_RELATIONSHIP_CACHE_KEY), OrganizationRelationshipModels, GetCacheEntryOptions(ORG_RELATIONSHIP_CACHE_KEY));
        }

        if (allOrganizationRelationships is null || allOrganizationRelationships.Count == 0)
        {
            return;
        }

        allOrganizationRelationships = [.. allOrganizationRelationships.OrderByDescending(x => x.ValidFrom)];

        if (Cache.TryGetValue<Dictionary<string, SubjectManager.Contracts.Model.OrganizationModel>>(CreateCacheKey(ORG_CACHE_KEY), out var organizations))
        {
            Organizations = organizations;
        }
        else
        {
            Organizations = [];

            var entryOpt = GetCacheEntryOptions(ORG_CACHE_KEY);
            Cache.Set(CreateCacheKey(ORG_CACHE_KEY), Organizations, entryOpt);
        }

        foreach (var item in allOrganizationRelationships)
        {
            foreach (var data in item.Data)
            {
                if (data.GetType() == typeof(OrganizationRelationshipSolutionPartnerDataModel))
                {
                    var model = (OrganizationRelationshipSolutionPartnerDataModel)data;

                    if (string.IsNullOrWhiteSpace(allPurchasedAggregatedItem.ApplicationSolutionPartnerId) && model.ApplicationCode == allPurchasedAggregatedItem.ApplicationCode)
                    {
                        if (!Organizations.TryGetValue(item.ParentOrganizationId, out var organization))
                        {
                            // the key isn't in the dictionary.
                            organization = await spaceOwnerSubjectManagerClient.GetOrganizationByIdAsync(item.ParentOrganizationId, false, DataAccessLevel.Public, false, ct);
                            if (organization == null)
                            {
                                Logger.LogError($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. Parent Organization with Id '{item.ParentOrganizationId}' does not exist.");
                                continue;
                            }
                            Organizations.Add(organization.Id, organization);
                            Cache.Set(CreateCacheKey(ORG_CACHE_KEY), Organizations, GetCacheEntryOptions(ORG_CACHE_KEY));
                        }

                        allPurchasedAggregatedItem.OranizationRelationshipId = item.Id;
                        allPurchasedAggregatedItem.OrganizationRelationshipDataId = data.Id;

                        allPurchasedAggregatedItem.ApplicationSolutionPartnerId = organization.Id;
                        allPurchasedAggregatedItem.ApplicationSolutionPartnerName = organization.Name;
                    }
                    else if (string.IsNullOrWhiteSpace(allPurchasedAggregatedItem.TenantSolutionPartnerId) && model.ApplicationCode == TENANT_SOLUTION_PARTNER_CODE)
                    {
                        if (!Organizations.TryGetValue(item.ParentOrganizationId, out var organization))
                        {
                            // the key isn't in the dictionary.
                            organization = await spaceOwnerSubjectManagerClient.GetOrganizationByIdAsync(item.ParentOrganizationId, false, DataAccessLevel.Public, false, ct);
                            if (organization == null)
                            {
                                Logger.LogError($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. Organization with Id '{item.ParentOrganizationId}' does not exist.");
                                continue;
                            }
                            Organizations.Add(organization.Id, organization);
                            Cache.Set(CreateCacheKey(ORG_CACHE_KEY), Organizations, GetCacheEntryOptions(ORG_CACHE_KEY));
                        }

                        allPurchasedAggregatedItem.OranizationRelationshipId = item.Id;
                        allPurchasedAggregatedItem.OrganizationRelationshipDataId = data.Id;

                        allPurchasedAggregatedItem.TenantSolutionPartnerId = organization.Id;
                        allPurchasedAggregatedItem.TenantSolutionPartnerName = organization.Name;
                    }
                }

                //subscriptionsSummaryModel.ModifiedOn = ; // TODO set after licences sync to store is completed
                if (!string.IsNullOrWhiteSpace(allPurchasedAggregatedItem.ApplicationSolutionPartnerId) &&
                    !string.IsNullOrWhiteSpace(allPurchasedAggregatedItem.TenantSolutionPartnerId))
                {
                    break;
                }
            }
        }
    }

    private async Task<OrderModel> SetOrderData(ISubjectManagerClient subjectManagerClient,
        AllPurchasedAggregatedItem allPurchasedAggregatedItem,
        OrderModel order,
        string orderNumber,
        CancellationToken ct)
    {
        allPurchasedAggregatedItem.OrderNumber = orderNumber;

        order = string.IsNullOrWhiteSpace(orderNumber)
            ? null
            : await OrderClient.GetOrderByNumberAsync(orderNumber, OrderAccessType.Customer, true, ct);

        if (order != null)
        {
            allPurchasedAggregatedItem.CustomerId = order.Customer.TenantId;
            allPurchasedAggregatedItem.CustomerName = order.Customer.Name;

            allPurchasedAggregatedItem.LicenseModifiedOn = order.ModifiedOn; //TODO: this is temporarry date, untill GetLicenseAggregatedByPackageCodeAsync will be returning ModifiedOn as well

            if (order.OrderSummary != null)
            {
                allPurchasedAggregatedItem.ApprovedByCustomerOn =
                    string.IsNullOrWhiteSpace(order.OrderSummary.ApprovedByCustomerOn)
                        ? null
                        : DateTime.Parse(order.OrderSummary.ApprovedByCustomerOn);
            }

            var vendorOrganization = await subjectManagerClient
                .GetOrganizationByIdentificationAsync(order.Vendor?.Code,
                    includeDefaultImages: false,
                    accessLevel: DataAccessLevel.Public,
                    acceptNotFound: true, ct: ct);

            if (vendorOrganization != null)
            {
                allPurchasedAggregatedItem.DevelopmentPartnerId = vendorOrganization.Id;
                allPurchasedAggregatedItem.DevelopmentPartnerName = vendorOrganization.Name;
            }
            else
            {
                Logger.LogInformation($"{nameof(SyncAllPurchasedDataService)}-RequestId: '{RequestId}'. VendorOrganization with code {order.Vendor?.Code} not found. Skipping setting DevelopmentPartner data");
            }

            if (order.OrderLines.Any(a => a.OrderLineType == PDM.Contracts.NodeType.Edition.ToString()))
            {
                var orderLineEdition = order.OrderLines.Single(l => l.OrderLineType == PDM.Contracts.NodeType.Edition.ToString());
                var editionSubscriptions = order.OrderLines.FirstOrDefault(w => w.OrderLineType == PDM.Contracts.NodeType.Subscription.ToString() && w.ParentOrderLineId == orderLineEdition.Id);
                if (editionSubscriptions != null)
                {
                    var billingPeriodElement = BillingPeriods.FirstOrDefault(x => x.Code == editionSubscriptions.BillingPeriodCode);
                    allPurchasedAggregatedItem.BillingPeriod = billingPeriodElement.PeriodUnit switch
                    {
                        PDM.Contracts.PeriodUnitModel.Month => PeriodTypes.Monthly,
                        PDM.Contracts.PeriodUnitModel.Year => PeriodTypes.Yearly,
                        _ => null
                    };
                }
            }
            else if (order.OrderLines.Any(a => a.OrderLineType == PDM.Contracts.NodeType.Licence.ToString()))
            {
                var orderLicence = order.OrderLines.First(l => l.OrderLineType == PDM.Contracts.NodeType.Licence.ToString());
                allPurchasedAggregatedItem.BillingPeriod = orderLicence.BillingPeriodV2 == null ? orderLicence.BillingPeriod :
                    orderLicence.BillingPeriodV2.PeriodUnit == PDM.Contracts.PeriodUnitModel.Month.ToString() &&
                    orderLicence.BillingPeriodV2.Period == 1 ? PeriodTypes.Monthly :
                    orderLicence.BillingPeriodV2.PeriodUnit == PDM.Contracts.PeriodUnitModel.Year.ToString() &&
                    orderLicence.BillingPeriodV2.Period == 1 ? PeriodTypes.Yearly : null;
            }
        }
        return order;
    }

    private void SetCategoryData(ProductCatalog productCatalog,
        AllPurchasedAggregatedItem allPurchasedAggregatedItem)
    {
        var primaryCategory = Categories
                    .Get(category => category.Code == StoreCategoryCodes.StoreItemPrimary)
                    .ApplyBaseEntityFilter(BaseEntityFilter.Default)
                    .FirstOrDefault();

        var itemPrimaryCategoryId = productCatalog.Categories.FirstOrDefault(
                category => category.CategoryRootPath.Any(cr => cr == primaryCategory.Id))?.CategoryId;

        if (itemPrimaryCategoryId != null)
        {
            var itemPrimaryCategory = Categories
                .Get(item => item.Id == itemPrimaryCategoryId)
                .ApplyBaseEntityFilter(BaseEntityFilter.Default)
                .FirstOrDefault();

            if (itemPrimaryCategory != null)
            {
                allPurchasedAggregatedItem.Category = itemPrimaryCategory;
            }
        }

        var integrationCategory = Categories
            .Get(category => category.Code == StoreCategoryCodes.Integration)
            .ApplyBaseEntityFilter(BaseEntityFilter.Default)
            .FirstOrDefault();

        var itemIntegrationCategoryIds = productCatalog.Categories.Where(
                category => category.CategoryRootPath.Any(cr => cr == integrationCategory.Id));

        if (itemIntegrationCategoryIds != null && itemIntegrationCategoryIds.Any())
        {
            allPurchasedAggregatedItem.IntegrationCategories = [];

            foreach (var item in itemIntegrationCategoryIds)
            {
                var itemIntegrationCategoryId = item?.CategoryId;

                var itemIntegrationCategory = Categories
                    .Get(item => item.Id == itemIntegrationCategoryId)
                    .ApplyBaseEntityFilter(BaseEntityFilter.Default)
                    .FirstOrDefault();

                if (itemIntegrationCategory != null)
                {
                    allPurchasedAggregatedItem.IntegrationCategories.Add(itemIntegrationCategory);
                }
            }
        }
    }

    private async Task<List<OrganizationRelationshipModel>> GetOrganizationRelationshipModels(string organizationId, CancellationToken ct = default)
    {
        var pagingFilter = new PagingFilter { Offset = 0, Limit = 500 };
        var filter = new OrganizationRelationshipFilter
        {
            ChildOrganizationId = organizationId,
            RelationTypeCode = APP_SOLUTION_PARTNER_CODE,
            IncludeData = true,
            OnlyValid = true
        };

        var organizationRelationshipsResult = new List<OrganizationRelationshipModel>();
        var allOrganizationRelationships = new List<OrganizationRelationshipModel>();

        do
        {
            var result = await IdmsmClient.OrganizationRelationships
                .GetOrganizationRelationshipsIncludeDataAsync(DataAccessLevel.Public, pagingFilter, filter, ct);

            organizationRelationshipsResult = result?.Items.ToList();

            if (organizationRelationshipsResult is null || organizationRelationshipsResult.Count == 0)
            {
                break;
            }

            allOrganizationRelationships.AddRange(organizationRelationshipsResult);
            pagingFilter.Offset += pagingFilter.Limit;
        }
        while (organizationRelationshipsResult != null && organizationRelationshipsResult.Count > 0);

        return allOrganizationRelationships;
    }

    private async Task SetAgregatedItemUrls(AllPurchasedAggregatedItem allPurchasedAggregatedItem)
    {
        var tenantRightObjectGroupModel = await GetGroupByCode(DataAccessLevel.Private, allPurchasedAggregatedItem.ApplicationCode);

        var tenantRightGroupOptionsModel = tenantRightObjectGroupModel?.Options.FirstOrDefault(x => x.OptionsType == AllPurchasedConstants.RightObjectGroupNavigationOptions);
        RightsObjectGroupNavigationOptionsModel tenantNavigationOptions = null;

        if (tenantRightGroupOptionsModel?.GetType() == typeof(RightsObjectGroupNavigationOptionsModel))
        {
            tenantNavigationOptions = (RightsObjectGroupNavigationOptionsModel)tenantRightGroupOptionsModel;
        }

        var masterRightObjectGroupModel = await GetGroupByCode(DataAccessLevel.Public, allPurchasedAggregatedItem.ApplicationCode);

        var masterRightGroupOptionsModel = masterRightObjectGroupModel?.Options.FirstOrDefault(x => x.OptionsType == AllPurchasedConstants.RightObjectGroupNavigationOptions);
        RightsObjectGroupNavigationOptionsModel masterNavigationOptions = null;

        if (masterRightGroupOptionsModel?.GetType() == typeof(RightsObjectGroupNavigationOptionsModel))
        {
            masterNavigationOptions = (RightsObjectGroupNavigationOptionsModel)masterRightGroupOptionsModel;

            allPurchasedAggregatedItem.HasAccesibleByRole = masterNavigationOptions != null && masterNavigationOptions.IsVisible;
        }

        var backendUrl = string.IsNullOrEmpty(tenantNavigationOptions?.BackendHref)
            ? masterNavigationOptions?.BackendHref
            : tenantNavigationOptions?.BackendHref;

        var frontEndUrl = string.IsNullOrEmpty(tenantNavigationOptions?.Href)
            ? masterNavigationOptions?.Href
            : tenantNavigationOptions?.Href;

        allPurchasedAggregatedItem.BackendUrl = UrlHelper.MakeAbsoluteUrlIfPossible(Options, backendUrl);
        allPurchasedAggregatedItem.FrontendUrl = UrlHelper.MakeAbsoluteUrlIfPossible(Options, frontEndUrl);
    }

    private async Task<RightObjectGroupModel> GetGroupByCode(DataAccessLevel accessLevel,
        string groupCode)
    {
        if (string.IsNullOrEmpty(groupCode))
        {
            throw new ArgumentNullException(nameof(groupCode));
        }

        RightObjectGroupModel group = null;

        if (accessLevel != DataAccessLevel.Private)
        {
            group = await IdmClient.RightsObjectGroups.GetByCodeAsync(groupCode, DataAccessLevel.Public, true, true);
        }

        if (group == null && accessLevel != DataAccessLevel.Public)
        {
            group = await IdmClient.RightsObjectGroups.GetByCodeAsync(groupCode, DataAccessLevel.Private, true, true);
        }

        return group;
    }

    private string CreateCacheKey(string cachedType)
    {
        return $"{nameof(SyncAllPurchasedDataService)}|{RequestId}|{cachedType}";
    }

    private MemoryCacheEntryOptions GetCacheEntryOptions(string cachedType)
    {
        return new MemoryCacheEntryOptions()
            .AddExpirationToken(new CancellationChangeToken(GetOrAddResetToken(cachedType).Token))
            .SetSlidingExpiration(CacheEntryTimeout);
    }

    private CancellationTokenSource GetOrAddResetToken(string cachedType)
    {
        var cancellationKey = CreateCacheResetTokenKey(cachedType);
        if (!Cache.TryGetValue<CancellationTokenSource>(cancellationKey, out var cacheCts))
        {
            cacheCts = new CancellationTokenSource();
            Cache.Set(cancellationKey, cacheCts);
        }
        return cacheCts;
    }

    private string CreateCacheResetTokenKey(string cachedType)
    {
        var cancellationKey = $"{nameof(SyncAllPurchasedDataService)}|CT|{cachedType}";
        return cancellationKey;
    }
}
