using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.ApiConnector;
using ASOL.PlatformStore.Store.Domain.Services.Helpdesk.Models;
using ASOL.PlatformStore.Store.Domain.Services.Helpdesk.Options;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Pathoschild.Http.Client;

namespace ASOL.PlatformStore.Store.Domain.Services.Helpdesk;

public class HelpdeskService : SecuredApiClientBase<HelpdeskClientOptions, IConnectorTokenProvider>, IHelpdeskService
{
    /// <summary>
    /// Api version prefix
    /// </summary>
    protected override string ApiVersionPrefix => "api/v1";

    /// <summary>
    /// Scheduler Client Options
    /// </summary>
    protected HelpdeskClientOptions HelpdeskClientOptions;

    /// <summary>
    /// Creates new client instance
    /// </summary>
    /// <param name="options">Client options</param>
    /// <param name="logger">Logger</param>
    /// <param name="tokenProvider">Token provider</param>
    /// <param name="requestHeaderProviders">Request headers providers</param>
    /// <param name="baseClient">Base client</param>
    /// <param name="manageBaseClient"></param>
    /// <returns></returns>
    public static HelpdeskService Create(
        HelpdeskClientOptions options,
        ILogger<HelpdeskService> logger,
        IConnectorTokenProvider tokenProvider,
        IEnumerable<IRequestHeaderProvider> requestHeaderProviders,
        HttpClient baseClient = null,
        bool manageBaseClient = false)
    {
        return new HelpdeskService(options, logger, tokenProvider, requestHeaderProviders, baseClient, manageBaseClient);
    }

    /// <summary>
    /// Initializes the instance.
    /// </summary>
    /// <param name="options">Client options</param>
    /// <param name="logger">Logger</param>
    /// <param name="tokenProvider">Token provider</param>
    /// <param name="requestHeaderProviders">Request headers providers</param>
    public HelpdeskService(
        IOptions<HelpdeskClientOptions> options,
        ILogger<HelpdeskService> logger,
        IConnectorTokenProvider tokenProvider,
        IEnumerable<IRequestHeaderProvider> requestHeaderProviders)
        : this(options?.Value, logger, tokenProvider, requestHeaderProviders, baseClient: null)
    {
        HelpdeskClientOptions = options?.Value;
    }

    /// <summary>
    /// Initialized the instance.
    /// </summary>
    /// <param name="options">Client options</param>
    /// <param name="logger">Logger</param>
    /// <param name="tokenProvider">Token provider</param>
    /// <param name="requestHeaderProviders">Request headers providers</param>
    public HelpdeskService(
        HelpdeskClientOptions options,
        ILogger<HelpdeskService> logger,
        IConnectorTokenProvider tokenProvider,
        IEnumerable<IRequestHeaderProvider> requestHeaderProviders)
        : this(options, logger, tokenProvider, requestHeaderProviders, baseClient: null)
    {
    }

    /// .ctor
    protected HelpdeskService(
        HelpdeskClientOptions options,
        ILogger<HelpdeskService> logger,
        IConnectorTokenProvider tokenProvider,
        IEnumerable<IRequestHeaderProvider> requestHeaderProviders,
        HttpClient baseClient = null,
        bool manageBaseClient = false)
        : base(options, logger, tokenProvider, requestHeaderProviders, baseClient, manageBaseClient)
    {
    }

    public async Task<string> PostGoldenTicketAsync(string applicationCode, CancellationToken ct)
    {
        Logger.LogInformation($"{nameof(HelpdeskService)} Calling Helpdesk PostGoldenTicketAsync API");

        try
        {
            var resource = $"{Options.BaseUrl}/{ApiVersionPrefix}/GoldenTickets";
            var model = new GoldenTicketRequest
            {
                ApplicationCode = applicationCode,
                LicenseCode = " ", //must be space because Helpdesk implementation is "special" for now. Will be updated after their changed implementation
                Caller = "AVA"
            };

            string result = null;

            var createTaskRequest = (await AddAuthentication(Client.PostAsync(resource, model), ct))
                .WithCancellationToken(ct);

            var response = await createTaskRequest.AsResponse();

            if (response.Status is HttpStatusCode.OK or HttpStatusCode.Created)
            {
                result = await createTaskRequest.As<string>();
            }

            return result;
        }
        catch (Exception e)
        {
            Logger.LogError(e, $"{nameof(HelpdeskService)} failed for 'PostGoldenTicketAsync'.");
        }

        return null;
    }

    public async Task<HelpdeskApplication> GetApplicationByCodeAsync(string applicationCode, CancellationToken ct)
    {
        Logger.LogInformation($"{nameof(HelpdeskService)} Calling Helpdesk GetApplicationByCodeAsync API");

        HelpdeskApplication result = null;

        try
        {
            var resource = $"{Options.BaseUrl}/{ApiVersionPrefix}/Applications/ByProductCatalog/{applicationCode}";

            var request = (await AddAuthentication(Client.GetAsync(resource), ct))
                .WithCancellationToken(ct);

            var response = await request.AsResponse();

            if (response.Status is HttpStatusCode.OK or HttpStatusCode.Created)
            {
                result = await request.As<HelpdeskApplication>();
            }
        }
        catch (Exception e)
        {
            Logger.LogError(e, $"{nameof(HelpdeskService)} failed for 'GetApplicationByCode'.");
        }

        return result;
    }

    public async Task<TicketResponse> PostTicketAsync(TicketRequest request, CancellationToken ct)
    {
        Logger.LogInformation($"{nameof(HelpdeskService)} Calling Helpdesk PostTicketAsync API");
        TicketResponse result = null;

        try
        {
            var resource = $"{Options.BaseUrl}/{ApiVersionPrefix}/Tickets";

            var httpRequest = (await AddAuthentication(Client.PostAsync(resource, request), ct))
                .WithCancellationToken(ct);

            var httpResponse = await httpRequest.AsResponse();

            if (httpResponse.Status is HttpStatusCode.OK or HttpStatusCode.Created)
            {
                result = await httpRequest.As<TicketResponse>();
            }
        }
        catch (Exception e)
        {
            Logger.LogError(e, $"{nameof(HelpdeskService)} failed for 'PostTicketAsync'.");
        }

        return result;
    }

    public async Task<bool> PostWorkflowTicketAsync(string ticketId, CancellationToken ct)
    {
        Logger.LogInformation($"{nameof(HelpdeskService)} Calling Helpdesk PostWorkflowTicketAsync API");
        var result = false;

        try
        {
            var resource = $"{Options.BaseUrl}/{ApiVersionPrefix}/Workflow/ticket/{ticketId}/1";

            var model = new WorkflowTicketRequest();

            var createTaskRequest = (await AddAuthentication(Client.PostAsync(resource, model), ct))
                .WithCancellationToken(ct);

            var response = await createTaskRequest.AsResponse();

            if (response.Status is HttpStatusCode.OK or HttpStatusCode.Created)
            {
                result = true;
            }
        }
        catch (Exception e)
        {
            Logger.LogError(e, $"{nameof(HelpdeskService)} failed for 'PostWorkflowTicketAsync'.");
        }

        return result;
    }
}
