using System.Threading;
using System.Threading.Tasks;
using ASOL.PlatformStore.Store.Domain.Services.Helpdesk.Models;

namespace ASOL.PlatformStore.Store.Domain.Services.Helpdesk;

public interface IHelpdeskService
{
    Task<string> PostGoldenTicketAsync(string applicationCode, CancellationToken ct = default);
    Task<HelpdeskApplication> GetApplicationByCodeAsync(string applicationCode, CancellationToken ct = default);
    Task<TicketResponse> PostTicketAsync(TicketRequest request, CancellationToken ct = default);
    Task<bool> PostWorkflowTicketAsync(string ticketId, CancellationToken ct = default);
}
