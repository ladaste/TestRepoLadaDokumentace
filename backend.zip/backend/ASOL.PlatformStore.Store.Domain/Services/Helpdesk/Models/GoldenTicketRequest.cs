namespace ASOL.PlatformStore.Store.Domain.Services.Helpdesk.Models;

public class GoldenTicketRequest
{
    public string ApplicationCode { get; set; }
    public string LicenseCode { get; set; }
    public string Caller { get; set; }
}

