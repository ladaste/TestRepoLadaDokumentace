using System;
using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.Domain.Services.Helpdesk.Models;

public class HelpdeskApplication
{
    public string Id { get; set; }
    public string Name { get; set; }
    public string Shortname { get; set; }
    public bool Active { get; set; }
    public List<ServiceLevelAgreements> ServiceLevelAgreements { get; set; }
    public string OlA1 { get; set; }
    public string OlA2 { get; set; }
    public string Description { get; set; }
    public string WorkflowDefinitionName { get; set; }
    public string ProductCatalogCode { get; set; }
    public string Type { get; set; }
    public int NestedLevel { get; set; }
    public bool Released { get; set; }
    public bool Deleted { get; set; }
    public string ModifiedBy { get; set; }
    public DateTime ModifiedOn { get; set; }
    public string CreatedBy { get; set; }
    public DateTime CreatedOn { get; set; }
}

public class ServiceLevelAgreements
{
    public string IncidentType { get; set; }
    public string Value { get; set; }
}

