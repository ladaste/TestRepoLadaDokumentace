namespace ASOL.PlatformStore.Store.Domain.Services.Helpdesk.Models;

public class TicketRequest
{
    public TicketProductApplication TicketProductApplication { get; set; }
    public string Title { get; set; }
    public string Description { get; set; }
    public string PluginVersion { get; set; }
    public string ApplicationVersion { get; set; }
    public string LicenseCode { get; set; }
    public TicketType Type { get; set; }
    public Issuer Issuer { get; set; }
    public string State { get; set; }
}

public class TicketProductApplication
{
    public string SourceApplicationCode { get; set; }
    public string SourceApplicationType { get; set; }
}

public class TicketType
{
    public string Type { get; set; }
}

public class Issuer
{
    public string Type { get; set; }
    public string Email { get; set; }
    public string FullName { get; set; }
    public string PhoneNumber { get; set; }
}
