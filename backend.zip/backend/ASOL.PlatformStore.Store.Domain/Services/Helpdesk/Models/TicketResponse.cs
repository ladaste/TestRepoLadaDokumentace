using System;
using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.Domain.Services.Helpdesk.Models;

public class TicketResponse
{
    public string Id { get; set; }
    public string ApplicationId { get; set; }
    public string ApplicationCode { get; set; }
    public string ApplicationVersion { get; set; }
    public string Title { get; set; }
    public TicketResponseType Type { get; set; }
    public string Description { get; set; }
    public string State { get; set; }
    public string Priority { get; set; }
    public int Level { get; set; }
    public int PreviousLevel { get; set; }
    public TicketIssuer Issuer { get; set; }
    public List<string> AttachmentIds { get; set; }
    public string ExternalStateName { get; set; }
    public string Mask { get; set; }
    public string ExternalState { get; set; }
    public string Resolution { get; set; }
    public string StateName { get; set; }
    public string PriorityName { get; set; }
    public string PluginVersion { get; set; }
    public string PartnerApplicationId { get; set; }
    public string LicenseCode { get; set; }
    public string JiraBaseUrl { get; set; }
    public string CrmBaseUrl { get; set; }
    public bool Released { get; set; }
    public bool Deleted { get; set; }
    public string ModifiedBy { get; set; }
    public DateTime ModifiedOn { get; set; }
    public string CreatedBy { get; set; }
    public DateTime CreatedOn { get; set; }
}

public class TicketResponseType
{
    public bool IsPaid { get; set; }
    public string Type { get; set; }
    public string TypeName { get; set; }
}

public class TicketIssuer
{
    public string CompanyName { get; set; }
    public string OrganizationCode { get; set; }
    public string Email { get; set; }
    public string PhoneNumber { get; set; }
    public string FullName { get; set; }
}
