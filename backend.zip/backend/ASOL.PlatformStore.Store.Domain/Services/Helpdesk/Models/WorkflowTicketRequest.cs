using System.Collections.Generic;

namespace ASOL.PlatformStore.Store.Domain.Services.Helpdesk.Models;

public class WorkflowTicketRequest
{
    public List<TicketParameter> Parameters { get; set; }
    public string Description { get; set; }
}

public class TicketParameter
{
    public string Property { get; set; }
    public bool TargetClassProperty { get; set; }
    public string Value { get; set; }
}
