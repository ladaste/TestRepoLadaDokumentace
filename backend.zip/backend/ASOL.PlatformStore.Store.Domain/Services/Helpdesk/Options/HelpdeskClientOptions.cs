using ASOL.Core.ApiConnector;
using ASOL.Core.ApiConnector.Options;

namespace ASOL.PlatformStore.Store.Domain.Services.Helpdesk.Options;

/// <summary>
/// Represents the PlatformStore Order client options.
/// </summary>
public class HelpdeskClientOptions : ApiClientOptions<IApiClient>
{
    /// <summary>
    /// Default section name in appsettings.json.
    /// </summary>
    public const string DefaultSectionName = nameof(HelpdeskClientOptions);

    /// <summary>
    /// Default options.
    /// </summary>
    public static HelpdeskClientOptions Default => new();
}
