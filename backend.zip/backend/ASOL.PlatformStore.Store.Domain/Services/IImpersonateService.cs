using ASOL.Core.Identity;

namespace ASOL.PlatformStore.Store.Domain.Services;

public interface IImpersonateService
{
    IRuntimeContextScope GetImpersonatedContext();

    IRuntimeContextScope GetTenantContext(string tenantId, string organizationCode = null);
}
