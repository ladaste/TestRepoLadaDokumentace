using System.Collections.Generic;
using ASOL.IdentityManager.Contracts;
using ASOL.IdentityManager.Contracts.Licenses;
using ASOL.PlatformStore.Store.Contracts;

namespace ASOL.PlatformStore.Store.Domain.Services;

public interface IMappingService
{
    StoreItemModel MapProductCatalogToStoreItem(ProductCatalog productCatalog, Dictionary<string, string> codesWithFrontendUrl = null);
    StoreItemDetailModel MapProductCatalogToStoreItemDetail(ProductCatalog productCatalog);
    StoreItemWithLicenceInformationModel MapStoreItemToStoreItemWithLicencesInformation(StoreItemModel storeItem, ApplicationLicenseModelAggregatedByPackageCode applicationLicense);
    StoreItemWithLicenceInformationModel MapStoreItemToStoreItemWithLicencesInformation(StoreItemModel storeItem, LicenseModelAggregatedByPackageCode applicationLicense);
    string GetStoreItemName(string productId);
}
