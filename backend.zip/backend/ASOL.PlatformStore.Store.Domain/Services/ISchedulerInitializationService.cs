using System.Threading;
using System.Threading.Tasks;

namespace ASOL.PlatformStore.Store.Domain.Services;

public interface ISchedulerInitializationService
{
    Task InitializeSchedulerAsync(CancellationToken ct = default);
}
