using System.Linq;
using System.Threading.Tasks;

namespace ASOL.PlatformStore.Store.Domain.Services;

public interface IStoreAccessControlService
{
    Task<IQueryable<T>> ApplyAccessFilter<T>(IQueryable<T> query) where T : ProductCatalog;

    Task<bool> TryAccessFilter<T>(T productCatalog) where T : ProductCatalog;
}
