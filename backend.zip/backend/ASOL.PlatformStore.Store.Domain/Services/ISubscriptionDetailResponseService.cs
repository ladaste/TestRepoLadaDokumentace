using System.Threading;
using System.Threading.Tasks;
using ASOL.PlatformStore.Store.Contracts.Subscription;

namespace ASOL.PlatformStore.Store.Domain.Services;

/// <summary>
/// Service for subscription operations with authorization logic
/// </summary>
public interface ISubscriptionDetailResponseService
{
    /// <summary>
    /// Get subscription detail with authorization checks
    /// Returns appropriate ActionResult based on authorization and data availability
    /// </summary>
    /// <param name="subscriptionId">Subscription ID</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>ActionResult with 200/403/404 based on authorization and data</returns>
    Task<SubscriptionDetailModel> GetSubscriptionDetailAsync(string subscriptionId, CancellationToken cancellationToken = default);
}
