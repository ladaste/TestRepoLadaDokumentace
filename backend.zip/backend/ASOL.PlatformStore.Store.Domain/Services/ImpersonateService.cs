using System;
using ASOL.Core.Identity;
using ASOL.Core.Multitenancy;
using Microsoft.Extensions.DependencyInjection;

namespace ASOL.PlatformStore.Store.Domain.Services;

public class ImpersonateService(
    IRuntimeContext runtimeContext,
    IServiceProvider serviceProvider) : IImpersonateService
{
    protected IRuntimeContext RuntimeContext { get; } = runtimeContext;

    protected IServiceProvider ServiceProvider { get; } = serviceProvider;

    /// <summary>
    /// Returns a <see cref="IRuntimeContextScope"/> scope, impersoanting
    /// </summary>
    public IRuntimeContextScope GetImpersonatedContext()
    {
        var scope = ServiceProvider.GetRequiredService<IRuntimeContextScope>();
        return scope;
    }

    /// <summary>
    /// Returns a <see cref="IRuntimeContextScope"/> scope, impersoanting a tenant with the id <b>tenantId</b>
    /// </summary>
    /// <param name="tenantId"></param>
    /// <param name="organizationCode"></param>         
    public IRuntimeContextScope GetTenantContext(string tenantId, string organizationCode = null)
    {
        var scope = ServiceProvider.GetRequiredService<IRuntimeContextScope>();
        var tenantHolder = scope.ScopeProvider.GetRequiredService<ITenantContextHolder>();
        tenantHolder.TenantContext = new TenantContext { Tenant = new TenantInfo(tenantId, null) };

        var languageCode = RuntimeContext.Localization?.LanguageCode ?? ClaimsPrincipalExtensions.DefaultLanguageCode;
        var principalBuilder = ClaimsPrincipalBuilder.CreateClientPrincipal(scope?.SsoAuthOptions?.ClientId ?? nameof(ImpersonateService), tenantId)
            .AddLocale(languageCode)
            .AddAuthenticateType();

        if (!string.IsNullOrEmpty(organizationCode))
        {
            principalBuilder.AddSelectedOrganizationCode(organizationCode);
        }

        var artificalUser = principalBuilder.Build();

        scope.LocalImpersonate(artificalUser, RuntimeContext.Trace?.TraceId ?? Guid.NewGuid().ToString());
        return scope;
    }
}
