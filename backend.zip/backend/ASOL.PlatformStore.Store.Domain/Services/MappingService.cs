using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using ASOL.Core.CustomAttributes.Contracts.Utils;
using ASOL.Core.CustomAttributes.Domain.Extensions;
using ASOL.Core.CustomAttributes.Domain.Repositories;
using ASOL.Core.Domain;
using ASOL.Core.Domain.Contracts;
using ASOL.Core.Identity;
using ASOL.Core.Localization;
using ASOL.Core.Multitenancy.Contracts;
using ASOL.Core.Multitenancy.Persistence;
using ASOL.IdentityManager.Contracts;
using ASOL.IdentityManager.Contracts.Licenses;
using ASOL.PlatformStore.Order.Connector;
using ASOL.PlatformStore.PDM.Connector;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Domain.Consts;
using ASOL.PlatformStore.Store.Domain.Repositories;
using ASOL.PlatformStore.Store.Domain.Resources;
using ASOL.SubjectManager.Connector;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using LicenseRoleModel = ASOL.PlatformStore.Store.Contracts.LicenseRoleModel;
using LicenseSystemStatus = ASOL.IdentityManager.Contracts.LicenseSystemStatus;

namespace ASOL.PlatformStore.Store.Domain.Services;

public class MappingService(
     IDbScopeSelector<ICategoryRepository> categories,
     IDbScopeSelector<IProductCatalogRepository> productCatalogs,
     IRuntimeContext context,
     IPlatformStoreOrderClient platformStoreOrderClient,
     IPlatformStorePdmClient platformStorePdmClient,
     ISubjectManagerClient subjectManagerClient,
     ILogger<MappingService> logger, IMapper mapper) : IMappingService
{
    private bool initialized;

    protected IRuntimeContext Context { get; } = context;
    protected ICategoryRepository Categories { get; } = categories.GetRepository(DataAccessLevel.Public);
    protected IProductCatalogRepository ProductCatalogs { get; } = productCatalogs.GetRepository(DataAccessLevel.Public);
    protected IPlatformStoreOrderClient PlatformStoreOrderClient { get; } = platformStoreOrderClient;
    protected IPlatformStorePdmClient PlatformStorePdmClient { get; } = platformStorePdmClient;
    protected ISubjectManagerClient SubjectManagerClient { get; } = subjectManagerClient;
    protected ILogger Logger { get; } = logger;
    protected IMapper Mapper { get; } = mapper;

    protected string CategoryStoreItemTypeId { get; set; }
    protected Dictionary<string, Core.CustomAttributes.Domain.Entities.Definition.Category> SubCategoriesStoreItemType { get; set; }
    protected string CategoryNonStorePurchaseId { get; set; }

    private const string SOLUTION_PARTNER_CODE = "SOLUTIONPARTNER";

    public StoreItemModel MapProductCatalogToStoreItem(ProductCatalog productCatalog, Dictionary<string, string> codesWithFrontendUrl = null)
    {
        EnsureInitialized();

        var storeItem = new StoreItemModel
        {
            Id = productCatalog.Id,
            Name = productCatalog.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.StoreItem, "name", Context.Localization.LanguageCode),
            CardImageId = productCatalog.GetCustomAttributeValue<FileRef>(StoreAttributeGroupCodes.StoreItem, "cardImage")?.FileId,
            ShortDescription = productCatalog.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.StoreItem, "shortDescription", Context.Localization.LanguageCode),
            Published = productCatalog.Published
        };

        var primaryCategory = Categories
            .Get(category => category.Code == StoreCategoryCodes.StoreItemPrimary)
            .ApplyBaseEntityFilter(BaseEntityFilter.Default)
            .FirstOrDefault();

        var itemPrimaryCategoryId = productCatalog.Categories.FirstOrDefault(
                category => category.CategoryRootPath.Any(cr => cr == primaryCategory.Id))?.CategoryId;

        if (codesWithFrontendUrl != null &&
            codesWithFrontendUrl.TryGetValue(productCatalog.PartCode, out var value))
        {
            storeItem.FrontendUrl = value;
        }

        if (itemPrimaryCategoryId != null)
        {
            var itemPrimaryCategory = Categories
                .Get(item => item.Id == itemPrimaryCategoryId)
                .ApplyBaseEntityFilter(BaseEntityFilter.Default)
                .FirstOrDefault();

            if (itemPrimaryCategory.Name != null && itemPrimaryCategory.Name.Values != null)
            {
                var defaultPrimaryCategoryName = itemPrimaryCategory.Name.Values.FirstOrDefault()?.Value;

                storeItem.Category = new CategoryModel
                {
                    Id = itemPrimaryCategory.Id,
                    Code = itemPrimaryCategory.Code,
                    Name = itemPrimaryCategory.Name.Translate(Context.Localization.LanguageCode,
                        defaultPrimaryCategoryName),
                };
            }
        }

        var integrationCategory = Categories
            .Get(category => category.Code == StoreCategoryCodes.Integration)
            .ApplyBaseEntityFilter(BaseEntityFilter.Default)
            .FirstOrDefault();

        var itemIntegrationCategoryIds = productCatalog.Categories.Where(
                category => category.CategoryRootPath.Any(cr => cr == integrationCategory.Id));

        if (itemIntegrationCategoryIds != null && itemIntegrationCategoryIds.Any())
        {
            storeItem.IntegrationCategories = [];
        }
        else
        {
            return storeItem;
        }

        foreach (var item in itemIntegrationCategoryIds)
        {
            var itemIntegrationCategoryId = item?.CategoryId;

            var itemIntegrationCategory = Categories
                .Get(item => item.Id == itemIntegrationCategoryId)
                .ApplyBaseEntityFilter(BaseEntityFilter.Default)
                .FirstOrDefault();

            var defaultIntegrationCategoryName = itemIntegrationCategory.Name.Values.FirstOrDefault()?.Value;

            var category = new CategoryModel
            {
                Id = itemIntegrationCategory.Id,
                Code = itemIntegrationCategory.Code,
                Name = itemIntegrationCategory.Name.Translate(Context.Localization.LanguageCode, defaultIntegrationCategoryName),
            };

            storeItem.IntegrationCategories.Add(category);
        }

        return storeItem;
    }

    public StoreItemDetailModel MapProductCatalogToStoreItemDetail(ProductCatalog productCatalog)
    {
        EnsureInitialized();

        var languageCode = Context.Localization.LanguageCode;
        var storeItem = MapProductCatalogToStoreItem(productCatalog);

        var detailDescriptionStructure = ExtractLocalizedObject<ICollection<DescriptionFeatureItem>>(
            productCatalog,
            StoreAttributeGroupCodes.StoreItem,
            StoreAttributeCodes.DetailDescriptionStructure,
            languageCode)?
            .Select(d => new DescriptionFeatureItemModel()
            {
                Description = new DescriptionDataItemModel() { Text = d.Description?.Text },
                Subject = new DescriptionDataItemModel() { Text = d.Subject?.Text },
                ContentImageId = d.ContentImage?.FileId,
                ImageRedirectUrl = d.ImageRedirectUrl

            }).ToList();

        var mediaFilesStructure = ExtractLocalizedObject<ICollection<MediaFile>>(
            productCatalog,
            StoreAttributeGroupCodes.StoreItem,
            StoreAttributeCodes.MediaFilesStructure,
            languageCode)?
            .Select(m => new MediaFileModel() { Type = m.Type, ContentFileId = m.ContentFile?.FileId, PosterFileId = m.PosterFile?.FileId }).ToList();

        var storeItemDetail = new StoreItemDetailModel
        {
            Id = storeItem.Id,
            Name = storeItem.Name,
            ShortDescription = storeItem.ShortDescription,
            Description = productCatalog.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.StoreItem, StoreAttributeCodes.Description, languageCode),
            DetailDescription = productCatalog.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.StoreItem, StoreAttributeCodes.DetailDescription, languageCode),
            MediaFiles = productCatalog.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.StoreItem, StoreAttributeCodes.MediaFiles, languageCode),
            SliderDefinition = productCatalog.GetCustomAttributeValue<string>(StoreAttributeGroupCodes.StoreItem, StoreAttributeCodes.SliderDefinition),
            NavigateToEditionVisible = productCatalog.GetCustomAttributeValue<bool>(StoreAttributeGroupCodes.StoreItem, StoreAttributeCodes.NavigateToEditionVisible),
            NavigateToEditionText = productCatalog.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.StoreItem, StoreAttributeCodes.NavigateToEditionText, languageCode),
            NavigateToEditionPartCode = productCatalog.GetCustomAttributeValue<string>(StoreAttributeGroupCodes.StoreItem, StoreAttributeCodes.NavigateToEditionPartCode),
            MarketingClaim = productCatalog.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.StoreItem, StoreAttributeCodes.MarketingClaim, languageCode),
            LegalDisclaimerShort = productCatalog.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.StoreItem, StoreAttributeCodes.LegalDisclaimerShort, languageCode),
            Version = productCatalog.GetCustomAttributeValue<string>(StoreAttributeGroupCodes.StoreItem, StoreAttributeCodes.Version),
            DefaultEditionId = productCatalog.GetCustomAttributeValue<string>(StoreAttributeGroupCodes.StoreItem, StoreAttributeCodes.DefaultEditionId),
            DefaultLicenceId = productCatalog.GetCustomAttributeValue<string>(StoreAttributeGroupCodes.StoreItem, StoreAttributeCodes.DefaultLicenceId),
            CardImageId = storeItem.CardImageId,
            FrontendUrl = storeItem.FrontendUrl,
            Category = storeItem.Category,
            IntegrationCategories = storeItem.IntegrationCategories,
            AdditionalLegalDocuments = GetLegalDocuments(productCatalog, languageCode),
            LicenceProvider = productCatalog.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.Vendor, StoreAttributeCodes.VendorLicenseProvider, languageCode),
            Published = storeItem.Published,

            MediaFilesStructure = mediaFilesStructure,
            DetailDescriptionStructure = detailDescriptionStructure
        };

        if (productCatalog.Children == null || productCatalog.Children.Count == 0)
        {
            return storeItemDetail;
        }

        var commingSoonCategory = Categories.Get(x => x.Code == StoreCategoryCodes.ComingSoon).FirstOrDefault();

        if (commingSoonCategory != null)
        {
            storeItemDetail.ComingSoon = productCatalog.Categories.Any(x => x.CategoryId == commingSoonCategory.Id);
        }

        storeItemDetail.Editions = [.. productCatalog.Children.Select(MapToEditionModel).OrderBy(x => x.SortOrder)];
        var filteredFeatures = new List<FeatureModel>();

        foreach (var edition in storeItemDetail?.Editions)
        {
            foreach (var feature in edition?.Features)
            {
                if (filteredFeatures.Count == 0)
                {
                    filteredFeatures.Add(feature);
                    continue;
                }

                if (filteredFeatures.Any(x => x.PartCode == feature.PartCode))
                {
                    continue;
                }

                filteredFeatures.Add(feature);
            }
        }

        storeItemDetail.Features = [.. filteredFeatures
            .OrderByDescending(x => x.SequenceNumber.HasValue)
            .ThenBy(p => p.SequenceNumber)];
        return storeItemDetail;
    }

    private T ExtractLocalizedObject<T>(ProductCatalog productCatalog, string attributeGroupCode, string attributeCode, string languageCode) where T : class
    {
        try
        {
            var attVal = productCatalog.GetCustomAttributeValue<object>(attributeGroupCode, attributeCode);
            if (attVal == null)
            {
                return null;
            }

            var json = JsonConvert.SerializeObject(attVal);
            var localized = JsonConvert.DeserializeObject<LocalizedValue<T>>(json);

            var res = (localized?.Values.FirstOrDefault(l => l.Locale == languageCode)) ?? (localized?.Values.FirstOrDefault(l => l.Locale == "en-US"));
            return res?.Value;
        }
        catch (Exception e)
        {
            Logger.LogError(e, $"Error extracting localized structured object {typeof(T).Name}");
            return null;
        }
    }

    public StoreItemWithLicenceInformationModel MapStoreItemToStoreItemWithLicencesInformation(StoreItemModel storeItem, ApplicationLicenseModelAggregatedByPackageCode applicationLicense)
    {
        EnsureInitialized();

        var storeItemWithLicenceInformation = new StoreItemWithLicenceInformationModel
        {
            Id = storeItem.Id,
            Name = storeItem.Name,
            ShortDescription = storeItem.ShortDescription,
            CardImageId = storeItem.CardImageId,
            FrontendUrl = storeItem.FrontendUrl,
            Category = storeItem.Category,
            ApplicationCode = applicationLicense.ApplicationCode
        };

        if (applicationLicense.Licenses == null || !applicationLicense.Licenses.Any())
        {
            return storeItemWithLicenceInformation;
        }

        var licenceInformationModels = new List<LicenceInformationModel>();

        foreach (var licenseModel in applicationLicense.Licenses)
        {
            storeItemWithLicenceInformation.OrderNumber = licenseModel.OrderNumber;

            var licenceInformationModel = new LicenceInformationModel();

            var edition = ProductCatalogs
                .Get(item => item.PartCode == applicationLicense.EditionCode)
                .ApplyBaseEntityFilter(BaseEntityFilter.Default)
                .FirstOrDefault();

            if (edition is null)
            {
                Logger.LogWarning($"There is no ProductCatalog (edition) with PartCode: '{applicationLicense.EditionCode}'");
            }

            licenceInformationModel.EditionName = edition.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.Edition, "name", Context.Localization.LanguageCode);
            licenceInformationModel.LicenceCode = licenseModel.Code;
            licenceInformationModel.OrderLineId = licenseModel.OrderLineId;
            licenceInformationModel.Role = licenseModel.Feature.Role != null
                ? new LicenseRoleModel
                {
                    RoleCode = licenseModel.Feature.Role.RoleCode,
                    RoleName = licenseModel.Feature.Role.RoleName?.Translate(Context.Localization.LanguageCode, licenseModel.Feature.Role.RoleName.Values?.FirstOrDefault()?.Value),
                    UserCount = licenseModel.Feature.Role.UserCount,
                    UserMaxCount = licenseModel.Feature.Role.UserMaxCount
                }
                : null;
            licenceInformationModel.IsTrial = licenseModel.Role != null && licenseModel.Role.IsTrial;
            licenceInformationModel.StatusDescription = MapLicenceSystemStatusToDescription(licenseModel.Status);
            licenceInformationModel.ValidFrom = licenseModel.ValidFrom;
            licenceInformationModel.ValidTo = licenseModel.ValidTo;

            licenceInformationModels.Add(licenceInformationModel);
        }

        storeItemWithLicenceInformation.LicenceInformationModels = licenceInformationModels;

        return storeItemWithLicenceInformation;
    }

    public StoreItemWithLicenceInformationModel MapStoreItemToStoreItemWithLicencesInformation(StoreItemModel storeItem, LicenseModelAggregatedByPackageCode applicationLicense)
    {
        EnsureInitialized();

        var storeItemWithLicenceInformation = new StoreItemWithLicenceInformationModel
        {
            Id = storeItem.Id,
            Name = storeItem.Name,
            ShortDescription = storeItem.ShortDescription,
            CardImageId = storeItem.CardImageId,
            FrontendUrl = storeItem.FrontendUrl,
            Category = storeItem.Category,
            ApplicationCode = applicationLicense.ApplicationCode
        };

        if (applicationLicense.Licenses == null || !applicationLicense.Licenses.Any())
        {
            return storeItemWithLicenceInformation;
        }

        var licenceInformationModels = new List<LicenceInformationModel>();

        foreach (var licenseModel in applicationLicense.Licenses)
        {
            storeItemWithLicenceInformation.OrderNumber = licenseModel.OrderNumber;

            var licenceInformationModel = new LicenceInformationModel();

            var edition = ProductCatalogs
                .Get(item => item.PartCode == applicationLicense.EditionCode)
                .ApplyBaseEntityFilter(BaseEntityFilter.Default)
                .FirstOrDefault();

            if (edition is null)
            {
                Logger.LogWarning($"There is no ProductCatalog (edition) with PartCode: '{applicationLicense.EditionCode}'");
            }

            licenceInformationModel.EditionName = edition.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.Edition, "name", Context.Localization.LanguageCode);
            licenceInformationModel.LicenceCode = licenseModel.Code;
            licenceInformationModel.OrderLineId = licenseModel.OrderLineId;
            licenceInformationModel.Role = licenseModel.Feature.Role != null
                ? new LicenseRoleModel
                {
                    RoleCode = licenseModel.Feature.Role.RoleCode,
                    RoleName = licenseModel.Feature.Role.RoleName?.Translate(Context.Localization.LanguageCode, licenseModel.Feature.Role.RoleName.Values?.FirstOrDefault()?.Value),
                    UserCount = licenseModel.Feature.Role.UserCount,
                    UserMaxCount = licenseModel.Feature.Role.UserMaxCount
                }
                : null;
            licenceInformationModel.IsTrial = licenseModel.Role != null && licenseModel.Role.IsTrial;
            licenceInformationModel.StatusDescription = MapLicenceSystemStatusToDescription(licenseModel.Status);
            licenceInformationModel.ValidFrom = licenseModel.ValidFrom;
            licenceInformationModel.ValidTo = licenseModel.ValidTo;

            licenceInformationModels.Add(licenceInformationModel);
        }

        storeItemWithLicenceInformation.LicenceInformationModels = licenceInformationModels;

        return storeItemWithLicenceInformation;
    }

    public string GetStoreItemName(string productId)
    {
        var productCatalog = ProductCatalogs
            .Get(item => item.Id == productId)
            .ApplyBaseEntityFilter(BaseEntityFilter.Default)
            .FirstOrDefault();

        return productCatalog.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.StoreItem, "name", Context.Localization.LanguageCode);
    }

    private static string MapLicenceSystemStatusToDescription(LicenseSystemStatus? licenseSystemStatus)
    {
        return licenseSystemStatus switch
        {
            null => Labels.StoreAppStatusOrdered,
            LicenseSystemStatus.Validation => Labels.StoreAppStatusOrdered,
            LicenseSystemStatus.Fail => Labels.StoreAppStatusOrdered,
            LicenseSystemStatus.Confirmed => Labels.StoreAppStatusPreparing,
            LicenseSystemStatus.Done => null,
            _ => null,
        };
    }

    private void EnsureInitialized()
    {
        if (initialized)
        {
            return;
        }

        CategoryStoreItemTypeId = Categories
            .Get(item => item.Code == StoreCategoryCodes.StoreItem)
            .ApplyBaseEntityFilter(BaseEntityFilter.Default)
            .FirstOrDefault()?.Id;
        SubCategoriesStoreItemType = Categories.Get(item => item.ParentIds.Contains(CategoryStoreItemTypeId)).ToDictionary(item => item.Id);

        initialized = true;
    }

    private EditionModel MapToEditionModel(NodeReference editionNodeReference)
    {
        var languageCode = Context.Localization.LanguageCode;
        var editionNode = ProductCatalogs
            .Get(item => item.Id == editionNodeReference.Id)
            .ApplyBaseEntityFilter(BaseEntityFilter.Default)
            .FirstOrDefault();

        var editionModel = new EditionModel
        {
            Id = editionNode.Id,
            PartCode = editionNode.PartCode,
            IsMandatory = editionNodeReference.IsMandatory,
            OwnershipType = (OwnershipTypeModel?)(editionNodeReference.OwnershipType ?? editionNodeReference.OwnershipType),
            UnitOfSaleCode = editionNode.UnitOfSaleCode,
            UnitOfMeasureCode = editionNode.UnitOfMeasureCode,
            BillingPeriodCode = !string.IsNullOrEmpty(editionNodeReference.BillingPeriodCode) ? editionNodeReference.BillingPeriodCode : editionNode.BillingPeriodCode,
            ItemTypeCode = editionNode.ItemTypeCode,
            ValidFrom = editionNodeReference.ValidFrom,
            ValidTo = editionNodeReference.ValidTo,
            UpgradeType = (UpgradeTypeModel?)editionNodeReference.UpgradeType,
            CanCancel = editionNodeReference.CanCancel,
            Name = editionNode.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.Edition, "name", languageCode),
            SortOrder = editionNode.GetCustomAttributeValue<decimal>(StoreAttributeGroupCodes.Edition, "sortOrder"),
            Default = editionNode.GetCustomAttributeValue<bool>(StoreAttributeGroupCodes.Edition, "default"),
            Description = editionNode.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.Edition, "description", languageCode),
            Features = editionNode.Children?
            .Where(ch => ch.ReferencedNodeType == NodeTypeModel.Feature)
            .Select(n => MapToFeatureModel(n, n.SequenceNumber))
            .OrderBy(x => x.SequenceNumber)
            .ToList(),

            Licences = editionNode.Children?
            .Where(ch => ch.ReferencedNodeType == NodeTypeModel.Licence)
            .Select(n => MapToLicenceModel(n.Id))
            .ToList(),

            Subscriptions = editionNode.Children?
            .Where(ch => ch.ReferencedNodeType == NodeTypeModel.Subscription)
            .Select(MapToSubscriptionModel)
            .ToList(),

            Extensions = editionNode.Children?
            .Where(ch => ch.ReferencedNodeType == NodeTypeModel.Extension)
            .Select(MapToExtensionModel)
            .ToList()
        };

        return editionModel;
    }

    private FeatureModel MapToFeatureModel(NodeReference featureNodeReference, int? sequenceNumber)
    {
        var featureNode = ProductCatalogs
            .Get(item => item.Id == featureNodeReference.Id)
            .ApplyBaseEntityFilter(BaseEntityFilter.Default)
            .FirstOrDefault();

        var featureModel = new FeatureModel
        {
            Id = featureNode.Id,
            PartCode = featureNode.PartCode,
            Name = featureNode.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.Feature, "name", Context.Localization.LanguageCode),
            SequenceNumber = sequenceNumber,
            IsMandatory = featureNodeReference.IsMandatory,
            OwnershipType = (OwnershipTypeModel?)(featureNodeReference.OwnershipType ?? featureNode.OwnershipType),
            UnitOfSaleCode = featureNode.UnitOfSaleCode,
            UnitOfMeasureCode = featureNode.UnitOfMeasureCode,
            BillingPeriodCode = !string.IsNullOrEmpty(featureNodeReference.BillingPeriodCode) ? featureNodeReference.BillingPeriodCode : featureNode.BillingPeriodCode,
            ItemTypeCode = featureNode.ItemTypeCode,
            ValidFrom = featureNodeReference.ValidFrom,
            ValidTo = featureNodeReference.ValidTo,
            UpgradeType = (UpgradeTypeModel?)featureNodeReference.UpgradeType,
            CanCancel = featureNodeReference.CanCancel
        };

        return featureModel;
    }

    private LicenceModel MapToLicenceModel(string licenceId)
    {
        var licence = ProductCatalogs
            .Get(item => item.Id == licenceId)
            .ApplyBaseEntityFilter(BaseEntityFilter.Default)
            .FirstOrDefault();

        var licenceModel = new LicenceModel
        {
            Id = licence.Id,
            PartCode = licence.PartCode,
            LicenceData = licence.GetCustomAttributeValue<string>(StoreAttributeGroupCodes.Licence, "licenceData"),
            LicenceData2 = licence.GetCustomAttributeValue<string>(StoreAttributeGroupCodes.Licence, "licenceData2")
        };

        return licenceModel;
    }

    private SubscriptionModel MapToSubscriptionModel(NodeReference subscriptionNodeReference)
    {
        var subscriptionNode = ProductCatalogs
            .Get(item => item.Id == subscriptionNodeReference.Id)
            .ApplyBaseEntityFilter(BaseEntityFilter.Default)
            .FirstOrDefault();

        return new SubscriptionModel
        {
            Id = subscriptionNode.Id,
            PartCode = subscriptionNode.PartCode,
            IsMandatory = subscriptionNodeReference.IsMandatory,
            OwnershipType = (OwnershipTypeModel?)(subscriptionNodeReference.OwnershipType ?? subscriptionNode.OwnershipType),
            UnitOfSaleCode = subscriptionNode.UnitOfSaleCode,
            UnitOfMeasureCode = subscriptionNode.UnitOfMeasureCode,
            BillingPeriodCode = !string.IsNullOrEmpty(subscriptionNodeReference.BillingPeriodCode) ? subscriptionNodeReference.BillingPeriodCode : subscriptionNode.BillingPeriodCode,
            ItemTypeCode = subscriptionNode.ItemTypeCode,
            ValidFrom = subscriptionNodeReference.ValidFrom,
            ValidTo = subscriptionNodeReference.ValidTo,
            UpgradeType = (UpgradeTypeModel?)subscriptionNodeReference.UpgradeType,
            CanCancel = subscriptionNodeReference.CanCancel,
            SubscriptionData = subscriptionNode.GetCustomAttributeValue<ExpandoObject>(StoreAttributeGroupCodes.Subscription, "subscriptionData"),
            InheritsAmountOfUnits = subscriptionNode.InheritsAmountOfUnits,
            InheritsBillingPeriod = subscriptionNode.InheritsBillingPeriod,
            SalesItems = subscriptionNode.Children
                .Where(ch => ch.ReferencedNodeType == NodeTypeModel.SalesItem)
                .Select(MapToSalesItemModel)
                .ToList()
        };
    }

    private SalesItemModel MapToSalesItemModel(NodeReference salesItemNodeReference)
    {
        var salesItemNode = ProductCatalogs
            .Get(item => item.Id == salesItemNodeReference.Id)
            .ApplyBaseEntityFilter(BaseEntityFilter.Default)
            .FirstOrDefault();

        return new SalesItemModel
        {
            Id = salesItemNode.Id,
            PartCode = salesItemNode.PartCode,
            IsMandatory = salesItemNodeReference.IsMandatory,
            OwnershipType = (OwnershipTypeModel?)(salesItemNodeReference.OwnershipType ?? salesItemNode.OwnershipType),
            UnitOfSaleCode = salesItemNode.UnitOfSaleCode,
            UnitOfMeasureCode = salesItemNode.UnitOfMeasureCode,
            BillingPeriodCode = !string.IsNullOrEmpty(salesItemNodeReference.BillingPeriodCode) ? salesItemNodeReference.BillingPeriodCode : salesItemNode.BillingPeriodCode,
            ItemTypeCode = salesItemNode.ItemTypeCode,
            ValidFrom = salesItemNodeReference.ValidFrom,
            ValidTo = salesItemNodeReference.ValidTo,
            UpgradeType = (UpgradeTypeModel?)salesItemNodeReference.UpgradeType,
            CanCancel = salesItemNodeReference.CanCancel,
            SalesItem = salesItemNodeReference.SalesItem != null ? Mapper.Map<SalesItemReferenceModel>(salesItemNodeReference.SalesItem) : null,
            Name = salesItemNode.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.SalesItem, "name", Context.Localization.LanguageCode),
            RoleCode = salesItemNode.GetCustomAttributeValue<string>(StoreAttributeGroupCodes.SalesItem, "roleCode"),
        };
    }

    private ExtensionModel MapToExtensionModel(NodeReference extensionNodeReference)
    {
        var extension = ProductCatalogs
            .Get(item => item.Id == extensionNodeReference.Id)
            .ApplyBaseEntityFilter(BaseEntityFilter.Default)
            .FirstOrDefault();

        var extensionModel = new ExtensionModel
        {
            Id = extension.Id,
            PartCode = extension.PartCode,
            IsMandatory = extensionNodeReference.IsMandatory,
            OwnershipType = (OwnershipTypeModel?)(extensionNodeReference.OwnershipType ?? extensionNodeReference.OwnershipType),
            UnitOfSaleCode = extension.UnitOfSaleCode,
            UnitOfMeasureCode = extension.UnitOfMeasureCode,
            BillingPeriodCode = !string.IsNullOrEmpty(extensionNodeReference.BillingPeriodCode) ? extensionNodeReference.BillingPeriodCode : extension.BillingPeriodCode,
            ItemTypeCode = extension.ItemTypeCode,
            ValidFrom = extensionNodeReference.ValidFrom,
            ValidTo = extensionNodeReference.ValidTo,
            UpgradeType = (UpgradeTypeModel?)extensionNodeReference.UpgradeType,
            CanCancel = extensionNodeReference.CanCancel,
            ExtensionData = extension.GetCustomAttributeValue<ExpandoObject>(StoreAttributeGroupCodes.Extension, "extensionData"),
            ExtensionName = extension.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.Extension, "name", Context.Localization.LanguageCode),
            ExtensionDescription = extension.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.Extension, "description", Context.Localization.LanguageCode),
            ExtensionLongDescriptionTitle = extension.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.Extension, "longDescriptionTitle", Context.Localization.LanguageCode),
            ExtensionLongDescription = extension.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.Extension, "longDescription", Context.Localization.LanguageCode),
            ExtensionSliderTitle = extension.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.Extension, "sliderTitle", Context.Localization.LanguageCode),
            ExtensionSliderDescription = extension.GetCustomAttributeLocalizedValue(StoreAttributeGroupCodes.Extension, "sliderDescription", Context.Localization.LanguageCode),
            Subscriptions = extension.Children
                .Where(ch => ch.ReferencedNodeType == NodeTypeModel.Subscription)
                .Select(MapToSubscriptionModel)
                .ToList(),
        };

        return extensionModel;
    }

    private static List<LegalDocumentLocalizedModel> GetLegalDocuments(ProductCatalog productCatalog, string languageCode)
    {
        var legalDocumentsJson = productCatalog
            .GetCustomAttributeValue<string>(StoreAttributeGroupCodes.Vendor, StoreAttributeCodes.VendorLegalDocuments);

        List<LegalDocumentLocalizedModel> legalDocumentLocalizedModels = null;

        if (!string.IsNullOrWhiteSpace(legalDocumentsJson))
        {
            legalDocumentLocalizedModels = [];

            var legalDocuments = JsonConvert.DeserializeObject<List<LegalDocumentModel>>(legalDocumentsJson);

            foreach (var item in legalDocuments)
            {
                legalDocumentLocalizedModels.Add(new LegalDocumentLocalizedModel
                {
                    Prefix = item.Prefix.Translate(languageCode, null),
                    HyperlinkTex = item.HyperlinkTex.Translate(languageCode, null),
                    Suffix = item.Suffix.Translate(languageCode, null),
                    LegalDocumentId = item.LegalDocument.Values?.FirstOrDefault(x => x.Locale == languageCode)?.Value.FileId,
                });
            }
        }

        return legalDocumentLocalizedModels;
    }
}
