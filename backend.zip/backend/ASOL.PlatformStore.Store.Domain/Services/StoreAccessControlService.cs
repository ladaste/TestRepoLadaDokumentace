using System.Linq;
using System.Threading.Tasks;
using ASOL.Core.Identity;
using ASOL.Core.Identity.Authorization;
using ASOL.Core.Identity.Exceptions;
using ASOL.IdentityManager.AspNetCore.Authorization.Config;
using ASOL.PlatformStore.Store.Domain.Consts;
using Microsoft.Extensions.Options;

namespace ASOL.PlatformStore.Store.Domain.Services;

public class StoreAccessControlService(
    IRuntimeContext runtimeContext,
    IPlatformAuthorizationService platformAuthorizationService,
    IOptions<AuthorizationServiceOptions> authOptions) : IStoreAccessControlService
{
    protected IRuntimeContext RuntimeContext { get; } = runtimeContext;

    protected IPlatformAuthorizationService PlatformAuthorizationService { get; } = platformAuthorizationService;

    protected AuthorizationServiceOptions AuthOptions { get; } = authOptions.Value;

    public async Task<IQueryable<T>> ApplyAccessFilter<T>(IQueryable<T> query) where T : ProductCatalog
    {
        if (await HasCrossTenantAccess())
        {
            return query;
        }

        return query.Where(p => p.Published);
    }

    public async Task<bool> TryAccessFilter<T>(T productCatalog) where T : ProductCatalog
    {
        if (await HasCrossTenantAccess())
        {
            return true;
        }

        return productCatalog.Published;
    }

    private async Task<bool> HasCrossTenantAccess()
    {
        if (!RuntimeContext.Security.IsAuthenticated)
        {
            // Anonymous have access only to published
            return false;
        }

        try
        {
            await PlatformAuthorizationService.AuthorizeAsync(new RightObjectAuthorizationRequirement()
            {
                ApplicationCode = AuthOptions.ApplicationCode,
                RightObjectCode = RightObjects.CrossTenantStoreAccess,
                Permission = Permission.Read
            });
        }
        catch (UnauthorizedAccessByPermissionException)
        {
            return false;
        }
        return true;
    }
}
