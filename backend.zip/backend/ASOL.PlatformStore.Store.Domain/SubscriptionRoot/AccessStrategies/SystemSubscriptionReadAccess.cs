using System;
using System.Threading;
using System.Threading.Tasks;
using ASOL.Core.Identity.Authorization;
using ASOL.IdentityManager.AspNetCore.Authorization.Config;
using ASOL.PlatformStore.Store.Domain.Consts;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Extensions;
using Microsoft.Extensions.Options;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.AccessStrategies;

public class SystemSubscriptionReadAccess
(
    IPlatformAuthorizationService platformAuthorizationService,
    IOptions<AuthorizationServiceOptions> authOptions)
{
    public async Task AuthorizeAsync(CancellationToken ct)
    {
        if (!await HasReadAccessAsync(ct))
        {
            throw new UnauthorizedAccessException("You are not authorized to access system Subscription.");
        }
    }

    public Task<bool> IsAuthorizedAsync(CancellationToken ct) => HasReadAccessAsync(ct);

    private async Task<bool> HasReadAccessAsync(CancellationToken ct)
    {
        var requirement = new RightObjectAuthorizationRequirement
        {
            ApplicationCode = authOptions.Value.ApplicationCode,
            RightObjectCode = RightObjects.SystemSubscriptionReadAccess,
            Permission = Permission.Read
        };

        return await platformAuthorizationService.TryAuthorizeAsync(requirement, ct);
    }
}
