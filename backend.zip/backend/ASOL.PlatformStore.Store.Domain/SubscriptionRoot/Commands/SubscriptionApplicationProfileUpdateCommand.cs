using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionApplicationProfileUpdateCommand : Command<Subscription, SubscriptionId>
{
    public SubscriptionApplicationProfileUpdateCommand(
        SubscriptionId aggregateId,
        string updateByOrderId
    ) : base(aggregateId)
    {
        UpdateByOrderId = updateByOrderId;
    }

    /// <summary>
    /// Application profile is updated by order id.
    /// </summary>
    public string UpdateByOrderId { get; private set; }
}
