using System.Threading;
using System.Threading.Tasks;
using ASOL.PlatformStore.Store.Domain.Resources;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionApplicationProfileUpdateCommandHandler : CommandHandler<Subscription, SubscriptionId, IExecutionResult, SubscriptionApplicationProfileUpdateCommand>
{
    public override Task<IExecutionResult> ExecuteCommandAsync(Subscription aggregate, SubscriptionApplicationProfileUpdateCommand command, CancellationToken cancellationToken)
    {
        if (string.IsNullOrEmpty(command.UpdateByOrderId))
        {
            return Task.FromResult(ExecutionResult.Failed(string.Format(FailedExecutionResultMessages.InvalidOrMissingId, nameof(command.UpdateByOrderId))));
        }

        var executionResult = aggregate.Handle(command);

        return executionResult;
    }
}
