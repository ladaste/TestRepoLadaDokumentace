using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Extensions;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Interfaces;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionApplicationSolutionPartnerUpdateCommand
    : Command<Subscription, SubscriptionId, IExecutionResult>,
        ISubscriptionSolutionPartner
{
    public SubscriptionApplicationSolutionPartnerUpdateCommand(
        SubscriptionId aggregateId,
        ISubscriptionSolutionPartner organization
    )
        : base(aggregateId)
    {
        this.CopyFrom(organization);
    }

    /// <inheritdoc/>
    public string Id { get; private set; }

    /// <inheritdoc/>
    public string TenantId { get; private set; }

    /// <inheritdoc/>
    public string OrganizationRelationshipId { get; private set; }

    /// <inheritdoc/>
    public string Name { get; private set; }

    /// <inheritdoc/>
    public string Code { get; private set; }

    /// <inheritdoc/>
    public string VatIn { get; private set; }

    /// <inheritdoc/>
    public string Line1 { get; private set; }

    /// <inheritdoc/>
    public string Line2 { get; private set; }

    /// <inheritdoc/>
    public string Line3 { get; private set; }

    /// <inheritdoc/>
    public string City { get; private set; }

    /// <inheritdoc/>
    public string CountryCode { get; private set; }

    /// <inheritdoc/>
    public string ZipCode { get; private set; }

    /// <inheritdoc/>
    public string RegistryNumber { get; private set; }

    /// <inheritdoc/>
    public string HouseNumber { get; private set; }

    /// <inheritdoc/>
    public string StreetName { get; private set; }
}
