using System.Threading;
using System.Threading.Tasks;
using ASOL.PlatformStore.Store.Domain.Resources;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionApplicationSolutionPartnerUpdateCommandHandler : CommandHandler<Subscription, SubscriptionId, IExecutionResult, SubscriptionApplicationSolutionPartnerUpdateCommand>
{
    public override Task<IExecutionResult> ExecuteCommandAsync(Subscription aggregate, SubscriptionApplicationSolutionPartnerUpdateCommand command, CancellationToken cancellationToken)
    {
        if (string.IsNullOrEmpty(command.Id))
        {
            return Task.FromResult(ExecutionResult.Failed(string.Format(FailedExecutionResultMessages.InvalidOrMissingId, nameof(command.Id))));
        }

        var executionResult = aggregate.Handle(command);

        return executionResult;
    }
}
