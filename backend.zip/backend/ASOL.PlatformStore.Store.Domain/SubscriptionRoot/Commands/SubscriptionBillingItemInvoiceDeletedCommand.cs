using System;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

/// <summary>
/// Command to handle deletion of an invoice for a billing item.
/// This command is triggered when a sales invoice item is deleted.
/// </summary>
public class SubscriptionBillingItemInvoiceDeletedCommand
(
    SubscriptionId aggregateId,
    string orderNumber,
    string orderLineId,
    DateOnly? accrualDateFrom,
    DateOnly? accrualDateTo
)
    : Command<Subscription, SubscriptionId, IExecutionResult>(aggregateId)
{
    /// <summary>
    /// Order number associated with the billing item
    /// </summary>
    public string OrderNumber { get; } = orderNumber;

    /// <summary>
    /// Order line identifier
    /// </summary>
    public string OrderLineId { get; } = orderLineId;

    /// <summary>
    /// Start date of the billing period
    /// </summary>
    public DateOnly? AccrualDateFrom { get; } = accrualDateFrom;

    /// <summary>
    /// End date of the billing period
    /// </summary>
    public DateOnly? AccrualDateTo { get; } = accrualDateTo;
}
