using System.Threading;
using System.Threading.Tasks;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionBillingItemInvoiceDeletedCommandHandler
    : CommandHandler<Subscription, SubscriptionId, IExecutionResult, SubscriptionBillingItemInvoiceDeletedCommand>
{
    public override Task<IExecutionResult> ExecuteCommandAsync
    (
        Subscription aggregate,
        SubscriptionBillingItemInvoiceDeletedCommand command,
        CancellationToken cancellationToken
    )
    {
        var executionResult = aggregate.Handle(command);

        return executionResult;
    }
}
