using System;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

/// <summary>
/// Command to update subscription billing item when an invoice is generated.
/// </summary>
public class SubscriptionBillingItemInvoiceGeneratedCommand
(
    SubscriptionId aggregateId,
    string orderNumber,
    string orderLineId,
    DateOnly? accrualDateFrom,
    DateOnly? accrualDateTo
)
    : Command<Subscription, SubscriptionId, IExecutionResult>(aggregateId)
{
    /// <summary>
    /// Gets the order number.
    /// </summary>
    public string OrderNumber { get; } = orderNumber;

    /// <summary>
    /// Gets the order line ID.
    /// </summary>
    public string OrderLineId { get; } = orderLineId;

    /// <summary>
    /// Gets the start date of the billing period for the generated invoice item.
    /// </summary>
    public DateOnly? AccrualDateFrom { get; } = accrualDateFrom;

    /// <summary>
    /// Gets the end date of the billing period for the generated invoice item.
    /// </summary>
    public DateOnly? AccrualDateTo { get; } = accrualDateTo;
}
