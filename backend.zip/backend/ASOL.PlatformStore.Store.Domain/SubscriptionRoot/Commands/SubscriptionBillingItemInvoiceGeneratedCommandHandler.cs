using System.Threading;
using System.Threading.Tasks;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionBillingItemInvoiceGeneratedCommandHandler
    : CommandHandler<Subscription, SubscriptionId, IExecutionResult, SubscriptionBillingItemInvoiceGeneratedCommand>
{
    public override Task<IExecutionResult> ExecuteCommandAsync
    (
        Subscription aggregate,
        SubscriptionBillingItemInvoiceGeneratedCommand command,
        CancellationToken cancellationToken
    )
    {
        var executionResult = aggregate.Handle(command);

        return executionResult;
    }
}
