using System;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

/// <summary>
/// Command to mark a billing item as skipped (no invoice generated) and advance billing.
/// </summary>
public class SubscriptionBillingItemInvoiceSkippedCommand
(
    SubscriptionId aggregateId,
    string orderNumber,
    string orderLineId,
    DateOnly? accrualDateFrom,
    DateOnly? accrualDateTo,
    string reason
)
    : Command<Subscription, SubscriptionId, IExecutionResult>(aggregateId)
{
    public string OrderNumber { get; } = orderNumber;

    public string OrderLineId { get; } = orderLineId;

    public DateOnly? AccrualDateFrom { get; } = accrualDateFrom;

    public DateOnly? AccrualDateTo { get; } = accrualDateTo;

    public string Reason { get; } = reason;
}
