using System.Threading;
using System.Threading.Tasks;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionBillingItemInvoiceSkippedCommandHandler
    : CommandHandler<Subscription, SubscriptionId, IExecutionResult, SubscriptionBillingItemInvoiceSkippedCommand>
{
    public override Task<IExecutionResult> ExecuteCommandAsync(
        Subscription aggregate,
        SubscriptionBillingItemInvoiceSkippedCommand command,
        CancellationToken cancellationToken)
    {
        var executionResult = aggregate.Handle(command);

        return executionResult;
    }
}
