using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionBillingItemsCreateCommand(SubscriptionId aggregateId) : Command<Subscription, SubscriptionId, IExecutionResult>(aggregateId)
{
}
