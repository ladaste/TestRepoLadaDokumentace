using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionBillingItemsTerminateCommand(SubscriptionId aggregateId) : Command<Subscription, SubscriptionId, IExecutionResult>(aggregateId)
{
}
