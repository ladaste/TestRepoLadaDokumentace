using System.Collections.Generic;
using ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Extensions;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionCustomerUpdateCommand : Command<Subscription, SubscriptionId>, ISubscriptionCustomerModel
{
    public SubscriptionCustomerUpdateCommand(
        SubscriptionId aggregateId,
        ISubscriptionCustomerModel organization)
        : base(aggregateId)
    {
        this.CopyFrom(organization);
    }

    /// <inheritdoc/>
    public string Id { get; private set; }

    /// <inheritdoc/>
    public string TenantId { get; private set; }

    /// <inheritdoc/>
    public string Name { get; private set; }

    /// <inheritdoc/>
    public string Code { get; private set; }

    /// <inheritdoc/>
    public string VatIn { get; private set; }

    /// <inheritdoc/>
    public string Line1 { get; private set; }

    /// <inheritdoc/>
    public string Line2 { get; private set; }

    /// <inheritdoc/>
    public string Line3 { get; private set; }

    /// <inheritdoc/>
    public string City { get; private set; }

    /// <inheritdoc/>
    public string CountryCode { get; private set; }

    /// <inheritdoc/>
    public string ZipCode { get; private set; }

    /// <inheritdoc/>
    public string RegistryNumber { get; private set; }

    /// <inheritdoc/>
    public string HouseNumber { get; private set; }

    /// <inheritdoc/>
    public string StreetName { get; private set; }

    /// <inheritdoc/>
    public ICollection<string> InvoiceEmails { get; private set; } = [];

    /// <inheritdoc/>
    public ICollection<string> InvoicePhones { get; private set; } = [];

    /// <inheritdoc/>
    public string InvoiceLanguageCode { get; private set; }
}
