using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionDeleteUpdateCommand(
    SubscriptionId aggregateId
) : Command<Subscription, SubscriptionId>(aggregateId)
{
}
