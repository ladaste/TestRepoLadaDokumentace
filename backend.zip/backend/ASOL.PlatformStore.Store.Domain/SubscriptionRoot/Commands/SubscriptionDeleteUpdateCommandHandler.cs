using System.Threading;
using System.Threading.Tasks;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionDeleteUpdateCommandHandler : CommandHandler<Subscription, SubscriptionId, IExecutionResult,
    SubscriptionDeleteUpdateCommand>
{
    public override Task<IExecutionResult> ExecuteCommandAsync(
        Subscription aggregate,
        SubscriptionDeleteUpdateCommand command,
        CancellationToken cancellationToken)
    {
        var executionResult = aggregate.Handle(command);

        return executionResult;
    }
}
