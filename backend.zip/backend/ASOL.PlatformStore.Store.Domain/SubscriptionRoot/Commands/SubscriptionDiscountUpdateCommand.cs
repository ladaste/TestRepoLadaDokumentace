using System;
using ASOL.PlatformStore.Store.Contracts.Subscription.Interfaces;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionDiscountUpdateCommand
(
    SubscriptionId aggregateId,
    decimal? discountAmount,
    DateOnly? discountValidFrom,
    DateOnly? discountValidTo,
    string discountInternalNote
)
    : Command<Subscription, SubscriptionId, IExecutionResult>(aggregateId), ISubscriptionDiscountModel
{
    /// <inheritdoc/>
    public decimal? DiscountAmount { get; } = discountAmount;
    
    /// <inheritdoc/>
    public DateOnly? DiscountValidFrom { get; } = discountValidFrom;
    
    /// <inheritdoc/>
    public DateOnly? DiscountValidTo { get; } = discountValidTo;
    
    /// <inheritdoc/>
    public string DiscountInternalNote { get; } = discountInternalNote;
}
