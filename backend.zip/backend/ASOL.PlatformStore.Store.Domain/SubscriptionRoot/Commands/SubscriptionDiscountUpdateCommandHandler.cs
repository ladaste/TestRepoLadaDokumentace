using System.Threading;
using System.Threading.Tasks;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionDiscountUpdateCommandHandler
    : CommandHandler<Subscription, SubscriptionId, IExecutionResult, SubscriptionDiscountUpdateCommand>
{
    public override Task<IExecutionResult> ExecuteCommandAsync(
        Subscription aggregate,
        SubscriptionDiscountUpdateCommand command,
        CancellationToken cancellationToken)
    {
        aggregate.UpdateSubscriptionDiscount(
            command.DiscountAmount,
            command.DiscountValidFrom,
            command.DiscountValidTo,
            command.DiscountInternalNote);

        return Task.FromResult(ExecutionResult.Success());
    }
}
