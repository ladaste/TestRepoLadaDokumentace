using System;
using ASOL.Core.Localization;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Interfaces;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

#nullable enable

public class SubscriptionLicenseCreateCommand
(
    SubscriptionId aggregateId,
    SubscriptionLicenseId subscriptionLicenseId,
    string? orderLineId,
    string orderNumber,
    string packageCode,
    LocalizedValue<string> packageName,
    string applicationCode,
    string? editionCode,
    string subscriptionCode,
    string salesItemCode,
    string roleCode,
    DateOnly? validFrom,
    DateOnly? validTo,
    LicenseSystemStatus? status,
    int? userMaxCount
)
    : Command<Subscription, SubscriptionId, IExecutionResult>(aggregateId), IDateRangeValidatable
{
    public SubscriptionLicenseId SubscriptionLicenseId { get; } = subscriptionLicenseId;

    public string? OrderLineId { get; } = orderLineId;

    public string OrderNumber { get; } = orderNumber;

    public string PackageCode { get; } = packageCode;

    public LocalizedValue<string> PackageName { get; } = packageName;

    public string ApplicationCode { get; } = applicationCode;

    public string? EditionCode { get; } = editionCode;

    public string SubscriptionCode { get; } = subscriptionCode;

    public string SalesItemCode { get; } = salesItemCode;

    public string RoleCode { get; } = roleCode;

    public DateOnly? ValidFrom { get; } = validFrom;

    public DateOnly? ValidTo { get; } = validTo;

    public LicenseSystemStatus? Status { get; } = status;

    public int? UserMaxCount { get; } = userMaxCount;
}
