using System.Threading;
using System.Threading.Tasks;
using ASOL.PlatformStore.Store.Domain.Resources;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Validation;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionLicenseCreateCommandHandler
    : CommandHandler<Subscription, SubscriptionId, IExecutionResult, SubscriptionLicenseCreateCommand>
{
    public override Task<IExecutionResult> ExecuteCommandAsync(
        Subscription aggregate,
        SubscriptionLicenseCreateCommand command,
        CancellationToken cancellationToken)
    {
        var validation = DateRangeValidator.Validate(
            command,
            nameof(command.ValidTo),
            nameof(command.ValidFrom),
            FailedExecutionResultMessages.ValueMustBeGreaterOrEqualOtherValue
        );

        if (!validation.IsValid)
        {
            return Task.FromResult(ExecutionResult.Failed(validation.ErrorMessage!));
        }

        var executionResult = aggregate.Handle(command);

        return executionResult;
    }
}
