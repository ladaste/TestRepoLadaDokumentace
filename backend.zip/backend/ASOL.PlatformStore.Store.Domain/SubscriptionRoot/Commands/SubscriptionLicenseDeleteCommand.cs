using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionLicenseDeleteCommand
(
    SubscriptionId aggregateId,
    SubscriptionLicenseId subscriptionLicenseId
)
    : Command<Subscription, SubscriptionId, IExecutionResult>(aggregateId)
{
    public SubscriptionLicenseId SubscriptionLicenseId { get; } = subscriptionLicenseId;
}
