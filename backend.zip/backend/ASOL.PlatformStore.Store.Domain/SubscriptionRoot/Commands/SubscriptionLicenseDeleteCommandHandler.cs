using System.Threading;
using System.Threading.Tasks;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionLicenseDeleteCommandHandler
    : CommandHandler<Subscription, SubscriptionId, IExecutionResult, SubscriptionLicenseDeleteCommand>
{
    public override Task<IExecutionResult> ExecuteCommandAsync(
        Subscription aggregate,
        SubscriptionLicenseDeleteCommand command,
        CancellationToken cancellationToken)
    {
        var executionResult = aggregate.Handle(command);

        return executionResult;
    }
}
