using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Enums;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

/// <summary>
/// Command instructing the <see cref="Subscription"/> aggregate
/// to evaluate whether any of its licenses should be removed.
/// <para>
/// The evaluation is based on the order number type specified
/// in <see cref="SubscriptionOrderNumberType"/>:
/// </para>
/// <list type="bullet">
///   <item>
///     <description>
///     <see cref="SubscriptionOrderNumberType.Main"/> – uses the main valid <c>OrderNumber</c>.
///     </description>
///   </item>
///   <item>
///     <description>
///     <see cref="SubscriptionOrderNumberType.Pending"/> – uses the <c>PendingOrderNumber</c>.
///     </description>
///   </item>
/// </list>
/// <para>
/// If matching licenses are found, the aggregate emits events requesting
/// their removal.
/// </para>
/// </summary>
public class SubscriptionLicenseEvaluateForRemovalCommand
(
    SubscriptionId aggregateId,
    SubscriptionOrderNumberType orderNumberType
)
    : Command<Subscription, SubscriptionId, IExecutionResult>(aggregateId)
{
    /// <summary>
    /// Indicates which order number type to use for the evaluation.
    /// </summary>
    public SubscriptionOrderNumberType OrderNumberType { get; } = orderNumberType;
}
