using ASOL.PlatformStore.Store.Contracts;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionLicenseStatusUpdateCommand
(
    SubscriptionId aggregateId,
    SubscriptionLicenseId subscriptionLicenseId,
    LicenseSystemStatus? status
)
    : Command<Subscription, SubscriptionId>(aggregateId)
{
    public SubscriptionLicenseId SubscriptionLicenseId { get; } = subscriptionLicenseId;

    public LicenseSystemStatus? Status { get; } = status;
}
