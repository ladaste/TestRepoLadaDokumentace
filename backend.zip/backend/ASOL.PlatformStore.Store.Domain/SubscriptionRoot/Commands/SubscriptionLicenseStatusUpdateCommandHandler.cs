using System.Threading;
using System.Threading.Tasks;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionLicenseStatusUpdateCommandHandler
    : CommandHandler<Subscription, SubscriptionId, IExecutionResult, SubscriptionLicenseStatusUpdateCommand>
{
    public override Task<IExecutionResult> ExecuteCommandAsync(
        Subscription aggregate,
        SubscriptionLicenseStatusUpdateCommand command,
        CancellationToken cancellationToken)
    {
        var executionResult = aggregate.Handle(command);

        return executionResult;
    }
}
