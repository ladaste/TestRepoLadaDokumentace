using System;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionLicenseTerminateCommand
(
    SubscriptionId aggregateId,
    SubscriptionLicenseId subscriptionLicenseId,
    DateOnly terminationDate
)
    : Command<Subscription, SubscriptionId, IExecutionResult>(aggregateId)
{
    public SubscriptionLicenseId SubscriptionLicenseId { get; } = subscriptionLicenseId;

    public DateOnly TerminationDate { get; } = terminationDate;
}
