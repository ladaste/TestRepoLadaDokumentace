using System.Threading;
using System.Threading.Tasks;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionLicenseTerminateCommandHandler : CommandHandler<Subscription, SubscriptionId, IExecutionResult, SubscriptionLicenseTerminateCommand>
{
    public override Task<IExecutionResult> ExecuteCommandAsync(Subscription aggregate, SubscriptionLicenseTerminateCommand command, CancellationToken cancellationToken)
    {
        var executionResult = aggregate.Handle(command);

        return executionResult;
    }
}
