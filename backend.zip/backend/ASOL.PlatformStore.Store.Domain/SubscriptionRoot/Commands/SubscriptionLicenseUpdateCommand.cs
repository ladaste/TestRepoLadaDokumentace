using System;
using ASOL.PlatformStore.Store.Contracts;
using ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Interfaces;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

#nullable enable

public class SubscriptionLicenseUpdateCommand
(
    SubscriptionId aggregateId,
    SubscriptionLicenseId subscriptionLicenseId,
    DateOnly? validFrom,
    DateOnly? validTo,
    LicenseSystemStatus? status,
    int? userMaxCount
)
    : Command<Subscription, SubscriptionId, IExecutionResult>(aggregateId), IDateRangeValidatable
{
    public SubscriptionLicenseId SubscriptionLicenseId { get; } = subscriptionLicenseId;

    public DateOnly? ValidFrom { get; } = validFrom;

    public DateOnly? ValidTo { get; } = validTo;

    public LicenseSystemStatus? Status { get; } = status;

    public int? UserMaxCount { get; internal set; } = userMaxCount;
}
