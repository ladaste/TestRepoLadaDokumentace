using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionOrderDeleteCommand(SubscriptionId aggregateId, string orderId) : Command<Subscription, SubscriptionId, IExecutionResult>(aggregateId)
{
    public string OrderId { get; } = orderId;
}
