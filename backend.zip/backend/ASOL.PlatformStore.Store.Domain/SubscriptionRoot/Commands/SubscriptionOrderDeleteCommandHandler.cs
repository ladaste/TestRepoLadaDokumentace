using System.Threading;
using System.Threading.Tasks;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

public class SubscriptionOrderDeleteCommandHandler : CommandHandler<Subscription, SubscriptionId, IExecutionResult, SubscriptionOrderDeleteCommand>
{
    public override Task<IExecutionResult> ExecuteCommandAsync(Subscription aggregate, SubscriptionOrderDeleteCommand command, CancellationToken cancellationToken)
    {
        var executionResult = aggregate.Handle(command);

        return executionResult;
    }
}
