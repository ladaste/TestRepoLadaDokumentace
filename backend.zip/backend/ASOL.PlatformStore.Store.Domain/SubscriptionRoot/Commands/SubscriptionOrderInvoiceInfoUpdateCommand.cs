using System;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace ASOL.PlatformStore.Store.Domain.SubscriptionRoot.Commands;

/// <summary>
/// Command to update invoice information for a subscription order.
/// This command is triggered when the latest sales invoice item changes.
/// </summary>
public class SubscriptionOrderInvoiceInfoUpdateCommand
(
    SubscriptionId aggregateId,
    string orderNumber,
    string orderLineId,
    DateTime? latestInvoiceVatDate,
    DateTime? latestInvoiceAccrualDateFrom,
    DateTime? latestInvoiceAccrualDateTo,
    int? orderInvoiceCount,
    DateTime? orderFirstInvoiceVatDate,
    DateTime? orderLastInvoiceVatDate
)
    : Command<Subscription, SubscriptionId, IExecutionResult>(aggregateId)
{

    /// <summary>
    /// Order number
    /// </summary>
    public string OrderNumber { get; } = orderNumber;

    /// <summary>
    /// Order line identifier
    /// </summary>
    public string OrderLineId { get; } = orderLineId;

    /// <summary>
    /// Date of the last approved invoice (DUZP) – VatDate
    /// </summary>
    public DateTime? LatestInvoiceVatDate { get; } = latestInvoiceVatDate;

    /// <summary>
    /// Period of the last approved invoice – AccrualDateFrom
    /// </summary>
    public DateTime? LatestInvoiceAccrualDateFrom { get; } = latestInvoiceAccrualDateFrom;

    /// <summary>
    /// Period of the last approved invoice – AccrualDateTo
    /// </summary>
    public DateTime? LatestInvoiceAccrualDateTo { get; } = latestInvoiceAccrualDateTo;

    /// <summary>
    /// Total number of invoices for this order
    /// </summary>
    public int? OrderInvoiceCount { get; } = orderInvoiceCount;

    /// <summary>
    /// Date of the first invoice for this order
    /// </summary>
    public DateTime? OrderFirstInvoiceVatDate { get; } = orderFirstInvoiceVatDate;

    /// <summary>
    /// Date of the last invoice for this order
    /// </summary>
    public DateTime? OrderLastInvoiceVatDate { get; } = orderLastInvoiceVatDate;
}
