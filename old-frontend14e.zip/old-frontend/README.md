# Order
## Changelog
## v14.1.4
- split SalesRep role for backward compatiblity with FE and BE application code consistency
## v14.1.3
- Consolidate ui role authorization metadata and ui authorization definition for all FE order versions. It's moved from "portal" FE. Because it's not allowed multiple files with same definition ASOLEU-PlatformStoreOrder-AP- and featureCode UIRoleAuthorization or UIAuthorization. Portal and order was overwrite same part of FE Order. Only one definition exists and depends on last deployed FE (order or portal). This commit break this bug.
## v14.1.2
- revert roles.json to the latest valid version, setup obsolete roles for obsolete application code [APL-2089]
## v14.1.1
- changed application code [APL-2089]
## v14.1.0
- renamed environments nqa -> alpha [APL-1776], rca -> beta [APL-1789]
## v14.0.50
-  fixed order statuses in order list [AB-462]
## v14.0.49
-  removed permissions as it was implemented in Private Portal (AB-419)
## v14.0.48
-  added permissions (AB-419)
## v14.0.47
-  fixed filtering for Order list (avas-4836)
## v14.0.46
-  revert permission changes for PP.TenantSolutionPartnerAdmin (avas-4148)
## v14.0.45
-  added permission for PP.CustomerEditor and PP.TenantSolutionPartnerAdmin (avas-4148)
## v14.0.44
-  all purchased optimalization [AVAS-3862]
## v14.0.43
-  fix responsive design for dialog button in customer, organization... by update store library [AVAS-3933]
## v14.0.42
-  fix for created on in order [AVAS-3250]
## v14.0.41
-  fixed last updated in list and detail order [AVAS-3541]
## v14.0.40
-  fixed created on date in list [AVAS-3250]
## v14.0.39
-  added asol-date pipe, fixed dates, added new column last updated [AVAS-3541]
## v14.0.38
-  fix translation [AVAS-3001]
## v14.0.37
- fix for creating nonstandard order (dic, adress) prefill [AVAS-3358]
## v14.0.36
- fix update status [AVAS-3239]
## v14.0.35
- fields name, email vat, and adress is enabled for nonstandar order  [AVAS-3359]
## v14.0.34
- fix for loading order list table from detail [AVAS-2727]
## v14.0.33
- date when customer accepted order in order detail fix [AVAS-2312]
## v14.0.32
- fix unvalid checkbox in order summary[AVAS-3118]
## v14.0.31
- fix for sidemenu.authorization code fail and note fix [AVAS-3224] [AVAS-3052]
## v14.0.30
- fix create date for nonstandardorder [AVAS-2312]
## v14.0.29
- fix for CustomOrder popup [AVAS-2951]
## v14.0.28
- vat is not more required in order [AVAS-2661]
## v14.0.27
- fixed date format issue [AVAS-2595]
## v14.0.26
- fixed VAT validation [AVAS-2661]
## v14.0.25
- added adress control [AVAS-2776]
## v14.0.24
- allowed to add custom order VAT if missing  [AVAS-2661]
## v14.0.23
- fixed validation if no phone or email is loaded from customer [AVAS-2540]
## v14.0.22
- fixed mobile version of padding for vertical stepper [AVAS-2540]
## v14.0.21
- fixed contactTypePhone problem [AVAS-2578]
## v14.0.20
- update asol-controls version in package and import directive module for vertical scroller [AVAS-2540]
## v14.0.19
- fixed guard permission routing for Sales Rep and StoreBuyer [AVAS-2304]
## v14.0.18
- sales rep editor logic permission for non standard order [AVAS-2304]
## v14.0.17
- changed header level of the OrderRecapitulation [AVAS-2444]
## v14.0.16
- add important information to custom order form [AVAS-2211]
## v14.0.15
- fixed misstake content-panel [AVAS-2433]
## v14.0.14
- added design adjustments for mobile version, and added vertical stepper for mobile version [AVAS-2433] [AVAS-2434]
## v14.0.13
- prepared for tenant impersonation - avas-2436

## v14.0.12
- provided customer order detail component via MF for private portal - avas-2339

## v14.0.11
- added store lib provider to the orders list module

## v14.0.10
- updated translations form funtions to pipelines
- orders can be now marked as testing - avas-2135

## v14.0.9
- removed duplicit imports 

## v14.0.8
- fixed translations in the order-summary - avas-2298
- fixed displaying of confirmation dialog - avas-2300

## v14.0.7
- fixing MF

## v14.0.6
- fixed roles importing

## v14.0.5
- fixed legal documents downloading - avas-2146

## v14.0.4
Orders-list changes:
(AVAS-2136) - added column with system status
(AVAS-1867) - changed date (from modified to created)
(AVAS-1791) - added columns to the export table

## 14.0.3
- fixed route for the orders list 

## 14.0.2
- updated provided modules - only one OrderModule is provided (which every app should use)
- prepared for new routing

## 14.0.1
- copied modules from the store library and the product app.

## 14.0.0
- prepared simple application

