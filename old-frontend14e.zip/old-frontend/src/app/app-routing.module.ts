import { loadRemoteModule } from '@angular-architects/module-federation';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AsolAuthGuard } from '@asol-platform/authentication';
import { AsolPlatformAppRoutingModule } from '@asol-platform/common';
import packageInfo from '../../package.json';
import { environment } from '../environments/environment';

const routes: Routes = [
  {
    path: 'orders',
    loadChildren: () =>
      import('./modules/orders-list/orders-list.module').then(
        (m) => m.OrdersListModule
      ),
  },

  {
    path: 'licensing',
    data: {
      canAddRoot: false,
      appCode: packageInfo.name,
      skipPermission: true,
    },
    loadChildren: () => {
      return loadRemoteModule({
        type: 'module',
        remoteEntry: `${environment.idmAppUrl}/remoteEntry.js`,
        exposedModule: './Licencing',
      }).then((m) => m.LicensingModule);
    },
  },
];

const baseRoutes: Routes = [
  {
    path: 'order/create',
    loadChildren: () =>
      import('./modules/order-form/order-form.module').then(
        (m) => m.OrderFormModule
      ),
  },
  {
    path: 'order/summary',
    loadChildren: () =>
      import('./modules/order-summary/order-summary.module').then(
        (m) => m.OrderSummaryModule
      ),
    canActivate: [AsolAuthGuard],
    data: {
      hideSidemenu: {
        desktop: true,
      },
      permissionAppCode: 'ASOLEU-PlatformStoreOrder-AP-',
      permissionPageCode: 'store-lib-non-standard-order-confirmation',
      isSharedPage: true,
    },
  },
];

@NgModule({
  imports: [
    AsolPlatformAppRoutingModule.forRoot(routes),
    RouterModule.forRoot(baseRoutes),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
