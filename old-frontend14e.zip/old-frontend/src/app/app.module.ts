import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouteReuseStrategy } from '@angular/router';
import { RECAPTCHA_V3_SITE_KEY } from 'ng-recaptcha';

import { AsolPlatformAuthenticationModule } from '@asol-platform/authentication';
import {
  AsolPlatformAppComponent,
  AsolPlatformCommonModule,
  AsolPlatformLibConfiguration,
  AsolPlatformLibConfigurationProvider,
} from '@asol-platform/common';
import { AsolPlatformControlsModule } from '@asol-platform/controls';
import {
  AsolCachingReusingStrategy,
  AsolLocalizeModule,
  AsolPlatformCoreModule,
} from '@asol-platform/core';
import { AsolPlatformGuidanceModule } from '@asol-platform/guidance';
import { AsolPlatformServicesModule } from '@asol-platform/services';
import { AsolPlatformStoreModule } from '@asol-platform/store';

import packageInfo from '../../package.json';
import { environment } from '../environments/environment';
import { AppRoutingModule } from './app-routing.module';
import { ConfigFromApp } from './shared/menu/menu.config';
import { MaterialModule } from './shared/modules/material.module';

const menuDebug: AsolPlatformLibConfiguration = {
  config: {
    provide: AsolPlatformLibConfigurationProvider,
    useClass: ConfigFromApp,
  },
};

@NgModule({
  declarations: [],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    MaterialModule,
    AsolPlatformControlsModule,
    AsolLocalizeModule,
    AsolPlatformCoreModule.forRoot(packageInfo.name),
    AsolPlatformCommonModule.forRoot(
      {
        identityManagerUrl: environment.identityManagerUrl,
        widgetManagementUrl: environment.widgetManagementUrl,
        widgetStoreUrl: environment.widgetStoreUrl,
        platformStorePdmUrl: environment.platformStorePdmUrl,
        platformStoreStoreUrl: environment.platformStoreStoreUrl,
        platformStoreOrderUrl: environment.platformStoreOrderUrl,
        messageProviderUrl: environment.messageProviderUrl,
        notificationAppUrl: environment.notificationAppUrl,
        connectorAppUrl: environment.connectorAppUrl,
        connectorUrl: environment.connectorUrl,
        domainCatalogUrl: environment.domainCatalogUrl,
        communityUrl: environment.communityUrl,
        contentManagerUrl: environment.contentManagerUrl,
        subjectManagerUrl: environment.subjectManagementUrl,
        hcmUrl: environment.hcmUrl,
        version: packageInfo.version,
      },
      menuDebug
    ),
    AsolPlatformGuidanceModule.forRoot({
      guidanceUrl: environment.guidanceUrl,
      rootAppElement: 'ASOL-PLATFORM-APP',
    }),
    AsolPlatformStoreModule.forRoot({
      contentManagerUrl: environment.contentManagerUrl,
      storeApiUrl: environment.platformStoreStoreUrl,
      customAttributesUrl: environment.customAttributesUrl,
      storeOrderUrl: environment.platformStoreOrderUrl,
      identityManagerUrl: environment.identityManagerUrl,
      portalUrl: environment.portalUrl,
      productUrl: environment.productUrl,
    }),
    AsolPlatformServicesModule.forRoot({
      subjectManagementUrl: environment.subjectManagementUrl,
      contentManagerUrl: environment.contentManagerUrl,
      platformStorePdmUrl: environment.platformStorePdmUrl,
      identityManagerUrl: environment.identityManagerUrl,
      telemetryConfig: {
        instrumentationKey: environment.telemetryKey,
        endPointUrl: environment.telemetryUrl,
        apiVersion: '1.0',
        serviceName: packageInfo.name,
        serviceVersion: '1.0',
      },
    }),
    AsolPlatformAuthenticationModule.forRoot({
      subjectManagerUrl: environment.subjectManagementUrl,
      identityServerUrl: environment.identityServerUrl,
      identityManagerUrl: environment.identityManagerUrl,
      portalUrl: environment.portalUrl,
      packageInfo: packageInfo,
    }),
  ],
  providers: [
    {
      provide: RECAPTCHA_V3_SITE_KEY,
      useValue: environment.captchaKey,
    },
    { provide: RouteReuseStrategy, useClass: AsolCachingReusingStrategy },
  ],
  bootstrap: [AsolPlatformAppComponent],
})
export class AppModule {}
