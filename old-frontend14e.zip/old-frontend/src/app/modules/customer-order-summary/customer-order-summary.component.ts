import { Component } from '@angular/core';
import { AsolImpersonationOptions } from '@asol-platform/services';
import { AsolOrderAccessType, OrderResponse } from '@asol-platform/store';
import { finalize } from 'rxjs';
import { SharedModule } from '../../shared/modules/shared.module';
import { StoreLibProviderModule } from '../../shared/modules/store-lib-provider.module';
import { OrderSummaryData } from '../order-detail-data/models/order-summary-data.interface';
import { OrderDetailDataModule } from '../order-detail-data/order-detail-data.module';
import { CustomerOrderSummaryService } from './services/customer-order-summary.service';

@Component({
  selector: 'app-customer-order-summary',
  templateUrl: './customer-order-summary.component.html',
  standalone: true,
  imports: [SharedModule, OrderDetailDataModule, StoreLibProviderModule],
  providers: [CustomerOrderSummaryService],
})
export class CustomerOrderSummaryComponent {
  protected loading = false;
  protected orderResponse: OrderResponse<OrderSummaryData> | undefined;

  private orderNumber: string | undefined;

  constructor(private summaryService: CustomerOrderSummaryService) {}

  /**
   * set order number and get order from the BE
   * @param orderNumber - number of the order
   */
  setOrderNumber(
    orderNumber: string | undefined,
    impersonation?: AsolImpersonationOptions
  ): void {
    if (!orderNumber) {
      this.orderResponse = undefined;
      this.orderNumber = undefined;
      return;
    }
    this.orderNumber = orderNumber;
    this.loading = true;
    this.summaryService
      .getOrderByOrderNumber(
        this.orderNumber,
        AsolOrderAccessType.Customer,
        impersonation
      )
      .pipe(
        finalize(() => {
          this.loading = false;
        })
      )
      .subscribe({
        next: (response) => {
          this.orderResponse = response;
        },
      });
  }
}
