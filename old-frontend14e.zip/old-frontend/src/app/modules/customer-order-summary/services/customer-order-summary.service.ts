import { Injectable } from '@angular/core';
import {
  AsolApiDataService,
  AsolImpersonationOptions,
} from '@asol-platform/services';
import { AsolOrderAccessType, OrderResponse } from '@asol-platform/store';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { OrderSummaryData } from '../../order-detail-data/models/order-summary-data.interface';

@Injectable()
export class CustomerOrderSummaryService {
  constructor(private apiDataService: AsolApiDataService) {}

  /**
   * get order by id
   * @param id id of the order
   * @param type type of access (supplier / customer)
   * @returns order from the BE
   */
  getOrderByOrderNumber(
    orderNumber: string,
    type: AsolOrderAccessType = AsolOrderAccessType.Customer,
    impersonation?: AsolImpersonationOptions
  ): Observable<OrderResponse<OrderSummaryData>> {
    return this.apiDataService.getOne(
      `${environment.platformStoreOrderUrl}/api/v1/Order/OrderNumber/${orderNumber}`,
      { orderAccessType: AsolOrderAccessType[type] },
      undefined,
      impersonation
    );
  }
}
