import { Component, Input } from '@angular/core';
import { FormRecord } from '@angular/forms';
import { OS_SECTION_VAL_CODE } from '../../constants/order-summary-section-value-code.constant';
import { OSSectionContent } from '../../models/order-summary-section-content.interface';

@Component({
  selector: 'asol-platform-checkboxes-box',
  templateUrl: './checkboxes-box.component.html',
  styleUrls: ['./checkboxes-box.component.scss'],
})
export class CheckboxesBoxComponent {
  protected OS_SECTION_VAL_CODE = OS_SECTION_VAL_CODE;

  /** formGroup of the with the checkboxes formControls */
  @Input() formGroup: FormRecord | undefined;
  /** data to display checkboxes */
  @Input() checkboxes: OSSectionContent[] = [];
  /** error which should be displayed (when in error state) */
  @Input() error: string | undefined;
}
