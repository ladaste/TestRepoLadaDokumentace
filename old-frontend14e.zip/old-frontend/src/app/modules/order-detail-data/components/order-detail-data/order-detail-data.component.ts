import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges,
} from '@angular/core';
import { FormControl, FormRecord, Validators } from '@angular/forms';
import {
  AsolLocalizationService,
  AsolTranslationService,
} from '@asol-platform/core';
import { OrderResponse } from '@asol-platform/store';
import { Subscription } from 'rxjs';
import { TRANS } from '../../../../shared/constants/localization.constant';
import { OS_SECTION_TYPE } from '../../constants/order-summary-section-type.const';
import { OSSectionType } from '../../constants/order-summary-section-type.enum';
import { OS_SECTION_VAL_CODE } from '../../constants/order-summary-section-value-code.constant';
import { OS_SECTION_VALUE_TYPES } from '../../constants/order-summary-section-value-type.const';
import { OSSectionValueType } from '../../constants/order-summary-section-value-type.enum';
import { TemplateVersion } from '../../constants/template-version.enum';
import { CheckboxEvent } from '../../models/checkbox-event.interface';
import { DocumentEvent } from '../../models/document-event.interface';
import { OrderSummaryData } from '../../models/order-summary-data.interface';
import { OSSectionContent } from '../../models/order-summary-section-content.interface';
import { OrderSummarySection } from '../../models/order-summary-section.interface';
import translation from './order-detail-data.translation.json';

@Component({
  selector: 'asol-platform-order-detail-data',
  templateUrl: './order-detail-data.component.html',
})
export class OrderDetailDataComponent implements OnChanges, OnDestroy {
  protected readonly TRANS = TRANS;
  protected readonly TemplateVersion = TemplateVersion;

  /**
   * Summary data of the order. Same data that are displayed in the PDF
   */
  @Input() orderDetails: OrderResponse<OrderSummaryData> | undefined;
  /**
   * Information about checkboxes. When false, user can interact with them.
   * Otherwise they are disabled
   */
  @Input() isCheckboxDisabled = false;
  /**
   * When set to true, bottom part of the screen is disabled.
   */
  @Input() isLegalSectionDisabled = false;
  /**
   * when true, error should be displayed under the checkbox. (if there is an error)
   */
  @Input() displayCheckboxRequiredError = false;
  /**
   * Whether to allow LG breakpoints -> two sections (customer and supplier) in one row.
   */
  @Input() allowLGBreakPoints = true;

  /** Whether to dispaly header or not */
  @Input() displayHeader = true;

  /** id of the order (for getting documents) */
  @Input() orderId: string | undefined;

  /**
   * information about change in the checkbox form
   * current value and valid state is returned
   */
  @Output() checkboxesChanged = new EventEmitter<CheckboxEvent>();

  /**
   * Emits event when document should be opened. If there is an order ID, this component opens it by itself.
   * However, when order ID is missing, custom function should be used.
   */
  @Output() documentClicked = new EventEmitter<DocumentEvent>();

  protected templateVersion = TemplateVersion.Three;

  protected orderSummary: OrderSummaryData | undefined;

  protected checkboxes: OSSectionContent[] = [];
  protected formGroup = new FormRecord({});
  private formSub?: Subscription;

  constructor(
    protected trans: AsolTranslationService,
    protected loc: AsolLocalizationService
  ) {
    this.trans.initialize(TRANS.ORDER_DETAIL_DATA_COMMON, translation);
  }

  ngOnDestroy(): void {
    this.checkboxesChanged.emit({
      value: {},
      isValid: false,
    });
    this.formSub?.unsubscribe();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.orderDetails && this.orderDetails) {
      if (this.orderDetails.orderData) {
        this.templateVersion = TemplateVersion.One;
        try {
          this.orderSummary = JSON.parse(this.orderDetails.orderData);
        } catch {
          this.orderSummary = undefined;
        }
      } else {
        this.templateVersion =
          this.orderDetails.orderSummary?.version === 2
            ? TemplateVersion.Three
            : TemplateVersion.Two;

        this.orderSummary = this.orderDetails.orderSummary;
        if (this.orderSummary) {
          this.orderSummary.nonStandardStatusInfo = {
            systemStatus:
              this.orderDetails?.nonStandardStatusInfo?.systemStatus ?? '',
            modifiedOn:
              this.orderDetails?.nonStandardStatusInfo?.modifiedOn ?? '',
            modifiedBy:
              this.orderDetails?.nonStandardStatusInfo?.modifiedBy ?? '',
          };
        }
      }
      this.initializeCheckboxes();
    }
  }

  /**
   * when document event occurs in the children templates, emit it further
   * @param event Document event emitted.
   */
  protected onDocumentClicked(event: DocumentEvent): void {
    this.documentClicked.emit(event);
  }

  /**
   * initialization of the legal documents section
   */
  private initializeCheckboxes() {
    if (!this.orderSummary) {
      return;
    }
    const section = this.orderSummary.orderSections.find((section) =>
      this.isSectionOfDocuments(section)
    );
    if (!section) {
      return;
    }
    this.checkboxes = section.sectionContent.filter((content) =>
      this.isValueTypeCheckbox(content)
    );

    this.checkboxes.forEach((check) => {
      const control = new FormControl(
        this.isCheckboxDisabled && check.value === 'True',
        check.orderSectionValueCode ===
        OS_SECTION_VAL_CODE.CUSTOMER_CONSENT.CHECKBOX_1
          ? [Validators.requiredTrue]
          : null
      );

      check.valueControl = control;

      this.formGroup?.addControl(check.orderSectionValueCode, control);
    });

    if (this.isCheckboxDisabled) {
      this.formGroup.disable();
    } else {
      this.formSub = this.formGroup.valueChanges.subscribe((change) => {
        this.checkboxesChanged.emit({
          value: change,
          isValid: this.formGroup.valid,
        });
      });
    }
  }

  /**
   * Function which checks section type.
   * In older versions, when orderData were stringified, type was of enum type -> number (0-6)
   * In newer versions, BE returns type's string version.
   * And because of that, it is necessary to know which template version we are checking
   * @param section Section to check.
   * @returns If section type is Legal documents, return true. Otherwise false.
   */
  private isSectionOfDocuments(section: OrderSummarySection): boolean {
    if (this.templateVersion === TemplateVersion.One) {
      return section.orderSectionType === OSSectionType.LegalDocuments;
    }

    return section.orderSectionType === OS_SECTION_TYPE.LEGAL_DOC;
  }

  /**
   * Function which checks section content type.
   * Same rule as for {@link isSectionOfDocuments()}
   * @param content section content to be checked
   * @returns If section content type is checkbox, return true. Otherwise false.
   */
  private isValueTypeCheckbox(content: OSSectionContent) {
    if (this.templateVersion === TemplateVersion.One) {
      return content.orderSectionValueType === OSSectionValueType.Checkbox;
    }

    return content.orderSectionValueType === OS_SECTION_VALUE_TYPES.CHECKBOX;
  }
}
