import { Component, inject, Input, OnInit } from '@angular/core';
import { AsolLoaderService } from '@asol-platform/controls';
import {
  AsolStoreAppDetail,
  AsolStoreAppDetailService,
  BILLING_PERIOD,
} from '@asol-platform/store';
import { finalize } from 'rxjs';
import { AdditionalLegalDocuments } from '../../../../shared/models/additional-legal-documents.interface';
import { PriceSectionData } from '../../../order-summary/constants/price-section-data.interface';
import { OS_SECTION_CODE } from '../../constants/order-summary-section-code.constant';
import { OSSectionType } from '../../constants/order-summary-section-type.enum';
import { OS_SECTION_VAL_CODE } from '../../constants/order-summary-section-value-code.constant';
import { OSSectionValueType } from '../../constants/order-summary-section-value-type.enum';
import { OrderDetailBaseDirective } from '../../directive/order-detail-base.directive';
import { versionOneSortOrderSections } from '../../functions/version-one-sort-order-sections';
import { OrderSummarySection } from '../../models/order-summary-section.interface';
import translation from './version-one.translation.json';

/**
 * Component to display order detail data.
 * Used for orders when Licences are used and when orderSummary was stringified in the orderData property.
 * Newly created orders (with calculation in the subscriptions) should not used this component
 */
@Component({
  selector: 'asol-platform-version-one',
  templateUrl: './version-one.component.html',
  styleUrls: ['./version-one.component.scss'],
  providers: [AsolStoreAppDetailService],
})
export class VersionOneComponent
  extends OrderDetailBaseDirective
  implements OnInit
{
  protected BILLING_PERIOD = BILLING_PERIOD;
  protected OSSectionType = OSSectionType;
  protected OSSectionValueType = OSSectionValueType;

  private detailProvider = inject(AsolStoreAppDetailService);
  private loader = inject(AsolLoaderService);

  /** Whether the order is not standard. */
  @Input() isNonStandard = false;

  /** detail of the app which was bought */
  protected appDetail: AsolStoreAppDetail | undefined;
  /** price details */
  protected priceData: PriceSectionData | undefined = undefined;
  /** details for the custom price */
  protected customPriceSection?: OrderSummarySection;
  /** additional legal documents */
  protected additionalDocuments?: AdditionalLegalDocuments[];

  ngOnInit() {
    this.trans.initialize(
      this.TRANS.ORDER_DETAIL_DATA_VERSION_ONE,
      translation
    );

    this.orderSummary.orderSections = versionOneSortOrderSections(
      this.orderSummary
    );

    this.initializePriceSection();

    this.initializeLegalDocuments();

    this.loadAppDetail();
  }

  /**
   * load app detail for the order header.
   */
  private loadAppDetail(): void {
    this.loader.start();
    this.detailProvider
      .getAppDetail(this.orderSummary.productId)
      .pipe(
        finalize(() => {
          this.loader.stop();
        })
      )
      .subscribe((response) => {
        this.appDetail = response;
      });
  }

  /**
   * initialization of the price section
   */
  private initializePriceSection() {
    const priceSection = this.orderSummary.orderSections.find(
      (section) => section.orderSectionType === OSSectionType.Price
    );

    if (this.orderSummary.isCustomPricing === 'True') {
      this.customPriceSection = this.orderSummary.orderSections.find(
        (s) => s.orderSectionCode === OS_SECTION_CODE.CUSTOM_PRICE
      );
    }

    if (!priceSection) {
      return;
    }
    this.priceData = {
      price: priceSection.sectionContent.find(
        (content) =>
          content.orderSectionValueCode ===
          OS_SECTION_VAL_CODE.PRICE.TOTAL_PRICE
      )?.value,
      period: priceSection.sectionContent.find(
        (content) =>
          content.orderSectionValueCode === OS_SECTION_VAL_CODE.PRICE.PERIOD
      )?.value,
      firstLine: priceSection.sectionContent.find(
        (content) =>
          content.orderSectionValueCode === OS_SECTION_VAL_CODE.PRICE.TEXT
      )?.value,
      finalInfo: priceSection.sectionContent.find(
        (content) =>
          content.orderSectionValueCode === OS_SECTION_VAL_CODE.PRICE.FINAL_TEXT
      )?.value,
    };
    const bal = priceSection.sectionContent.find(
      (content) =>
        content.orderSectionValueCode === OS_SECTION_VAL_CODE.PRICE.BALANCE
    );
    const prevPrice = priceSection.sectionContent.find(
      (content) =>
        content.orderSectionValueCode ===
        OS_SECTION_VAL_CODE.PRICE.PREVIOUS_PRICE
    );
    this.priceData.balance = bal?.value;
    this.priceData.balanceText = bal?.name ? bal.name : '';

    this.priceData.previousPrice = prevPrice?.value;
    this.priceData.previousPriceText = prevPrice?.name ? prevPrice.name : '';

    if (this.orderSummary?.previousOrderId) {
      this.priceData.changedOrder = true;
    }
  }

  /**
   * when there are additional documents, parse its value, so we can display it.
   */
  private initializeLegalDocuments() {
    const section = this.orderSummary.orderSections.find(
      (section) => section.orderSectionType === OSSectionType.LegalDocuments
    );
    if (!section) {
      return;
    }
    const additionalDocuments = section.sectionContent.find(
      (content) =>
        content.orderSectionValueCode ===
        OS_SECTION_VAL_CODE.CUSTOMER_CONSENT.ADDITIONAL_DOCUMENTS
    );
    if (additionalDocuments && additionalDocuments.value) {
      this.additionalDocuments = JSON.parse(additionalDocuments.value);
    }
  }
}
