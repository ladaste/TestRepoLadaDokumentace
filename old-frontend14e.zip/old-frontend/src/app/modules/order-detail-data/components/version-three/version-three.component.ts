import { Component, Input, OnInit } from '@angular/core';
import { AdditionalLegalDocuments } from '../../../../shared/models/additional-legal-documents.interface';
import { OS_SECTION_TYPE } from '../../constants/order-summary-section-type.const';
import { OS_SECTION_VAL_CODE } from '../../constants/order-summary-section-value-code.constant';
import { OS_SECTION_VALUE_TYPES } from '../../constants/order-summary-section-value-type.const';
import { OrderDetailBaseDirective } from '../../directive/order-detail-base.directive';
import translation from './version-three.translation.json';

@Component({
  selector: 'asol-platform-version-three',
  templateUrl: './version-three.component.html',
  styleUrls: ['../../styles/common-styles.scss'],
})
export class VersionThreeComponent
  extends OrderDetailBaseDirective
  implements OnInit
{
  protected OS_SECTION_TYPE = OS_SECTION_TYPE;
  protected OS_SECTION_VALUE_TYPES = OS_SECTION_VALUE_TYPES;

  protected additionalDocuments?: AdditionalLegalDocuments[];

  /**
   * whether display should be displayed.
   * for 3rd tab of the order there is custom header.
   */
  @Input() displayHeader = true;

  ngOnInit() {
    this.trans.initialize(
      this.TRANS.ORDER_DETAIL_DATA_VERSION_THREE,
      translation
    );
    this.initializeLegalDocuments();
    this.initializePaymentsTable();
  }

  /**
   * initialization of the legal documents section
   */
  private initializeLegalDocuments() {
    const section = this.orderSummary.orderSections.find(
      (section) => section.orderSectionType === OS_SECTION_TYPE.LEGAL_DOC
    );
    if (!section) {
      return;
    }

    const additionalDocuments = section.sectionContent.find(
      (content) =>
        content.orderSectionValueCode ===
        OS_SECTION_VAL_CODE.CUSTOMER_CONSENT.ADDITIONAL_DOCUMENTS
    );
    if (additionalDocuments && additionalDocuments.value) {
      this.additionalDocuments = JSON.parse(additionalDocuments.value);
    }
  }

  /**
   * Prepare payment table sections for the display.
   * There has are cells which should be divided into rows by breaks.
   */
  private initializePaymentsTable() {
    const paymentSections = this.orderSummary.orderSections.filter(
      (section) =>
        section.orderSectionType === OS_SECTION_TYPE.PAYMENTS ||
        section.orderSectionType === OS_SECTION_TYPE.PAYMENTS_TABLE
    );

    paymentSections.forEach((ps) => {
      const contents = ps.sectionContent.filter(
        (sc) =>
          sc.orderSectionValueType === OS_SECTION_VALUE_TYPES.CELL ||
          sc.orderSectionValueType === OS_SECTION_VALUE_TYPES.BREAK
      );

      if (contents.length === 0) {
        return;
      }
      ps.tableRow = [[]];
      let currentIndex = 0;
      contents.forEach((c) => {
        if (!ps.tableRow) {
          return;
        }
        if (c.orderSectionValueType === OS_SECTION_VALUE_TYPES.BREAK) {
          currentIndex++;
          return;
        }
        if (currentIndex === ps.tableRow.length) {
          ps.tableRow.push([]);
        }
        ps.tableRow[currentIndex].push(c);
      });
    });
  }
}
