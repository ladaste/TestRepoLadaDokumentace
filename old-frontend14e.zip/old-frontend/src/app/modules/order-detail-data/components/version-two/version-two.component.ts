import { Component, OnInit } from '@angular/core';
import { AdditionalLegalDocuments } from '../../../../shared/models/additional-legal-documents.interface';
import { OS_SECTION_TYPE } from '../../constants/order-summary-section-type.const';
import { OS_SECTION_VAL_CODE } from '../../constants/order-summary-section-value-code.constant';
import { OS_SECTION_VALUE_TYPES } from '../../constants/order-summary-section-value-type.const';
import { OrderDetailBaseDirective } from '../../directive/order-detail-base.directive';
import translation from './version-two.translation.json';

/**
 * Component to display order detail data.
 * Used for orders, which has data in the order-summary property (not stringified, but in JSON).
 */
@Component({
  selector: 'asol-platform-version-two',
  templateUrl: './version-two.component.html',
  styleUrls: ['../../styles/common-styles.scss'],
})
export class VersionTwoComponent
  extends OrderDetailBaseDirective
  implements OnInit
{
  protected OS_SECTION_TYPE = OS_SECTION_TYPE;
  protected OS_SECTION_VALUE_TYPES = OS_SECTION_VALUE_TYPES;

  protected additionalDocuments?: AdditionalLegalDocuments[];

  ngOnInit() {
    this.trans.initialize(
      this.TRANS.ORDER_DETAIL_DATA_VERSION_TWO,
      translation
    );
    this.initializeLegalDocuments();
  }

  /**
   * initialization of the legal documents section
   */
  private initializeLegalDocuments() {
    const section = this.orderSummary.orderSections.find(
      (section) => section.orderSectionType === OS_SECTION_TYPE.LEGAL_DOC
    );
    if (!section) {
      return;
    }
    const additionalDocuments = section.sectionContent.find(
      (content) =>
        content.orderSectionValueCode ===
        OS_SECTION_VAL_CODE.CUSTOMER_CONSENT.ADDITIONAL_DOCUMENTS
    );
    if (additionalDocuments && additionalDocuments.value) {
      this.additionalDocuments = JSON.parse(additionalDocuments.value);
    }
  }
}
