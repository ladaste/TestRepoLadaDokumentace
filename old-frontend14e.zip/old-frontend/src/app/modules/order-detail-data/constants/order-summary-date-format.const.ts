export const ORDER_SUMMARY_DATE_FORMAT = 'dd.MM.yyyy';
