export const OS_SECTION_CODE = {
  SUPPLIER: 'supplier',
  CUSTOMER: 'customer',
  PRICE: 'price',
  CUSTOM_PRICE: 'custom-price',
  ORDER_DETAILS: 'orderDetails',
  CUSTOMER_CONSENT: 'customerConsent',

  EDITIONS: 'editionAndApplicationDetails',
  EXTENSIONS: 'extensionsDetails',
  YEARLY: 'yearlyPayments',
  MONTHLY: 'monthlyPayments',
  ONE_TIME: 'oneTimePayments',

  EXTENSION_TABLE: 'extensionsPayments',
  EDITION_TABLE: 'editionAndApplicationPayments',
  TAX_INFO: 'vatTaxInfo',

  MORE_AGGREMENTS: 'moreAgreements',
};
