export const OS_SECTION_TYPE = {
  SUPPLIER: 'Supplier',
  CUSTOMER: 'Customer',
  PAYMENTS: 'Payments',
  ORDER_SPEC: 'OrderSpecifications',
  LEGAL_DOC: 'LegalDocuments',
  CUSTOM: 'Custom',
  PAYMENTS_TABLE: 'PaymentsTable',
};
