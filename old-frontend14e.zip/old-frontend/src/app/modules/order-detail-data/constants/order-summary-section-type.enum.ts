export enum OSSectionType {
  Supplier = 1,
  Customer,
  Price,
  OrderSpecifications,
  LegalDocuments,
  Custom,
}
