export const OS_SECTION_VALUE_TYPES = {
  TEXT: 'Text',
  KEY_VAL: 'KeyValue',
  CHECKBOX: 'Checkbox',
  BREAK: 'Break',
  CELL: 'Cell',
};
