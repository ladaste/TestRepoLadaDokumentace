export enum OSSectionValueType {
  Text = 1,
  KeyValue,
  Checkbox,
  Break,
}
