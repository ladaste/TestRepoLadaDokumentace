export enum TemplateVersion {
  One,
  Two,
  Three,
}
