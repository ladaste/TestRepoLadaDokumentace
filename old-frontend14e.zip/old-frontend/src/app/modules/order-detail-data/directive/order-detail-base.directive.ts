import { Directive, EventEmitter, inject, Input, Output } from '@angular/core';
import { AsolTranslationService } from '@asol-platform/core';
import { AsolNavigationService } from '@asol-platform/services';
import { environment } from '../../../../environments/environment';
import { TRANS } from '../../../shared/constants/localization.constant';
import { ORDER_SUMMARY_DATE_FORMAT } from '../constants/order-summary-date-format.const';
import { OS_SECTION_CODE } from '../constants/order-summary-section-code.constant';
import { OS_SECTION_VAL_CODE } from '../constants/order-summary-section-value-code.constant';
import { DocumentEvent } from '../models/document-event.interface';
import { OrderSummaryData } from '../models/order-summary-data.interface';
import { DocumentsService } from '../services/documents-service';

/**
 * Directive of the template for order detail data
 * It should contain all of the common inputs and properties
 */
@Directive()
export abstract class OrderDetailBaseDirective {
  private documentsService = inject(DocumentsService);
  private navigationService = inject(AsolNavigationService);
  protected trans = inject(AsolTranslationService);

  protected readonly OS_SECTION_CODE = OS_SECTION_CODE;
  protected readonly OS_SECTION_VAL_CODE = OS_SECTION_VAL_CODE;
  protected readonly TRANS = TRANS;
  protected readonly ORDER_SUMMARY_DATE_FORMAT = ORDER_SUMMARY_DATE_FORMAT;

  /**
   * Order summary data of the order. Same data that are displayed in the PDF
   */
  @Input() orderSummary!: OrderSummaryData;
  /**
   * Information about checkboxes. When false, user can interact with them.
   * Otherwise they are disabled
   */
  @Input() isCheckboxDisabled = false;
  /**
   * When set to true, bottom part of the screen is disabled.
   */
  @Input() isLegalSectionDisabled = false;
  /**
   * when true, error should be displayed under the checkbox. (if there is an error)
   */
  @Input() displayCheckboxRequiredError = true;
  /**
   * Whether to allow LG breakpoints -> two sections (customer and supplier) in one row.
   */
  @Input() allowLGBreakPoints = false;
  /**
   * id of the order (for getting documents)
   */
  @Input() orderId?: string;
  /**
   * Emits event when document should be opened. If there is an order ID, this component opens it by itself.
   * However, when order ID is missing, custom function should be used.
   */
  @Output() documentClicked = new EventEmitter<DocumentEvent>();

  /**
   * Download PDF after clicking on it
   * @param type -> Type of default PDF document
   * @param additionalFileId -> id of custom app document
   */
  docClicked(type?: string, additionalFileId?: string): void {
    if (!this.orderId) {
      this.documentClicked.emit({ type, additionalFileId });
      return;
    }
    this.documentsService
      .getDocumentsById(this.orderId)
      .subscribe((response) => {
        const documents = response?.items.filter(
          (doc) => this.orderSummary?.languageCode == doc.languageCode
        );
        type = type?.replace('customerConsent', '');
        const file = documents.find(
          (doc) => doc.type == type || doc.name === additionalFileId
        );
        if (!file) {
          return;
        }
        this.navigationService.openExternalUrl(
          environment.contentManagerUrl +
            '/api/v1/PublicFiles/Path/' +
            file.path
        );
      });
  }
}
