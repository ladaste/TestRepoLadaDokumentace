import { OS_SECTION_CODE } from '../constants/order-summary-section-code.constant';
import { OSSectionType } from '../constants/order-summary-section-type.enum';
import { OrderSummaryData } from '../models/order-summary-data.interface';
import { OrderSummarySection } from '../models/order-summary-section.interface';

/**
 * Sorting order-data sections, so it is displayed in demanded order.
 * @param orderData
 * @returns
 */
export function versionOneSortOrderSections(orderData: OrderSummaryData) {
  const sections: OrderSummarySection[] = [...orderData.orderSections];

  const supplierArray = sections.filter(
    (sec) => sec.orderSectionType === OSSectionType.Supplier
  );
  const customerArray = sections.filter(
    (sec) => sec.orderSectionType === OSSectionType.Customer
  );
  const detailsArray = sections.filter(
    (sec) =>
      sec.orderSectionType === OSSectionType.OrderSpecifications ||
      sec.orderSectionCode === OS_SECTION_CODE.ORDER_DETAILS
  );

  const priceArray = sections.filter(
    (sec) => sec.orderSectionType === OSSectionType.Price
  );

  const legalArray = sections.filter(
    (sec) => sec.orderSectionType === OSSectionType.LegalDocuments
  );

  const customArray = sections.filter(
    (sec) =>
      sec.orderSectionType === OSSectionType.Custom &&
      sec.orderSectionCode !== OS_SECTION_CODE.ORDER_DETAILS
  );

  return [
    ...supplierArray,
    ...customerArray,
    ...detailsArray,
    ...priceArray,
    ...legalArray,
    ...customArray,
  ];
}
