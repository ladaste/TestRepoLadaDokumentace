export interface CheckboxEvent {
  value: { [key: string]: boolean };
  isValid: boolean;
}
