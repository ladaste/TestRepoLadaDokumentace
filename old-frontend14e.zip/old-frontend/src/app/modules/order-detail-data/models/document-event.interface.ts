export interface DocumentEvent {
  type?: string;
  additionalFileId?: string;
}
