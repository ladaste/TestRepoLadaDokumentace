export interface NonStandardStatusInfo {
  systemStatus: string;
  modifiedOn: string;
  modifiedBy: string;
}
