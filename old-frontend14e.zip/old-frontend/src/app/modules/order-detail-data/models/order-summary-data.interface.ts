import { NonStandardStatusInfo } from './nonstandard-status-info.interface';
import { OrderSummarySection } from './order-summary-section.interface';

export interface OrderSummaryData {
  languageCode: string;
  orderSections: OrderSummarySection[];

  productId: string;
  orderNumber: string;
  createdOn: string;
  orderPrice: number;
  orderBillingPeriod: string;

  version?: number;

  // VERSION TWO DATA
  packageName?: string;
  packageCardImageFileId?: string;
  packageShortDescription?: string;
  primaryCategoryName?: string;
  editionName?: string;
  editionDescription?: string;

  // VERSION ONE DATA
  selectedEdition?: string;
  numberOfUsers?: number;
  previousOrderId?: string;
  previousPrice?: string;
  isCustomPricing?: string;
  isChangeSubscription?: boolean | null;
  previousOrderPrice?: number | null;
  previousCreatedOn?: string | null;

  nonStandardStatusInfo?: NonStandardStatusInfo;
  approvedByCustomerOn?: string;
}
