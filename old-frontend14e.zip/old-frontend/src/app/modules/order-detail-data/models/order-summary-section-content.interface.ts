import { FormControl } from '@angular/forms';
import { OSSectionValueType } from '../constants/order-summary-section-value-type.enum';

export interface OSSectionContent {
  orderSectionValueType: OSSectionValueType | string;
  orderSectionValueCode: string;
  name: string | null;
  /**
   * property which contain (in some cases) reference to the formControl
   * which is used by user to adjust value of the name (key) of the contentValue
   */
  nameControl?: FormControl;
  value: string;
  /**
   * property which contain (in some cases) reference to the formControl
   * which is used by user to change value in the SectionContent
   */
  valueControl?: FormControl;
}
