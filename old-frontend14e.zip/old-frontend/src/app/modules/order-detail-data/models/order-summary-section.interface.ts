import { OSSectionType } from '../constants/order-summary-section-type.enum';
import { OSSectionContent } from './order-summary-section-content.interface';

export interface OrderSummarySection {
  orderSectionType: OSSectionType | string;
  orderSectionCode: string;
  sectionName: string;
  sectionContent: OSSectionContent[];

  // Used by third template for Payment tables
  tableRow?: OSSectionContent[][];
}
