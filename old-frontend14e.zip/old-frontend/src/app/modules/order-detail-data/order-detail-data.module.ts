import { NgModule } from '@angular/core';
import { AsolNavigationService } from '@asol-platform/services';
import { AppWideInfoCardComponent } from '@asol-platform/store';
import { SharedModule } from '../../shared/modules/shared.module';
import { CheckboxesBoxComponent } from './components/checkboxes-box/checkboxes-box.component';
import { OrderDetailDataComponent } from './components/order-detail-data/order-detail-data.component';
import { VersionOneComponent } from './components/version-one/version-one.component';
import { VersionThreeComponent } from './components/version-three/version-three.component';
import { VersionTwoComponent } from './components/version-two/version-two.component';
import { UsersNumberPipe } from './pipes/users-number-pipe';
import { DocumentsService } from './services/documents-service';

@NgModule({
  imports: [SharedModule, AppWideInfoCardComponent],
  declarations: [
    OrderDetailDataComponent,
    VersionOneComponent,
    VersionTwoComponent,
    CheckboxesBoxComponent,
    VersionThreeComponent,
    UsersNumberPipe,
  ],
  exports: [OrderDetailDataComponent],
  providers: [AsolNavigationService, DocumentsService],
})
export class OrderDetailDataModule {}
