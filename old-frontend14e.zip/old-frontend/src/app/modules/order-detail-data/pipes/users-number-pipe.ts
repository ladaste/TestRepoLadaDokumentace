import { Pipe, PipeTransform } from '@angular/core';
import { AsolTranslationService } from '@asol-platform/core';
import { TRANS } from '../../../shared/constants/localization.constant';
import translation from './users-pipe.translation.json';

@Pipe({
  name: 'usersNumber',
})
export class UsersNumberPipe implements PipeTransform {
  constructor(private trans: AsolTranslationService) {
    this.trans.initialize(TRANS.USERS_PIPE, translation);
  }

  /**
   * get number of users and return string with number and word users
   * @param value number of users
   * @param addSlash whether to add slash before number
   * @returns string with number and word users
   */
  transform(value: number | undefined, addSlash = false): string {
    if (value) {
      const addedSlash = addSlash ? '/ ' : '';
      if (value === 1) {
        return (
          addedSlash + value + ' ' + this.trans.get(TRANS.USERS_PIPE, '1user')
        );
      } else if (value > 1 && value < 5) {
        return (
          addedSlash +
          value +
          ' ' +
          this.trans.get(TRANS.USERS_PIPE, '2_4users')
        );
      } else {
        return (
          addedSlash + value + ' ' + this.trans.get(TRANS.USERS_PIPE, '5users')
        );
      }
    }
    return ''; // if 0 return '' too
  }
}
