import { Injectable } from '@angular/core';
import {
  AsolApiDataService,
  AsolCollectionResultModel,
} from '@asol-platform/services';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { OrderDocument } from '../../../shared/models/order-document.interface';

@Injectable()
export class DocumentsService {
  constructor(private apiDataService: AsolApiDataService) {}

  /**
   * Get documents for the order by order id
   * @param orderId - id of the order
   * @returns observable with documents
   */
  getDocumentsById(
    orderId: string
  ): Observable<AsolCollectionResultModel<OrderDocument>> {
    return this.apiDataService.get<OrderDocument>(
      environment.platformStoreOrderUrl +
        `/api/v1/BusinessConditionFiles/${orderId}`
    );
  }
}
