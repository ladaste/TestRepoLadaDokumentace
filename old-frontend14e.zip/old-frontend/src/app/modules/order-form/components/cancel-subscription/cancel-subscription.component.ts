import { Component, EventEmitter, Input, Output } from '@angular/core';
import { NonNullableFormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AsolLoaderService } from '@asol-platform/controls';
import {
  AsolLocalizationService,
  AsolTranslationService,
} from '@asol-platform/core';
import { AsolDialogMessageService } from '@asol-platform/services';
import { Subscription, finalize } from 'rxjs';
import { TRANS } from '../../../../shared/constants/localization.constant';
import { CancelDataEvent } from '../../models/cancel-data-event.interface';
import { CancelSubscriptionService } from '../../services/cancel-subscription.service';
import translation from './cancel-subscription.translate.json';

@Component({
  selector: 'asol-platform-cancel-subscription',
  templateUrl: './cancel-subscription.component.html',
  styleUrls: ['./cancel-subscription.component.scss'],
  providers: [CancelSubscriptionService],
})
export class CancelSubscriptionComponent {
  protected readonly TRANS = TRANS;

  protected cancelReasons: { value: string; displayValue: string }[] = [];

  protected cancelGroup = this.formBuilder.group({
    cancelationReason: this.formBuilder.control(''),
    cancelationMessage: this.formBuilder.control(''),
    improvementsMessage: this.formBuilder.control(''),
  });

  @Input() cancelData?: CancelDataEvent;
  @Output() backClicked = new EventEmitter();
  private sub: Subscription;

  constructor(
    private router: Router,
    private formBuilder: NonNullableFormBuilder,
    protected trans: AsolTranslationService,
    private cancelService: CancelSubscriptionService,
    private loader: AsolLoaderService,
    private dialogMessage: AsolDialogMessageService,
    protected loc: AsolLocalizationService
  ) {
    this.trans.initialize(TRANS.CANCEL_SUBSCRIPTION_PAGE, translation);
    this.sub = loc.updated.subscribe(() => {
      this.transReasons();
    });
  }

  ngOnInit() {
    this.transReasons();
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  /**
   * prepare translations for reasons of cancelation
   */
  private transReasons() {
    this.cancelReasons = [
      {
        value: 'MissingFeature',
        displayValue: this.trans.get(
          TRANS.CANCEL_SUBSCRIPTION_PAGE,
          'MissingFeature'
        ),
      },
      {
        value: 'QualityOfServices',
        displayValue: this.trans.get(
          TRANS.CANCEL_SUBSCRIPTION_PAGE,
          'QualityOfServices'
        ),
      },
      {
        value: 'Price',
        displayValue: this.cancelData?.billingPeriod
          ? this.trans.get(
              TRANS.CANCEL_SUBSCRIPTION_PAGE,
              this.cancelData?.billingPeriod + 'Price'
            )
          : '',
      },
      {
        value: 'Others',
        displayValue: this.trans.get(TRANS.CANCEL_SUBSCRIPTION_PAGE, 'Others'),
      },
    ];
  }

  /**
   * sends unsubscribe request to backend
   */
  protected sendRequest() {
    if (!this.cancelData?.orderNumber) {
      return;
    }

    this.loader.start();
    this.cancelService
      .sendUnsubcribeRequest({
        orderNumber: this.cancelData.orderNumber,
        cancelationMessage: this.cancelGroup.controls.cancelationMessage.value,
        improvementsMessage:
          this.cancelGroup.controls.improvementsMessage.value,
        cancelationReason: this.cancelGroup.controls.cancelationReason.value,
        deeplinkBaseUrl: window.location.origin,
      })
      .pipe(
        finalize(() => {
          this.loader.stop();
        })
      )
      .subscribe(() => {
        this.dialogMessage.showSimpleMessage(
          this.trans.get(TRANS.CANCEL_SUBSCRIPTION_PAGE, 'RequestSended')
        );
        this.router.navigate(['my-apps']);
      });
  }

  /**
   * react to event of back button click
   */
  protected back() {
    this.backClicked.emit();
  }
}
