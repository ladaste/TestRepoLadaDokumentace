import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { Component, Inject, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {
  AsolPermission,
  AsolPermissionService,
} from '@asol-platform/authentication';
import {
  AsolButtonType,
  AsolLocalizationService,
  AsolTranslationService,
} from '@asol-platform/core';
import { APPLICATION_CODE } from '../../../../shared/constants/application-code.constant';
import { TRANS } from '../../../../shared/constants/localization.constant';
import { PERMISSION } from '../../../../shared/constants/permission.constant';
import { OS_SECTION_VAL_CODE } from '../../../order-detail-data/constants/order-summary-section-value-code.constant';
import { OS_SECTION_VALUE_TYPES } from '../../../order-detail-data/constants/order-summary-section-value-type.const';
import { OrderSummarySection } from '../../../order-detail-data/models/order-summary-section.interface';

@Component({
  selector: 'asol-platform-customization-order-data-dialog',
  styleUrls: ['./customization-order-data-dialog.component.scss'],
  templateUrl: './customization-order-data-dialog.component.html',
})
export class CustomizationOrderDataDialogComponent implements OnInit {
  protected readonly TRANS = TRANS;
  protected readonly OS_SECTION_VALUE_TYPES = OS_SECTION_VALUE_TYPES;
  protected readonly PERMISSION = PERMISSION;
  protected readonly AsolPermission = AsolPermission;
  protected readonly APPLICATION_CODE = APPLICATION_CODE;

  protected customizationAllowed = true;

  constructor(
    protected trans: AsolTranslationService,
    protected loc: AsolLocalizationService,
    private dialogRef: MatDialogRef<CustomizationOrderDataDialogComponent>,
    private permissionService: AsolPermissionService,
    @Inject(MAT_DIALOG_DATA)
    protected data: { sections: OrderSummarySection[] } | undefined
  ) {}

  ngOnInit(): void {
    this.permissionService
      .hasPermission(
        this.PERMISSION.EDIT_NONSTANDARD_ORDER,
        this.PERMISSION.ORDER_ROOT,
        AsolPermission.Update,
        APPLICATION_CODE.ORDER
      )
      .subscribe((hasPermission) => {
        if (hasPermission) {
          return;
        }
        this.customizationAllowed = false;
        this.data?.sections.forEach((section) => {
          section.sectionContent.forEach((content) => {
            content.nameControl?.disable();
            content.valueControl?.disable();
          });
        });
      });
  }

  /**
   * function to handle drag and drop.
   * @param event drag and drop event
   * @param section section, where it happened
   */
  protected drop(event: CdkDragDrop<unknown>, section: OrderSummarySection) {
    const popped = section.sectionContent[event.previousIndex];
    section.sectionContent.splice(event.previousIndex, 1);
    // first should not move
    section.sectionContent.splice(event.currentIndex, 0, popped);
  }

  /**
   * remove row from section content of the order
   * @param section - section from which row will be removed
   * @param index - index of row to remove
   */
  protected removeRow(section: OrderSummarySection, index: number) {
    section.sectionContent.splice(index, 1);
  }

  /**
   * add new row to section content of the order
   * @param section - section to which row will be added
   */
  protected addRow(section: OrderSummarySection) {
    section.sectionContent.push({
      orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
      orderSectionValueCode: OS_SECTION_VAL_CODE.ORDER_DETAILS.ADDED_LINE,
      name: '',
      value: '',
      nameControl: new FormControl(''),
      valueControl: new FormControl(''),
    });
  }

  /**
   * Reaction to dialog button click.
   * @param event - Button type clicked
   *
   * if user click cancel, return old values
   * if user click save, return new values
   */
  protected dialogButtonClicked(event: AsolButtonType) {
    if (event === 'Cancel') {
      this.data?.sections.forEach((section) => {
        section.sectionContent.forEach((content) => {
          content.nameControl?.setValue(content.name);
          content.valueControl?.setValue(content.value);
        });
      });
    } else if (event === 'Save') {
      this.data?.sections.forEach((section) => {
        section.sectionContent.forEach((content) => {
          content.name =
            content.nameControl?.getRawValue().replaceAll('\n', ' ') ?? '';
          content.value =
            content.valueControl?.getRawValue().replaceAll('\n', ' ') ?? '';
        });
      });
    }
    this.dialogRef.close(this.data?.sections);
  }
}
