import { Component, Inject, OnInit } from '@angular/core';
import { NonNullableFormBuilder } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {
  AsolButtonType,
  AsolLocalizationService,
  AsolTranslationService,
} from '@asol-platform/core';
import { TRANS } from '../../../../shared/constants/localization.constant';
import translation from './customization-other-data-dialog.translation.json';
import { CustomOtherDialogData } from '../../models/custom-static-dialog-data.interface';
import {
  AsolPermission,
  AsolPermissionService,
} from '@asol-platform/authentication';
import { APPLICATION_CODE } from '../../../../shared/constants/application-code.constant';
import { PERMISSION } from '../../../../shared/constants/permission.constant';

@Component({
  selector: 'asol-platform-customization-other-data-dialog',
  templateUrl: './customization-other-data-dialog.component.html',
})
export class CustomizationOtherDataDialogComponent implements OnInit {
  protected readonly TRANS = TRANS;
  private PERMISSION = PERMISSION;

  // Form data
  protected form = this.fb.group({
    additionalInformation: this.fb.control<string>(''),
  });

  constructor(
    protected trans: AsolTranslationService,
    protected fb: NonNullableFormBuilder,
    protected loc: AsolLocalizationService,
    private permissionService: AsolPermissionService,
    private dialogRef: MatDialogRef<
      CustomizationOtherDataDialogComponent,
      CustomOtherDialogData
    >,
    @Inject(MAT_DIALOG_DATA)
    protected data: CustomOtherDialogData | undefined
  ) {
    this.trans.initialize(TRANS.STATIC_DATA_DIALOG, translation);
  }

  ngOnInit(): void {
    if (!this.data) {
      return;
    }
    this.form.patchValue({
      additionalInformation: this.data.additionalInformation,
    });
    this.permissionService
      .hasPermission(
        this.PERMISSION.EDIT_NONSTANDARD_ORDER,
        this.PERMISSION.ORDER_ROOT,
        AsolPermission.Update,
        APPLICATION_CODE.ORDER
      )
      .subscribe((hasPermission) => {
        if (hasPermission) {
          return;
        }
        this.form.disable();
      });
  }

  /**
   * Reaction to the dialog button click.
   */
  protected onButtonClick(button: AsolButtonType) {
    if (button === 'Cancel') {
      this.dialogRef.close();
      return;
    }
    const result: CustomOtherDialogData = this.form.getRawValue();
    this.dialogRef.close(result);
  }
}
