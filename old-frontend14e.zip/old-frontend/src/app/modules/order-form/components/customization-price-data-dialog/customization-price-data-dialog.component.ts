import { Component, Inject, OnInit } from '@angular/core';
import { FormGroup, NonNullableFormBuilder } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {
  AsolButtonType,
  AsolLocalizationService,
  AsolTranslationService,
  localize,
} from '@asol-platform/core';
import {
  EditionHolderSelection,
  EditionSubscription,
  OrderProposalSalesItem,
} from '@asol-platform/store';
import { Subject, takeUntil } from 'rxjs';
import { TRANS } from '../../../../shared/constants/localization.constant';
import { CustomPriceDialogData } from '../../models/custom-price-dialog-data.interface';
import { CustomPriceDialogResult } from '../../models/custom-price-dialog-result.interface';
import { CustomPriceDialogSalesItem } from '../../models/custom-price-dialog-sales-item.interface';
import translation from './customization-price-data-dialog.translation.json';

@Component({
  selector: 'asol-platform-customization-price-data-dialog',
  templateUrl: './customization-price-data-dialog.component.html',
})
export class CustomizationPriceDataDialogComponent implements OnInit {
  protected readonly TRANS = TRANS;

  protected form = this.formBuilder.group({
    editionName: this.formBuilder.control({
      value: '',
      disabled: true,
    }),
    subscription: this.formBuilder.control<EditionSubscription | undefined>(
      undefined
    ),
    firstInvoice: this.formBuilder.control<Date>(new Date()),
  });

  protected salesItems: CustomPriceDialogSalesItem[] = [];
  protected editionPrice = 0;

  protected actualBillingPeriod = '';

  private endSubject$ = new Subject<void>();

  constructor(
    protected trans: AsolTranslationService,
    protected formBuilder: NonNullableFormBuilder,
    protected loc: AsolLocalizationService,
    private dialogRef: MatDialogRef<
      CustomizationPriceDataDialogComponent,
      CustomPriceDialogResult | null
    >,
    @Inject(MAT_DIALOG_DATA)
    protected data: CustomPriceDialogData | undefined
  ) {
    this.trans.initialize(TRANS.PRICE_DATA_DIALOG, translation);
    this.form.controls.subscription.valueChanges
      .pipe(takeUntil(this.endSubject$))
      .subscribe(() => {
        this.initializeOnSubscriptionChange();
      });
  }

  ngOnInit(): void {
    if (!this.data?.appDetail) {
      return;
    }

    this.form.patchValue({
      editionName: this.data.selectedEdition.name,
      subscription: this.data.selectedEdition.selectedSubscription,
      firstInvoice: this.data.firstInvoiceDate
        ? new Date(this.data.firstInvoiceDate)
        : new Date(),
    });

    if (this.data.selectedEdition.subscriptions.length === 1) {
      this.form.controls.subscription.disable();
    }
  }

  ngOnDestroy() {
    this.endSubject$.next();
    this.endSubject$.complete();
  }

  /**
   * when subscription is changed, billingPeriod should be actualized,
   * sales items can change so they has to be initialized again and then
   * price should be recalculated.
   */
  private initializeOnSubscriptionChange() {
    this.actualizeBillingPeriod();
    this.initializeSalesItems();
    this.recalculateEditionPrice();
  }

  /**
   * create string for the translation for the bottom of the page based on the
   * current subscription's billingPeriodCode
   */
  private actualizeBillingPeriod() {
    const sub = this.form.getRawValue().subscription;
    if (!sub || !this.data) {
      return;
    }
    this.actualBillingPeriod =
      this.data.typesService.parseBillingCode(sub.billingPeriodCode) ?? '';
  }

  /**
   * based on subscription's sales items, creates array of the salesItems with label
   * from the parsedSliderDefinition (if exists). This array should also contain roleCount,
   * rolePrice and unitPrice values. This array will be displayed in the dialog with
   * 3 input fields and section title.
   */
  private initializeSalesItems() {
    const subSalesItems = this.form.getRawValue().subscription?.salesItems;
    if (!subSalesItems || subSalesItems.length === 0) {
      this.salesItems = [];
      return;
    }
    this.salesItems = subSalesItems.map((salesItem) => {
      const slider = this.data?.appDetail.parsedSliderDefinition?.find(
        (slid) => salesItem.roleCode === slid.roleCode
      );

      let unitPrice = '0';
      if (salesItem?.rolePrice && salesItem.roleCount) {
        unitPrice = (
          parseFloat(salesItem.rolePrice) / salesItem.roleCount
        ).toFixed(2);
      }

      let proposalSalesItem: OrderProposalSalesItem | undefined;
      if (this.data?.proposal?.subscriptions?.length) {
        proposalSalesItem = this.data.proposal.subscriptions[0].salesItems.find(
          (si) => si.licenceRole.roleCode === salesItem.roleCode
        );
      }

      /**
       * role count should be get from the proposal where it should be saved at the end.
       * However, if not present, it should be taken from the salesItem (in the edition -> subscriptions).
       * For TypeScript value check, there is 0 at the end, so roleCount is always number
       */
      const roleCount =
        proposalSalesItem?.licenceRole.roleCount ?? salesItem?.roleCount ?? 0;

      const rolePrice =
        proposalSalesItem?.licenceRole.rolePrice ??
        (salesItem?.rolePrice ? parseFloat(salesItem.rolePrice) : 0);

      const form = this.formBuilder.group({
        roleCount: this.formBuilder.control(roleCount),
        rolePrice: this.formBuilder.control(rolePrice),
        unitPrice: this.formBuilder.control({
          value: unitPrice,
          disabled: true,
        }),
      });

      form.controls.roleCount.valueChanges
        .pipe(takeUntil(this.endSubject$))
        .subscribe(() => {
          this.recalculateUnitPrice(form);
        });

      form.controls.rolePrice.valueChanges
        .pipe(takeUntil(this.endSubject$))
        .subscribe(() => {
          this.recalculateUnitPrice(form);
        });

      return {
        id: salesItem.id,
        roleCode: salesItem.roleCode,
        name: salesItem.name,
        label: localize(slider?.name, this.loc) ?? '',
        form,
      };
    });
  }

  /**
   * calculate unit price on role count or rolePrice change.
   * @param form form of the salesItem
   */
  private recalculateUnitPrice(form: FormGroup) {
    const formValue = form.getRawValue();
    form.controls.unitPrice.patchValue(
      (formValue.rolePrice / formValue.roleCount).toFixed(2)
    );
    this.recalculateEditionPrice();
  }

  /**
   * When rolePrice or roleCount is changed, unitPrice and editionPrice should be recalculated.
   * edition price should be equal to new sum of the rolePrices for each salesItem
   *
   * @param salesItem current salesItem changed
   */
  private recalculateEditionPrice() {
    this.editionPrice = this.salesItems.reduce((acc, s) => {
      return acc + s.form.getRawValue().rolePrice;
    }, 0);
  }

  /**
   * reaction to the dialog button click. On cancel, nothing should be saved.
   * On save (else branch), each salesItems changed value should be written to the
   * edition salesItems (so it can be displayed in the order summary).
   * Also price of the edition should be updated
   * Then EditionHolderSelection model is filled, as proposal
   * has to be actualized in the order component.
   * @param button AsolButtonType which was clicked
   * At the end dialogRef is closed with null value, or the @see {CustomPriceDialogResult} value
   */
  protected onButtonClick(button: AsolButtonType) {
    if (!this.data || button === 'Cancel') {
      this.dialogRef.close(null);
      return;
    }

    this.data.selectedEdition.selectedSubscription =
      this.form.getRawValue().subscription;

    this.salesItems.forEach((salesItem) => {
      const editionSI =
        this.data?.selectedEdition?.selectedSubscription?.salesItems.find(
          (si) => si.roleCode === salesItem.roleCode
        );
      if (!editionSI) {
        return;
      }

      const formValue = salesItem.form.getRawValue();

      editionSI.roleCount = formValue.roleCount;
      editionSI.rolePrice = formValue.rolePrice?.toFixed(2);
    });

    this.data.selectedEdition.price = this.editionPrice;

    // update order proposal. with current values. Possibly also update values in the edition - subscriptions?
    const editionSelectionData: Partial<EditionHolderSelection> = {
      totalPrice: this.editionPrice,
      billingPeriod: this.actualBillingPeriod,
      salesItems: this.salesItems.map((si) => {
        const formValue = si.form.getRawValue();

        return {
          id: si.id,
          licenceRole: {
            roleCode: si.roleCode,
            roleCount: formValue.roleCount,
            rolePrice: formValue.rolePrice,
          },
        };
      }),
      selectedSubscription: this.data.selectedEdition?.selectedSubscription,
      selectedEdition: this.data.selectedEdition,
    };

    const customPriceResult: CustomPriceDialogResult = {
      editionSelectionData,
      firstInvoiceDate: this.form.value.firstInvoice?.toISOString(),
    };

    this.dialogRef.close(customPriceResult);
  }
}
