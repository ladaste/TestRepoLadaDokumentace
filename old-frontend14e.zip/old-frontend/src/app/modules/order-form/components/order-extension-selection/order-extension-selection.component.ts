import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  inject,
} from '@angular/core';
import { MatExpansionPanel } from '@angular/material/expansion';
import { AsolProgressDataValue } from '@asol-platform/controls';
import {
  ASOL_CORE_PATHS,
  ASOL_GENERAL_TRANSLATION,
  AsolLocalizationService,
  AsolTranslationService,
} from '@asol-platform/core';
import {
  AppDetailEdition,
  AsolStoreTypesService,
  EditionExtension,
  basePriceMultiplication,
  priceToStringWithTwoDecimals,
  updateUnitText,
} from '@asol-platform/store';
import moment from 'moment';
import { TRANS } from '../../../../shared/constants/localization.constant';
import { EMPTY_EXTENSIONS } from '../../constants/empty-extension.const';
import { OrderDetailData } from '../../models/order-detail-data.interface';
import translation from './order-extension-selection.translation.json';

@Component({
  selector: 'asol-platform-order-extension-selection',
  templateUrl: './order-extension-selection.component.html',
  styleUrls: ['./order-extension-selection.component.scss'],
})
export class OrderExtensionSelectionComponent implements OnChanges {
  protected readonly TRANS = TRANS;
  protected readonly ASOL_GENERAL_TRANSLATION = ASOL_GENERAL_TRANSLATION;
  protected readonly emptyExtensionImage =
    inject(ASOL_CORE_PATHS).publicFilesUrl + EMPTY_EXTENSIONS;

  @Input() selectedEdition: AppDetailEdition | undefined;
  @Output() extensionsSelected = new EventEmitter<EditionExtension[]>();

  protected optionalExtensions: EditionExtension[] = [];
  protected mandatoryExtensions: EditionExtension[] = [];

  constructor(
    protected trans: AsolTranslationService,
    protected loc: AsolLocalizationService,
    private typesService: AsolStoreTypesService
  ) {
    this.trans.initialize(TRANS.ORDER_EXTENSION_PAGE, translation);
  }

  ngOnChanges() {
    if (this.selectedEdition) {
      const previousSelected = this.selectedExtensions();
      const filteredExtensions = this.selectedEdition.extensions.filter(
        (ext) => ext.subscriptions.length
      );
      filteredExtensions.forEach((e) => {
        e.selected =
          e.isMandatory ||
          !!previousSelected.find((previous) => previous.id === e.id);
        e.previousCount = e.count;
        e.selectedSubscription = e.subscriptions[0];

        updateUnitText(this.typesService, e, e.selectedSubscription.salesItems);

        if (e.extensionData?.progresScales) {
          let values = e.extensionData.progresScales?.flatMap((scale) => {
            const array: AsolProgressDataValue[] = [];

            for (
              let i = scale.minLicences;
              i <= scale.maxLicences;
              i += scale.stepLicences
            ) {
              array.push({
                value: i,
                labelText: i.toString(),
              });
            }

            return array;
          });

          /**
           * filter values which are duplicit
           * than sort it form lowest to the highest
           */
          values = values
            .filter(
              (val, index) =>
                values.findIndex((v) => v.value === val.value) === index
            )
            .sort((a, b) => {
              return a.value - b.value;
            });

          e.shownValues = values;
        }
      });
      this.optionalExtensions = filteredExtensions.filter(
        (ext) => !ext.isMandatory
      );
      this.mandatoryExtensions = filteredExtensions.filter(
        (ext) => ext.isMandatory
      );

      this.optionalExtensions.forEach((ext) => {
        this.recalculateExtension(ext);
      });
      this.mandatoryExtensions.forEach((ext) => {
        this.recalculateExtension(ext);
      });

      this.extensionsSelected.emit(this.selectedExtensions());
    }
  }

  /**
   * Reaction to save button click
   * @param ext - extension which is being changed
   * @param panel - panel which is being closed
   */
  protected saveConfig(ext: EditionExtension, panel: MatExpansionPanel) {
    ext.previousCount = ext.count;
    ext.expanded = false;
    panel.close();
  }

  /**
   * Reaction to cancel button click
   * @param ext - extension which is being closed
   * @param panel - panel which is being closed
   */
  protected cancelChanges(ext: EditionExtension, panel: MatExpansionPanel) {
    ext.count = ext.previousCount;
    this.recalculateExtension(ext);
    panel.close();
  }

  /**
   * On change of the extension count recalculate the price and update unit text
   * @param ext - extension being changed
   */
  protected recalculateExtension(ext: EditionExtension) {
    const salesItem = ext.selectedSubscription?.salesItems.length
      ? ext.selectedSubscription?.salesItems[0]
      : undefined;
    if (!salesItem) {
      return;
    }
    const actualPrice = salesItem.salesItem.priceList.find(
      (price) =>
        moment().isAfter(price.validFrom) &&
        (!price.validTo || moment().isBefore(price.validTo))
    );
    if (!(actualPrice && typeof ext.count === 'number')) {
      return;
    }

    const extCount = ext.count;

    // to actualize text of the extension.
    ext.unitText = this.typesService.getUnitTranslation(
      ext.count,
      salesItem.unitOfSaleCode,
      salesItem.unitOfMeasureCode
    );

    let price = 0;
    let previousMax = 0;

    salesItem.salesItem.priceScales
      ?.filter((scale) => extCount >= scale.minLicences)
      .sort((a, b) => {
        return a.minLicences - b.minLicences;
      })
      .forEach((scale) => {
        const basePriceAdjusted = basePriceMultiplication(
          actualPrice.basePrice,
          scale.basePricePercentage
        );

        if (extCount > scale.maxLicences) {
          price += basePriceAdjusted * (scale.maxLicences - previousMax);
          previousMax = scale.maxLicences;
        } else {
          price += basePriceAdjusted * (extCount - previousMax);
        }
      });

    salesItem.rolePrice = priceToStringWithTwoDecimals(price);
    salesItem.roleCount = extCount;
    ext.price = parseFloat(salesItem.rolePrice);
    this.extensionsSelected.emit(this.selectedExtensions());
  }

  /**
   * Reaction to the extension selection
   * @param event - event, which has been triggered and should be stopped (so it does not close the panel)
   */
  protected selectedExt(event: Event) {
    event.stopPropagation();
    this.extensionsSelected.emit(this.selectedExtensions());
  }

  /**
   * Fill order payload with data based on extensions that are selected.
   * There should be id of the selected extensions and its selected subscription
   * @param data order data which should be filled
   */
  public fillExtensions(data: OrderDetailData) {
    const selectedExtensions = this.selectedExtensions();
    data.extensions = selectedExtensions.map((ext) => {
      return {
        id: ext.id,
        subscriptions: ext.subscriptions.map((s) => {
          return {
            id: s.id,
            salesItems: s.salesItems.map((si) => {
              return {
                id: si.id,
                licenceRole: {
                  roleCode: si.roleCode,
                  roleCount: ext.count ?? 1,
                },
              };
            }),
          };
        }),
      };
    });
  }

  /**
   * Method which return all selected extensions
   * @returns array of extensions
   */
  private selectedExtensions() {
    return [
      ...this.mandatoryExtensions,
      ...this.optionalExtensions.filter((ext) => ext.selected),
    ];
  }
}
