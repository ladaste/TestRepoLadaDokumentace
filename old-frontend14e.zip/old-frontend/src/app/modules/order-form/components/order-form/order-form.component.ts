import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import {
  AbstractControl,
  FormControl,
  NonNullableFormBuilder,
  Validators,
} from '@angular/forms';
import {
  AsolAuthService,
  AsolPermission,
  AsolPermissionService,
} from '@asol-platform/authentication';
import {
  ASOL_GENERAL_TRANSLATION,
  AsolLocalizationService,
  AsolPhoneNumberValidator,
  AsolTranslationService,
} from '@asol-platform/core';
import {
  AsolAddress,
  AsolCountry,
  AsolDialogMessageService,
  AsolOrganization,
  AsolPerson,
  AsolSubjectManagerService,
} from '@asol-platform/services';
import {
  AsolCustomerOrganization,
  AsolCustomerOrganizationPickerService,
  AsolCustomerPersonPickerService,
  CustomerPerson,
} from '@asol-platform/store';
import {
  Observable,
  Subject,
  Subscription,
  catchError,
  forkJoin,
  mergeMap,
  of,
  switchMap,
  takeUntil,
  tap,
} from 'rxjs';
import { APPLICATION_CODE } from '../../../../shared/constants/application-code.constant';
import { TRANS } from '../../../../shared/constants/localization.constant';
import { PERMISSION } from '../../../../shared/constants/permission.constant';
import { OrderFormEvent } from '../../constants/order-form-events.type';
import { OrderDetailData } from '../../models/order-detail-data.interface';
import { OrderFormFilledData } from '../../models/order-form-filled.interface';
import { UpdateOrganizationData } from '../../models/update-organization-data.interface';
import { OrderService } from '../../services/order.service';
import { SalesRepChangesService } from '../../services/sales-rep-changes.service';

@Component({
  selector: 'asol-platform-order-form',
  templateUrl: './order-form.component.html',
})
export class OrderFormComponent implements OnInit {
  protected readonly TRANS = TRANS;
  protected readonly ASOL_GENERAL_TRANSLATION = ASOL_GENERAL_TRANSLATION;
  protected readonly PERMISSION = PERMISSION;
  protected readonly APPLICATION_CODE = APPLICATION_CODE;
  protected readonly AsolPermission = AsolPermission;

  private infoLoaded = false;

  /** countries which can be selected */
  protected countriesData: AsolCountry[] = [];

  private allowOrganizationDataChange = false;
  @Input() disableNextButton = false;
  @Input() stepFilledController: FormControl | undefined;

  protected purchasingPerson = this.formBuilder.group({
    email: this.formBuilder.control('', {
      validators: [Validators.required, Validators.email],
    }),
    phoneNumber: this.formBuilder.control('', {
      validators: [Validators.required, AsolPhoneNumberValidator],
    }),
    firstName: this.formBuilder.control('', {
      validators: [Validators.required],
    }),
    lastName: this.formBuilder.control('', {
      validators: [Validators.required],
    }),

    // filled only for orders created by sales rep (when selecting person of selected tenant).
    personId: this.formBuilder.control<string | undefined>(undefined),
    accountId: this.formBuilder.control<string | undefined>(undefined),
    userName: this.formBuilder.control<string | undefined>(undefined),
  });

  protected customer = this.formBuilder.group({
    invoiceEmail: this.formBuilder.control('', {
      validators: [Validators.required],
    }),
    name: this.formBuilder.control('', {
      validators: [Validators.required],
    }),
    // should be in format "number | countyCode" (e.g. 12345678|CZ)
    code: this.formBuilder.control({ value: '', disabled: true }),
    // should be just number of the above code
    codeNumber: this.formBuilder.control({ value: '', disabled: true }),
    vatIn: this.formBuilder.control(''),
    mainAddress: this.formBuilder.group({
      street: this.formBuilder.control('', {
        validators: [Validators.required],
      }),
      city: this.formBuilder.control('', {
        validators: [Validators.required],
      }),
      zipCode: this.formBuilder.control('', {
        validators: [Validators.required],
      }),
      countryCode: this.formBuilder.control('', {
        validators: [Validators.required],
      }),
    }),

    // filled only for orders created by sales rep (when selecting tenant).
    tenantId: this.formBuilder.control<string | undefined>(undefined),
  });

  get address() {
    return this.customer.controls.mainAddress;
  }

  @Output() formFilledEvent = new EventEmitter<OrderFormFilledData>();
  @Output() organizationSelected = new EventEmitter<boolean>();
  @Output() orderFormEvent = new EventEmitter<OrderFormEvent>();

  private personData: AsolPerson | undefined;
  private organizationData: AsolOrganization | undefined;

  protected selectedOrganization: AsolCustomerOrganization | undefined;
  private selectedPerson: CustomerPerson | undefined;

  private endSubject$ = new Subject<void>();
  private formSubs?: Subscription;

  private updateNonstandardOrgCusData = false;

  constructor(
    private formBuilder: NonNullableFormBuilder,
    private orderService: OrderService,
    protected trans: AsolTranslationService,
    protected loc: AsolLocalizationService,
    private dialogService: AsolDialogMessageService,
    private auth: AsolAuthService,
    private organizationPicker: AsolCustomerOrganizationPickerService,
    private personPicker: AsolCustomerPersonPickerService,
    private salesRepChanges: SalesRepChangesService,
    private subjectManager: AsolSubjectManagerService,
    private permissionService: AsolPermissionService
  ) {
    this.subscribeToForms();
    this.salesRepChanges.onChange$
      .pipe(takeUntil(this.endSubject$))
      .subscribe(() => {
        if (this.salesRepChanges.hasSomethingChanged()) {
          this.resetFormOnSalesRepChanges();
        }
      });
  }

  ngOnInit(): void {
    this.loadPermissions();

    forkJoin([this.loadTenant(), this.loadUser()])
      .pipe(takeUntil(this.endSubject$))
      .subscribe(() => {
        this.infoLoaded = true;
        this.checkFormValidity();
        this.orderFormEvent.emit('formLoaded');
      });

    this.subjectManager
      .getCountries()
      .pipe(takeUntil(this.endSubject$))
      .subscribe((response) => {
        this.countriesData = response.items;
      });
  }

  ngOnDestroy(): void {
    this.formSubs?.unsubscribe();
    this.endSubject$.next();
    this.endSubject$.complete();
  }

  private loadPermissions(): void {
    this.permissionService
      .hasPermission(
        PERMISSION.ORGANIZATION_DATA,
        PERMISSION.ORDER_ROOT,
        AsolPermission.Update,
        APPLICATION_CODE.ORDER
      )
      .pipe(takeUntil(this.endSubject$))
      .subscribe((allowedChange) => {
        this.allowOrganizationDataChange = allowedChange;
        if (allowedChange) {
          this.customer.enable();
          this.customer.controls.code.disable();
          this.customer.controls.codeNumber.disable();
        } else {
          this.customer.disable();
        }
      });

    this.permissionService
      .hasPermission(
        PERMISSION.UPDATE_NONSTANDARD_CUSTOMER_DATA,
        PERMISSION.ORDER_ROOT,
        AsolPermission.Update,
        APPLICATION_CODE.ORDER
      )
      .pipe(takeUntil(this.endSubject$))
      .subscribe((allowedChange) => {
        this.updateNonstandardOrgCusData = allowedChange;
      });
  }

  /** initial load of users data */
  private loadUser(): Observable<AsolPerson> {
    return this.subjectManager.getCurrentPersonObject().pipe(
      tap((response: AsolPerson) => {
        this.personData = response;
        const email = response.email ? response.email : this.auth.email;
        this.purchasingPerson.patchValue({
          firstName: response.name.firstName,
          lastName: response.name.surname,
          email: email,
          phoneNumber: response.getPhoneNumber() ?? '',
        });

        //for now for testing
        this.customer.controls['invoiceEmail'].setValue(email);
      })
    );
  }

  /** initial load of tenant data */
  private loadTenant(): Observable<AsolOrganization | null> {
    return this.orderService.getTenantOwnerOrganization().pipe(
      mergeMap((foundOrganization) => {
        if (!foundOrganization) {
          return of(null);
        }
        this.customer.patchValue({ code: foundOrganization.code });
        return this.orderService.getOrganizationsData(foundOrganization);
      }),
      tap((resp) => {
        if (!resp) {
          return;
        }
        this.organizationData = resp;
        this.customer.patchValue({
          name: resp.name,
          codeNumber: resp.organizationIdentification.number,
          /** vatIn can be null, although AsolOrganization has vatIn as string value always */
          vatIn: resp.vatIn ?? '',
        });

        const mainAddress = resp.addresses.find(
          (address: AsolAddress) =>
            address.systemAddressType !== null &&
            address.systemAddressType === 'Main'
        );
        if (!mainAddress) {
          return;
        }
        this.address.patchValue({
          street: mainAddress.line1,
          city: mainAddress.city,
          zipCode: mainAddress.zipCode,
          countryCode: mainAddress.countryCode,
        });
      })
    );
  }

  /**
   * USED WHEN DISABLED CONTROLS NEET TO BE VALIDATED.
   * Function to check the validity of a form control.
   * @param control - The form control to be checked.
   */
  private isFormControlValid(control: AbstractControl): boolean {
    if (!control.hasValidator(Validators.required)) {
      return true;
    }
    return control.disabled || (!!control.value && control.valid);
  }

  /**
   * USED WHEN DISABLED CONTROLS NEET TO BE VALIDATED.
   * Function to handle form changes for both purchasing person and customer forms.
   * If the condition is met, it enables the corresponding control.
   * @param control - The form control to be handled.
   * @param incomingData - data to be handled
   */
  private handleFormChanges(
    control: AbstractControl,
    incomingData: unknown
  ): void {
    const validData = !!incomingData;
    if (validData || !this.updateNonstandardOrgCusData) {
      return;
    }
    control.valueChanges.pipe(takeUntil(this.endSubject$)).subscribe(() => {
      this.checkFormValidity();
    });
    control.enable();
  }

  /**
   * function which checks form validity. It controls all fields, even disabled.
   * @param leaveTouched defines, whether all fields should be marked as touched or not
   * as result stepFilledController's value is set to true if everything is filled as it should be
   * and next step is allowed
   * otherwise user cannot go to the second step.
   */
  protected checkFormValidity(leaveTouched?: boolean): void {
    if (this.salesRepChanges.hasSomethingChanged()) {
      const isPurchasingPersonValid = this.isFormControlValid(
        this.purchasingPerson.controls.phoneNumber
      );

      const isFormValid =
        !!this.selectedOrganization &&
        !!this.selectedPerson &&
        isPurchasingPersonValid;

      this.stepFilledController?.setValue(isFormValid);
      return;
    }

    this.formSubs?.unsubscribe();

    if (this.selectedOrganization) {
      this.stepFilledController?.setValue(!!this.selectedPerson);
    } else if (this.infoLoaded) {
      this.purchasingPerson.markAllAsTouched();
      this.customer.enable();
      this.customer.controls.code.disable();
      this.customer.controls.codeNumber.disable();
      this.customer.markAllAsTouched();
      //during checking validation must formgroup be enabled

      if (this.purchasingPerson.valid && this.customer.valid) {
        this.stepFilledController?.setValue(true);
      } else {
        this.stepFilledController?.setValue(false);
        if (!leaveTouched) {
          this.purchasingPerson.markAsUntouched();
          this.customer.markAsUntouched();
        }
      }
      if (!this.allowOrganizationDataChange) {
        this.customer.disable();
      }
    }
    this.subscribeToForms();
  }

  /** Reaction to the next button click */
  protected nextButtonClicked(): void {
    // if something is not filled show it
    this.purchasingPerson.markAllAsTouched();
    this.customer.markAllAsTouched();

    // update validity of sstepFilledController
    this.checkFormValidity(true);

    if (!this.stepFilledController?.value) {
      this.dialogService.showErrorDialog(
        this.trans.get(TRANS.ORDER_PAGE, 'EmptyInputs')
      );
    }
  }

  /**
   * compare organzation data with actual form value (not by sales rep)
   * @returns true if something has been changed
   */
  private areOrganizationDataChanged(): boolean {
    const mainAddress = this.organizationData?.addresses.find(
      (address: AsolAddress) =>
        address.systemAddressType !== null &&
        address.systemAddressType === 'Main'
    );
    if (
      mainAddress?.city === this.address.value.city &&
      mainAddress?.line1 === this.address.value.street &&
      mainAddress?.zipCode === this.address.value.zipCode &&
      mainAddress?.countryCode === this.address.value.countryCode &&
      this.organizationData?.name === this.customer.value.name
    ) {
      return false;
    }
    return true;
  }

  /** sales rep function, which allows him to select another organization for the order */
  protected selectOrganization() {
    let selectedTableOrganization: AsolCustomerOrganization | undefined;
    this.organizationPicker
      .pickCustomerOrganization() //{ getRawTableData: true }
      .pipe(
        switchMap((tableData) => {
          if (!tableData) {
            return of();
          }
          selectedTableOrganization = tableData;
          return this.orderService.getOrganizationDataByTenantId(
            tableData.organizationIdentificationCountryCode,
            tableData.organizationIdentificationNumber,
            tableData.tenantId
          );
        })
      )
      .subscribe((org) => {
        if (!org || !selectedTableOrganization) {
          return;
        }
        selectedTableOrganization.address = {
          street: org.addresses[0]?.streetName ?? org.addresses[0]?.line1,
          city: org.addresses[0]?.city ?? '',
          zipCode: org.addresses[0]?.zipCode ?? '',
          countryCode: org.addresses[0]?.countryCode ?? '',
        };
        selectedTableOrganization.vatIn = org.vatIn ?? '';
        this.selectedOrganization = selectedTableOrganization;
        this.formSubs?.unsubscribe();

        this.customer.patchValue({
          tenantId: selectedTableOrganization.tenantId,
          invoiceEmail: '',
          name: org.name,
          code: `${selectedTableOrganization.organizationIdentificationNumber}|${selectedTableOrganization.organizationIdentificationCountryCode}`,
          codeNumber:
            selectedTableOrganization.organizationIdentificationNumber,
          vatIn: selectedTableOrganization.vatIn,
          mainAddress: selectedTableOrganization.address,
        });

        this.purchasingPerson.reset();
        this.selectedPerson = undefined;

        this.checkFormValidity();
        this.customer.disable();

        if (this.allowOrganizationDataChange) {
          this.customer.controls.vatIn.enable();
          this.customer.controls.name.enable();
          this.customer.controls.mainAddress.enable();
          this.customer.controls.invoiceEmail.enable();
        }

        this.purchasingPerson.disable();

        const formControlProperties = [
          {
            control: this.customer.controls.code,
            value: selectedTableOrganization?.organizationIdentificationNumber,
          },
        ];

        formControlProperties.forEach(({ control, value }) => {
          this.handleFormChanges(control, value);
        });
      });

    this.salesRepChanges.organizationChanged();
  }

  /** sales rep function, which allows him to select person of the selected organization */
  protected selectPerson(): void {
    if (!this.selectedOrganization) {
      return;
    }

    this.personPicker
      .pickCustomerPerson(this.selectedOrganization.tenantId)
      .subscribe((people) => {
        if (people && people[0]) {
          const person = people[0];
          this.purchasingPerson.patchValue({
            personId: person.personId,
            email: person.email,
            phoneNumber: person.phoneNumber,
            firstName: person.firstName,
            lastName: person.lastName,
            accountId: person.accountId,
            userName: person.userName,
          });

          this.customer.patchValue({
            invoiceEmail: person.email,
          });
          this.handleFormChanges(
            this.purchasingPerson.controls.phoneNumber,
            person.phoneNumber
          );
          this.selectedPerson = person;
        }
        this.checkFormValidity();
      });
  }

  /** when open dialog is clicked, emit event to the parent */
  protected openOrderDataDialog(): void {
    this.orderFormEvent.emit('openChangeDataDialog');
    this.resetFormOnSalesRepChanges();
    this.checkFormValidity();
  }

  /** when open dialog is clicked, emit event to the parent */
  protected openStaticDataDialog(): void {
    this.orderFormEvent.emit('openChangeStaticDataDialog');
    this.resetFormOnSalesRepChanges();
    this.checkFormValidity();
  }

  /**
   * reaction to button click. Emits event to the parent
   */
  protected openPriceDialog(): void {
    this.orderFormEvent.emit('openChangePriceDialog');
  }

  /**
   * When changing order data, User cannot order app for himself
   * Customer has to be selected.
   */
  private resetFormOnSalesRepChanges(): void {
    this.formSubs?.unsubscribe();

    if (!this.selectedOrganization) {
      this.purchasingPerson.reset();
      this.customer.reset();
      this.customer.disable();
      this.purchasingPerson.disable();
    }
  }

  /**
   * subscribe to form changes
   */
  private subscribeToForms(): void {
    this.formSubs = new Subscription();
    this.formSubs.add(
      this.purchasingPerson.valueChanges.subscribe(() => {
        this.checkFormValidity();
      })
    );
    this.formSubs.add(
      this.customer.valueChanges.subscribe(() => {
        this.checkFormValidity();
      })
    );
  }

  /**
   * fill order detail data with information that formGroups contatin
   * @param data order data which should be filled
   */
  public fillCustomerData(data: OrderDetailData): void {
    if (this.stepFilledController?.value) {
      this.personData?.setPhoneNumber(this.purchasingPerson.value.phoneNumber);

      data.customer = this.customer.getRawValue();
      data.purchasingPerson = this.purchasingPerson.getRawValue();
    }
  }

  /**
   * when creating order by customer (not the sales rep) information about
   * Person / Organization should be also filled.
   * @returns observable of changes that happened.
   */
  public subjectManagerChanges() {
    if (this.salesRepChanges.isOrganzationChanged()) {
      return of([]);
    }

    const updates = [];

    if (this.personData) {
      updates.push(
        this.subjectManager.updatePerson(this.personData).pipe(
          catchError(() => {
            return of(null);
          })
        )
      );
    }

    if (
      this.allowOrganizationDataChange &&
      this.organizationData &&
      this.areOrganizationDataChanged()
    ) {
      const data: UpdateOrganizationData = {
        address: {
          street: this.address.getRawValue().street,
          zipCode: this.address.getRawValue().zipCode,
          countryCode: this.address.getRawValue().countryCode,
          city: this.address.getRawValue().city,
        },
        name: this.customer.getRawValue().name,
        vatIn: this.customer.getRawValue().vatIn,
      };

      updates.push(
        this.orderService.updateOrganizationData(data).pipe(
          catchError(() => {
            return of(null);
          })
        )
      );
    }

    return updates.length ? forkJoin(updates) : of([]);
  }
}
