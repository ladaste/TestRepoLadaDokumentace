import {
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  QueryList,
  ViewChild,
  ViewChildren,
} from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MatExpansionPanel } from '@angular/material/expansion';
import { MatStepper } from '@angular/material/stepper';
import { ActivatedRoute, Router } from '@angular/router';
import { AsolLoaderService } from '@asol-platform/controls';
import {
  ASOL_GENERAL_TRANSLATION,
  AsolLocalizationService,
  AsolTranslationService,
} from '@asol-platform/core';
import {
  ASOL_DIALOG_MEDIUM,
  AsolDialogMessageService,
  AsolNavigationService,
} from '@asol-platform/services';
import {
  AppDetailEdition,
  AsolCustomerOrganizationPickerService,
  AsolCustomerPersonPickerService,
  AsolStoreAppDetail,
  AsolStoreAppDetailService,
  AsolStoreTypesService,
  BILLING_PERIOD,
  CustomPricePipe,
  EditionExtension,
  EditionHolderSelection,
  EditionSubscription,
  EditionsHolderComponent,
  LICENCE_ORDER_TYPE,
  ORDER_ERROR_CODE,
  OrderProposal,
  OrderResponse,
  hasEditionRole,
} from '@asol-platform/store';
import {
  Observable,
  Subject,
  finalize,
  find,
  forkJoin,
  mergeMap,
  takeUntil,
} from 'rxjs';
import { environment } from '../../../../../environments/environment';
import { CheckboxEvent } from '../../../../modules/order-detail-data/models/checkbox-event.interface';
import { DocumentEvent } from '../../../../modules/order-detail-data/models/document-event.interface';
import { OrderFinishedDialogComponent } from '../../../../shared/components/order-finished-dialog/order-finished-dialog.component';
import { TRANS } from '../../../../shared/constants/localization.constant';
import { OrderDocument } from '../../../../shared/models/order-document.interface';
import { OS_SECTION_VAL_CODE } from '../../../order-detail-data/constants/order-summary-section-value-code.constant';
import { OrderSummaryData } from '../../../order-detail-data/models/order-summary-data.interface';
import { OrderSummarySection } from '../../../order-detail-data/models/order-summary-section.interface';
import { EMPTY_ORDER_DATA } from '../../constants/empty-order-data.const';
import { OrderFormEvent } from '../../constants/order-form-events.type';
import { priceAdding } from '../../functions/price-adding.function';
import { CancelDataEvent } from '../../models/cancel-data-event.interface';
import { CustomPriceDialogData } from '../../models/custom-price-dialog-data.interface';
import { CustomPriceDialogResult } from '../../models/custom-price-dialog-result.interface';
import { CustomOtherDialogData } from '../../models/custom-static-dialog-data.interface';
import { OrderDetailData } from '../../models/order-detail-data.interface';
import { CancelSubscriptionService } from '../../services/cancel-subscription.service';
import { OrderService } from '../../services/order.service';
import { SalesRepChangesService } from '../../services/sales-rep-changes.service';
import { SummaryGeneratorService } from '../../services/summary-generator.service';
import { CustomizationOrderDataDialogComponent } from '../customization-order-data-dialog/customization-order-data-dialog.component';
import { CustomizationOtherDataDialogComponent } from '../customization-other-data-dialog/customization-other-data-dialog.component';
import { CustomizationPriceDataDialogComponent } from '../customization-price-data-dialog/customization-price-data-dialog.component';
import { OrderExtensionSelectionComponent } from '../order-extension-selection/order-extension-selection.component';
import { OrderFormComponent } from '../order-form/order-form.component';
import localization from './asol-order.translation.json';

@Component({
  selector: 'asol-platform-order',
  templateUrl: './asol-order.component.html',
  styleUrls: ['./asol-order.component.scss'],
  providers: [
    AsolCustomerOrganizationPickerService,
    AsolCustomerPersonPickerService,
    CustomPricePipe,
    SummaryGeneratorService,
    SalesRepChangesService,
    AsolStoreAppDetailService,
    CancelSubscriptionService,
  ],
})
export class AsolOrderComponent implements OnInit, OnDestroy {
  protected readonly TRANS = TRANS;
  protected readonly ASOL_GENERAL_TRANSLATION = ASOL_GENERAL_TRANSLATION;
  protected readonly BILLING_PERIOD = BILLING_PERIOD;

  /** whether app is loaded */
  private appLoaded = false;
  /** whether order form information is loaded */
  private orderFormLoaded = false;
  /** subject, which should be completed on destroy */
  private endSubject$ = new Subject<void>();

  /**
   * true, when user has trial and clicks on the order button
   * should select default edition
   */
  protected setDefault = false;
  /**
   * true, when user has order and wants to change subscription
   * not used right now as functionality was not specified yet
   */
  protected changeSubscription = false;

  /** detail info of the app user is ordering */
  protected appDetail: AsolStoreAppDetail | null = null;
  /** information which user wants to have preselected */
  protected proposal: OrderProposal | undefined;
  /** currently selected extensions */
  protected selectedExtensions: EditionExtension[] = [];

  /** if true, editions are shown, otherwise they are hidden */
  protected boxOfEditionOpened = false;
  /** object which should be send to the BE */
  protected orderDetailData: OrderDetailData = EMPTY_ORDER_DATA;
  /** date of the order -> today, if not changing yearly subscription */
  protected displayedDate = new Date();
  /** documents which should be shown on the last step of the order */
  protected documents: OrderDocument[] = [];

  /** when loading response of create order, new request has to be disabled. */
  protected sendingRequest = false;

  /** form control which controls going to the next step */
  protected orderFormFilled = new FormControl(false, [Validators.requiredTrue]);

  /** data needed to cancel the subscription */
  protected cancelData?: CancelDataEvent;
  /** total price of the selcted edition based on number of users */
  protected totalEditionPrice = 0;
  /** total count of the licence editions */
  protected totalUserCount = 0;
  /** currently selected billing period */
  protected actualBillingPeriod: string = BILLING_PERIOD.MONTHLY;
  /** currently selected edition */
  protected selectedEdition: AppDetailEdition | undefined;

  /** initial value for the edition holder */
  protected boxHandlerInitialValue: EditionHolderSelection | null = null;

  private lastSavedChange: Partial<EditionHolderSelection> = {};
  private lastChange: Partial<EditionHolderSelection> = {};

  /**
   * details section, which should be displayed for every user at the last step
   * they are also for sales rep, who can change them.
   */
  protected customizableOrderSections: OrderSummarySection[] =
    this.summaryGenerator.initializeChangingDetailsSection();

  protected localOrderResponse: OrderResponse<OrderSummaryData> | undefined;

  protected termAndConditionsNotAccepted = false;

  @ViewChild(MatStepper) matStepper: MatStepper | undefined;
  @ViewChild(OrderFormComponent) orderForm: OrderFormComponent | undefined;
  @ViewChildren(EditionsHolderComponent) editionHolder:
    | QueryList<EditionsHolderComponent>
    | undefined;

  @ViewChild(OrderExtensionSelectionComponent)
  extensionSelection: OrderExtensionSelectionComponent | undefined;

  /**
   * displaying second step, when there is at least one extension in the app (in any edition)
   */
  protected showExtensionSelection = true;

  @ViewChildren('EditionExpansionPanel') expansionPanels:
    | QueryList<MatExpansionPanel>
    | undefined;

  constructor(
    protected trans: AsolTranslationService,
    protected loc: AsolLocalizationService,
    private dataProvider: AsolStoreAppDetailService,
    private orderService: OrderService,
    private loader: AsolLoaderService,
    private route: ActivatedRoute,
    private router: Router,
    private cdr: ChangeDetectorRef,
    private dialogMessageService: AsolDialogMessageService,
    private typesService: AsolStoreTypesService,
    protected salesRepChanges: SalesRepChangesService,
    private summaryGenerator: SummaryGeneratorService,
    private navigationService: AsolNavigationService,
    private cancelSubscription: CancelSubscriptionService
  ) {
    this.trans.initialize(TRANS.ORDER_PAGE, localization);

    this.loc.updated.pipe(takeUntil(this.endSubject$)).subscribe(() => {
      if (this.proposal) {
        this.loader.start();
        this.getAppDetail(this.proposal, this.matStepper?.selectedIndex);
      }

      this.customizableOrderSections =
        this.summaryGenerator.initializeChangingDetailsSection();
    });
  }

  ngOnInit(): void {
    const propId = this.route.snapshot.params.proposalId;
    if (!propId) {
      return;
    }
    this.loader.start();
    this.orderDetailData.proposalId = propId;
    this.loadApp(propId);

    const queryParams = this.route.snapshot.queryParams;
    this.setDefault = !!queryParams.setDefault;
    this.changeSubscription = !!queryParams.changeSubscription;
  }

  ngOnDestroy(): void {
    this.endSubject$.next();
    this.endSubject$.complete();
  }

  /**
   * initial loadiing of order details
   */
  private loadApp(proposalId: string): void {
    this.appLoaded = false;
    this.orderService.getOrderProposal(proposalId).subscribe((proposal) => {
      // get proposal by id which is in Input()
      // then get info about app to show it in app card on top of page
      // then set billinPeriod and proposal
      this.proposal = proposal;
      this.getAppDetail(proposal);
    });

    this.orderService.getDocuments().subscribe((response) => {
      this.documents = response.items;
      // getting actual versions of legal documents
    });
  }

  /**
   * initial load of details for app, which is user ordering.
   * After appDetail is loaded, it should initialize order summary. Also it should update third tab texts, if needed (via changedStep function)
   * @param proposal proposal for order
   * @param tabIndex - index of the current tab displayed.
   */
  private getAppDetail(proposal: OrderProposal, tabIndex?: number) {
    forkJoin({
      detail: this.dataProvider.getAppDetail(proposal.solutionPackageId),
      typesServiceLoaded: this.typesService.loaded$.pipe(
        takeUntil(this.endSubject$),
        find((loaded) => loaded)
      ),
    }).subscribe((response: { detail: AsolStoreAppDetail }) => {
      // getting appDetail which should be shown.
      // it is here because of language changes and
      // dissappearing of box of editions
      this.appDetail = null;
      this.cdr.detectChanges();
      this.appDetail = response.detail;

      // third step generation
      this.summaryGenerator.initializeOrderSummary(this.appDetail);
      if (tabIndex !== undefined) {
        this.changedStep(tabIndex);
      }

      this.orderDetailData.solutionPackageId = this.appDetail.id;
      this.orderDetailData.licenceProvider = this.appDetail.licenceProvider;

      this.appDetail.editions = this.appDetail.editions.filter((edition) =>
        edition.subscriptions.find(
          (sub) =>
            sub.subscriptionData.orderType === LICENCE_ORDER_TYPE.STANDARD
        )
      );

      /**
       * only those extensions should be shown, which has at least one subscription
       */
      this.showExtensionSelection = !!this.appDetail.editions.find(
        (e) => !!e.extensions.filter((ext) => !!ext.subscriptions.length).length
      );

      this.appDetail.editions.forEach((edition) => {
        edition.extensions.forEach((extension) => {
          extension.count = extension.extensionData.defaultLicenceCount ?? 1;
          extension.expanded = false;
          extension.price = 0;
        });
      });

      let edition: AppDetailEdition | undefined;
      let sub: EditionSubscription | undefined;
      //select default edition
      edition = this.appDetail.editions.find(
        (edition) =>
          (this.setDefault && edition.default) ||
          (!this.setDefault && edition.id === this.proposal?.editionId)
      );
      if (!edition) {
        if (this.appDetail.editions.length > 0) {
          edition = this.appDetail.editions[0];
        } else {
          return;
        }
      }

      if (this.setDefault && edition.subscriptions.length) {
        sub = edition.subscriptions[0];
      } else {
        sub = edition.subscriptions.find(
          (s) => s.id === this.proposal?.subscriptions?.[0]?.id
        );
      }

      const defaultBillingPeriod =
        this.typesService.parseBillingCode(sub?.billingPeriodCode) ??
        BILLING_PERIOD.MONTHLY;
      this.actualBillingPeriod = defaultBillingPeriod;

      this.boxHandlerInitialValue = {
        selectedEdition: edition,

        selectedSubscription: sub,
        totalPrice: 0,
        billingPeriod: defaultBillingPeriod,
        salesItems: proposal.subscriptions?.[0]?.salesItems ?? [],
      };

      this.boxOfEditionOpened =
        this.setDefault || (this.changeSubscription && !!this.proposal);

      this.appLoaded = true;

      this.selectedEdition = edition;

      if (this.allLoaded()) this.loader.stop();
    });
  }

  /**
   * part of the initial loading. When everything is loaded, it should stop the loader
   */
  private formLoaded(): void {
    this.orderFormLoaded = true;
    if (this.allLoaded()) this.loader.stop();
  }

  /**
   * Check whether all data are loaded
   * @returns current state of loading
   */
  private allLoaded(): boolean {
    return this.appLoaded && this.orderFormLoaded;
  }

  /**
   * Reaction to all events from order form. Based on the event type, it call other methods.
   * @param event - event from order form
   */
  protected reactionToOrderFormEvent(event: OrderFormEvent) {
    switch (event) {
      case 'openChangeDataDialog':
        this.openChangeDataDialog();
        break;
      case 'openChangePriceDialog':
        this.openChangePriceDialog();
        break;
      case 'openChangeStaticDataDialog':
        this.openStaticDataDialog();
        break;
      case 'formLoaded':
        this.formLoaded();
        break;
    }
  }

  /**
   * reaction to change of the checkboxes value. Only used for calculationType Second. (and newer, when there is orderDetailData component)
   * @param event CheckboxEvent from order detail template
   */
  protected conditionsAccepted(event: CheckboxEvent): void {
    this.orderDetailData.termsAndConditionsAccepted =
      event.value[OS_SECTION_VAL_CODE.CUSTOMER_CONSENT.CHECKBOX_1];
    this.orderDetailData.marketingConditionsAccepted =
      event.value[OS_SECTION_VAL_CODE.CUSTOMER_CONSENT.CHECKBOX_2];

    this.termAndConditionsNotAccepted =
      this.termAndConditionsNotAccepted &&
      !this.orderDetailData.termsAndConditionsAccepted;
  }

  /**
   * function for submitting whole order
   * done after second step of the order
   * This param became deprecated, as checkboxes update their value on click.
   */
  protected onSubmit(): void {
    if (this.sendingRequest) {
      return;
    }

    /**
     * However, if salesRep hasSomethingChanged, acceptance should be reset.
     */
    if (this.salesRepChanges.hasSomethingChanged()) {
      this.orderDetailData.termsAndConditionsAccepted = false;
      this.orderDetailData.marketingConditionsAccepted = false;
    } else if (!this.orderDetailData.termsAndConditionsAccepted) {
      this.termAndConditionsNotAccepted = true;
      return;
    }
    this.termAndConditionsNotAccepted = false;

    if (this.salesRepChanges.hasSomethingChanged()) {
      const detailSections: OrderSummarySection[] = JSON.parse(
        JSON.stringify(this.customizableOrderSections)
      );
      detailSections.forEach((section) => {
        section.sectionContent.forEach((content) => {
          delete content.valueControl;
          delete content.nameControl;
        });
      });

      this.orderDetailData.orderSectionModels = detailSections;
    }

    this.sendingRequest = true;
    this.loader.start();

    if (!this.orderForm) {
      return;
    }

    this.orderForm
      .subjectManagerChanges()
      .pipe(
        mergeMap(() => {
          return this.orderService.createOrder(this.orderDetailData);
        }),
        finalize(() => {
          this.loader.stop();
          this.sendingRequest = false;
        })
      )
      .subscribe({
        next: (response) => {
          if (!response.orderNumber) {
            return;
          }
          let dialogObservable: Observable<unknown> | undefined;
          if (this.salesRepChanges.hasSomethingChanged()) {
            dialogObservable = this.dialogMessageService.showInfoDialog(
              this.trans.get(TRANS.ORDER_PAGE, 'OrderCreatedTitle'),
              this.trans.get(TRANS.ORDER_PAGE, 'OrderCreated')
            );
          } else {
            dialogObservable = this.dialogMessageService
              .openDialog(
                OrderFinishedDialogComponent,
                {
                  data: {
                    bought: response.orderNumber,
                    date: response.createdOn,
                  },
                },
                ASOL_DIALOG_MEDIUM
              )
              .afterClosed();
          }

          dialogObservable.subscribe(() => {
            this.router.navigate(['my-apps']);
          });
        },
        error: (err) => {
          if (err.error.errorCode === ORDER_ERROR_CODE.ORDER_ALREADY_ORDERED) {
            this.dialogMessageService.showInfoDialog(
              this.trans.get(TRANS.ORDER_PAGE, 'CannotOrderAgainTitle'),
              this.trans.get(TRANS.ORDER_PAGE, 'CannotOrderAgainText'),
              { primaryButtonType: 'Close' }
            );
          } else {
            this.dialogMessageService.showErrorDialog(`${err.error.title}`);
          }
        },
      });
  }

  /**
   * reaction to the mat stepper's step change
   * @param stepIndex - index of the step user is going to
   * if user goes to the last page, orderResponse for the OrderDetailDataComponent should be regenerated
   */
  protected changedStep(stepIndex: number) {
    if (!this.matStepper || !this.appDetail) {
      return;
    }

    if (stepIndex === 0) {
      this.boxOfEditionOpened = this.changeSubscription;
    } else {
      this.boxOfEditionOpened = false;
    }

    this.orderForm?.fillCustomerData(this.orderDetailData);
    this.extensionSelection?.fillExtensions(this.orderDetailData);

    if (stepIndex === this.matStepper.steps.length - 1) {
      this.localOrderResponse = undefined;

      /**
       * to reload orderDetailData component, as productOrderResponse return object
       * with same objectReference (baseResponse is save in the summary generator)
       */
      this.cdr.detectChanges();

      this.loader.start();
      this.typesService.loaded$
        .pipe(
          takeUntil(this.endSubject$),
          find((loaded) => loaded),
          finalize(() => {
            this.loader.stop();
          })
        )
        .subscribe(() => {
          if (!this.selectedEdition) {
            return;
          }
          this.localOrderResponse = this.summaryGenerator.productOrderResponse(
            this.orderDetailData,
            this.selectedEdition,
            this.selectedExtensions
          );
        });
    }
  }

  /**
   * function which handles cancellation of subscription
   */
  protected cancelSub() {
    if (!this.appDetail) {
      return;
    }

    this.cancelSubscription
      .getOrderLicenceInfo(this.appDetail.id)
      .subscribe((app) => {
        if (!app?.orderNumber || !this.appDetail) {
          return;
        }
        this.cancelData = {
          orderNumber: app.orderNumber,
          appName: this.appDetail.name,
          billingPeriod: this.actualBillingPeriod,
        };
      });
  }

  /**
   * Cancel changes -> everything changed should be reverted and panel should be closed
   * @param panel - panel which is being closed
   */
  protected cancelChanges(panel: MatExpansionPanel) {
    this.actualizeProposal(this.lastSavedChange);
    panel.close();
  }

  /**
   * updated proposal, so it can return to this state in future
   * @param panel - panel which is being closed
   */
  protected saveChanges(panel: MatExpansionPanel) {
    this.lastSavedChange = this.lastChange;
    panel.close();
  }

  /**
   * actualization of proposal from edition holder
   * reacting to event
   * @param selectionChange event from edition holder, when something is changed
   */
  protected actualizeProposal(
    selectionChange: Partial<EditionHolderSelection>,
    updateEditionHolder = true
  ) {
    if (!this.proposal) {
      return;
    }

    this.lastSavedChange = selectionChange;
    this.lastChange = selectionChange;

    if (updateEditionHolder) {
      this.editionHolder?.forEach((holder) => {
        holder.acceptChange(selectionChange);
      });
    }

    const edition = selectionChange.selectedEdition;
    if (edition) {
      this.proposal.editionId = edition.id;
      this.selectedEdition = edition;

      if (
        !this.changeSubscription &&
        !this.setDefault &&
        this.selectedEdition.name !== edition.name
      ) {
        this.boxOfEditionOpened = false;
      }
      this.selectedEdition.name = edition.name;

      this.proposal.featureIds = edition.features.map(({ id }) => id);
    }

    this.proposal.subscriptions = [
      {
        id: selectionChange.selectedSubscription?.id ?? '',
        salesItems: selectionChange.salesItems ?? [],
      },
    ];

    this.totalUserCount =
      selectionChange.salesItems?.reduce(
        (acc, curr) => acc + curr.licenceRole.roleCount,
        0
      ) ?? 0;

    if (selectionChange.totalPrice) {
      this.totalEditionPrice = selectionChange.totalPrice;
    }
    if (selectionChange.billingPeriod) {
      this.actualBillingPeriod = selectionChange.billingPeriod;
    }

    // actualize OrderDetailData
    this.orderDetailData.editionId = this.proposal.editionId;
    this.orderDetailData.featureIds = this.proposal.featureIds;
    // set subscriptions. But removed licenceRoles, that has roleCount = 0
    // as user should not be able to order 0 units.
    // also removed those roles, which are not defined in the edition
    this.orderDetailData.subscriptions =
      this.proposal.subscriptions?.map((sub) => {
        sub.salesItems = sub.salesItems?.filter(
          (s) =>
            hasEditionRole(edition, s.licenceRole.roleCode) &&
            s.licenceRole.roleCount
        );
        return sub;
      }) ?? [];

    this.acutalizeTotalPrice();

    this.actualizeFixedSections();

    // to force Angular to check expression again, as it might be in middle of one already
    // ExpressionChangedAfterItHasBeenCheckedError
    this.cdr.detectChanges();
  }

  /**
   * reaction to the extension selection
   * @param extensions - selected extensions
   */
  protected extensionsSelected(extensions: EditionExtension[]) {
    this.selectedExtensions = extensions;
    this.actualizeFixedSections();
    this.acutalizeTotalPrice();
  }

  /**
   * When something (affecting final tab) is changed in the order, this function is called
   * It actualizes the orderDetailData and pricing.
   */
  private actualizeFixedSections() {
    if (!this.appDetail) {
      return;
    }

    if (this.orderDetailData) {
      this.orderDetailData.price = this.totalEditionPrice;
      this.selectedExtensions.forEach((ext) => {
        if (this.orderDetailData && ext.price)
          this.orderDetailData.price = priceAdding(
            this.orderDetailData.price,
            ext.price
          );
      });
    }
  }

  /**
   * When price is changed, this function is called
   * It actualizes the orderDetailData and pricing.
   */
  private acutalizeTotalPrice() {
    this.orderDetailData.price = this.totalEditionPrice;
    this.selectedExtensions.forEach((ext) => {
      if (ext.price) {
        this.orderDetailData.price = priceAdding(
          this.orderDetailData.price,
          ext.price
        );
      }
    });
  }

  /**
   * THIS PART SHOULD SERVE AS ADDING SOME CUSTOMIZATION TO THE STANDARD ORDER:
   */
  protected openChangeDataDialog() {
    if (!this.salesRepChanges.isDetailsSectionChanged()) {
      if (this.appDetail && this.selectedEdition) {
        this.salesRepChanges.detailsSectionChanged();

        this.customizableOrderSections =
          this.summaryGenerator.initializeChangingDetailsSection();
      }
    }
    this.dialogMessageService.openDialog(
      CustomizationOrderDataDialogComponent,
      {
        data: { sections: this.customizableOrderSections },
      },
      ASOL_DIALOG_MEDIUM
    );
  }

  /**
   * THIS PART SHOULD SERVE AS ADDING SOME CUSTOMIZATION TO THE STANDARD ORDER:
   */
  protected openStaticDataDialog(): void {
    if (!this.salesRepChanges.isStaticDataChanged()) {
      if (this.appDetail && this.selectedEdition) {
        this.salesRepChanges.staticDataChanged();
      }
    }

    const staticDialogData: CustomOtherDialogData = {
      additionalInformation: this.selectedEdition?.description,
    };

    const dialogRef = this.dialogMessageService.openDialog(
      CustomizationOtherDataDialogComponent,
      {
        data: staticDialogData,
      },
      ASOL_DIALOG_MEDIUM
    );

    dialogRef.afterClosed().subscribe((value: CustomOtherDialogData | null) => {
      if (!value) {
        return;
      }
      // Remape data from dialog
      if (value.additionalInformation) {
        this.selectedEdition!.description = value.additionalInformation;
        this.orderDetailData.orderDetailsAdditionalInformation =
          value.additionalInformation;
      }
    });
  }

  /**
   * With price change, user should be able to update price and of the orders without
   * some of the restrictions (max / min users, dependency matrix)
   */
  protected openChangePriceDialog() {
    if (!this.selectedEdition || !this.appDetail || !this.proposal) {
      return;
    }
    const dialogData: CustomPriceDialogData = {
      appDetail: this.appDetail,
      selectedEdition: this.selectedEdition,
      proposal: this.proposal,
      firstInvoiceDate: this.orderDetailData.firstInvoiceDate,
      typesService: this.typesService,
    };

    this.typesService.loaded$
      .pipe(
        takeUntil(this.endSubject$),
        find((loaded) => loaded)
      )
      .subscribe(() => {
        const dialogRef = this.dialogMessageService.openDialog(
          CustomizationPriceDataDialogComponent,
          {
            data: dialogData,
          },
          ASOL_DIALOG_MEDIUM
        );
        dialogRef
          .afterClosed()
          .subscribe((value: CustomPriceDialogResult | null) => {
            if (!value) {
              return;
            }

            this.salesRepChanges.priceDataChanged();

            this.actualizeProposal(
              {
                ...value.editionSelectionData,
              },
              false
            );

            this.orderDetailData.firstInvoiceDate = value.firstInvoiceDate;

            this.expansionPanels?.forEach((panel) => {
              panel.close();
            });
          });
      });
  }

  /**
   * open the document user has clicked on.
   * @param type type of the document (if one of the base documents)
   * @param document document name (if one of the additional documents)
   * as result, content manager url should be open in new tab, where document is downloaded
   */
  protected docClicked(event: DocumentEvent): void {
    if (event.additionalFileId) {
      this.navigationService.openExternalUrl(
        environment.contentManagerUrl +
          '/api/v1/PublicFiles/' +
          event.additionalFileId
      );
    } else {
      // to get type of the file from code of the content
      const type = event.type?.replace('customerConsent', '');
      const file = this.documents.find(
        (doc) => doc.type == type && doc.languageCode === this.loc.locale
      );
      if (!file) {
        return;
      }
      this.navigationService.openExternalUrl(
        environment.contentManagerUrl + '/api/v1/PublicFiles/Path/' + file.path
      );
    }
  }
}
