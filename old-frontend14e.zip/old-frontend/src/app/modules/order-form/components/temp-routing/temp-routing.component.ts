import { Component } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Subject, takeUntil } from 'rxjs';

/**
 * @deprecated - should be removed arround 10/2023 - when the old routing will be removed
 * This component is used to redirect to the correct order summary component.
 * It is used only for the transition period when we are migrating from the old routing to the new one.
 */
@Component({
  selector: 'app-temp-routing',
  template: '',
})
export class TempRoutingComponent {
  private subs = new Subject<void>();

  constructor(private router: Router, private route: ActivatedRoute) {
    this.router.events.pipe(takeUntil(this.subs)).subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.processNavigation();
      }
    });
  }
  ngOnDestroy() {
    this.subs.next();
    this.subs.unsubscribe();
  }

  /**
   * get query params and redirect to the correct order summary route
   */
  private processNavigation(): void {
    const proposalId = this.route.snapshot.queryParams.proposalId;
    if (proposalId) {
      this.router.navigate(['../', proposalId], { relativeTo: this.route });
      return;
    }

    this.router.navigate(['store/subscriptions'], { relativeTo: this.route });
  }
}
