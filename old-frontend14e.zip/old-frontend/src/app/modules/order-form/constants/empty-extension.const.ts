export const EMPTY_EXTENSIONS = 'Path/asol/publicportal/no-extension.png';
