import { OrderDetailData } from '../models/order-detail-data.interface';

export const EMPTY_ORDER_DATA: OrderDetailData = {
  editionId: '',
  featureIds: [],
  solutionPackageId: '',
  purchasingPerson: {
    email: '',
    phoneNumber: '',
    firstName: '',
    lastName: '',
  },
  customer: {
    name: '',
    code: '',
    vatIn: '',
    invoiceEmail: '',
    mainAddress: {
      street: '',
      city: '',
      countryCode: '',
      zipCode: '',
    },
  },
  price: 0,
  subscriptions: [],
  extensions: [],
  proposalId: '',
  marketingConditionsAccepted: false,
  termsAndConditionsAccepted: false,
  deeplinkBaseUrl: window.location.origin,
  licenceProvider: '',
  orderDetailsAdditionalInformation: undefined,
};
