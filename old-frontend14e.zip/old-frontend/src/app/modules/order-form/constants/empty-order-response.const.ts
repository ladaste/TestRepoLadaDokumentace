import { OrderResponse } from '@asol-platform/store';
import { OrderSummaryData } from '../../order-detail-data/models/order-summary-data.interface';

export const EMPTY_ORDER_RESPONSE: OrderResponse<OrderSummaryData> = {
  id: '',
  orderNumber: '',
  licenceId: '',
  licenceCode: '',
  orderLines: [],
  customer: {
    name: '',
    code: '',
    number: '',
    vatIn: '',
    invoiceEmail: '',
    mainAddress: {
      city: '',
      street: '',
      zipCode: '',
      countryCode: '',
    },
  },
  supplier: {
    name: '',
    code: '',
    vatIn: '',
    mainAddress: {
      city: '',
      street: '',
      zipCode: '',
      countryCode: '',
    },
    registryInfo: '',
  },
  createdBy: {
    accountId: '',
    personId: '',
    userName: '',
    email: '',
    phoneNumber: '',
    firstName: '',
    lastName: '',
  },
  createdOn: '',
  totalPriceWithoutVat: 0,
  vat: 0,
  productId: '',
  isTesting: false,

  orderSummary: {
    // required but can be default
    orderSections: [],
    productId: '',
    orderNumber: '',
    createdOn: '',
    orderPrice: 0,
    orderBillingPeriod: '',
    languageCode: '',
  },
};
