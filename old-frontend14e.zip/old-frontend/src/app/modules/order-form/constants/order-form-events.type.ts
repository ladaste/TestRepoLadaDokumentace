export type OrderFormEvent =
  | 'formLoaded'
  | 'openChangeDataDialog'
  | 'openChangeStaticDataDialog'
  | 'openChangePriceDialog';
