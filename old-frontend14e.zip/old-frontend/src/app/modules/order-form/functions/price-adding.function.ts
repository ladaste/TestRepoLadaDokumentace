const multiplier = 100;
/**
 * Add to prices, which can be decimal.
 * All prices should have max 2 decimal places
 * @param a first price
 * @param b second price
 * @return sum of the prices with precision to two decimal places
 */
export function priceAdding(a: number, b: number): number {
  /** to count in the integers */
  const first = Math.round(a * multiplier);
  /** to count in the integers */
  const second = Math.round(b * multiplier);

  const sum = (first + second) / multiplier;

  return sum;
}
