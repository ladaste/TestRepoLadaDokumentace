export interface CancelDataEvent {
  orderNumber: string;
  appName: string;
  billingPeriod: string;
}
