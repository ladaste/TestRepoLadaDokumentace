export interface CancelSubscribeData {
  orderNumber: string;
  cancelationReason: string;
  cancelationMessage: string;
  improvementsMessage: string;
  deeplinkBaseUrl: string;
}
