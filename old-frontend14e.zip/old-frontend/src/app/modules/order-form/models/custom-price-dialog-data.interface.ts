import {
  AppDetailEdition,
  AsolStoreAppDetail,
  AsolStoreTypesService,
  OrderProposal,
} from '@asol-platform/store';

export interface CustomPriceDialogData {
  appDetail: AsolStoreAppDetail;
  proposal: OrderProposal;
  selectedEdition: AppDetailEdition;
  firstInvoiceDate?: string;

  /** because of dependency issue when it is provided in Module Federation */
  typesService: AsolStoreTypesService;
}
