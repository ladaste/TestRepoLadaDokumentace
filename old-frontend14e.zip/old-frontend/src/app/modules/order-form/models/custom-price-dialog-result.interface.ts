import { EditionHolderSelection } from '@asol-platform/store';

export interface CustomPriceDialogResult {
  editionSelectionData: Partial<EditionHolderSelection>;
  firstInvoiceDate?: string;
}
