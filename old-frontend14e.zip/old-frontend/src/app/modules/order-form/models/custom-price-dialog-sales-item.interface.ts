import { FormControl, FormGroup } from '@angular/forms';

export interface CustomPriceDialogSalesItem {
  id: string;
  roleCode: string;
  name?: string;
  label: string;
  form: FormGroup<{
    roleCount: FormControl<number>;
    rolePrice: FormControl<number>;
    unitPrice: FormControl<string>;
  }>;
}
