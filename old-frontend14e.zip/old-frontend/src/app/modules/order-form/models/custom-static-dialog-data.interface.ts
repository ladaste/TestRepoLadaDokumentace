export interface CustomOtherDialogData {
  additionalInformation?: string;
}
