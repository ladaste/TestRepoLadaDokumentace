import { AsolUserOrganization } from '@asol-platform/authentication';

export interface ExtendUserOrganization extends AsolUserOrganization {
  isTenantOwner?: boolean;
  code?: string;
}
