export interface OrderAcceptance {
  termsAndConditionsAccepted: boolean;
  marketingConditionsAccepted: boolean;
}
