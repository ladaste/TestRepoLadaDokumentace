export interface OrderCustomer {
  name: string;
  code: string;
  vatIn: string;
  invoiceEmail: string;
  tenantId?: string;
  mainAddress: {
    street: string;
    city: string;
    zipCode: string;
    countryCode: string;
  };
}
