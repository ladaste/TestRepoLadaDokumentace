import {
  OrderProposalExtension,
  OrderProposalSubscription,
} from '@asol-platform/store';
import { OrderSummarySection } from '../../order-detail-data/models/order-summary-section.interface';
import { OrderCustomer } from './order-customer.interface';
import { OrderPurchasingPerson } from './order-purchasing-person.interface';

export interface OrderDetailData {
  editionId: string;
  featureIds: Array<string>;
  solutionPackageId: string;
  purchasingPerson: OrderPurchasingPerson;
  customer: OrderCustomer;
  price: number;
  unpaidBalance?: number;
  previousPrice?: number;
  proposalId: string;
  termsAndConditionsAccepted: boolean;
  marketingConditionsAccepted: boolean;
  orderSectionModels?: OrderSummarySection[];
  deeplinkBaseUrl: string;
  orderDetailsAdditionalInformation?: string;

  subscriptions: OrderProposalSubscription[];
  extensions: OrderProposalExtension[];

  firstInvoiceDate?: string;
  licenceProvider?: string;
}
