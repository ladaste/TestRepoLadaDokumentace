import { AsolOrganization, AsolPerson } from '@asol-platform/services';
import { OrderCustomer } from './order-customer.interface';
import { OrderPurchasingPerson } from './order-purchasing-person.interface';

export interface OrderFormFilledData {
  purchasingPerson: OrderPurchasingPerson;
  customer: OrderCustomer;
  personData?: AsolPerson;
  organizationData?: AsolOrganization;
}
