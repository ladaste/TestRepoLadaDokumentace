// not needed bcs nothing is used from this model
// import { OrderLicenceRole } from './order-licence-role.interface';
// export interface OrderLicenceInformation {
//   editionName: string;
//   licenceCode: string;
//   orderLineId: string;
//   isTrial: boolean;
//   statusDescription: string;
//   validFrom: string;
//   validTo: string;
//   allowedOperation: string;
//   role: OrderLicenceRole;
// }
