// not needed bcs nothing is used from this model
// export interface OrderLicenceRole {
//   roleCode: string;
//   roleName: string;
//   userCount: number;
//   userMaxCount: number;
// }
