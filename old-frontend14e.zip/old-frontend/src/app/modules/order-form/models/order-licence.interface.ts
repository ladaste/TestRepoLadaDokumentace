export interface OrderLicence {
  orderNumber: string;
  // not needed bcs nothing is used from this model
  // licenceInformationModels: OrderLicenceInformation[];
}
