export interface OrderPaymentData {
  name: string;
  amount: string;
  unit: string;
  price: string;
}
