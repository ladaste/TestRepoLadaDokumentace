export interface OrderPurchasingPerson {
  email: string;
  phoneNumber: string;
  firstName: string;
  lastName: string;
}
