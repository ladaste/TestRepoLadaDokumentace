export interface PurchasedApp {
  id: string;
  orderNumber: string;
}
