export interface SalesRepChanges {
  organizationChange: boolean;
  detailsSectionChange: boolean;
}
