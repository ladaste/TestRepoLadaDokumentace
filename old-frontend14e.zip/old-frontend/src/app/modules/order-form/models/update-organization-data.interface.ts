export interface UpdateOrganizationData {
  address: {
    street: string;
    city: string;
    zipCode: string;
    countryCode: string;
  };
  vatIn: string;
  name: string;
}
