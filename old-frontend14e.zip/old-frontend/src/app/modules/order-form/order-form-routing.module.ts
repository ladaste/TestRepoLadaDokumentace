import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AsolAuthGuard } from '@asol-platform/authentication';

import { AsolOrderComponent } from './components/order/asol-order.component';
import { TempRoutingComponent } from './components/temp-routing/temp-routing.component';

const routes: Routes = [
  { path: '', redirectTo: 'temp', pathMatch: 'full' },
  { path: 'temp', component: TempRoutingComponent },
  {
    path: ':proposalId',
    component: AsolOrderComponent,
    canActivate: [AsolAuthGuard],
    data: {
      login: true,
      backToOrigin: true,
      hideSidemenu: {
        desktop: true,
      },
      permissionAppCode: 'ASOLEU-PlatformStoreOrder-AP-',
      permissionPageCode: 'store-lib-store-order-route',
      isSharedPage: true,
    },
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OrderFormRoutingModule {}
