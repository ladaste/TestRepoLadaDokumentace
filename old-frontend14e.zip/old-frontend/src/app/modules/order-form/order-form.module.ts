import { NgModule } from '@angular/core';
import {
  AsolDialogModule,
  AsolDirectivesModule,
  AsolInfoboxModule,
  AsolProgressScaleModule,
  AsolSliderModule,
} from '@asol-platform/controls';
import {
  AppWideInfoCardComponent,
  EditionsHandlerModule,
} from '@asol-platform/store';
import { SharedModule } from '../../shared/modules/shared.module';
import { StoreLibProviderModule } from '../../shared/modules/store-lib-provider.module';
import { OrderDetailDataModule } from '../order-detail-data/order-detail-data.module';
import { CancelSubscriptionComponent } from './components/cancel-subscription/cancel-subscription.component';
import { CustomizationOrderDataDialogComponent } from './components/customization-order-data-dialog/customization-order-data-dialog.component';
import { CustomizationOtherDataDialogComponent } from './components/customization-other-data-dialog/customization-other-data-dialog.component';
import { CustomizationPriceDataDialogComponent } from './components/customization-price-data-dialog/customization-price-data-dialog.component';
import { OrderExtensionSelectionComponent } from './components/order-extension-selection/order-extension-selection.component';
import { OrderFormComponent } from './components/order-form/order-form.component';
import { AsolOrderComponent } from './components/order/asol-order.component';
import { OrderFormRoutingModule } from './order-form-routing.module';
import { OrderService } from './services/order.service';

@NgModule({
  declarations: [
    OrderFormComponent,
    AsolOrderComponent,
    CancelSubscriptionComponent,
    CustomizationOrderDataDialogComponent,
    OrderExtensionSelectionComponent,
    CustomizationPriceDataDialogComponent,
    CustomizationOtherDataDialogComponent,
  ],
  imports: [
    SharedModule,
    OrderFormRoutingModule,
    StoreLibProviderModule,
    EditionsHandlerModule,
    AsolInfoboxModule,
    AsolDialogModule,
    AsolSliderModule,
    AsolProgressScaleModule,
    OrderDetailDataModule,
    AppWideInfoCardComponent,
    AsolDirectivesModule,
  ],
  providers: [OrderService],
  exports: [AsolOrderComponent],
})
export class OrderFormModule {}
