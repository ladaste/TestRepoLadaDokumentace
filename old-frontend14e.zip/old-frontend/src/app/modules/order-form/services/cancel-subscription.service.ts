import { Injectable } from '@angular/core';
import { AsolApiDataService } from '@asol-platform/services';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { CancelSubscribeData } from '../models/cancel-subscribe-data.interface';
import { OrderLicence } from './../models/order-licence.interface';

@Injectable()
export class CancelSubscriptionService {
  constructor(private apiDataService: AsolApiDataService) {}

  /**
   * cancel subscription - send request to backend
   * @param data - data for request
   * @returns observable with response
   */
  sendUnsubcribeRequest(data: CancelSubscribeData): Observable<null> {
    return this.apiDataService.create(
      environment.platformStoreOrderUrl + '/api/v1/Order/Unsubscribe',
      data
    );
  }

  /**
   * get order licence info
   * @param appId - id of the app
   * @returns observable with info
   */
  getOrderLicenceInfo(
    productCatalogId: string
  ): Observable<OrderLicence | undefined> {
    return this.apiDataService.getOne<OrderLicence>(
      environment.platformStoreStoreUrl +
        '/api/v1/Store/getOrderLicenceInformation',
      { productCatalogId: productCatalogId }
    );
  }
}
