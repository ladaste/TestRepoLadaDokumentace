import { Injectable } from '@angular/core';
import { AsolUserTenant } from '@asol-platform/authentication';
import {
  AsolApiDataService,
  AsolCollectionResultModel,
  AsolOrganization,
  AsolSubjectManagerService,
} from '@asol-platform/services';
import { OrderProposal, OrderResponse } from '@asol-platform/store';
import { Observable, catchError, map, of } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { OrderDocument } from '../../../shared/models/order-document.interface';

import { OrderSummaryData } from '../../order-detail-data/models/order-summary-data.interface';
import { ExtendUserOrganization } from '../models/extend-user-organization.interface';
import { OrderDetailData } from '../models/order-detail-data.interface';
import { UpdateOrganizationData } from '../models/update-organization-data.interface';

@Injectable()
export class OrderService {
  constructor(
    private apiDataService: AsolApiDataService,
    private subjectManagerService: AsolSubjectManagerService
  ) {}

  /**
   * load actual tenant data.
   * then return the first organization found with isTenantOwner
   * @returns ExtendUserOrganization
   */
  getTenantOwnerOrganization(): Observable<ExtendUserOrganization | undefined> {
    const observable = this.apiDataService.getOne<AsolUserTenant>(
      environment.identityManagerUrl + '/api/v1/Tenants'
    );
    return observable.pipe(
      map((actualTenant) => {
        if (!actualTenant.organizations) {
          return undefined;
        }
        const firstOrg: ExtendUserOrganization | undefined =
          actualTenant.organizations.find(
            (org: ExtendUserOrganization) => org.isTenantOwner == true
          );
        return firstOrg;
      })
    );
  }

  /**
   * load data based on actual tenant.
   * @param firstOrg - first organization found.
   * @returns - observable with organization data of tenantOwner org of the tenant.
   */
  getOrganizationsData(
    firstOrg: ExtendUserOrganization
  ): Observable<AsolOrganization | null> {
    const code = firstOrg?.code?.split('|');
    if (!code) {
      return of(null);
    }

    return this.subjectManagerService
      .getOrganizationIndentification(code[1], code[0])
      .pipe(
        catchError(() => {
          return of(null);
        })
      );
  }

  /**
   * update organization data when user change it in the order process.
   * @param organizationData - data to update.
   */
  updateOrganizationData(
    organizationData: UpdateOrganizationData
  ): Observable<void> {
    return this.apiDataService.patch(
      `${environment.platformStoreOrderUrl}/api/v1/Customer/Organization`,
      organizationData
    );
  }

  /**
   * creates order based on orderData.
   * @param orderData
   * @returns - observable with order response.
   */
  createOrder(
    orderData: OrderDetailData
  ): Observable<OrderResponse<OrderSummaryData>> {
    return this.apiDataService.create(
      `${environment.platformStoreOrderUrl}/api/v1/Order`,
      orderData
    );
  }

  /**
   * get order proposal by id.
   * @param id id of order proposal.
   * @returns observalbe with order proposal.
   */
  getOrderProposal(id: string): Observable<OrderProposal> {
    return this.apiDataService.getOne(
      `${environment.platformStoreOrderUrl}/api/v1/OrderProposal/${id}`
    );
  }

  /**
   * get current BusinessConditionFiles
   * @returns observable with loaded documents.
   */
  getDocuments(): Observable<AsolCollectionResultModel<OrderDocument>> {
    return this.apiDataService.get<OrderDocument>(
      environment.platformStoreOrderUrl + '/api/v1/BusinessConditionFiles'
    );
  }

  /**
   * get customer organization data based on tenantId.
   * @returns observable with loaded documents.
   */
  getOrganizationDataByTenantId(
    orgCountryCode: string,
    orgIndetificationNumber: string,
    tenantId: string
  ): Observable<AsolOrganization> {
    return this.apiDataService.getOne<AsolOrganization>(
      `${environment.platformStoreOrderUrl}/api/v1/Customer/Organizations/identification/${orgCountryCode}/${orgIndetificationNumber}`,
      { tenantId: tenantId }
    );
  }
}
