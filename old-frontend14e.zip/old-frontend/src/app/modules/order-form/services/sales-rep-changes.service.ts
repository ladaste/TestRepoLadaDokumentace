import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class SalesRepChangesService {
  private organizationChange = false;
  private detailsSectionChange = false;
  private priceDataChange = false;
  private staticDataChange = false;

  private onChange = new BehaviorSubject(false);
  public onChange$ = this.onChange.asObservable();

  /**
   * notify service, that organization has been changed.
   */
  organizationChanged() {
    this.organizationChange = true;
    this.onChange.next(true);
  }

  /**
   * Return information about organization being changed.
   * @returns true, if it was changed
   */
  isOrganzationChanged() {
    return this.organizationChange;
  }

  /**
   * Return information about organization being changed.
   * @returns true, if it was changed
   */
  isStaticDataChanged() {
    return this.staticDataChange;
  }

  /**
   * notify service, that static data section has been changed.
   */
  staticDataChanged() {
    this.staticDataChange = true;
    this.onChange.next(true);
  }

  /**
   * notify service, that details section has been changed.
   */
  detailsSectionChanged() {
    this.detailsSectionChange = true;
    this.onChange.next(true);
  }

  /**
   * Return information about details section being changed.
   * @returns true, if it was changed
   */
  isDetailsSectionChanged() {
    return this.detailsSectionChange;
  }

  /**
   * notify service, that price data has been changed.
   */
  priceDataChanged() {
    this.priceDataChange = true;
    this.onChange.next(true);
  }

  /**
   * Return information about price data being changed.
   * @returns true, if it was changed
   */
  isPriceDataChanged() {
    return this.priceDataChange;
  }

  /**
   * Gives information, whether salesRep has done any change.
   * @returns true, if he did.
   */
  hasSomethingChanged() {
    return (
      this.staticDataChange ||
      this.detailsSectionChange ||
      this.organizationChange ||
      this.priceDataChange
    );
  }
}
