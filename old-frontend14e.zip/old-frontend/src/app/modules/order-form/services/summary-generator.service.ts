import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import {
  AsolLocalizationService,
  AsolTranslationService,
  localize,
} from '@asol-platform/core';
import {
  AsolOrganization,
  AsolSubjectManagerService,
} from '@asol-platform/services';

import {
  AppDetailEdition,
  AsolStoreAppDetail,
  AsolStoreTypesService,
  BILLING_PERIOD,
  CustomPricePipe,
  EditionExtension,
  EditionSubscription,
  OrderProposalSubscription,
  OrderResponse,
} from '@asol-platform/store';
import { TRANS } from '../../../shared/constants/localization.constant';
import { OS_SECTION_CODE } from '../../order-detail-data/constants/order-summary-section-code.constant';
import { OS_SECTION_TYPE } from '../../order-detail-data/constants/order-summary-section-type.const';
import { OS_SECTION_VAL_CODE } from '../../order-detail-data/constants/order-summary-section-value-code.constant';
import { OS_SECTION_VALUE_TYPES } from '../../order-detail-data/constants/order-summary-section-value-type.const';
import { OrderSummaryData } from '../../order-detail-data/models/order-summary-data.interface';
import { OSSectionContent } from '../../order-detail-data/models/order-summary-section-content.interface';
import { OrderSummarySection } from '../../order-detail-data/models/order-summary-section.interface';
import { EMPTY_ORDER_RESPONSE } from '../constants/empty-order-response.const';
import { priceAdding } from '../functions/price-adding.function';
import { OrderCustomer } from '../models/order-customer.interface';
import { OrderDetailData } from '../models/order-detail-data.interface';
import { OrderPurchasingPerson } from '../models/order-purchasing-person.interface';
import { SalesRepChangesService } from './sales-rep-changes.service';
import translation from './summary-generator.translation.json';

/**
 * generates order summary for the 3rd tab of the order.
 * should be same generator as on the BE.
 */
@Injectable()
export class SummaryGeneratorService {
  /** order that is being filled */
  private order: OrderResponse<OrderSummaryData> | undefined;
  /** detail of the app that is being ordered */
  private appDetail: AsolStoreAppDetail | undefined;
  /** current space owner data */
  private spaceOwner: AsolOrganization | undefined;
  /** section with the supplier info (space owner) */
  private supplierSection: OrderSummarySection | undefined;
  /** information about tax -> section which is placed after every Payment section */
  private vatTaxInfo: OrderSummarySection | undefined;
  /** section which can be changed */
  private changeableSection: OrderSummarySection[] = [];
  /** section whith informations about legal documents, additional documents and also checkboxes */
  private legalDocumentsSection: OrderSummarySection | undefined;
  /** data about licenceProviderContent. It is in changeable section, but cannot be changed. */
  private licenceProviderContent: OSSectionContent[] = [];

  constructor(
    private trans: AsolTranslationService,
    private loc: AsolLocalizationService,
    private subjectManager: AsolSubjectManagerService,
    private typesService: AsolStoreTypesService,
    private pricePipe: CustomPricePipe,
    private salesRepChanges: SalesRepChangesService
  ) {
    this.trans.initialize(TRANS.SUMMARY_GENERATOR, translation);
  }

  /**
   * function to intialize generator -> created empty order response
   * which should be filled by data (mainly orderSummary) which will be dispalyed
   * on the last tab of the order
   * @param appDetail - detail of the application which is being ordered
   */
  public initializeOrderSummary(appDetail: AsolStoreAppDetail): void {
    if (this.spaceOwner) {
      this.initializeSupplierContent(this.spaceOwner);
    } else {
      this.subjectManager
        .getSpaceOwnerOrganization()
        .subscribe((spaceOwner) => {
          this.spaceOwner = spaceOwner;
          this.initializeSupplierContent(spaceOwner);
        });
    }
    this.appDetail = appDetail;
    this.order = EMPTY_ORDER_RESPONSE;
    if (this.order.orderSummary) {
      this.order.orderSummary.languageCode = this.loc.locale;
      this.order.orderSummary.packageName = appDetail.name;
      this.order.orderSummary.primaryCategoryName = localize(
        appDetail.category?.name,
        this.loc
      );
      this.order.orderSummary.packageCardImageFileId = appDetail.cardImageId;
      this.order.orderSummary.packageShortDescription =
        appDetail.shortDescription;
      this.order.orderSummary.version = 2;
    }

    this.vatTaxInfo = {
      orderSectionType: OS_SECTION_TYPE.ORDER_SPEC,
      orderSectionCode: OS_SECTION_CODE.TAX_INFO,
      sectionName: '',
      sectionContent: [
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.TEXT,
          orderSectionValueCode: OS_SECTION_VAL_CODE.PRICE.FINAL_TEXT,
          name: null,
          value: this.trans.get(TRANS.SUMMARY_GENERATOR, 'TextAboutVat'),
        },
      ],
    };

    this.licenceProviderContent =
      this.generateLicenceProviderContent(appDetail);
    this.legalDocumentsSection = this.generateLegalDocumentsSection(appDetail);
  }

  /**
   * initialization of the current details section. Can be changed by sales rep.
   * @returns reference to the created changeableSection
   */
  public initializeChangingDetailsSection(): OrderSummarySection[] {
    this.changeableSection = [
      {
        orderSectionType: OS_SECTION_TYPE.ORDER_SPEC,
        orderSectionCode: OS_SECTION_CODE.ORDER_DETAILS,
        sectionName: this.trans.get(TRANS.SUMMARY_GENERATOR, 'OrderDetails'),
        sectionContent: [
          {
            orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
            orderSectionValueCode: OS_SECTION_VAL_CODE.ORDER_DETAILS.TIME,
            name: this.trans.get(TRANS.SUMMARY_GENERATOR, 'OrderValidation'),
            value: this.trans.get(
              TRANS.SUMMARY_GENERATOR,
              'GrantedAuthorization'
            ),
          },
          {
            orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
            orderSectionValueCode: OS_SECTION_VAL_CODE.ORDER_DETAILS.OTHERS,
            name: this.trans.get(TRANS.SUMMARY_GENERATOR, 'OtherRestrictions'),
            value: this.trans.get(
              TRANS.SUMMARY_GENERATOR,
              'OtherRestrictionsText'
            ),
          },
          {
            orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
            orderSectionValueCode:
              OS_SECTION_VAL_CODE.ORDER_DETAILS.LEGISLATION,
            name: this.trans.get(TRANS.SUMMARY_GENERATOR, 'Legislation'),
            value: this.trans.get(TRANS.SUMMARY_GENERATOR, 'LegislationText'),
          },
        ],
      },
      ...(this.salesRepChanges.isDetailsSectionChanged()
        ? [
            {
              orderSectionType: OS_SECTION_TYPE.ORDER_SPEC,
              orderSectionCode: OS_SECTION_CODE.MORE_AGGREMENTS,
              sectionName: this.trans.get(
                TRANS.SUMMARY_GENERATOR,
                'MoreAggreements'
              ),
              sectionContent: [
                {
                  orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
                  orderSectionValueCode:
                    OS_SECTION_VAL_CODE.ORDER_DETAILS.OTHERS,
                  name: this.trans.get(
                    TRANS.SUMMARY_GENERATOR,
                    'MoreAggreements'
                  ),
                  value: '',
                },
              ],
            },
          ]
        : []),
    ];

    this.changeableSection.forEach((section) => {
      section.sectionContent.forEach((content) => {
        content.nameControl = new FormControl(content.name);
        content.valueControl = new FormControl(content.value);
      });
    });
    return this.changeableSection;
  }

  /**
   * generate final orderSummary which will be displayed on the third tab of the order
   * @param orderData - orderData user is planning selected
   * @param edition - currently selected edition
   * @param extensions - currently selected extensions
   * @returns order response for the third tab (with many empty properties.)
   */
  public productOrderResponse(
    orderData: OrderDetailData,
    edition: AppDetailEdition,
    extensions: EditionExtension[]
  ): OrderResponse<OrderSummaryData> | undefined {
    // this condition checks, whether order summary has been initialized correctly
    if (
      !this.order?.orderSummary ||
      !this.supplierSection ||
      !this.appDetail ||
      !this.vatTaxInfo ||
      !this.legalDocumentsSection
    ) {
      return undefined;
    }

    this.order.orderSummary.editionName = edition.name;

    const customerSection: OrderSummarySection = this.createCustomerSection(
      orderData.customer,
      orderData.purchasingPerson
    );

    const fixedSections = this.generateFixedDetailSection(
      edition,
      extensions,
      orderData
    );

    const priceSections = this.generatePriceSection(
      edition,
      orderData,
      extensions
    );

    const isProviderInserted = this.changeableSection[0].sectionContent.find(
      (sc) =>
        sc.orderSectionValueCode ===
        OS_SECTION_VAL_CODE.ORDER_DETAILS.LICENCE_PROVIDER
    );
    if (
      !isProviderInserted &&
      this.licenceProviderContent &&
      this.changeableSection.length
    ) {
      this.changeableSection[0].sectionContent.unshift(
        ...this.licenceProviderContent
      );
    }

    this.order.orderSummary.orderSections = [
      this.supplierSection,
      customerSection,
      ...fixedSections,
      ...priceSections,
      this.vatTaxInfo,
      ...this.changeableSection,
      this.legalDocumentsSection,
    ];
    return this.order;
  }

  /**
   * function which creates supplier section. For now, supplier is always spaceOwner.
   * @param spaceOwner loaded spaceOwner
   */
  private initializeSupplierContent(spaceOwner: AsolOrganization): void {
    this.supplierSection = {
      orderSectionType: OS_SECTION_TYPE.SUPPLIER,
      orderSectionCode: OS_SECTION_CODE.SUPPLIER,
      sectionName: this.trans.get(TRANS.SUMMARY_GENERATOR, 'Supplier'),
      sectionContent: [
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.TEXT,
          orderSectionValueCode: OS_SECTION_VAL_CODE.SUPPLIER.SUPLIER_NAME,
          name: null,
          value: spaceOwner.name,
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
          orderSectionValueCode: OS_SECTION_VAL_CODE.SUPPLIER.STREET,
          name: null,
          value: spaceOwner.addresses[0]?.line1,
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
          orderSectionValueCode: OS_SECTION_VAL_CODE.SUPPLIER.CITY,
          name: null,
          value: `${this.trans.get(TRANS.SUMMARY_GENERATOR, 'ZIP_CODE')} ${
            spaceOwner.addresses[0]?.zipCode
          } ${spaceOwner.addresses[0]?.city}`,
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
          orderSectionValueCode: OS_SECTION_VAL_CODE.SUPPLIER.COUNTRY,
          name: null,
          value: spaceOwner.addresses[0]?.countryCode,
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
          orderSectionValueCode: OS_SECTION_VAL_CODE.SUPPLIER.REGISTRATION_NO,
          name: this.trans.get(TRANS.SUMMARY_GENERATOR, 'Company_ID'),
          value: spaceOwner.organizationIdentification?.number,
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
          orderSectionValueCode: OS_SECTION_VAL_CODE.SUPPLIER.VAT_NO,
          name: this.trans.get(TRANS.SUMMARY_GENERATOR, 'VAT'),
          value: spaceOwner.vatIn,
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
          orderSectionValueCode: OS_SECTION_VAL_CODE.SUPPLIER.VAT_NO,
          name: null,
          value: this.trans.get(TRANS.SUMMARY_GENERATOR, 'Registred'),
        },
      ],
    };
  }

  /**
   * preparation of the customer section
   * @param customer - company which is ordering
   * @param person - person which is ordering
   * @returns
   */
  private createCustomerSection(
    customer: OrderCustomer,
    person: OrderPurchasingPerson
  ): OrderSummarySection {
    return {
      orderSectionType: OS_SECTION_TYPE.CUSTOMER,
      orderSectionCode: OS_SECTION_CODE.CUSTOMER,
      sectionName: this.trans.get(TRANS.SUMMARY_GENERATOR, 'Customer'),
      sectionContent: [
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.TEXT,
          orderSectionValueCode: OS_SECTION_VAL_CODE.COMPANY.COMPANY_NAME,
          name: null,
          value: customer.name,
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
          orderSectionValueCode: OS_SECTION_VAL_CODE.COMPANY.ADDRESS,
          name: null,
          value: customer.mainAddress.street,
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
          orderSectionValueCode: OS_SECTION_VAL_CODE.COMPANY.ADDRESS,
          name: null,
          value: `${this.trans.get(TRANS.SUMMARY_GENERATOR, 'ZIP_CODE')} ${
            customer.mainAddress.zipCode
          } ${customer.mainAddress.city}`,
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
          orderSectionValueCode: OS_SECTION_VAL_CODE.COMPANY.ADDRESS,
          name: null,
          value: customer.mainAddress.countryCode,
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
          orderSectionValueCode: OS_SECTION_VAL_CODE.COMPANY.REGISTRATION_NO,
          name: this.trans.get(TRANS.SUMMARY_GENERATOR, 'Company_ID'),
          value: customer.code.split('|')[0],
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
          orderSectionValueCode: OS_SECTION_VAL_CODE.COMPANY.VAT_NO,
          name: this.trans.get(TRANS.SUMMARY_GENERATOR, 'VAT'),
          value: customer.vatIn,
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
          orderSectionValueCode: OS_SECTION_VAL_CODE.COMPANY.PERSON_NAME,
          name: null,
          value: `${person.firstName} ${person.lastName}`,
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
          orderSectionValueCode: OS_SECTION_VAL_CODE.COMPANY.PERSON_PHONE,
          name: null,
          value: person.phoneNumber,
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
          orderSectionValueCode: OS_SECTION_VAL_CODE.COMPANY.PERSON_EMAIL,
          name: null,
          value: person.email,
        },
      ],
    };
  }

  /**
   * Generate licence provider section content
   * @param appDetail - detail which provides info
   * @returns
   */
  private generateLicenceProviderContent(
    appDetail: AsolStoreAppDetail | undefined
  ): OSSectionContent[] {
    if (appDetail?.licenceProvider) {
      return [
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
          orderSectionValueCode:
            OS_SECTION_VAL_CODE.ORDER_DETAILS.LICENCE_PROVIDER,
          name: this.trans.get(TRANS.SUMMARY_GENERATOR, 'LicenseProvider'),
          value: appDetail.licenceProvider,
        },
      ];
    }
    return [];
  }

  /**
   * generate template for the 3rd tab of the order, where all information should be displayed.
   * This is part with information about edition, application and extensions.
   * It also contains information payment tables.
   * @param edition - currently ordering edition
   * @param extensions - selected extensions
   * @param orderData - orderData which are going to be send to the BE
   * @returns all necessary sections.
   */
  private generateFixedDetailSection(
    edition: AppDetailEdition,
    extensions: EditionExtension[],
    orderData: OrderDetailData
  ): OrderSummarySection[] {
    if (!this.appDetail) {
      return [];
    }
    const featuresNames = edition?.features
      .map((feat) => {
        return feat.name;
      })
      .toString()
      .replace(/,/g, ', ');

    const extSections: OrderSummarySection[] = [];
    extensions?.forEach((ext) => {
      extSections.push({
        orderSectionType: OS_SECTION_TYPE.ORDER_SPEC,
        orderSectionCode: OS_SECTION_CODE.ORDER_DETAILS,
        sectionName: this.trans.get(
          TRANS.SUMMARY_GENERATOR,
          'ExtensionDetails'
        ),
        sectionContent: [
          {
            orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
            orderSectionValueCode: OS_SECTION_VAL_CODE.ORDER_DETAILS.EXT_NAME,
            name: this.trans.get(TRANS.SUMMARY_GENERATOR, 'ExtensionName'),
            value: ext.extensionName,
          },
          {
            orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
            orderSectionValueCode:
              OS_SECTION_VAL_CODE.ORDER_DETAILS.EXT_DESCRIPTION,
            name: this.trans.get(
              TRANS.SUMMARY_GENERATOR,
              'ExtensionDescription'
            ),
            value: ext.extensionDescription,
          },
        ],
      });
      extSections.push({
        orderSectionType: OS_SECTION_TYPE.PAYMENTS_TABLE,
        orderSectionCode: OS_SECTION_CODE.EXTENSION_TABLE,
        sectionName: this.trans.get(
          TRANS.SUMMARY_GENERATOR,
          'PriceSectionName'
        ),
        sectionContent: [
          ...this.getHeaderRow(),
          ...this.generatePaymentTable(
            ext.selectedSubscription,
            orderData.extensions.find((e) => e.id === ext.id)?.subscriptions ??
              [],
            ext.extensionName
          ),
        ],
      });
    });

    const orderDataSections: OrderSummarySection[] = [
      {
        orderSectionType: OS_SECTION_TYPE.ORDER_SPEC,
        orderSectionCode: OS_SECTION_CODE.ORDER_DETAILS,
        sectionName: this.trans.get(TRANS.SUMMARY_GENERATOR, 'AppDetails'),
        sectionContent: [
          {
            orderSectionValueType: OS_SECTION_VALUE_TYPES.TEXT,
            orderSectionValueCode: OS_SECTION_VAL_CODE.ORDER_DETAILS.TEXT_1,
            name: null,
            value: this.trans.get(
              TRANS.SUMMARY_GENERATOR,
              'AtTheTimeOfPayment'
            ),
          },
          {
            orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
            orderSectionValueCode: OS_SECTION_VAL_CODE.ORDER_DETAILS.SPA_NAME,
            name: this.trans.get(TRANS.SUMMARY_GENERATOR, 'ProductApp'),
            value: this.appDetail.name,
          },
          {
            orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
            orderSectionValueCode:
              OS_SECTION_VAL_CODE.ORDER_DETAILS.SPA_EDITION,
            name: this.trans.get(TRANS.SUMMARY_GENERATOR, 'ProductEdition'),
            value: edition?.name ?? '',
          },
          ...(edition?.features.length
            ? [
                {
                  orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
                  orderSectionValueCode:
                    OS_SECTION_VAL_CODE.ORDER_DETAILS.SPA_DESC,
                  name: this.trans.get(TRANS.SUMMARY_GENERATOR, 'ProductDesc'),
                  value: featuresNames ? featuresNames : '',
                },
              ]
            : []),
          {
            orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
            orderSectionValueCode: OS_SECTION_VAL_CODE.ORDER_DETAILS.ADDITIONAL,
            name: this.trans.get(
              TRANS.SUMMARY_GENERATOR,
              'AdditionalInformation'
            ),
            value: edition.description,
          },
        ],
      },
      {
        orderSectionType: OS_SECTION_TYPE.PAYMENTS_TABLE,
        orderSectionCode: OS_SECTION_CODE.EDITION_TABLE,
        sectionName: this.trans.get(
          TRANS.SUMMARY_GENERATOR,
          'PriceSectionName'
        ),
        sectionContent: [
          ...this.getHeaderRow(),
          ...this.generatePaymentTable(
            edition.selectedSubscription,
            orderData.subscriptions,
            edition.name
          ),
        ],
      },
      ...extSections,
    ];

    return orderDataSections;
  }

  /**
   * generation of the legal document section. It contains some fixed texts,
   * all documents and additionalDocuments and checkboxes.
   * @param appDetail detail of the app that is being ordered
   * @returns created section
   */
  private generateLegalDocumentsSection(
    appDetail: AsolStoreAppDetail
  ): OrderSummarySection {
    const additionalDocumentsContent: OSSectionContent[] =
      appDetail.additionalLegalDocuments
        ? [
            {
              orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
              orderSectionValueCode:
                OS_SECTION_VAL_CODE.CUSTOMER_CONSENT.ADDITIONAL_DOCUMENTS,
              name: null,
              value: JSON.stringify(appDetail.additionalLegalDocuments),
            },
          ]
        : [];

    return {
      orderSectionType: OS_SECTION_TYPE.LEGAL_DOC,
      orderSectionCode: OS_SECTION_CODE.CUSTOMER_CONSENT,
      sectionName: this.trans.get(TRANS.SUMMARY_GENERATOR, 'CustomerConsent'),
      sectionContent: [
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.TEXT,
          orderSectionValueCode: OS_SECTION_VAL_CODE.CUSTOMER_CONSENT.TEXT_1,
          name: null,
          value: this.trans.get(TRANS.SUMMARY_GENERATOR, 'BeforeBuy'),
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.TEXT,
          orderSectionValueCode: OS_SECTION_VAL_CODE.CUSTOMER_CONSENT.TEXT_2,
          name: null,
          value: this.trans.get(
            TRANS.SUMMARY_GENERATOR,
            'ContractRelationship'
          ),
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
          orderSectionValueCode: OS_SECTION_VAL_CODE.CUSTOMER_CONSENT.FRAMEWORK,
          name: this.trans.get(TRANS.SUMMARY_GENERATOR, 'ROP_SHORT'),
          value: this.trans.get(TRANS.SUMMARY_GENERATOR, 'ROP'),
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
          orderSectionValueCode: OS_SECTION_VAL_CODE.CUSTOMER_CONSENT.GENERAL,
          name: this.trans.get(TRANS.SUMMARY_GENERATOR, 'VOPZ_SHORT'),
          value: this.trans.get(TRANS.SUMMARY_GENERATOR, 'VOPZ'),
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.TEXT,
          orderSectionValueCode: OS_SECTION_VAL_CODE.CUSTOMER_CONSENT.PRIVACY,
          name: null,
          value: this.trans.get(TRANS.SUMMARY_GENERATOR, 'AggreementPersonal'),
        },
        ...additionalDocumentsContent,
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.CHECKBOX,
          orderSectionValueCode:
            OS_SECTION_VAL_CODE.CUSTOMER_CONSENT.CHECKBOX_1,
          name: this.trans.get(TRANS.SUMMARY_GENERATOR, 'FinalText'),
          value: 'False',
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.CHECKBOX,
          orderSectionValueCode:
            OS_SECTION_VAL_CODE.CUSTOMER_CONSENT.CHECKBOX_2,
          name: this.trans.get(TRANS.SUMMARY_GENERATOR, 'AgreeNews'),
          value: 'False',
        },
      ],
    };
  }

  /**
   * generate section content for the payment table based on subscriptions selected
   * @param subscritpionData array of the possibled subscriptions
   * @param subscriptions array of the selected subscriptions (in the proposal)
   * @param nameToDisplayWith name of the parent object of the subscription. (extension / edition)
   * @returns created OSSectionContent[]
   */
  private generatePaymentTable(
    selectedSubscription: EditionSubscription | undefined,
    subscriptions: OrderProposalSubscription[],
    nameToDisplayWith: string
  ): OSSectionContent[] {
    if (!subscriptions.length || !selectedSubscription) {
      return [];
    }
    const salesItems = selectedSubscription.salesItems.filter((si) =>
      subscriptions[0].salesItems.find((selected) => selected.id === si.id)
    );

    const content: OSSectionContent[] = salesItems.flatMap((si) => {
      return [
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.CELL,
          orderSectionValueCode: 'column_1',
          name: nameToDisplayWith,
          value: si.name || si.roleCode,
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.CELL,
          orderSectionValueCode: 'column_2',
          name: null,
          value: `${si.roleCount ?? ''}`,
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.CELL,
          orderSectionValueCode: 'column_3',
          name: null,
          value: this.typesService.getUnitTranslation(
            1,
            si.unitOfSaleCode,
            si.unitOfMeasureCode,
            false
          ),
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.CELL,
          orderSectionValueCode: 'column_4',
          name: this.pricePipe.transform(si.rolePrice),
          value: '',
        },
        {
          orderSectionValueType: OS_SECTION_VALUE_TYPES.BREAK,
          orderSectionValueCode: 'column_break',
          name: null,
          value: '',
        },
      ];
    });

    return content;
  }

  /**
   * provides header for each payment table
   * @returns generated OSSectionContent[]
   */
  private getHeaderRow(): OSSectionContent[] {
    return [
      {
        orderSectionValueType: OS_SECTION_VALUE_TYPES.CELL,
        orderSectionValueCode: 'column_header_1',
        name: null,
        value: this.trans.get(TRANS.SUMMARY_GENERATOR, 'HeaderName'),
      },
      {
        orderSectionValueType: OS_SECTION_VALUE_TYPES.CELL,
        orderSectionValueCode: 'column_header_2',
        name: null,
        value: this.trans.get(TRANS.SUMMARY_GENERATOR, 'HeaderCount'),
      },
      {
        orderSectionValueType: OS_SECTION_VALUE_TYPES.CELL,
        orderSectionValueCode: 'column_header_3',
        name: null,
        value: this.trans.get(TRANS.SUMMARY_GENERATOR, 'HeaderType'),
      },
      {
        orderSectionValueType: OS_SECTION_VALUE_TYPES.CELL,
        orderSectionValueCode: 'column_header_4',
        name: null,
        value: this.trans.get(TRANS.SUMMARY_GENERATOR, 'HeaderPrice'),
      },
      {
        orderSectionValueType: OS_SECTION_VALUE_TYPES.BREAK,
        orderSectionValueCode: 'column_break',
        name: null,
        value: '',
      },
    ];
  }

  /**
   * generate price section content for the 3rd tab of the order.
   * @param edition - selected edition
   * @param orderData - orderDetailData which will be send to the BE
   * @param selectedExtensions - selected extensions
   * @returns created section
   */
  private generatePriceSection(
    edition: AppDetailEdition,
    orderData: OrderDetailData,
    selectedExtensions: EditionExtension[]
  ): OrderSummarySection[] {
    const monthly: OSSectionContent[] = [];
    const yearly: OSSectionContent[] = [];
    const oneTime: OSSectionContent[] = [];
    let totalMonthly = 0;
    let totalYearly = 0;
    let totalOneTime = 0;

    if (!edition.selectedSubscription) {
      return [];
    }

    const period = this.typesService.parseBillingCode(
      edition.selectedSubscription.billingPeriodCode
    );

    const editionContents: OSSectionContent[] = this.generatePaymentTable(
      edition.selectedSubscription,
      orderData.subscriptions,
      edition.name
    );

    switch (period) {
      case BILLING_PERIOD.MONTHLY:
        totalMonthly = priceAdding(totalMonthly, edition.price ?? 0);
        monthly.push(...editionContents);
        break;
      case BILLING_PERIOD.YEARLY:
        totalYearly = priceAdding(totalYearly, edition.price ?? 0);
        yearly.push(...editionContents);
        break;
      case BILLING_PERIOD.ONE_TIME:
        totalOneTime = priceAdding(totalOneTime, edition.price ?? 0);
        oneTime.push(...editionContents);
        break;
    }

    selectedExtensions.forEach((ext) => {
      if (ext.selectedSubscription) {
        const extPeriod = this.typesService.parseBillingCode(
          ext.selectedSubscription.billingPeriodCode
        );

        const content: OSSectionContent[] = this.generatePaymentTable(
          ext.selectedSubscription,
          orderData.extensions.find((e) => ext.id === e.id)?.subscriptions ??
            [],
          ext.extensionName
        );

        switch (extPeriod) {
          case BILLING_PERIOD.MONTHLY:
            totalMonthly = priceAdding(totalMonthly, ext.price ?? 0);
            monthly.push(...content);
            break;
          case BILLING_PERIOD.YEARLY:
            totalYearly = priceAdding(totalYearly, ext.price ?? 0);
            yearly.push(...content);
            break;
          case BILLING_PERIOD.ONE_TIME:
            totalOneTime = priceAdding(totalOneTime, ext.price ?? 0);
            oneTime.push(...content);
            break;
        }
      }
    });

    return [
      ...(monthly.length
        ? [
            {
              orderSectionType: OS_SECTION_TYPE.PAYMENTS,
              orderSectionCode: OS_SECTION_CODE.MONTHLY,
              sectionName: this.trans.get(
                TRANS.SUMMARY_GENERATOR,
                'MonthlyPayment'
              ),
              sectionContent: [
                ...this.getHeaderRow(),
                ...monthly,
                {
                  orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
                  orderSectionValueCode: OS_SECTION_VAL_CODE.PAYMENT.SUM,
                  name: this.trans.get(TRANS.SUMMARY_GENERATOR, 'Total'),
                  value: `${totalMonthly}`,
                },
              ],
            },
          ]
        : []),
      ...(yearly.length
        ? [
            {
              orderSectionType: OS_SECTION_TYPE.PAYMENTS,
              orderSectionCode: OS_SECTION_CODE.YEARLY,
              sectionName: this.trans.get(
                TRANS.SUMMARY_GENERATOR,
                'YearlyPayment'
              ),
              sectionContent: [
                ...this.getHeaderRow(),
                ...yearly,
                {
                  orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
                  orderSectionValueCode: OS_SECTION_VAL_CODE.PAYMENT.SUM,
                  name: this.trans.get(TRANS.SUMMARY_GENERATOR, 'Total'),
                  value: `${totalYearly}`,
                },
              ],
            },
          ]
        : []),
      ...(oneTime.length
        ? [
            {
              orderSectionType: OS_SECTION_TYPE.PAYMENTS,
              orderSectionCode: OS_SECTION_CODE.ONE_TIME,
              sectionName: this.trans.get(
                TRANS.SUMMARY_GENERATOR,
                'OneTimePayment'
              ),
              sectionContent: [
                ...this.getHeaderRow(),
                ...oneTime,
                {
                  orderSectionValueType: OS_SECTION_VALUE_TYPES.KEY_VAL,
                  orderSectionValueCode: OS_SECTION_VAL_CODE.PAYMENT.SUM,
                  name: this.trans.get(TRANS.SUMMARY_GENERATOR, 'Total'),
                  value: `${totalOneTime}`,
                },
              ],
            },
          ]
        : []),
    ];
  }
}
