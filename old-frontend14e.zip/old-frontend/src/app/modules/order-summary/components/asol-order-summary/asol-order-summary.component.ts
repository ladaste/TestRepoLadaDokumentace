import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AsolPermission } from '@asol-platform/authentication';
import { AsolLoaderService } from '@asol-platform/controls';
import {
  ASOL_GENERAL_TRANSLATION,
  AsolLocalizationService,
  AsolTranslationService,
} from '@asol-platform/core';
import { AsolDialogMessageService } from '@asol-platform/services';
import {
  AsolOrderAccessType,
  BILLING_PERIOD,
  OrderResponse,
} from '@asol-platform/store';
import { finalize } from 'rxjs';
import { OrderFinishedDialogComponent } from '../../../../shared/components/order-finished-dialog/order-finished-dialog.component';
import { APPLICATION_CODE } from '../../../../shared/constants/application-code.constant';
import { TRANS } from '../../../../shared/constants/localization.constant';
import { NON_STANDARD_ORDER_SYSTEM_STATUS } from '../../../../shared/constants/non-standard-order-system-status.const';
import { PERMISSION } from '../../../../shared/constants/permission.constant';
import { OS_SECTION_CODE } from '../../../order-detail-data/constants/order-summary-section-code.constant';
import { OS_SECTION_VAL_CODE } from '../../../order-detail-data/constants/order-summary-section-value-code.constant';
import { CheckboxEvent } from '../../../order-detail-data/models/checkbox-event.interface';
import { OrderSummaryData } from '../../../order-detail-data/models/order-summary-data.interface';
import { APP_ROUTES } from '../../constants/app-routes.const';
import { OrderAcceptance } from '../../constants/order-acceptance.interface';
import { NonStandardOrderService } from '../../services/non-standard-order.service';
import { OrderSummaryService } from '../../services/order-summary.service';
import translation from './asol-order-summary.translation.json';

/**
 * This component is used on the route 'order-summary'
 * and it is used for customer when accepting custom order from sales person.
 */
@Component({
  selector: 'asol-platform-order-summary',
  templateUrl: './asol-order-summary.component.html',
  styleUrls: ['../../styles/general-order-summary.scss'],
  providers: [NonStandardOrderService, OrderSummaryService],
})
export class AsolOrderSummaryComponent implements OnInit {
  protected readonly TRANS = TRANS;
  protected readonly ASOL_GENERAL_TRANSLATION = ASOL_GENERAL_TRANSLATION;
  protected readonly OS_SECTION_CODE = OS_SECTION_CODE;
  protected readonly BILLING_PERIOD = BILLING_PERIOD;
  protected readonly PERMISSION = PERMISSION;
  protected readonly APPLICATION_CODE = APPLICATION_CODE;
  protected readonly AsolPermission = AsolPermission;
  protected readonly NON_STANDARD_ORDER_SYSTEM_STATUS =
    NON_STANDARD_ORDER_SYSTEM_STATUS;

  /** order information part */
  protected orderId: string | undefined;
  protected orderResponse: OrderResponse<OrderSummaryData> | undefined;
  protected orderSummary: OrderSummaryData | undefined;
  protected orderStatus: string | undefined;
  protected languageCode: string | undefined;

  /** order state information part */
  protected loading = false;
  protected isNonStandard: boolean | undefined = false;
  protected showError = false;
  protected canBeAccepted = false;

  private acceptObject: OrderAcceptance = {
    termsAndConditionsAccepted: false,
    marketingConditionsAccepted: false,
  };
  private formGroupValid = false;

  constructor(
    protected trans: AsolTranslationService,
    protected loc: AsolLocalizationService,
    private location: Location,
    private orderSummaryService: OrderSummaryService,
    private route: ActivatedRoute,
    private loader: AsolLoaderService,
    private router: Router,
    private nonStandardOrderService: NonStandardOrderService,
    private dialogMessageService: AsolDialogMessageService
  ) {
    this.trans.initialize(TRANS.ORDER_SUMMARY, translation);
  }

  ngOnInit(): void {
    this.orderId = this.route.snapshot.params.orderId;

    if (!this.orderId) {
      return;
    }
    this.loadOrder(this.orderId);
  }

  /**
   * load order by id to display it
   * @param orderId - id of order to load
   */
  private loadOrder(orderId: string) {
    this.loader.start();
    this.loading = true;
    this.orderSummaryService
      .getOrderById(orderId, AsolOrderAccessType.Customer)
      .pipe(
        finalize(() => {
          this.loader.stop();
          this.loading = false;
        })
      )
      .subscribe({
        next: (response) => {
          this.orderResponse = response;
          this.parseOrderResponse(response);
        },
      });
  }

  /**
   * Based on the order data prepare the order acceptance object (if needed)
   * If version one, then prepare the order summary object
   * @param response - order response loaded
   */
  private parseOrderResponse(response: OrderResponse) {
    this.isNonStandard = response.isNonStandard;
    this.orderStatus = response.nonStandardStatusInfo?.systemStatus;
    this.canBeAccepted =
      this.orderStatus === NON_STANDARD_ORDER_SYSTEM_STATUS.SENT_TO_CUSTOMER;

    // For version ONE orders -> when orderSummary were stringified.

    if (this.orderResponse?.orderData) {
      try {
        this.orderSummary = JSON.parse(this.orderResponse.orderData);
        this.languageCode = this.orderSummary?.languageCode;
      } catch {
        this.dialogMessageService.showErrorDialog(
          this.trans.get(TRANS.ORDER_SUMMARY, 'CorruptedData')
        );
      }
    } else {
      this.languageCode = this.orderResponse?.orderSummary?.languageCode;
    }
  }

  /**
   * reaction to the back button click - navigate back
   */
  protected back() {
    this.location.back();
  }

  /**
   * reaction to the change of the checkboxes.
   * updated the acceptObject of the checkboxes.
   */
  protected checkboxesChanged(event: CheckboxEvent) {
    this.acceptObject = {
      termsAndConditionsAccepted:
        event.value[OS_SECTION_VAL_CODE.CUSTOMER_CONSENT.CHECKBOX_1],
      marketingConditionsAccepted:
        event.value[OS_SECTION_VAL_CODE.CUSTOMER_CONSENT.CHECKBOX_2],
    };
    this.formGroupValid = event.isValid;
  }

  /**
   * Function for accepting order by customer
   */
  protected acceptOrder() {
    this.showError = true;

    if (!(this.orderId && this.formGroupValid)) {
      return;
    }
    this.loader.start();
    this.nonStandardOrderService
      .acceptOrder(this.orderId, this.acceptObject)
      .pipe(
        finalize(() => {
          this.loader.stop();
        })
      )
      .subscribe({
        next: (response) => {
          if (!response.orderNumber) {
            return;
          }
          const dialogRef = this.dialogMessageService.openDialog(
            OrderFinishedDialogComponent,
            {
              data: {
                bought: response.orderNumber,
                date: response.acceptedOn,
              },
            }
          );
          dialogRef.afterClosed().subscribe(() => {
            this.router.navigate([APP_ROUTES.MY_APPS]);
          });
        },
      });
  }

  /**
   * Function for rejecting order by customer
   */
  protected rejectOrder() {
    this.dialogMessageService
      .showInfoDialog(
        this.trans.get(TRANS.ORDER_SUMMARY, 'RejectOrder'),
        this.trans.get(TRANS.ORDER_SUMMARY, 'RejectConfirmation'),
        { primaryButtonType: 'Yes', secondaryButtonType: 'No' }
      )
      .subscribe((result) => {
        if (result !== 'Yes' || !this.orderId) {
          return;
        }
        this.loader.start();
        this.nonStandardOrderService
          .rejectOrder(this.orderId)
          .pipe(
            finalize(() => {
              this.loader.stop();
            })
          )
          .subscribe({
            next: () => {
              this.router.navigate([APP_ROUTES.SUBSCRIPTION]);
            },
          });
      });
  }
}
