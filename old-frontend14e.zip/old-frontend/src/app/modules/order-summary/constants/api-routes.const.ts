export const API_ROUTTES = {
  ORDER: 'api/v1/Order',
  MEMBERS: 'GetMembersByRole',
  RESPONSIBLE: 'SetResponsiblePerson',
  UPDATE_STATUS: 'SetStatusBySalesRep',
  ACCEPT_ORDER: 'acceptNonStandardOrder',
  REJECT_ORDER: 'rejectNonStandardOrder',
  NON_STANDARD_ORDER: 'api/v1/NonStandardOrder',
  SET_READY: 'readyToSend',
  SET_CANCEL: 'cancel',
  SEND_TO_MANAGER: 'sentToManager',
  SEND_TO_CUSTOMER: 'sentToCustomer',
  PROPOSAL: 'api/v1/OrderProposal',
};
