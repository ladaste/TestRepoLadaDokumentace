export const APP_ROUTES = {
  MY_APPS: 'store/my-apps',
  SUBSCRIPTION: 'store/subscriptions',
  ORDER_LIST: 'app/orders/list',
  ORDER_LIST_EDIT: 'edit',
};
