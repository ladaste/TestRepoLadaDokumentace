import { OS_SECTION_CODE } from '../../order-detail-data/constants/order-summary-section-code.constant';
import { OSSectionType } from '../../order-detail-data/constants/order-summary-section-type.enum';
import { OS_SECTION_VAL_CODE } from '../../order-detail-data/constants/order-summary-section-value-code.constant';

export const CUSTOM_PRICE_SECTION_TEMPLATE = {
  orderSectionType: OSSectionType.Custom,
  orderSectionCode: OS_SECTION_CODE.CUSTOM_PRICE,
  sectionName: '',
  sectionContent: [
    {
      orderSectionValueType: 1,
      orderSectionValueCode: OS_SECTION_VAL_CODE.PRICE.TEXT,
      name: null,
      value: '',
    },
  ],
};
