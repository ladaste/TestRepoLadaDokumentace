import { FormControl } from '@angular/forms';

export interface PriceSectionData {
  price?: string;
  period?: string;
  firstLine?: string;
  finalInfo?: string;
  priceControl?: FormControl;
  periodControl?: FormControl;
  changedOrder?: boolean;
  previousPrice?: string;
  previousPriceText?: string;
  balance?: string;
  balanceText?: string;
}
