export interface NonStandardOrderAccepted {
  orderId: string;
  orderNumber: string;
  acceptedOn: string;
}
