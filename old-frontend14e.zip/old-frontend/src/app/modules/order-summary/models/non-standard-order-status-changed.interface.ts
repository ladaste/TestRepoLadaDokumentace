export interface NonStandardOrderStatusChanged {
  orderId: string;
}
