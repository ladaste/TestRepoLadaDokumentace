import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AsolAuthGuard } from '@asol-platform/authentication';
import { AsolOrderSummaryComponent } from './components/asol-order-summary/asol-order-summary.component';
import { TempRoutingComponent } from './components/temp-routing/temp-routing.component';

const routes: Routes = [
  { path: '', redirectTo: 'temp', pathMatch: 'full' },
  { path: 'temp', component: TempRoutingComponent },
  {
    path: ':orderId',
    component: AsolOrderSummaryComponent,
    canActivate: [AsolAuthGuard],
    data: {
      hideSidemenu: {
        desktop: true,
      },
      permissionAppCode: 'ASOLEU-PlatformStoreOrder-AP-',
      permissionPageCode: 'store-lib-non-standard-order-confirmation',
      isSharedPage: true,
    },
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OrderSummaryRoutingModule {}
