import { NgModule } from '@angular/core';
import { AsolDialogModule } from '@asol-platform/controls';
import { SharedModule } from '../../shared/modules/shared.module';
import { StoreLibProviderModule } from '../../shared/modules/store-lib-provider.module';
import { OrderDetailDataModule } from '../order-detail-data/order-detail-data.module';
import { AsolOrderSummaryComponent } from './components/asol-order-summary/asol-order-summary.component';
import { TempRoutingComponent } from './components/temp-routing/temp-routing.component';
import { OrderSummaryRoutingModule } from './order-summary-routing.module';

@NgModule({
  declarations: [AsolOrderSummaryComponent, TempRoutingComponent],
  imports: [
    SharedModule,
    OrderSummaryRoutingModule,
    StoreLibProviderModule,
    AsolDialogModule,
    OrderDetailDataModule,
  ],

  exports: [AsolOrderSummaryComponent],
})
export class OrderSummaryModule {}
