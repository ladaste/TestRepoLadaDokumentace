import { Injectable } from '@angular/core';
import { AsolApiDataService } from '@asol-platform/services';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { API_ROUTTES } from '../constants/api-routes.const';
import { OrderAcceptance } from '../constants/order-acceptance.interface';
import { NonStandardOrderAccepted } from '../models/non-standard-order-accepted.interface';
import { NonStandardOrderStatusChanged } from '../models/non-standard-order-status-changed.interface';

@Injectable()
export class NonStandardOrderService {
  private deeplinkConfig = {
    deeplinkBaseUrl: window.location.origin,
  };

  constructor(private apiDataService: AsolApiDataService) {}

  /**
   * Accept incoming order by customer
   * @param orderId id of the order
   * @param accept acceptance of the conditions
   * @returns observable with acceptance of the order
   */
  acceptOrder(
    orderId: string,
    accept: OrderAcceptance
  ): Observable<NonStandardOrderAccepted> {
    return this.apiDataService.update(
      `${environment.platformStoreOrderUrl}/${API_ROUTTES.ORDER}/${orderId}/${API_ROUTTES.ACCEPT_ORDER}`,
      { ...this.deeplinkConfig, ...accept }
    );
  }

  /**
   * Reject incoming order by customer
   * @param orderId id of the order
   * @returns observable with status changed
   */
  rejectOrder(orderId: string): Observable<NonStandardOrderStatusChanged> {
    return this.apiDataService.update(
      `${environment.platformStoreOrderUrl}/${API_ROUTTES.ORDER}/${orderId}/${API_ROUTTES.REJECT_ORDER}`,
      this.deeplinkConfig
    );
  }
}
