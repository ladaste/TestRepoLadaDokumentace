import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'create',
    loadChildren: () =>
      import('../order-form/order-form.module').then((m) => m.OrderFormModule),
  },
  {
    path: 'summary',
    loadChildren: () =>
      import('../order-summary/order-summary.module').then(
        (m) => m.OrderSummaryModule
      ),
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OrderRoutingModule {}
