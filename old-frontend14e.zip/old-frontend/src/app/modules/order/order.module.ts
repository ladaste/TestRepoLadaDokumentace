import { NgModule } from '@angular/core';
import { OrderRoutingModule } from './order-routing.module';

@NgModule({
  imports: [OrderRoutingModule],
})
export class OrderModule {}
