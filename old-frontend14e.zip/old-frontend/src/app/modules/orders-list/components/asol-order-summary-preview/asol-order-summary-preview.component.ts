import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import {
  AsolPermission,
  AsolPermissionService,
} from '@asol-platform/authentication';
import { AsolLoaderService } from '@asol-platform/controls';
import {
  ASOL_GENERAL_TRANSLATION,
  AsolLocalizationService,
  AsolTranslationService,
} from '@asol-platform/core';
import {
  AsolDialogMessageService,
  AsolNavigationService,
} from '@asol-platform/services';
import {
  AsolCustomerPersonPickerService,
  OrderResponse,
} from '@asol-platform/store';
import {
  Observable,
  Subject,
  catchError,
  concatMap,
  finalize,
  forkJoin,
  from,
  last,
  of,
  takeUntil,
} from 'rxjs';
import { TRANS } from '../../../../shared/constants/localization.constant';
import { NON_STANDARD_ORDER_SYSTEM_STATUS } from '../../../../shared/constants/non-standard-order-system-status.const';
import { isFirstDateLater } from '../../../../shared/functions/date-comparer.function';
import { APPLICATION_CODE } from '../../constants/application-code.constant';
import { OrderCustomSystemStatusType } from '../../constants/order-custom-status.type';
import { ASOL_ORDER_SYSTEM_STATUS } from '../../constants/order-system-status.constant';
import { OrderSystemStatusType } from '../../constants/order-system-status.type';
import { PERMISSION } from '../../constants/permission.constant';
import { APP_ROUTES } from '../../models/app-routes.const';
import { OrderNote } from '../../models/order-note.interface';
import { PersonModel } from '../../models/person.model';
import { NonStandardOrderStatusService } from '../../services/non-standard-order-status.service';
import { OrderStatusChangesService } from '../../services/order-status-changes.service';
import { OrderService } from '../../services/order.service';
import { CancelOrderDialogComponent } from '../cancel-order-dialog/cancel-order-dialog.component';
import translation from './asol-order-summary-preview.translation.json';

@Component({
  selector: 'asol-platform-asol-order-summary-preview',
  templateUrl: './asol-order-summary-preview.component.html',
  styleUrls: ['./asol-order-summary-preview.component.scss'],
  providers: [
    NonStandardOrderStatusService,
    AsolCustomerPersonPickerService,
    AsolPermissionService,
    OrderStatusChangesService,
  ],
})
export class AsolOrderSummaryPreviewComponent implements OnInit {
  protected readonly TRANS = TRANS;
  protected readonly ASOL_TRANS = ASOL_GENERAL_TRANSLATION;
  protected readonly PERMISSION = PERMISSION;
  protected readonly AsolPermission = AsolPermission;
  protected readonly NON_STANDARD_ORDER_SYSTEM_STATUS =
    NON_STANDARD_ORDER_SYSTEM_STATUS;
  protected readonly ASOL_ORDER_SYSTEM_STATUS = ASOL_ORDER_SYSTEM_STATUS;
  protected readonly APPLICATION_CODE = APPLICATION_CODE;

  /** possible order statuses to choose from when updating status of the order */
  protected readonly orderStatuses = [
    {
      value: ASOL_ORDER_SYSTEM_STATUS.VALIDATION,
      disabled: false,
    },
    {
      value: ASOL_ORDER_SYSTEM_STATUS.CONFIRMED,
      disabled: false,
    },
    {
      value: ASOL_ORDER_SYSTEM_STATUS.FAIL,
      disabled: false,
    },
    {
      value: ASOL_ORDER_SYSTEM_STATUS.DONE,
      disabled: false,
    },
  ];

  private endSubject$ = new Subject<void>();

  protected orderResponse: OrderResponse | undefined;
  protected orderNote?: OrderNote | undefined;
  protected modifiedOnDisplay: string | undefined;
  protected modifiedByDisplay: string | undefined;

  /** boolean if user has permission to edit the order */
  protected readyToSendAllowEdit = false;
  /** boolean if user has permission to edit the order in the sent to manager state */
  protected sentToManagerAllowEdit = false;
  /** status of the order -> when it is nonstandard, and not yet accepted by customer */
  protected nonStandardOrderStatus: OrderCustomSystemStatusType | undefined;
  /** status of the order -> when standard or already accepted by customer */
  protected orderStatus: OrderSystemStatusType | undefined;
  /** boolean to hide / display edit form */
  protected editingInformation = false;
  /** formGroup for edit form */
  protected form = this.formBuilder.group({
    responsible: [''],
    integration: [''],
  });

  /** FormControl for the order note */
  protected noteFormControl = this.formBuilder.control('', {
    nonNullable: true,
  });
  /** boolean, true if note can be saved */
  protected isNoteContentChanged = false;
  /** previous value of the note content (last saved content) */
  protected previousNoteContent = '';

  /** sales rep options to choose from (which one will be responsible for the order) */
  protected salesReps: PersonModel[] = [];
  /** name of the current selected responsible person which should be displayed */
  protected responsiblePerson = '';

  /** id of the order */
  private orderId: string | undefined;
  /** defines color of the circle at order status */
  protected circleColor = '';

  constructor(
    protected trans: AsolTranslationService,
    protected loc: AsolLocalizationService,
    private loader: AsolLoaderService,
    private orderService: OrderService,
    private router: Router,
    private route: ActivatedRoute,
    private permissionService: AsolPermissionService,
    private personPicker: AsolCustomerPersonPickerService,
    private nonStandardOrderStatusService: NonStandardOrderStatusService,
    private dialog: MatDialog,
    private formBuilder: FormBuilder,
    private orderStatusService: OrderStatusChangesService,
    private dialogMessage: AsolDialogMessageService,
    private navigationService: AsolNavigationService
  ) {
    this.trans.initialize(TRANS.ORDER_SUMMARY_PREVIEW, translation);
  }

  ngOnInit(): void {
    this.noteFormControl.valueChanges
      .pipe(takeUntil(this.endSubject$))
      .subscribe((value) => {
        this.isNoteContentChanged = this.previousNoteContent === value;
      });

    this.route.params.subscribe((params) => {
      this.orderId = params.id;
      this.loadOrder();
    });

    this.orderStatusService.getSalesRep().subscribe((response) => {
      this.salesReps = response.map((person) => {
        return {
          ...person,
          name: `${person.firstName} ${person.lastName ?? ''}`,
        };
      });
      this.setResponsiblePerson();
    });
  }

  ngOnDestroy(): void {
    this.endSubject$.next();
    this.endSubject$.complete();
  }

  /**
   * load order data and prepare its data for displaying.
   * Also load order note and load licence connected to the order
   */
  private loadOrder() {
    if (!this.orderId) {
      return;
    }
    this.loader.start();
    forkJoin({
      order: this.orderService.getOrderByIdForSupplier(this.orderId),
      note: this.orderService.getOrderNoteByOrderId(this.orderId).pipe(
        catchError(() => {
          this.orderNote = undefined;
          this.noteFormControl.setValue('');
          return of(null);
        })
      ),
    })
      .pipe(
        finalize(() => {
          this.loader.stop();
        })
      )
      .subscribe({
        next: ({ order, note }) => {
          this.orderResponse = order;

          if (note) {
            this.orderNote = note;
            this.previousNoteContent = note.content;
            this.isNoteContentChanged = false;
            this.noteFormControl.setValue(note?.content);
          }
          this.setModifiedOnDisplay(order, note);
          this.setModifiedByDisplay(order, note);
          this.nonStandardOrderStatus = order.nonStandardStatusInfo
            ?.systemStatus as OrderCustomSystemStatusType;
          this.orderStatus = order.currentStatusInfo
            ?.systemStatus as OrderSystemStatusType;

          this.form.patchValue({
            responsible: order.responsiblePersonId,
            integration: this.orderStatus,
          });
          if (this.isIntegrationDisabled()) {
            this.form.controls['integration'].disable();
          }
          if (this.orderStatus === ASOL_ORDER_SYSTEM_STATUS.CONFIRMED) {
            this.orderStatuses[0].disabled = true;
          }
          this.setResponsiblePerson();

          this.circleColor = this.setUpCircleColor();
          this.checkEditable();
        },
      });
  }

  /**
   * update order note of the order
   * if note does not exist (noteId is undefined), create new note for the order.
   * When request is finished, update values of previousNoteContent and isNoteContentChanged
   */
  protected updateOrderNote() {
    const noteId = this.orderNote?.id;
    let request: Observable<void> | undefined;
    this.noteFormControl.disable();
    if (noteId) {
      request = this.orderService.updateOrderNote(
        noteId,
        this.noteFormControl.getRawValue()
      );
    } else if (this.orderResponse?.id) {
      request = this.orderService.createOrderNote(
        this.orderResponse?.id,
        this.noteFormControl.getRawValue()
      );
    }

    if (!request) {
      return;
    }
    request
      .pipe(
        finalize(() => {
          this.noteFormControl.enable();
        })
      )
      .subscribe(() => {
        this.previousNoteContent = this.noteFormControl.value;
        this.isNoteContentChanged = false;
        this.dialogMessage.showSimpleMessage(
          this.trans.get(TRANS.ORDER_SUMMARY_PREVIEW, 'NoteUpdated')
        );
      });
  }

  /**
   * prepare responsible person to display his name
   */
  private setResponsiblePerson() {
    if (!this.orderResponse || !this.salesReps.length) {
      return;
    }
    const id = this.orderResponse?.responsiblePersonId;
    if (!id) {
      this.responsiblePerson = '';
    }
    const person = this.salesReps.find((rep) => rep.personId === id);
    if (person) {
      this.responsiblePerson = `${person.firstName} ${person.lastName ?? ''}`;
    } else {
      this.responsiblePerson = '';
    }
  }

  /** navigate back to the order list */
  protected back() {
    this.router.navigate([APP_ROUTES.ORDER_LIST]);
  }

  /**
   * After edit button is clicked, navigate to edit page
   */
  protected navigateToEdit() {
    this.router.navigate([APP_ROUTES.ORDER_LIST, APP_ROUTES.ORDER_LIST_EDIT], {
      queryParams: { orderId: this.orderResponse?.id },
    });
  }

  /**
   * Go back from order detail to order list
   */
  private navigateToList() {
    // to reload ordersList ...   // TEMPORARY OFF
    // this.orderListService.markForReload();
    this.router.navigate([APP_ROUTES.ORDER_LIST]);
  }

  /**
   * Function used to check whether order can be edited by current user,
   * and how can it be modefied
   */
  private checkEditable() {
    // order could be editable if user has permission for STORE_NONSTANDARD_READY_TO_SEND and status is READY_TO_SEND
    // or user has permission STORE_NONSTANDARD_SENT_TO_MANAGER and status is SENT_TO_MANAGER

    this.permissionService
      .hasPermission(
        PERMISSION.READY_TO_SEND_EDIT,
        PERMISSION.ORDER_ROOT,
        AsolPermission.Execute,
        APPLICATION_CODE.ORDER
      )
      .pipe(takeUntil(this.endSubject$))
      .subscribe((readyPermission) => {
        this.readyToSendAllowEdit =
          readyPermission &&
          this.nonStandardOrderStatus ===
            NON_STANDARD_ORDER_SYSTEM_STATUS.READY_TO_SEND;
      });

    this.permissionService
      .hasPermission(
        PERMISSION.SENT_TO_MANAGER_EDIT,
        PERMISSION.ORDER_ROOT,
        AsolPermission.Execute,
        APPLICATION_CODE.ORDER
      )
      .pipe(takeUntil(this.endSubject$))
      .subscribe((sendPermission) => {
        this.sentToManagerAllowEdit =
          sendPermission &&
          this.nonStandardOrderStatus ===
            NON_STANDARD_ORDER_SYSTEM_STATUS.SENT_TO_MANAGER;
      });
  }

  /**
   * send order to the customer for acceptance
   * @param orderId id of the order
   */
  protected sendToCustomer(orderId: string) {
    this.nonStandardOrderStatusService.sendToCustomer(orderId).subscribe(() => {
      this.navigateToList();
    });
  }

  /**
   * send order to the manager for approval
   * @param orderId id of the order
   */
  protected sendToManager(orderId: string) {
    this.personPicker.pickManager().subscribe((managers) => {
      if (!managers) {
        return;
      }
      this.nonStandardOrderStatusService
        .sendToManager(
          orderId,
          managers.map((m) => {
            return m.email;
          })
        )
        .subscribe(() => {
          this.navigateToList();
        });
    });
  }

  /**
   * reject order by the manager
   * order then should be fixed and send again for approval
   * @param orderId id of the order
   */
  protected setReadyToSend(orderId: string) {
    // should have rights
    // should be in status SENT TO MANAGER
    this.nonStandardOrderStatusService.setReadyToSend(orderId).subscribe(() => {
      this.navigateToList();
    });
  }

  /**
   * based on current status of order set color of the circle (near the showed status)
   */
  private setUpCircleColor(): string {
    if (!this.orderStatus) {
      return this.orderResponse?.isNonStandard ? 'warning' : 'secondary';
    }

    switch (this.orderStatus) {
      case ASOL_ORDER_SYSTEM_STATUS.FAIL:
        return 'danger';
      case ASOL_ORDER_SYSTEM_STATUS.DONE:
        return 'success';
      case ASOL_ORDER_SYSTEM_STATUS.VALIDATION:
        return 'secondary';
      default:
        return 'warning';
    }
  }

  /**
   * opens dialog, when user wants to cancel the order
   */
  protected openCancelDialog() {
    const dialogRef = this.dialog.open(CancelOrderDialogComponent);
    const dialogSub = dialogRef.afterClosed().subscribe((result) => {
      dialogSub.unsubscribe();
      if (!result || !this.orderId) {
        return;
      }
      if (
        this.orderResponse?.isNonStandard &&
        this.nonStandardOrderStatus !==
          NON_STANDARD_ORDER_SYSTEM_STATUS.APPROVED_BY_CUSTOMER
      ) {
        this.nonStandardOrderStatusService
          .setCancel(this.orderId, result)
          .subscribe(() => {
            this.loadOrder();
          });
      } else {
        this.form.patchValue({
          integration: ASOL_ORDER_SYSTEM_STATUS.FAIL,
        });
        this.submitChanges(true, result);
      }
    });
  }

  /**
   * Saves the current changes of the order
   * @param onlyIntegration - if only integration -> status should be saved (when cancelling order for example)
   * @param note -> message which can be send with status change
   */
  protected submitChanges(onlyIntegration = false, note?: string) {
    if (!this.orderResponse) {
      return;
    }
    // first submit status, then responsible person
    this.loader.start();

    if (this.form.value.integration) {
      let statuses: string[] = [];
      const integrationValue = this.form.controls.integration.value;

      if (!this.orderStatus) {
        statuses.push(ASOL_ORDER_SYSTEM_STATUS.VALIDATION);

        if (
          integrationValue === ASOL_ORDER_SYSTEM_STATUS.CONFIRMED ||
          integrationValue === ASOL_ORDER_SYSTEM_STATUS.DONE
        ) {
          statuses.push(ASOL_ORDER_SYSTEM_STATUS.CONFIRMED);
        }

        if (integrationValue === ASOL_ORDER_SYSTEM_STATUS.DONE) {
          statuses.push(ASOL_ORDER_SYSTEM_STATUS.DONE);
        }
      } else if (
        this.orderStatus === ASOL_ORDER_SYSTEM_STATUS.VALIDATION &&
        integrationValue === ASOL_ORDER_SYSTEM_STATUS.DONE
      ) {
        statuses = [
          ASOL_ORDER_SYSTEM_STATUS.CONFIRMED,
          ASOL_ORDER_SYSTEM_STATUS.DONE,
        ];
      }

      // Check if statuses array is empty and populate it if necessary
      if (statuses.length === 0) {
        statuses = [integrationValue ?? ''];
      }

      // Convert the array of statuses into an observable sequence
      from(statuses)
        .pipe(
          concatMap((status) =>
            this.orderStatusService
              .updateStatus(this.orderResponse?.id ?? '', status, note)
              .pipe(
                catchError((error) => {
                  console.error('Error updating status:', error);
                  this.stopLoaderWhenError();
                  return of(null);
                })
              )
          ),
          last(),
          takeUntil(this.endSubject$)
        )
        .subscribe((result) => {
          if (!result) {
            return;
          }
          // Perform additional logic here based on the result if needed
          if (!onlyIntegration) {
            this.updateResponsiblePerson();
          } else {
            this.stopLoaderAndRefreshData();
          }
        });
    } else {
      if (!onlyIntegration) {
        this.updateResponsiblePerson();
      }
      this.loader.stop();
    }
  }

  /**
   * change responsible person for the order.
   */
  protected updateResponsiblePerson() {
    if (!(this.orderResponse && this.form.value.responsible)) {
      this.stopLoaderAndRefreshData();
      return;
    }
    this.orderStatusService
      .changeResponsiblePerson(
        this.orderResponse.id,
        this.form.value.responsible
      )
      .subscribe({
        next: () => {
          this.stopLoaderAndRefreshData();
        },
        error: () => {
          this.stopLoaderWhenError();
        },
      });
  }

  /**
   * stop loader and show simple message - saved
   * Also loads order again and sets editingInformation to false
   */
  private stopLoaderAndRefreshData() {
    this.loader.stop();
    this.dialogMessage.showSimpleMessage('Saved');
    this.loadOrder();
    this.editingInformation = false;
  }

  /**
   * stop loader and show error message
   * Also sets responsible person to null and integration to previous value
   */
  private stopLoaderWhenError() {
    this.form.patchValue({
      responsible: null,
      integration: this.orderStatus,
    });
    this.dialogMessage.showErrorDialog(
      this.trans.get(TRANS.ORDER_SUMMARY_PREVIEW, 'ErrorOccurred')
    );
    this.loader.stop();
  }

  /**
   * Control if the order is in status, when integration is disabled
   * Integration field is disabled, when order is in status DONE, FAIL or is non standard and is not approved by customer
   * @returns
   */
  private isIntegrationDisabled(): boolean {
    return (
      (!!this.orderResponse?.isNonStandard &&
        this.nonStandardOrderStatus !==
          NON_STANDARD_ORDER_SYSTEM_STATUS.APPROVED_BY_CUSTOMER) ||
      this.orderStatus === ASOL_ORDER_SYSTEM_STATUS.DONE ||
      this.orderStatus === ASOL_ORDER_SYSTEM_STATUS.FAIL
    );
  }

  /**
   * Show dialog with confirmation, wheter user wants to mark order as testing
   * If yes, then process the request and show it result
   */
  protected markAsTesting(): void {
    this.dialogMessage
      .showConfirmationDialog(
        this.trans.get(TRANS.ORDER_SUMMARY_PREVIEW, 'MarkAsTesting'),
        this.trans.get(TRANS.ORDER_SUMMARY_PREVIEW, 'MarkAsTestingDialogText'),
        {
          primaryButtonText: this.trans.get(
            TRANS.ORDER_SUMMARY_PREVIEW,
            'MarkAsTesting'
          ),
          secondaryButtonText: this.trans.get(
            ASOL_GENERAL_TRANSLATION,
            'Cancel'
          ),
        }
      )
      .subscribe((r) => {
        if (!r || !this.orderId) {
          return;
        }
        this.orderStatusService.markAsTesting(this.orderId).subscribe(() => {
          this.dialogMessage.showSimpleMessage(
            this.trans.get(TRANS.ORDER_SUMMARY_PREVIEW, 'MarkedAsTesting')
          );
          if (!this.orderResponse) {
            this.navigateToList();
            return;
          }
          this.orderResponse.isTesting = true;
        });
      });
  }

  /**
   * mark order as testing order and delete it.
   */
  protected deleteOrder(): void {
    this.dialogMessage
      .showConfirmationDialog(
        this.trans.get(TRANS.ORDER_SUMMARY_PREVIEW, 'DeleteOrder'),
        this.trans.get(TRANS.ORDER_SUMMARY_PREVIEW, 'DeleteOrderDialogText'),
        {
          primaryButtonText: this.trans.get(
            TRANS.ORDER_SUMMARY_PREVIEW,
            'DeleteOrder'
          ),
          secondaryButtonText: this.trans.get(
            ASOL_GENERAL_TRANSLATION,
            'Cancel'
          ),
        }
      )
      .subscribe((r) => {
        if (!r || !this.orderId) {
          return;
        }
        this.orderStatusService.deleteOrder(this.orderId).subscribe(() => {
          this.dialogMessage.showSimpleMessage(
            this.trans.get(TRANS.ORDER_SUMMARY_PREVIEW, 'OrderDeleted')
          );
          this.navigateToList();
        });
      });
  }

  /**
   * download pdf version of the order detail. (if exists)
   */
  protected downloadPDF(): void {
    if (!this.orderId) {
      return;
    }
    this.loader.start();
    if (
      this.orderResponse?.isNonStandard &&
      this.nonStandardOrderStatus !==
        NON_STANDARD_ORDER_SYSTEM_STATUS.APPROVED_BY_CUSTOMER
    ) {
      this.loader.stop();

      this.dialogMessage.showInfoDialog(
        this.trans.get(TRANS.ORDER_SUMMARY_PREVIEW, 'NotSupportedYet'),
        this.trans.get(TRANS.ORDER_SUMMARY_PREVIEW, 'NotSupportedYetText')
      );
      return;

      // TODO download draft PDF when prepared on the BE.
    }
    this.orderService
      .getOrderPdfUrl(this.orderId)
      .pipe(
        finalize(() => {
          this.loader.stop();
        })
      )
      .subscribe((res) => {
        if (!res) {
          this.dialogMessage.showErrorDialog(
            this.trans.get(TRANS.ORDER_SUMMARY_PREVIEW, 'OrderPDFUnavailbable')
          );
          return;
        }
        this.navigationService.openExternalUrl(res);
      });
  }

  /**
   * Sets the `modifiedOnDisplay` property based on the provided order and order note.
   *
   * @private
   * @param {OrderResponse<unknown>} order - The order object.
   * @param {OrderNote | null} orderNote - The order note object, or null if no order note is available.
   */
  private setModifiedOnDisplay(
    order: OrderResponse<unknown>,
    orderNote: OrderNote | null
  ): void {
    let dateToTransform = order.modifiedOn;

    if (
      orderNote &&
      orderNote.modifiedOn &&
      order.modifiedOn &&
      isFirstDateLater(
        new Date(orderNote.modifiedOn),
        new Date(order.modifiedOn)
      )
    ) {
      dateToTransform = orderNote.modifiedOn;
    }

    this.modifiedOnDisplay = dateToTransform;
  }

  /**
   * Sets the `modifiedByDisplay` property based on the provided order and order note.
   *
   * @private
   * @param {OrderResponse<unknown>} order - The order object.
   * @param {OrderNote | null} orderNote - The order note object, or null if no order note is available.
   */
  private setModifiedByDisplay(
    order: OrderResponse<unknown>,
    orderNote: OrderNote | null
  ): void {
    let modifiedBy = order.createdBy.userName;

    if (
      orderNote &&
      orderNote.modifiedOn &&
      order.modifiedOn &&
      isFirstDateLater(
        new Date(orderNote.modifiedOn),
        new Date(order.modifiedOn)
      )
    ) {
      modifiedBy = orderNote.modifiedBy;
    }
    this.modifiedByDisplay = modifiedBy;
  }
}
