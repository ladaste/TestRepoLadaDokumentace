import { Component } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import {
  AsolButtonType,
  AsolLocalizationService,
  AsolTranslationService,
} from '@asol-platform/core';
import { TRANS } from '../../../../shared/constants/localization.constant';

@Component({
  selector: 'asol-platform-cancel-order-dialog',
  templateUrl: './cancel-order-dialog.component.html',
})
export class CancelOrderDialogComponent {
  protected readonly TRANS = TRANS;

  protected reasonForm = new FormControl('');

  constructor(
    protected trans: AsolTranslationService,
    protected loc: AsolLocalizationService,
    private ref: MatDialogRef<CancelOrderDialogComponent>
  ) {}

  /**
   * reaction to btn click
   * if users confirm canceling order, return reason
   */
  protected btnClicked(event: AsolButtonType) {
    if (event === 'Ok') {
      this.ref.close(
        this.reasonForm.value ? this.reasonForm.value : 'No message'
      );
    } else {
      this.ref.close(null);
    }
  }
}
