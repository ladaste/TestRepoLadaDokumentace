import { Component, Inject } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {
  AsolButtonType,
  AsolLocalizationService,
  AsolTranslationService,
} from '@asol-platform/core';

import { TRANS } from '../../../../shared/constants/localization.constant';
import translation from './order-list-filter.dialog.translation.json';

@Component({
  selector: 'app-order-list-filter-dialog',
  templateUrl: './order-list-filter-dialog.component.html',
})
export class OrderListFilterDialogComponent {
  protected readonly TRANS = TRANS;
  protected readonly statusOptions = [
    {
      value: '',
      display: '-----',
    },
    {
      value: 'ReadyToSend',
      display: this.trans.get(TRANS.ORDERS_LIST, 'ReadyToSend'),
    },
    {
      value: 'SentToManager',
      display: this.trans.get(TRANS.ORDERS_LIST, 'SentToManager'),
    },
    {
      value: 'SentToCustomer',
      display: this.trans.get(TRANS.ORDERS_LIST, 'SentToCustomer'),
    },
    {
      value: 'ApprovedByCustomer',
      display: this.trans.get(TRANS.ORDERS_LIST, 'Ordered'),
    },
    {
      value: 'StandardOrder',
      display: this.trans.get(TRANS.ORDERS_LIST, 'StandardOrder'),
    },
  ];

  protected form = this.formBuilder.group({
    customer: [''],
    application: [''],
    edition: [''],
    status: [''],
    includeTestingOrders: [false],
    // responsiblePerson: [''],
  });

  constructor(
    private formBuilder: FormBuilder,
    private dialogRef: MatDialogRef<OrderListFilterDialogComponent>,
    protected trans: AsolTranslationService,
    protected loc: AsolLocalizationService,
    @Inject(MAT_DIALOG_DATA)
    data: { previousFilter: { [key: string]: string } }
  ) {
    this.trans.initialize(TRANS.ORDERS_LIST_FILTER_DIALOG, translation);
    this.form.patchValue(data.previousFilter);
  }

  /**
   * reaction to the close button of the filter clicked
   * @param button type of close clicked
   */
  onCloseClick(button: AsolButtonType) {
    if (button === 'Reset') {
      this.form.reset();
    } else if (button === 'Submit') {
      this.dialogRef.close(this.form.value);
    } else {
      this.dialogRef.close(null);
    }
  }
}
