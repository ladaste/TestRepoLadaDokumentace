import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {
  AsolDataToolbarEvent,
  AsolPlatformDataSource,
} from '@asol-platform/controls';
import {
  AsolLocalizationService,
  AsolTranslationService,
} from '@asol-platform/core';

import { TRANS } from '../../../../shared/constants/localization.constant';
import { ORDER_EXPORT_CONFIG } from '../../constants/order-export.constant';
import { OrdersListData } from '../../models/orders-list-data.interface';
import { OrdersListService } from '../../services/orders-list.service';
import { OrderListFilterDialogComponent } from '../order-list-filter-dialog/order-list-filter-dialog.component';
import translation from './orders-list.translation.json';

@Component({
  selector: 'app-order-list-table',
  templateUrl: './order-list-table.component.html',
})
export class OrderListTableComponent {
  protected readonly TRANS = TRANS;
  protected readonly OrderListFilterDialogComponent =
    OrderListFilterDialogComponent;
  protected readonly ordersListProvider: AsolPlatformDataSource<OrdersListData>;
  protected readonly exportConfiguration = ORDER_EXPORT_CONFIG;

  constructor(
    protected trans: AsolTranslationService,
    protected loc: AsolLocalizationService,
    private router: Router,
    private route: ActivatedRoute,
    orderListService: OrdersListService
  ) {
    this.trans.initialize(TRANS.ORDERS_LIST, translation);
    this.ordersListProvider = new AsolPlatformDataSource(orderListService);
    this.route.queryParams.subscribe((params) => {
      // for redirect for older emails
      if (params.node) {
        this.router.navigate([params.node], { relativeTo: this.route });
      }
    });
  }

  /**
   * Redirect to detail of order.
   * @param event -> dataObject of the order which detail was clicked.
   */
  protected orderClicked(event: OrdersListData) {
    const orderId = event.id;
    this.router.navigate([orderId], { relativeTo: this.route });
  }

  /**
   * Click handler for table buttons.
   * @param event
   */
  protected tableClick(event: AsolDataToolbarEvent): void {
    if (event.dataObjectProperty === 'detailString') {
      this.orderClicked(event.dataObject);
    }
  }
}
