export const API_ROUTES = {
  ORDER: 'api/v1/Order',
  MEMBERS: 'GetMembersByRole',
  RESPONSIBLE: 'SetResponsiblePerson',
  UPDATE_STATUS: 'SetStatusBySalesRep',
  NON_STANDARD_ORDER: 'api/v1/NonStandardOrder',
  SET_READY: 'readyToSend',
  SET_CANCEL: 'cancel',
  SEND_TO_MANAGER: 'sentToManager',
  SEND_TO_CUSTOMER: 'sentToCustomer',
  MARK_AS_TESTING: 'MarkAsTesting',
};
