export const APPLICATION_CODE = {
  ORDER: 'ASOLEU-PlatformStoreOrder-AP-',
};
