export type OrderCustomSystemStatusType =
  | 'ReadyToSend'
  | 'SentToManager'
  | 'SentToCustomer'
  | 'ApprovedByCustomer'
  | 'Cancel'
  | 'StandardOrder';
