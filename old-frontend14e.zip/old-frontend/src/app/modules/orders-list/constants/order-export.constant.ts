import { AsolExportConfiguration } from '@asol-platform/controls';
import { TRANS } from '../../../shared/constants/localization.constant';

export const ORDER_EXPORT_CONFIG: AsolExportConfiguration = {
  exportFileName: 'Orders list',
  exportingHeaders: [
    {
      code: 'orderNumber',
      transKey: TRANS.ORDERS_LIST,
      headerKey: 'OrderNumber',
    },
    {
      code: 'dateString',
      transKey: TRANS.ORDERS_LIST,
      headerKey: 'Created',
    },
    {
      code: 'customerName',
      transKey: TRANS.ORDERS_LIST,
      headerKey: 'Customer',
    },
    {
      code: 'customerEmail',
      transKey: TRANS.ORDERS_LIST,
      headerKey: 'Email',
    },
    {
      code: 'application',
      transKey: TRANS.ORDERS_LIST,
      headerKey: 'Application',
    },
    {
      code: 'edition',
      transKey: TRANS.ORDERS_LIST,
      headerKey: 'Edition',
    },
    {
      code: 'priceString',
      transKey: TRANS.ORDERS_LIST,
      headerKey: 'Amount',
    },
    {
      code: 'exportStatusString',
      transKey: TRANS.ORDERS_LIST,
      headerKey: 'CustomStatus',
    },
    {
      code: 'systemStatusString',
      transKey: TRANS.ORDERS_LIST,
      headerKey: 'SystemStatus',
    },
    {
      code: 'isTesting',
      transKey: TRANS.ORDERS_LIST,
      headerKey: 'TestingOrder',
    },
    {
      code: 'note',
      transKey: TRANS.ORDERS_LIST,
      headerKey: 'Note',
    },
    {
      code: 'responsiblePerson',
      transKey: TRANS.ORDERS_LIST,
      headerKey: 'ResponsiblePerson',
    },
  ],
};
