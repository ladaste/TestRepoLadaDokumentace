export const ASOL_ORDER_SYSTEM_STATUS = {
  VALIDATION: 'Validation',
  FAIL: 'Fail',
  CONFIRMED: 'Confirmed',
  DONE: 'Done',
};
