export type OrderSystemStatusType =
  | 'Validation'
  | 'Fail'
  | 'Confirmed'
  | 'Done';
