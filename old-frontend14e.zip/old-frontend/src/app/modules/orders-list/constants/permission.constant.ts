export const PERMISSION = {
  ORDER_ROOT: 'order-root',
  NONSTANDARD_ORDER: 'store-lib-non-standard-order',
  READY_TO_SEND_EDIT: 'store-lib-non-standard-order-ready-to-send-update',
  SEND_TO_MANAGER: 'store-lib-non-standard-order-send-to-manager',
  SENT_TO_MANAGER_EDIT: 'store-lib-non-standard-order-sent-to-manager-update',
  REJECT_BY_MANAGER: 'store-lib-non-standard-order-reject-by-manager',
  SEND_TO_CUSTOMER: 'store-lib-non-standard-order-send-to-customer',
  MARK_AS_TESTING: 'store-lib-order-mark-as-testing',
};
