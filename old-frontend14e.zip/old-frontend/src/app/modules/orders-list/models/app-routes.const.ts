export const APP_ROUTES = {
  ORDER_LIST: 'app/orders/list',
  ORDER_LIST_EDIT: 'edit',
};
