export interface OrderDocument {
  path: string;
  type: string;
}
