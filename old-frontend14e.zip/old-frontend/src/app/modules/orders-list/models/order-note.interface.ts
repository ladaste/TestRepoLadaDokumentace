export interface OrderNote {
  id: string;
  orderId: string;
  content: string;
  modifiedBy: string;
  modifiedOn: string;
}
