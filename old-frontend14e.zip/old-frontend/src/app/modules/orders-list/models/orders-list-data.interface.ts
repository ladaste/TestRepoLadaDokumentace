import { OrderCustomSystemStatusType } from '../constants/order-custom-status.type';
import { OrderSystemStatusType } from '../constants/order-system-status.type';
import { OrderNote } from './order-note.interface';

export interface OrdersListData {
  id: string;
  orderNumber: string;
  modifiedOn: string;
  customerName: string;
  application: string;
  edition: string;
  price: string;
  billingPeriod: string;
  status: OrderCustomSystemStatusType;
  isCustomPricing: boolean;
  isTesting: boolean;

  createdBy: string;
  createdOn: string;
  customerEmail: string;
  systemStatus: OrderSystemStatusType;
  modifiedBy: string;
  released: boolean;
  deleted: boolean;

  responsiblePerson?: string;

  // added by me for table display
  dateString?: string;
  priceString?: string;

  /**
   * status of the custom orders (before being approved by customer)
   * for export display, just status is displayed
   */
  exportStatusString?: string;
  /**
   * status of the custom orders (before being approved by customer)
   * for grid display, TEST is added if isTesting is true
   */
  gridStatusString?: string;
  /** status of the orders (after being confirmed by customer in custom order flow) */
  systemStatusString?: string;
  systemStatusClass?: string;
  detailString?: string;
  orderNote?: OrderNote;
  // when order is approved by customer, this is set
  statusChangedByCustomerDate?: string;
  createdOrApprovedByCustomerOn?: string;
  // FOR table display
  note?: string;
  lastUpdate?: string | null;
}
