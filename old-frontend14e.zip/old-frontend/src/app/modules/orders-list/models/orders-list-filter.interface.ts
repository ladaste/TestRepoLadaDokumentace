export interface OrdersListFilter {
  customer?: string;
  application?: string;
  edition?: string;
  status?: string;
  includeTestingOrders?: boolean;
  // responsiblePerson?: string;
}
