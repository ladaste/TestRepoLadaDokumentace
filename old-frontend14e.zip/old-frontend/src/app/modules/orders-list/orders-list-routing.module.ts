import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AsolAuthGuard } from '@asol-platform/authentication';
import { AsolOrderSummaryPreviewComponent } from './components/asol-order-summary-preview/asol-order-summary-preview.component';
import { OrderListTableComponent } from './components/order-list-table/order-list-table.component';

const routes: Routes = [
  { path: '', redirectTo: 'list', pathMatch: 'full' },
  {
    path: 'list',
    canActivate: [AsolAuthGuard],
    component: OrderListTableComponent,
    data: {
      permissionPageCode: 'orders-list',
      permissionAppCode: 'ASOLEU-Product-AP-',
      disableContainer: true,
    },
  },
  {
    path: 'list/:id',
    canActivate: [AsolAuthGuard],
    component: AsolOrderSummaryPreviewComponent,
    data: {
      permissionPageCode: 'orders-list',
      permissionAppCode: 'ASOLEU-Product-AP-',
    },
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OrderListRoutingModule {}
