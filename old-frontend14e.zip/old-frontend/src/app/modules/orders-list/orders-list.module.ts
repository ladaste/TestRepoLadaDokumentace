import { NgModule } from '@angular/core';
import { AsolAuthPipesModule } from '@asol-platform/authentication';
import {
  AsolDataToolbarModule,
  AsolDialogModule,
} from '@asol-platform/controls';
import { SharedModule } from '../../shared/modules/shared.module';
import { StoreLibProviderModule } from '../../shared/modules/store-lib-provider.module';
import { AsolDatePipe } from '../../shared/pipes/asol-date.pipe';
import { OrderDetailDataModule } from '../order-detail-data/order-detail-data.module';
import { AsolOrderSummaryPreviewComponent } from './components/asol-order-summary-preview/asol-order-summary-preview.component';
import { CancelOrderDialogComponent } from './components/cancel-order-dialog/cancel-order-dialog.component';
import { OrderListFilterDialogComponent } from './components/order-list-filter-dialog/order-list-filter-dialog.component';
import { OrderListTableComponent } from './components/order-list-table/order-list-table.component';
import { OrderListRoutingModule } from './orders-list-routing.module';
import { NonStandardOrderStatusService } from './services/non-standard-order-status.service';
import { NonStandardOrderService } from './services/non-standard-order.service';
import { OrderService } from './services/order.service';
import { OrdersListService } from './services/orders-list.service';

@NgModule({
  declarations: [
    OrderListTableComponent,
    OrderListFilterDialogComponent,
    CancelOrderDialogComponent,
    AsolOrderSummaryPreviewComponent,
  ],
  imports: [
    SharedModule,
    StoreLibProviderModule,
    OrderListRoutingModule,
    AsolDataToolbarModule,
    AsolDialogModule,
    OrderDetailDataModule,
    AsolAuthPipesModule,
  ],
  providers: [
    OrdersListService,
    OrderService,
    NonStandardOrderStatusService,
    NonStandardOrderService,
    AsolDatePipe,
  ],
})
export class OrdersListModule {}
