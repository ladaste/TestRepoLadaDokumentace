import { Injectable } from '@angular/core';
import { AsolLoaderService } from '@asol-platform/controls';
import { AsolTranslationService } from '@asol-platform/core';
import { AsolDialogMessageService } from '@asol-platform/services';
import { Observable } from 'rxjs';
import { finalize, map } from 'rxjs/operators';

import { TRANS } from '../../../shared/constants/localization.constant';
import { NON_STANDARD_ORDER_SYSTEM_STATUS } from '../../../shared/constants/non-standard-order-system-status.const';
import translation from '../translations/order-status-changes.translation.json';
import { NonStandardOrderService } from './non-standard-order.service';

@Injectable()
export class NonStandardOrderStatusService {
  constructor(
    private nonStandardOrderService: NonStandardOrderService,
    private loader: AsolLoaderService,
    private dialogMessageService: AsolDialogMessageService,
    private trans: AsolTranslationService
  ) {
    this.trans.initialize(TRANS.ORDER_STATUS_CHANGES, translation);
  }
  /**
   * Send order to customer for approval
   * @param orderId id of the order
   * @returns
   */
  sendToCustomer(orderId: string): Observable<string> {
    this.loader.start();
    return this.nonStandardOrderService.sendToCustomer(orderId).pipe(
      map(() => {
        this.dialogMessageService.showSimpleMessage(
          this.trans.get(TRANS.ORDER_STATUS_CHANGES, 'OrderSentToCustomer')
        );

        // return new status
        return NON_STANDARD_ORDER_SYSTEM_STATUS.SENT_TO_CUSTOMER;
      }),
      finalize(() => {
        this.loader.stop();
      })
    );
  }

  /**
   * sends order to manager, who can send it to customer
   * @param orderId id of the order
   * @param managersEmails emails of managers, who should be notfied
   * @returns
   */
  sendToManager(orderId: string, managersEmails: string[]): Observable<string> {
    this.loader.start();
    return this.nonStandardOrderService
      .sendToManager(orderId, managersEmails)
      .pipe(
        map(() => {
          this.dialogMessageService.showSimpleMessage(
            this.trans.get(TRANS.ORDER_STATUS_CHANGES, 'OrderSentToManager')
          );
          return NON_STANDARD_ORDER_SYSTEM_STATUS.SENT_TO_MANAGER;
        }),
        finalize(() => {
          this.loader.stop();
        })
      );
  }

  /**
   * Reject order by manager -> send it back to sales rep for fixing
   * @param orderId id of the order
   * @returns
   */
  setReadyToSend(orderId: string): Observable<string> {
    // should have rights
    // should be in status SENT TO MANAGER
    this.loader.start();

    return this.nonStandardOrderService.setReadyToSend(orderId).pipe(
      map(() => {
        this.dialogMessageService.showSimpleMessage(
          this.trans.get(TRANS.ORDER_STATUS_CHANGES, 'OrderRejected')
        );
        return NON_STANDARD_ORDER_SYSTEM_STATUS.READY_TO_SEND;
      }),
      finalize(() => {
        this.loader.stop();
      })
    );
  }

  /**
   * cancel nonstandard order
   * @param orderId id of the order
   * @param note message which says why is user cancelling order
   * @returns
   */
  setCancel(orderId: string, note: string): Observable<string> {
    // should have rights
    // should be in status SENT TO MANAGER
    this.loader.start();

    return this.nonStandardOrderService.setCancel(orderId, note).pipe(
      map(() => {
        this.dialogMessageService.showSimpleMessage(
          this.trans.get(TRANS.ORDER_STATUS_CHANGES, 'OrderCancelled')
        );
        return NON_STANDARD_ORDER_SYSTEM_STATUS.CANCELED;
      }),
      finalize(() => {
        this.loader.stop();
      })
    );
  }
}
