import { Injectable } from '@angular/core';
import { AsolApiDataService } from '@asol-platform/services';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { API_ROUTES } from '../constants/api-routes.constant';
import { NonStandardOrderStatusChanged } from '../models/non-standard-order-status-changed.interface';

@Injectable()
export class NonStandardOrderService {
  private deeplinkConfig = {
    deeplinkBaseUrl: window.location.origin,
  };

  constructor(private apiDataService: AsolApiDataService) {}

  /**
   * Change status of nonstandard order to ReadyToSend
   * @param orderId id of the order
   * @returns observable with status changed
   */
  setReadyToSend(orderId: string): Observable<NonStandardOrderStatusChanged> {
    return this.apiDataService.update(
      `${environment.platformStoreOrderUrl}/${API_ROUTES.NON_STANDARD_ORDER}/${orderId}/${API_ROUTES.SET_READY}`,
      this.deeplinkConfig
    );
  }

  /**
   * Change status of the order to cancelled
   * @param orderId id of the order
   * @param note message why the order is cancelled
   * @returns observable with status changed
   */
  setCancel(
    orderId: string,
    note: string
  ): Observable<NonStandardOrderStatusChanged> {
    return this.apiDataService.update(
      `${environment.platformStoreOrderUrl}/${API_ROUTES.NON_STANDARD_ORDER}/${orderId}/${API_ROUTES.SET_CANCEL}`,
      { ...this.deeplinkConfig, note }
    );
  }

  /**
   * Set status of the order to SendToManager
   * @param orderId id of the order
   * @param managersEmails
   * @returns observable with status changed
   */
  sendToManager(
    orderId: string,
    managersEmails: string[]
  ): Observable<NonStandardOrderStatusChanged> {
    return this.apiDataService.update(
      `${environment.platformStoreOrderUrl}/${API_ROUTES.NON_STANDARD_ORDER}/${orderId}/${API_ROUTES.SEND_TO_MANAGER}`,
      {
        ...this.deeplinkConfig,
        recipients: managersEmails,
      }
    );
  }

  /**
   * Set status of the order to SentToCustomer
   * @param orderId id of the order
   * @returns observable with status changed
   */
  sendToCustomer(orderId: string): Observable<NonStandardOrderStatusChanged> {
    return this.apiDataService.update(
      `${environment.platformStoreOrderUrl}/${API_ROUTES.NON_STANDARD_ORDER}/${orderId}/${API_ROUTES.SEND_TO_CUSTOMER}`,
      this.deeplinkConfig
    );
  }
}
