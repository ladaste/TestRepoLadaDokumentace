import { Injectable } from '@angular/core';
import { AsolApiDataService } from '@asol-platform/services';
import { map, Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { API_ROUTES } from '../constants/api-routes.constant';
import { PersonModel } from '../models/person.model';

@Injectable()
export class OrderStatusChangesService {
  constructor(private apiDataService: AsolApiDataService) {}

  /**
   * Request all people which have role of SalesRep
   * @returns observable of people
   */
  getSalesRep(): Observable<PersonModel[]> {
    /*
    TODO: change to API (sth like) getResponsiblePerson, which will return all users with
    one of the roles
    */
    return this.apiDataService
      .get<PersonModel>(
        `${environment.platformStoreOrderUrl}/${API_ROUTES.ORDER}/${API_ROUTES.MEMBERS}`,
        { role: 'ASOLEU-PlatformStoreOrder-AP-SalesRep' }
      )
      .pipe(
        map((response) => {
          return response.items ?? [];
        })
      );
  }

  /**
   * Update orders responsible person
   * @param orderId id of the order
   * @param personId id of the person
   * @returns Observable with response of request
   */
  changeResponsiblePerson(
    orderId: string,
    personId: string
  ): Observable<unknown> {
    return this.apiDataService.update(
      `${environment.platformStoreOrderUrl}/${API_ROUTES.ORDER}/${orderId}/${API_ROUTES.RESPONSIBLE}`,
      { id: personId }
    );
  }

  /**
   * Updated status of the order
   * @param orderId id of the order
   * @param newStatus status which should be set
   * @param message message with more information (optional)
   * @returns Observable with response of request
   */
  updateStatus(
    orderId: string,
    newStatus: string,
    message?: string
  ): Observable<unknown> {
    return this.apiDataService.create(
      `${environment.platformStoreOrderUrl}/${API_ROUTES.ORDER}/${orderId}/${API_ROUTES.UPDATE_STATUS}`,
      { systemStatus: newStatus, message: message ?? 'No message' }
    );
  }

  /**
   * delete order
   * @param orderId id of the order
   * @returns observable with the response
   */
  deleteOrder(orderId: string): Observable<void> {
    return this.apiDataService.delete(
      `${environment.platformStoreOrderUrl}/${API_ROUTES.ORDER}`,
      orderId,
      { orderAccessType: 'Supplier' }
    );
  }

  /**
   * mark order as testing
   * @param orderId id of the order
   * @returns observable with response
   */
  markAsTesting(orderId: string): Observable<void> {
    return this.apiDataService.post(
      `${environment.platformStoreOrderUrl}/${API_ROUTES.ORDER}/${orderId}/${API_ROUTES.MARK_AS_TESTING}?orderAccessType=Supplier`
    );
  }
}
