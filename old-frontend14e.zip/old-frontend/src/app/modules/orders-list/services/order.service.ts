import { Injectable } from '@angular/core';
import { AsolApiDataService } from '@asol-platform/services';
import { OrderResponse } from '@asol-platform/store';
import { Observable, map } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { OrderDocument } from '../models/order-document.interface';
import { OrderNote } from '../models/order-note.interface';

@Injectable()
export class OrderService {
  constructor(private apiDataService: AsolApiDataService) {}

  /**
   * get complete order data.
   * @param id id of the order
   * @returns
   */
  getOrderByIdForSupplier(id: string): Observable<OrderResponse> {
    return this.apiDataService.getOne(
      `${environment.platformStoreOrderUrl}/api/v1/Order/${id}`,
      { orderAccessType: 'Supplier' }
    );
  }

  /**
   * get documents of the order by calling BusinessConditionFiles and find SummaryPdf file
   * Take its path and return full URL path of the order detail pdf.
   * @param orderId id of the order
   * @returns string when file can be found. Otherwise undefined is returned.
   */
  getOrderPdfUrl(orderId: string): Observable<string | undefined> {
    return this.apiDataService
      .get<OrderDocument>(
        environment.platformStoreOrderUrl +
          `/api/v1/BusinessConditionFiles/${orderId}`,
        {
          orderAccessType: 'Supplier',
        }
      )
      .pipe(
        map((res) => {
          if (res?.items) {
            const pdfFile = res.items.find((i) => i.type === 'SummaryPdf');
            if (pdfFile) {
              return (
                environment.contentManagerUrl +
                '/api/v1/PublicFiles/Path/' +
                pdfFile.path
              );
            }
          }
          return undefined;
        })
      );
  }

  /**
   * get Order Note by Order Id
   * @param orderId - id of the order to get note for
   * @returns Observable of OrderNote
   */
  public getOrderNoteByOrderId(orderId: string): Observable<OrderNote> {
    return this.apiDataService.getOne<OrderNote>(
      `${environment.platformStoreOrderUrl}/api/v1/OrderNote/OfOrder/${orderId}`
    );
  }

  /**
   * create Order Note for the order
   * @param orderId - id of the order to create note for
   * @param content - content of the note
   * @returns Observable of the void
   */
  public createOrderNote(orderId: string, content: string): Observable<void> {
    return this.apiDataService.create(
      `${environment.platformStoreOrderUrl}/api/v1/OrderNote`,
      {
        orderId,
        content,
      }
    );
  }

  /**
   * update content of the Order Note
   * @param noteId id of the order note
   * @param content new content of the order note
   * @returns Obervable of the void
   */
  public updateOrderNote(noteId: string, content: string): Observable<void> {
    return this.apiDataService.update(
      `${environment.platformStoreOrderUrl}/api/v1/OrderNote/${noteId}`,
      { content }
    );
  }
}
