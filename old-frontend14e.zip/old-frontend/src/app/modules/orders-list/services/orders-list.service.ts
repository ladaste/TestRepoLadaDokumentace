import { Injectable } from '@angular/core';
import { AsolGridService } from '@asol-platform/controls';
import {
  AsolLocalizationService,
  AsolTranslationService,
} from '@asol-platform/core';
import {
  AsolApiDataService,
  AsolCollectionResultModel,
} from '@asol-platform/services';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

import { environment } from '../../../../environments/environment';
import { TRANS } from '../../../shared/constants/localization.constant';
import { isFirstDateLater } from '../../../shared/functions/date-comparer.function';
import { AsolDatePipe } from '../../../shared/pipes/asol-date.pipe';
import { OrdersListData } from '../models/orders-list-data.interface';
import { OrdersListFilter } from '../models/orders-list-filter.interface';

@Injectable()
export class OrdersListService implements AsolGridService<OrdersListData> {
  // TEMPORARY OFF
  // private previousResult?: AsolCollectionResultModel<OrdersListData>;
  // private previousParams?: {
  //   filter: OrdersListFilter;
  //   sortColumn: string | null;
  //   sortDirection: string | null;
  //   pageIndex: number;
  //   pageSize: number;
  // };

  constructor(
    private apiDataService: AsolApiDataService,
    private trans: AsolTranslationService,
    protected loc: AsolLocalizationService,
    private datePipe: AsolDatePipe
  ) {}

  /**
   * load data for the orders list table
   * @param filter - filter object
   * @param sortColumn - column to sort by
   * @param sortDirection - direction to sort by
   * @param pageIndex - page index
   * @param pageSize -  page size
   * @returns
   */
  loadData(
    filter: OrdersListFilter,
    sortColumn: string | null,
    sortDirection: string | null,
    pageIndex: number,
    pageSize: number
  ): Observable<AsolCollectionResultModel<OrdersListData>> {
    // TEMPORARY OFF
    // if (
    //   this.previousResult &&
    //   this.previousParams &&
    //   JSON.stringify(this.previousParams) ===
    //     JSON.stringify({
    //       filter,
    //       sortColumn,
    //       sortDirection,
    //       pageIndex,
    //       pageSize,
    //     })
    // ) {
    //   // do not load same data over and over and over....
    //   return of(this.previousResult);
    // }

    // this.previousParams = {
    //   filter,
    //   sortColumn,
    //   sortDirection,
    //   pageIndex,
    //   pageSize,
    // };

    if (sortColumn === 'dateString') {
      sortColumn = 'modifiedOn';
    }
    // filter.search
    return this.apiDataService
      .get<OrdersListData>(
        `${environment.platformStoreOrderUrl}/api/v1/Order/filteredOrders`,
        {
          ...filter,
          offset: pageIndex * pageSize,
          limit: pageSize,
          OrderAccessType: 'Supplier',
          orderASC: sortColumn && sortDirection === 'asc',
          orderBy: sortColumn,
          unreleased: true,
        }
      )
      .pipe(
        map((r) => {
          r.items.forEach((i) => {
            const createdFrom = i.createdOrApprovedByCustomerOn ?? i.createdOn;

            i.dateString =
              this.datePipe.transform(createdFrom, this.loc.locale) ?? '';

            this.setLastUpdate(i);

            i.priceString = i.isCustomPricing
              ? this.trans.get(TRANS.ORDERS_LIST, 'CustomPrice')
              : i.price + ' €';
            i.detailString = 'detail';
            i.gridStatusString =
              (i.isTesting ? 'TEST - ' : '') +
              this.trans.get(TRANS.ORDERS_LIST, i.status ?? 'Empty');

            i.exportStatusString = this.trans.get(
              TRANS.ORDERS_LIST,
              i.status ?? 'Empty'
            );

            if (i.systemStatus) {
              i.systemStatusString = this.trans.get(
                TRANS.ORDERS_LIST,
                i.systemStatus
              );
              i.systemStatusClass = this.getStatusClass(i.systemStatus);
            }

            i.note = i.orderNote?.content ?? '';
          });
          // this.previousResult = r;
          return r;
        }),
        catchError(() => {
          return of(new AsolCollectionResultModel<OrdersListData>());
        })
      );
  }

  /**
   * Method returns string with class for status
   * @param value string - status
   * @returns the status badge class
   */
  private getStatusClass(value?: string): string {
    switch (value) {
      case 'Done':
        return 'success';
      case 'Validation':
        return 'primary';
      case 'Confirmed':
        return 'warning';
      default:
        return 'danger';
    }
  }

  // TEMPORARY OFF
  /** when next loaded orders, it will be reloaded (not used cached result.) */
  // public markForReload(): void {
  //   this.previousParams = undefined;
  //   this.previousResult = undefined;
  // }

  deleteItem(item: OrdersListData): Observable<boolean> {
    throw new Error('Method not implemented.');
  }
  deleteItems(item: OrdersListData[]): Observable<boolean> {
    throw new Error('Method not implemented.');
  }

  /**
   * set last update date to the orders list item
   * @param i - orders list item
   * @returns void
   */
  private setLastUpdate(i: OrdersListData): void {
    let dateToTransform = i.modifiedOn;

    if (
      i.orderNote?.modifiedOn &&
      isFirstDateLater(new Date(i.orderNote.modifiedOn), new Date(i.modifiedOn))
    ) {
      dateToTransform = i.orderNote.modifiedOn;
    }

    i.lastUpdate = this.datePipe.transform(dateToTransform, this.loc.locale);
  }
}
