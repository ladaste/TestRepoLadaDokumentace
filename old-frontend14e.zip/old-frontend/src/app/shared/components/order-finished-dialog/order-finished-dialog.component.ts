import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import {
  AsolLocalizationService,
  AsolTranslationService,
} from '@asol-platform/core';
import { TRANS } from '../../constants/localization.constant';
import { OrderFinishedEvent } from '../../models/order-finished-event.interface';
import translation from './order-finished-dialog.translation.json';

@Component({
  selector: 'asol-platform-order-finished-dialog',
  templateUrl: './order-finished-dialog.component.html',
})
export class OrderFinishedDialogComponent {
  protected readonly TRANS = TRANS;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: OrderFinishedEvent,
    protected trans: AsolTranslationService,
    protected loc: AsolLocalizationService
  ) {
    this.trans.initialize(TRANS.ORDER_FINISHED_DIALOG, translation);
  }
}
