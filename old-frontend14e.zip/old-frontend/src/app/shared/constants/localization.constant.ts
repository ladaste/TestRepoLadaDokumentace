export const TRANS = {
  SUMMARY_GENERATOR: 'app-order-summary-generator-template',
  CANCEL_SUBSCRIPTION_PAGE: 'app-order-cancel-subscription-page',
  PRICE_DATA_DIALOG: 'app-order-price-data-dialog',
  STATIC_DATA_DIALOG: 'app-order-static-data-dialog',

  ORDER_EXTENSION_PAGE: 'app-order-extension-page',
  ORDER_PAGE: 'aps-store-order-page',
  ORDER_PAGE_DETAIL_PAGE: 'aps-store-order-page-detail-page',

  ORDER_DETAIL_DATA_COMMON: 'app-order-detail-data-common',
  ORDER_DETAIL_DATA_VERSION_ONE: 'app-order-detail-data-version-one',
  USERS_PIPE: 'app-users-pipe',
  ORDER_DETAIL_DATA_VERSION_TWO: 'app-order-detail-data-version-two',
  ORDER_DETAIL_DATA_VERSION_THREE: 'app-order-detail-data-version-three',

  ORDER_FINISHED_DIALOG: 'app-order-finished-dialog',

  ORDERS_LIST: 'app-orders-list',
  ORDERS_LIST_FILTER_DIALOG: 'app-orders-list-filter-dialog',
  ORDER_SUMMARY_PREVIEW: 'app-order-summary-preview',
  ORDER_STATUS_CHANGES: 'app-order-summary-status-changes',

  /** TODO VERIFY */
  ORDER_SUMMARY: 'app-order-summary',
};
