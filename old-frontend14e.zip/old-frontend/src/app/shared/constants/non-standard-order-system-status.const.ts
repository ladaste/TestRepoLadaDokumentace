export const NON_STANDARD_ORDER_SYSTEM_STATUS = {
  // Order ready to be send to Manager
  READY_TO_SEND: 'ReadyToSend',
  // Order sent to Manager
  SENT_TO_MANAGER: 'SentToManager',
  // Order sent to Customer
  SENT_TO_CUSTOMER: 'SentToCustomer',
  // Order accepted by Customer
  APPROVED_BY_CUSTOMER: 'Ordered',
  /// Order cancelled
  CANCELED: 'Canceled',
};
