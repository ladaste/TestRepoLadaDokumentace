export const PERMISSION = {
  ORDER_ROOT: 'order-root',
  NONSTANDARD_ORDER: 'store-lib-non-standard-order',
  CREATE_NONSTANDARD_ORDER: 'store-lib-non-standard-order-create',
  READY_TO_SEND_EDIT: 'store-lib-non-standard-order-ready-to-send-update',
  SEND_TO_MANAGER: 'store-lib-non-standard-order-send-to-manager',
  SENT_TO_MANAGER_EDIT: 'store-lib-non-standard-order-sent-to-manager-update',
  REJECT_BY_MANAGER: 'store-lib-non-standard-order-reject-by-manager',
  SEND_TO_CUSTOMER: 'store-lib-non-standard-order-send-to-customer',
  ORGANIZATION_DATA: 'store-lib-order-organization',
  EDIT_NONSTANDARD_ORDER: 'store-lib-non-standard-order-custamization-edit',
  UPDATE_NONSTANDARD_CUSTOMER_DATA:
    'store-lib-non-standard-order-customer-data-edit',

  // STANDARD_ORDER: 'store-lib-standard-order',
  // INVOICES: 'store-lib-invoices',
  // STORE_DRAFT: 'store-item-draft',
};
