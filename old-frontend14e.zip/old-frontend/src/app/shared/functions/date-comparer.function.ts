/**
 * Compares two dates and returns true if the first date is later than the second date.
 *
 * @export
 * @param date1
 * @param date2
 * @returns boolean
 */
export function isFirstDateLater(date1: Date, date2: Date): boolean {
  // Date.UTC() is used to compare dates without time
  const d1 = new Date(
    Date.UTC(date1.getFullYear(), date1.getMonth(), date1.getDate())
  );
  const d2 = new Date(
    Date.UTC(date2.getFullYear(), date2.getMonth(), date2.getDate())
  );
  return d1 > d2;
}
