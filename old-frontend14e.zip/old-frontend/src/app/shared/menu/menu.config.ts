import { Injectable } from '@angular/core';
import {
  AsolPlatformLibConfigurationProvider,
  MenuConfig,
} from '@asol-platform/common';

import { environment } from '../../../environments/environment';
import sidemenu from '../../../assets/menu/side-menu.definition.json';

@Injectable({ providedIn: 'root' })
export class ConfigFromApp implements AsolPlatformLibConfigurationProvider {
  get config(): MenuConfig {
    return {
      sideMenuDebug: environment.sideMenuDebug.toLocaleLowerCase() === 'true', // flag determining if the Menu service should load the side menu from API or local JSON, (true = local)
      topMenuDebug: false,
      sideMenuList: sidemenu,
      topMenuList: null,
    };
  }
}
