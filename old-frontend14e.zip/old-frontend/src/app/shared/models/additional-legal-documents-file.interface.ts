export interface AdditionalLegalDocumentsFile {
  fileId: string;
  isPublic: boolean;
}
