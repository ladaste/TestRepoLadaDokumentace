import { AdditionalLegalDocumentsFile } from './additional-legal-documents-file.interface';

export interface AdditionalLegalDocuments {
  prefix: string;
  hyperlinkTex: string;
  suffix: string;
  legalDocumentId: string;
  legalDocument?: AdditionalLegalDocumentsFile;
}
