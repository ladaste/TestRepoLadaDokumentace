import { OrderResponse } from '@asol-platform/store';
import { OrderSummaryData } from '../../modules/order-detail-data/models/order-summary-data.interface';

export interface LocalOrderResponse extends OrderResponse {
  orderSummary: OrderSummaryData;
}
