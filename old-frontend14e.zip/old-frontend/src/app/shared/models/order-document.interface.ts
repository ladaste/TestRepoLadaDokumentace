export interface OrderDocument {
  name: string;
  path: string;
  type: string;
  languageCode?: string;
}
