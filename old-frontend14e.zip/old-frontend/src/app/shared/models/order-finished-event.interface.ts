export interface OrderFinishedEvent {
  bought?: string;
  date?: string;
  trial?: string;
}
