import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AsolAuthPipesModule } from '@asol-platform/authentication';
import {
  AsolDialogModule,
  AsolPlatformControlsModule,
} from '@asol-platform/controls';
import { AsolLocalizeModule, AsolTranslationModule } from '@asol-platform/core';
import { CustomPricePipe } from '@asol-platform/store';
import { OrderFinishedDialogComponent } from '../components/order-finished-dialog/order-finished-dialog.component';
import { MaterialModule } from './material.module';

@NgModule({
  declarations: [OrderFinishedDialogComponent],
  imports: [
    CommonModule,
    RouterModule,
    AsolPlatformControlsModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    AsolLocalizeModule,
    AsolDialogModule,
    CustomPricePipe,
    AsolTranslationModule,
    AsolAuthPipesModule,
  ],
  exports: [
    CommonModule,
    RouterModule,
    AsolPlatformControlsModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    OrderFinishedDialogComponent,
    CustomPricePipe,
    AsolTranslationModule,
    AsolAuthPipesModule,
  ],
})
export class SharedModule {}
