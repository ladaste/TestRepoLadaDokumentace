import { CdkScrollable } from '@angular/cdk/scrolling';
import { NgModule } from '@angular/core';
import { AsolPlatformStoreModule } from '@asol-platform/store';
import { environment } from '../../../environments/environment';
import { SharedModule } from './shared.module';

/**
 * Module for providing the store library with forRoot configuration.
 * It is needed mainly for the standalone store components, which cannot directly imports the AsolPlatformStoreModule
 * with its configuration and its providers.
 */
@NgModule({
  declarations: [],
  imports: [
    SharedModule,
    AsolPlatformStoreModule.forRoot({
      contentManagerUrl: environment.contentManagerUrl,
      storeApiUrl: environment.platformStoreStoreUrl,
      customAttributesUrl: environment.customAttributesUrl,
      storeOrderUrl: environment.platformStoreOrderUrl,
      identityManagerUrl: environment.identityManagerUrl,
      portalUrl: environment.portalUrl,
      productUrl: environment.productUrl,
    }),
  ],
  exports: [AsolPlatformStoreModule],
  providers: [CdkScrollable],
})
export class StoreLibProviderModule {}
