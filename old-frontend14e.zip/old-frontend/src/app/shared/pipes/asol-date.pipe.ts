import { DatePipe } from '@angular/common';
import { Pipe, PipeTransform } from '@angular/core';

/**
 * Pipe for formatting for AVA date format strategy.
 *
 * @export
 * @class
 * @implements {PipeTransform}
 */
@Pipe({
  name: 'asolDate',
  standalone: true,
})
export class AsolDatePipe implements PipeTransform {
  transform(
    value: Date | string | number | null | undefined,
    localeLanguage: string
  ): string | null {
    const datePipe = new DatePipe('en-US');
    if (localeLanguage === 'en-US') {
      return datePipe.transform(value, 'MM/dd/yyyy');
    }
    if (localeLanguage === 'cs-CZ' || localeLanguage === 'sk-SK') {
      return datePipe.transform(value, 'dd.MM.yyyy');
    }
    return datePipe.transform(value);
  }
}
