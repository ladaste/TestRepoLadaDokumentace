// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,

  identityServerUrl: 'https://beta.avaplace.com/api/asol/idp',
  identityManagerUrl: 'https://beta.avaplace.com/api/asol/idm',
  widgetStoreUrl: 'https://beta.avaplace.com/api/asol/widgetstore',
  widgetManagementUrl:
    'https://beta.avaplace.com/api/asol/widgetstoremanagement',
  platformStorePdmUrl: 'https://beta.avaplace.com/api/asol/pdm',
  platformStoreStoreUrl: 'https://beta.avaplace.com/api/asol/store',
  platformStoreOrderUrl: 'https://beta.avaplace.com/api/asol/ord',
  messageProviderUrl: 'https://beta.avaplace.com/api/asol/mp',
  notificationAppUrl: 'https://beta.avaplace.com/apps/asol-notify',
  dataProviderUrl: 'https://beta.avaplace.com/api/asol/dataprovider',
  connectorUrl: 'https://beta.avaplace.com/api/asol/cc',
  guidanceUrl: 'https://beta.avaplace.com/api/asol/guidance',
  connectorAppUrl: 'https://beta.avaplace.com/apps/connector',
  subjectManagementUrl: 'https://beta.avaplace.com/api/asol/idmsm',
  masterSubjectManagementUrl: 'https://beta.avaplace.com/api/asol/idmsmm',
  domainCatalogUrl: 'https://beta.avaplace.com/api/asol/dcat',
  communityUrl: 'https://beta.avaplace.com/api/asol/cmnt',
  contentManagerUrl: 'https://beta.avaplace.com/api/asol/cnt',
  captchaKey: '6Lc0bkUaAAAAAJWcwr9o-rtElRjwurcgTQH7ZUkt',
  telemetryKey: '3dcb720c-e4bd-4028-8d40-755f89a1c757',
  telemetryUrl: 'https://beta.avaplace.com/api/asol/tmg',
  hcmUrl: 'https://beta.avaplace.com/api/asol/hcm',
  customAttributesUrl: 'https://beta.avaplace.com/api/asol/cuatt',
  portalUrl: 'https://beta.avaplace.com/apps/portal',
  productUrl: 'https://beta.avaplace.com/apps/product',
  idmAppUrl: 'https://beta.avaplace.com/apps/idm-app',

  sideMenuDebug: 'true',
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
