// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
// import { version } from '../../package.json';
// import { name } from '../../package.json';
import config from '../assets/appsettings.json';

export const environment = {
  production: false,

  BASE_URL: document.getElementsByTagName('base')[0].href,

  identityServerUrl: config.IdentityServer_URL,
  identityManagerUrl: config.IdentityManager_URL,
  widgetStoreUrl: config.WidgetStore_URL,
  widgetManagementUrl: config.WidgetManagement_URL,
  auditManagementUrl: config.AuditManagement_URL,
  platformStorePdmUrl: config.PlatformStorePdm_URL,
  platformStoreStoreUrl: config.PlatformStoreStore_URL,
  platformStoreOrderUrl: config.PlatformStoreOrder_URL,
  auditingUrl: config.Auditing_URL,
  messageProviderUrl: config.MessageProvider_Url,
  notificationAppUrl: config.NotificationApp_Url,
  connectorAppUrl: config.ConnectorApp_Url,
  dataProviderUrl: config.DataProvider_Url,
  connectorUrl: config.Connector_Url,
  guidanceUrl: config.Guidance_Url,
  subjectManagementUrl: config.SubjectManagement_Url,
  domainCatalogUrl: config.DomainCatalog_Url,
  communityUrl: config.Community_Url,
  contentManagerUrl: config.ContentManager_Url,
  captchaKey: config.CaptchaKey,
  telemetryKey: config.TelemetryKey,
  telemetryUrl: config.Telemetry_Url,
  hcmUrl: config.Hcm_Url,
  customAttributesUrl: config.CustomAttributes_Url,
  portalUrl: config.PortalApp_Url,
  productUrl: config.Product_Url,
  idmAppUrl: config.IdmApp_URL,

  sideMenuDebug: config.sideMenuDebug,
};
