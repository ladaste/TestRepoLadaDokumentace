// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,

  identityServerUrl: 'https://alpha.avaplace.com/api/asol/idp',
  identityManagerUrl: 'https://alpha.avaplace.com/api/asol/idm',
  widgetStoreUrl: 'https://alpha.avaplace.com/api/asol/widgetstore',
  widgetManagementUrl:
    'https://alpha.avaplace.com/api/asol/widgetstoremanagement',
  platformStorePdmUrl: 'https://alpha.avaplace.com/api/asol/pdm',
  platformStoreStoreUrl: 'https://alpha.avaplace.com/api/asol/store',
  platformStoreOrderUrl: 'https://alpha.avaplace.com/api/asol/ord',
  messageProviderUrl: 'https://alpha.avaplace.com/api/asol/mp',
  notificationAppUrl: 'https://alpha.avaplace.com/apps/asol-notify',
  dataProviderUrl: 'https://alpha.avaplace.com/api/asol/dataprovider',
  connectorUrl: 'https://alpha.avaplace.com/api/asol/cc',
  guidanceUrl: 'https://alpha.avaplace.com/api/asol/guidance',
  connectorAppUrl: 'https://alpha.avaplace.com/apps/connector',
  subjectManagementUrl: 'https://alpha.avaplace.com/api/asol/idmsm',
  masterSubjectManagementUrl: 'https://alpha.avaplace.com/api/asol/idmsmm',
  domainCatalogUrl: 'https://alpha.avaplace.com/api/asol/dcat',
  communityUrl: 'https://alpha.avaplace.com/api/asol/cmnt',
  contentManagerUrl: 'https://alpha.avaplace.com/api/asol/cnt',
  captchaKey: '6Lc0bkUaAAAAAJWcwr9o-rtElRjwurcgTQH7ZUkt',
  telemetryKey: '3dcb720c-e4bd-4028-8d40-755f89a1c757',
  telemetryUrl: 'https://alpha.avaplace.com/api/asol/tmg',
  hcmUrl: 'https://alpha.avaplace.com/api/asol/hcm',
  customAttributesUrl: 'https://alpha.avaplace.com/api/asol/cuatt',
  portalUrl: 'https://alpha.avaplace.com/apps/portal',
  productUrl: 'https://alpha.avaplace.com/apps/product',
  idmAppUrl: 'https://alpha.avaplace.com/apps/idm-app',

  sideMenuDebug: 'true',
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
