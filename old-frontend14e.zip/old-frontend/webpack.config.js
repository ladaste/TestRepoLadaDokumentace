/* eslint-disable @typescript-eslint/no-var-requires */
const {
  withModuleFederationPlugin,
  share,
} = require('@angular-architects/module-federation/webpack');

module.exports = withModuleFederationPlugin({
  name: 'order',
  exposes: {
    './Order': './src/app/modules/order/order.module.ts',
    './OrdersList': './src/app/modules/orders-list/orders-list.module.ts',
    './CustomerOrderSummary':
      './src/app/modules/customer-order-summary/customer-order-summary.component.ts',
  },
  shared: share({
    '@angular/core': {
      singleton: true,
      strictVersion: true,
      requiredVersion: '>=14.1.1',
    },
    '@angular/common': {
      singleton: true,
      strictVersion: true,
      requiredVersion: '>=14.1.1',
    },
    '@angular/router': {
      singleton: true,
      strictVersion: true,
      requiredVersion: '>=14.1.1',
    },
    '@angular/material': {
      singleton: true,
      strictVersion: true,
      requiredVersion: '>=14.1.1',
    },
    '@angular/forms': {
      singleton: true,
      strictVersion: true,
      requiredVersion: '>=14.1.1',
    },
    'ngx-toastr': {
      singleton: true,
      strictVersion: true,
      requiredVersion: '>=15.0.0',
    },
    '@asol-platform/authentication': {
      singleton: true,
      strictVersion: true,
      requiredVersion: '>=14.3.7',
    },
    '@asol-platform/services': {
      singleton: true,
      strictVersion: true,
      requiredVersion: '>=14.3.3',
    },
    '@asol-platform/guidance': {
      singleton: true,
      strictVersion: true,
      requiredVersion: '>=14.3.0',
    },
    '@asol-platform/core': {
      singleton: true,
      strictVersion: true,
      requiredVersion: '>=14.3.3',
    },
    '@asol-platform/controls': {
      singleton: true,
      strictVersion: true,
      requiredVersion: '>=14.3.20',
    },
    '@asol-platform/common': {
      singleton: true,
      strictVersion: true,
      requiredVersion: '>=14.3.5',
    },
  }),
});
